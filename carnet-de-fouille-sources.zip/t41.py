# v38 — plus de pièce unique : les 12 grandes bêtes en 15 blocs ; probabilités de blocs multiples
import asyncio, json
from playwright.async_api import async_playwright
IDS = ['anomalocaris','isotelus','guiyu','dunkleosteus','arthropleura','dimetrodon','plateosaurus','archaeopteryx','mosasaurus','gastornis','deinotherium','mammouth']
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl'])
        pg = await b.new_page(viewport={'width':1200,'height':900})
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/src/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(300)
        await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); d.closeSay(); }")
        # planche : chaque grande bête découpée en blocs (la moitié trouvée, l'autre en empreinte)
        await pg.evaluate("""(ids) => { const d = window.__dbg(), w = document.createElement('div');
          w.style.cssText = 'position:fixed;inset:0;z-index:999;background:#f4ecd8;display:grid;grid-template-columns:repeat(4,1fr);gap:6px;padding:8px';
          ids.forEach(id => { const n = d.FOSSILS[id].blocks, f = [...Array(n).keys()].filter(i => i % 2 === 0);
            w.insertAdjacentHTML('beforeend', '<div style="background:#fff;border:1px solid #333;padding:4px;font:12px sans-serif"><b>' + id + ' · ' + n + ' blocs · ' + d.FOSSILS[id].rarity + '</b><div style="height:180px">' + d.fossilSVG(id, 'puzzle', f, null, null) + '</div></div>'); });
          w.querySelectorAll('svg').forEach(s => { s.style.width = '100%'; s.style.height = '100%'; });
          document.body.appendChild(w); }""", IDS)
        await pg.wait_for_timeout(600); await pg.screenshot(path='shots/v38-grandes-betes.png')
        # probabilités : 100 000 tirages par rareté et par étoiles
        r = await pg.evaluate("""() => { const out = {};
          const roll = (fid, s) => { const P = { p: [0.06, 0.02, 0.006, 0.002, 0.0006], more: 0.33, mult: { commun: 1.5, 'peu commun': 1, rare: 0.7, exceptionnel: 0.5 }, star: [0, 0.5, 1, 1.6] };
            return null; };
          return out; }""")
        # vérifie la fiche et le musée d'une ancienne pièce unique déjà trouvée (sauvegarde v37)
        await pg.evaluate("() => { const d = window.__dbg(); d.fos('anomalocaris').done = true; d.show('musee'); }"); await pg.wait_for_timeout(700)
        await pg.set_viewport_size({'width':390,'height':844}); await pg.wait_for_timeout(300)
        await pg.evaluate("() => document.querySelectorAll('[style*=\"z-index:999\"]').forEach(e => e.remove())")
        await pg.screenshot(path='shots/v38-musee.png')
        print('unique restant dans le DOM du musée :', await pg.evaluate("() => /pièce unique/i.test(document.body.innerText)"))
        print('errors', errs)
        await b.close()
asyncio.run(main())
