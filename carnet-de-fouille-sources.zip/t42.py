# v40 — tutoriel sur écran court (visionneuse de l'app) : bulle entière, pas de barre d'onglets
import asyncio
from playwright.async_api import async_playwright
async def run(b, w, h):
    pg = await b.new_page(viewport={'width':w,'height':h})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    await pg.route('**/fonts.*/**', lambda r: r.abort())
    await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
    await pg.goto('file:///home/claude/src/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
    await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(900)
    await pg.evaluate("() => { const D = window.__dbg().Bench3D.debug(), pl = D.ST.planes[0]; D.tap(pl.contour.pts[D.hotIndex(pl)]); D.strike(pl.contour.pts[0], 0.95); }"); await pg.wait_for_timeout(400)
    r = await pg.evaluate("""() => { const app = document.getElementById('app').getBoundingClientRect(), c = document.querySelector('.tuto-coach').getBoundingClientRect(), st = document.getElementById('stage').getBoundingClientRect(), t = document.querySelector('.tuto-coach .ky-text');
      return { tabs: getComputedStyle(document.querySelector('.tabs')).display, coachBottom: Math.round(c.bottom), appBottom: Math.round(app.bottom), stageH: Math.round(st.height), textFits: t.scrollHeight <= t.clientHeight + 1 }; }""")
    print(w, h, r, 'bulle entière', r['coachBottom'] <= r['appBottom'])
    await pg.screenshot(path=f'shots/tuto/court-{w}x{h}.png')
    await pg.evaluate("() => window.__dbg().tutoFinish()"); await pg.wait_for_timeout(400)
    print('  onglets revenus', await pg.evaluate("() => getComputedStyle(document.querySelector('.tabs')).display"), errs)
    await pg.close()
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl'])
        for w, h in [(360, 560), (360, 520), (375, 667), (390, 844)]: await run(b, w, h)
        await b.close()
asyncio.run(main())
