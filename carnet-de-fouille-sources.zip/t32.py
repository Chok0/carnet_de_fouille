import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        for dpr in [1, 2.75]:
            ctx = await b.new_context(viewport={'width':390,'height':844}, device_scale_factor=dpr, has_touch=True, is_mobile=True)
            pg = await ctx.new_page()
            await pg.route('**/fonts.*/**', lambda r: r.abort())
            await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
            await pg.goto('file:///home/claude/carnet/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
            await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(300)
            await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); }"); await pg.wait_for_timeout(200)
            await pg.evaluate("() => { const d = window.__dbg(); d.closeSay(); ['pierre','creux','sourd','massive'].forEach(n => d.G.notes[n] = 1); const S = d.G.site, p = S.poches[0]; d.dig({x: p.x, y: p.y}); }")
            await pg.wait_for_timeout(900); await pg.evaluate("() => window.__dbg().show('etabli')"); await pg.wait_for_timeout(1500)
            r = await pg.evaluate("""async () => {
              const cv = document.querySelector('.b3-gl'), R = cv.getBoundingClientRect();
              // bord bas de la pierre sur la colonne centrale
              const x = R.left + R.width / 2;
              const ev = (t, X, Y) => cv.dispatchEvent(new PointerEvent(t, { pointerId: 9, pointerType: 'touch', clientX: X, clientY: Y, bubbles: true }));
              const lens = [...document.querySelectorAll('canvas')].find(c => getComputedStyle(c).position === 'fixed');
              const out = [];
              for (const fy of [R.top + R.height * 0.5, R.top + R.height * 0.6]) {
                ev('pointerdown', x, fy); await new Promise(r => setTimeout(r, 450));
                // profil vertical : lentille (colonne centrale) vs écran (GL) autour du doigt
                const lc = lens.getContext('2d'), L = lens.width, col = lc.getImageData(L / 2, 0, 1, L).data;
                const tmp = document.createElement('canvas'); tmp.width = cv.width; tmp.height = cv.height; tmp.getContext('2d').drawImage(cv, 0, 0);
                const gk = cv.width / cv.clientWidth, sc = tmp.getContext('2d').getImageData(Math.round((x - R.left) * gk), 0, 1, cv.height).data;
                const alphaL = [], alphaS = [];
                for (let i = 0; i < L; i++) alphaL.push(col[i * 4 + 1]);
                // la lentille montre 88 px css (half = L/3 css) autour du centre
                const half = 132 / 3, best = { off: 0, err: 1e18 };
                for (let off = -120; off <= 120; off += 2) {
                  let e = 0;
                  for (let i = 0; i < L; i += 3) { const yCss = (fy - R.top) + off + (i / L * 2 - 1) * half; const yy = Math.round(yCss * gk); if (yy < 0 || yy >= cv.height) { e += 1e4; continue; } const a = sc[yy * 4 + 3]; const gl = a > 10 ? sc[yy * 4 + 1] : -1; if (gl < 0) continue; e += (gl - alphaL[i]) ** 2; }
                  if (e < best.err) { best.err = e; best.off = off; }
                }
                out.push({ fy: Math.round(fy), bestOffsetCss: best.off });
                ev('pointercancel', x, fy); await new Promise(r => setTimeout(r, 200));
              }
              return out; }""")
            print('dpr', dpr, r)
            await ctx.close()
        await b.close()
asyncio.run(main())
