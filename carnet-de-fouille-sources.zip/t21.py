import asyncio, sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':390,'height':844}, device_scale_factor=1)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)+' '+str(e.stack)[:300]))
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/carnet/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(300)
        await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); }"); await pg.wait_for_timeout(200)
        ev = lambda js: pg.evaluate(js)
        await ev("() => { const d = window.__dbg(); d.closeSay(); }")
        print('tabs', await ev("() => [...document.querySelectorAll('.tab')].filter(t => !t.hidden).length"), 'digs', await ev("() => window.__dbg().digsLeft()"))
        await ev("() => { const d = window.__dbg(), S = d.G.site; d.dig({x: 20, y: 20}); d.G.stone = null; d.endStone(); d.dig({x: 540, y: 540}); d.G.stone = null; d.endStone(); }"); await pg.wait_for_timeout(900); await ev("() => { const d = window.__dbg(); d.closeSay(); d.show('carte'); }"); await pg.wait_for_timeout(300)
        await pg.click('#eyeBtn', force=True); await pg.wait_for_timeout(300)
        print('glass on', await ev("() => [window.__dbg().G.site.glass, document.getElementById('eyeBtn').getAttribute('aria-pressed'), document.getElementById('eyeBtn').style.getPropertyValue('--g')]"))
        await pg.wait_for_timeout(2500)
        print('glass off', await ev("() => document.getElementById('eyeBtn').getAttribute('aria-pressed')"))
        await ev("() => { const d = window.__dbg(), p = d.G.site.poches[0]; d.G.notes.pierre = 1; d.dig({x: p.x, y: p.y}); }"); await pg.wait_for_timeout(1500)
        await ev("""() => { const D = window.__dbg().Bench3D.debug(), V={unique:4,os:3,eclat:2,veine:1,rien:0}; const pl = D.ST.planes.slice().sort((a,b)=>V[b.C.type]-V[a.C.type])[0]; const pts = pl.contour.pts.slice().sort((a,b)=>D.distToContent(pl,a)-D.distToContent(pl,b)); D.strike(pts[Math.floor(pts.length*0.15)], 1); }""")
        await pg.wait_for_timeout(2500)
        print('res', await ev("() => [document.getElementById('rTitle').textContent, document.getElementById('rSub').textContent]"))
        await ev("() => window.__dbg().show('etabli')"); 
        print(errs)
        await b.close()
asyncio.run(main())
