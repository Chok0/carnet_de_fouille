import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':390,'height':844}, device_scale_factor=2)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)+' '+str(e.stack)[:300]))
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/carnet/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(300)
        await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); }"); await pg.wait_for_timeout(200)
        await pg.evaluate("() => { const d = window.__dbg(); d.closeSay(); d.show('carte'); }"); await pg.wait_for_timeout(500)
        r = await pg.locator('#mapBox').bounding_box()
        x, y = r['x'] + r['width']*0.5, r['y'] + r['height']*0.55
        await pg.mouse.click(x, y)
        for i, t in enumerate([100, 90, 120, 90, 110]):
            await pg.wait_for_timeout(t)
            await pg.screenshot(path=f'shots/v14/shovel{i}.png', clip={'x': x-90, 'y': y-120, 'width': 180, 'height': 170})
        await pg.wait_for_timeout(800)
        await pg.evaluate("() => { const d = window.__dbg(); d.G.stone = null; d.endStone(); d.closeSay(); d.show('carte'); }"); await pg.wait_for_timeout(400)
        await pg.evaluate("() => document.getElementById('siteGauge').scrollIntoView({block:'center'})"); await pg.wait_for_timeout(200); gb = await pg.locator('#siteGauge').bounding_box(); print('gb', gb); await pg.screenshot(path='shots/v14/gauge.png', clip={'x': 0, 'y': gb['y']-10, 'width': 390, 'height': gb['height']+20})
        print('holes', await pg.evaluate("() => window.__dbg().G.site.holes.length"), errs)
        await pg.evaluate("() => { const d = window.__dbg(); d.glassOn && d.glassOn(); }"); await pg.wait_for_timeout(700)
        bb = await pg.locator('#eyeBtn').bounding_box()
        await pg.screenshot(path='shots/v14/ring.png', clip={'x': bb['x']-20, 'y': bb['y']-20, 'width': bb['width']+40, 'height': bb['height']+40})
        await b.close()
asyncio.run(main())
