import asyncio
from playwright.async_api import async_playwright
JS = r"""async () => {
  const d = window.__dbg(), bad = [], ids = Object.keys(d.FOSSILS).filter(f => d.FOSSILS[f].kind === 'frag');
  const inP = (x, y, P) => { let c = false; for (let a = 0, b = P.length - 1; a < P.length; b = a++) if ((P[a][1] > y) !== (P[b][1] > y) && x < (P[b][0] - P[a][0]) * (y - P[a][1]) / (P[b][1] - P[a][1]) + P[a][0]) c = !c; return c; };
  let minShare = 1, worst = '';
  for (const id of ids) {
    const A = d.ART[id], [vw, vh] = A.vb, k = 200 / Math.max(vw, vh);
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + vw + ' ' + vh + '" width="' + Math.round(vw * k) + '" height="' + Math.round(vh * k) + '"><g>' + A.fn(d.FPAL[d.FOSSILS[id].epoch]) + '</g></svg>';
    const img = new Image(); img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg); await new Promise(r => { img.onload = r; img.onerror = r; });
    const W = Math.round(vw * k), H = Math.round(vh * k), c = document.createElement('canvas'); c.width = W; c.height = H; const cx = c.getContext('2d'); cx.drawImage(img, 0, 0);
    const px = cx.getImageData(0, 0, W, H).data, cells = d.fossilSVG && window.__cells ? null : null;
    const B = d.blocksOf(id), cnt = B.cells.map(() => 0); let tot = 0;
    for (let y = 0; y < H; y += 2) for (let x = 0; x < W; x += 2) if (px[(y * W + x) * 4 + 3] > 60) { tot++; const X = x / k, Y = y / k; const i = B.cells.findIndex(P => inP(X, Y, P)); if (i >= 0) cnt[i]++; }
    const share = Math.min(...cnt) / (tot / cnt.length);
    if (share < minShare) { minShare = share; worst = id; }
    if (Math.min(...cnt) < 3) bad.push(id + ':' + cnt.join(','));
  }
  return { bad, minShare: +minShare.toFixed(2), worst }; }"""
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl'])
        pg = await b.new_page(viewport={'width':390,'height':844})
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/carnet/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        print(await pg.evaluate(JS))
        await b.close()
asyncio.run(main())
