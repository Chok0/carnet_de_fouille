# v35 — frappe réelle à l'établi : lisière → au moins ★ ; cœur sur pierre fraîche → ★★★ ; cœur après 25 tapotements → moins ; veine près/loin
import asyncio, json
from playwright.async_api import async_playwright
CASE = """async ([mode, want]) => {
  const _st = window.setTimeout; window.setTimeout = (f, d, ...a) => _st(f, Math.min(d || 0, 60), ...a);
  let d = window.__dbg(); d.closeSay(); d.newSite(d.G.site.epoch, 1); d = window.__dbg(); d.show('carte');
  const S = d.G.site, q = S.poches[0];
  let pnt = want === 'os' ? { x: q.x, y: q.y } : null;
  if (!pnt) { for (let i = 0; i < 400 && !pnt; i++) { const c = { x: 20 + Math.random() * 520, y: 20 + Math.random() * 520 }; const f = d.holeFind(c, d.SITE.zones[d.MapView.zoneAt(c.x, c.y)]); if (f && f.bias === 'caillou' && S.poches.every(p => Math.hypot(p.x - c.x, p.y - c.y) > 200)) pnt = c; } }
  d.dig(pnt); await new Promise(r => _st(r, 1500)); d.closeSay();
  const D = d.Bench3D.debug(), pl = D.ST.planes.find(p => p.C.type === want);
  if (!pl) return { skip: D.ST.planes.map(p => p.C.type) };
  const dm = pl.C.dmin != null ? pl.C.dmin : (pl.C.r || 0), pts = pl.contour.pts.map(P => [P, D.distToContent(pl, P)]).filter(x => x[1] < 1e8).sort((a, b) => a[1] - b[1]);
  const core = pts[0][0], edgeD = want === 'os' ? dm + 0.40 : 0.37, edge = pts.slice().sort((a, b) => Math.abs(a[1] - edgeD) - Math.abs(b[1] - edgeD))[0];
  let P = mode === 'edge' ? edge[0] : core;
  if (mode === 'tired') for (let i = 0; i < 22; i++) D.tap(core);
  const fat = D.rock.fatigue, money0 = d.G.money;
  D.strike(P, 1);
  await new Promise(r => _st(r, 2500));
  const fid = q.fid, st = d.fos(fid), I = st.ind[st.ind.length - 1];
  const stars = want === 'os' ? (I ? Object.values(I.q).slice(-1)[0] : 'aucun bloc') : null;
  return { mode, want, dist: +(mode === 'edge' ? edge[1] : pts[0][1]).toFixed(2), fatigue: +fat.toFixed(2), stars, gain: d.G.money - money0, title: document.getElementById('rTitle').textContent, shattered: D.rock && D.rock.done };
}"""
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl'])
        errs=[]
        for mode, want in [('edge','os'),('edge','os'),('edge','os'),('core','os'),('core','os'),('tired','os'),('tired','os'),('core','veine'),('edge','veine'),('tired','veine')]:
            pg = await b.new_page(viewport={'width':390,'height':844})
            pg.on('pageerror', lambda e: errs.append(str(e)))
            await pg.route('**/fonts.*/**', lambda r: r.abort())
            await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
            await pg.goto('file:///home/claude/src/dist/preview-debug.html'); await pg.wait_for_timeout(1200)
            await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(300)
            await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); }"); await pg.wait_for_timeout(200)
            print(json.dumps(await pg.evaluate(CASE, [mode, want]), ensure_ascii=False))
            await pg.close()
        print('errors', errs)
        await b.close()
asyncio.run(main())
