# v39 — consigne de Kayou en bas de l'établi ; remarques visibles dans la bulle ; « Passer » confirmé
import asyncio
from playwright.async_api import async_playwright
async def run(b, w, h):
    pg = await b.new_page(viewport={'width':w,'height':h})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    await pg.route('**/fonts.*/**', lambda r: r.abort())
    await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
    await pg.goto('file:///home/claude/src/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
    await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(900)
    box = await pg.locator('.tuto-coach').bounding_box(); stage = await pg.locator('#stage').bounding_box()
    print(w, h, 'bulle y', round(box['y']), 'h', round(box['height']), '· établi y', round(stage['y']), 'h', round(stage['height']), '· bulle sous la pierre', box['y'] >= stage['y'] + stage['height'] - 1)
    await pg.screenshot(path=f'shots/tuto/bas-{w}x{h}-1.png')
    await pg.evaluate("() => { const D = window.__dbg().Bench3D.debug(); D.strike(D.ST.planes[0].contour.pts[0], 0.5); }"); await pg.wait_for_timeout(250)
    print('  remarque', await pg.locator('.tc-note').text_content(), await pg.locator('.tc-note').is_visible())
    await pg.screenshot(path=f'shots/tuto/bas-{w}x{h}-2.png')
    await pg.evaluate("() => { const D = window.__dbg().Bench3D.debug(), pl = D.ST.planes[0]; D.tap(pl.contour.pts[D.hotIndex(pl)]); D.strike(pl.contour.pts[D.hotIndex(pl)], 0.5); }"); await pg.wait_for_timeout(1800)
    await pg.screenshot(path=f'shots/tuto/bas-{w}x{h}-3.png')
    await pg.locator('.tc-skip').click(); await pg.wait_for_timeout(150)
    print('  1er toucher', await pg.locator('.tc-skip').text_content(), bool(await pg.evaluate("() => !!window.__dbg().tuto()")))
    await pg.locator('.tc-skip').click(); await pg.wait_for_timeout(400)
    print('  passé', not await pg.evaluate("() => !!window.__dbg().tuto()"), errs)
    await pg.close()
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl'])
        await run(b, 375, 667); await run(b, 390, 844)
        await b.close()
asyncio.run(main())
