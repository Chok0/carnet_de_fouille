import asyncio
from playwright.async_api import async_playwright
# toucher réel : appui long, la loupe au-dessus, la frappe part sous la croix
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        ctx = await b.new_context(viewport={'width':390,'height':844}, device_scale_factor=2, has_touch=True, is_mobile=True)
        pg = await ctx.new_page()
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)+' '+str(e.stack)[:300]))
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/carnet/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(300)
        await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); }"); await pg.wait_for_timeout(200)
        await pg.evaluate("() => { const d = window.__dbg(); d.closeSay(); ['pierre','creux','sourd','massive'].forEach(n => d.G.notes[n] = 1); const S = d.G.site, p = S.poches[0]; d.dig({x: p.x, y: p.y}); }")
        await pg.wait_for_timeout(900); await pg.evaluate("() => window.__dbg().show('etabli')"); await pg.wait_for_timeout(1200)
        cv = await pg.locator('.b3-gl').bounding_box()
        x, y = cv['x'] + cv['width']/2, cv['y'] + cv['height']*0.62
        await pg.evaluate(f"""() => {{ const cv = document.querySelector('.b3-gl'); const ev = (t, x, y) => cv.dispatchEvent(new PointerEvent(t, {{ pointerId: 7, pointerType: 'touch', clientX: x, clientY: y, bubbles: true }})); window.__ev = ev; ev('pointerdown', {x}, {y}); }}""")
        await pg.wait_for_timeout(500)
        info = await pg.evaluate("() => { const l = document.querySelector('.b3-lens') || [...document.querySelectorAll('canvas')].find(c => c.style.position === 'fixed' || getComputedStyle(c).position === 'fixed'); const r = l ? l.getBoundingClientRect() : null; return r ? [r.left + r.width/2, r.top + r.height/2, l.style.display] : null; }")
        print('finger', x, y, 'lens center', info)
        await pg.screenshot(path='shots/v14/aim.png')
        await pg.evaluate(f"() => window.__ev('pointerup', {x}, {y})"); await pg.wait_for_timeout(2500)
        print('result', await pg.evaluate("() => [document.getElementById('rTitle').textContent, document.getElementById('rSub').textContent, document.querySelector('.b3-say') && document.querySelector('.b3-say').textContent]"), errs)
        await b.close()
asyncio.run(main())
