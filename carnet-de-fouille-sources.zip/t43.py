# v41 — accueil, nappe sonore, fatigue + tak au tutoriel, 8 pelles, journal de partie exporté
import asyncio, json
from playwright.async_api import async_playwright
URL = 'file:///home/claude/src/dist/preview-debug.html'
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--autoplay-policy=no-user-gesture-required'])
        ctx = await b.new_context(viewport={'width':375,'height':667}, accept_downloads=True)
        pg = await ctx.new_page()
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        ev = lambda js: pg.evaluate(js)
        await pg.goto(URL + '?title'); await pg.wait_for_timeout(1500)
        print('accueil', await pg.locator('.title-screen').count(), await pg.locator('.nb-tag').text_content())
        await pg.screenshot(path='shots/v41/accueil-neuf.png')
        await pg.locator('.nb').click(); await pg.wait_for_timeout(2300)
        print('intro après accueil', await pg.locator('.intro').count(), '· nappe', await ev("() => window.__dbg && Ambient ? 1 : 0") if False else '')
        # tutoriel jusqu'à la 3e pierre
        await pg.locator('#inSkip').click(); await pg.wait_for_timeout(800)
        H = """(() => { const d = window.__dbg(), D = d.Bench3D.debug(), pl = i => D.ST.planes[i], hot = i => pl(i).contour.pts[D.hotIndex(pl(i))]; return { d, D, hot }; })()"""
        await ev(f"() => {{ const h = {H}; h.D.tap(h.hot(0)); h.D.strike(h.hot(0), 0.5); }}"); await pg.wait_for_timeout(1800); await pg.locator('#btnBack').click(); await pg.wait_for_timeout(700)
        await ev(f"() => {{ const h = {H}; h.D.tap(h.hot(1)); h.D.strike(h.hot(1), 1); }}"); await pg.wait_for_timeout(1800); await pg.locator('#btnBack').click(); await pg.wait_for_timeout(700)
        print('pierre 3 : jauge visible', await ev("() => getComputedStyle(document.querySelector('.fat-row')).display !== 'none' && getComputedStyle(document.getElementById('benchTop')).display !== 'none'"))
        # des taks hors fil : la jauge monte, la remarque parle de fatigue, la pierre n'éclate pas
        await ev("""() => { const D = window.__dbg().Bench3D.debug(), THREE = window.THREE; for (let i = 0; i < 30; i++) { const P = D.surfacePoint(new THREE.Vector3(Math.cos(i), 0.9, Math.sin(i))); if (P && !D.onPlane(P, 0.07)) D.tap(P); } }""")
        await pg.wait_for_timeout(300)
        print('  fatigue', await ev("() => Math.round(window.__dbg().Bench3D.debug().rock.fatigue * 100) / 100"), '· éclatée', await ev("() => window.__dbg().Bench3D.debug().rock.done"), '·', await pg.locator('.tc-note').text_content())
        await pg.screenshot(path='shots/v41/tuto-fatigue.png')
        await ev(f"() => {{ const h = {H}; h.D.tap(h.hot(0)); h.D.tap(h.hot(1)); h.D.strike(h.hot(1), 1); }}"); await pg.wait_for_timeout(3000); await pg.locator('#btnBack').click(); await pg.wait_for_timeout(900)
        print('8 pelles', await ev("() => window.__dbg().maxDigs()"), '·', await pg.locator('#mapStamp').text_content())
        print('nappe active', await ev("() => window.__dbg().Ambient.on"))
        # jouer quelques pierres pour remplir le journal
        for k in range(3):
            await ev("""() => { const d = window.__dbg(); d.closeSay(); d.G.notes.pierre = 1; d.G.notes.creux = 1; const q = d.G.site.poches[0]; d.dig({ x: q.x + ([-1, 0, 1][d.G.site.holes.length % 3]) * 36, y: q.y + 20 }); }"""); await pg.wait_for_timeout(1300)
            print('  pierre ?', await ev("() => { const d = window.__dbg(); return [!!d.G.stone, d.CUR && d.CUR.state, document.getElementById('toast').textContent, d.G.site.holes.length]; }"))
            await ev("() => { const d = window.__dbg(); if (d.G.stone && !d.Bench3D.debug().ST) d.show('etabli'); }"); await pg.wait_for_timeout(900)
            await ev("""() => { const d = window.__dbg(); d.closeSay(); const D = d.Bench3D.debug(); const i = D.ST.planes.findIndex(p => p.C.type !== 'rien'); const pl = D.ST.planes[Math.max(0, i)]; for (let j = 0; j < 4; j++) D.tap(pl.contour.pts[j * 5 % pl.contour.pts.length]); D.strike(pl.contour.pts[D.hotIndex(pl)], 1); }"""); await pg.wait_for_timeout(2600)
            await ev("() => { const d = window.__dbg(); d.closeSay(); d.tryCloseMoment(); }"); await pg.wait_for_timeout(300); await ev("() => { const d = window.__dbg(); d.closeSay(); d.advance(); }"); await pg.wait_for_timeout(400)
        await pg.screenshot(path='shots/v41/carte.png')
        # journal : réglages → journal → réponses → envoyer (téléchargement en bureau)
        await ev("() => window.__dbg().closeSay()")
        await pg.locator('#btnMenu').click(); await pg.wait_for_timeout(300)
        await pg.screenshot(path='shots/v41/reglages.png')
        await pg.locator('#btnLog').click(); await pg.wait_for_timeout(300)
        tas = pg.locator('.jr-q textarea')
        for i, t in enumerate(['Les gros POK, et voir le trilobite sortir.', 'Au début sur la carte.', 'pic rien, pok os, ting minerai, bong géode'][:await tas.count()]): await tas.nth(i).fill(t)
        await pg.screenshot(path='shots/v41/journal.png')
        async with pg.expect_download() as dl:
            await pg.locator('#jrSend').click()
        d = await dl.value; path = await d.path(); data = json.load(open(path))
        print('fichier', d.suggested_filename)
        print('résumé', json.dumps(data['resume'], ensure_ascii=False)[:700])
        print('réponses', [v['reponse'] for v in data['reponses'].values()] or 'questions désactivées')
        print('types', sorted(set(e['e'] for e in data['evenements'])))
        print('exemple pierre', json.dumps([e for e in data['evenements'] if e['e'] == 'pierre'][-1], ensure_ascii=False))
        # relance : l'accueil propose de continuer
        await pg.goto(URL + '?title'); await pg.wait_for_timeout(1500)
        print('relance', await pg.locator('.nb-tag').text_content(), '|', await pg.locator('.ts-new').text_content(), '|', await pg.locator('.ts-save').text_content())
        await pg.screenshot(path='shots/v41/accueil-suite.png')
        print('errors', errs)
        await b.close()
asyncio.run(main())
