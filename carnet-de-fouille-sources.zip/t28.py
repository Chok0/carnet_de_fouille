import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':390,'height':844}, device_scale_factor=1)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/carnet/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(300)
        await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); }"); await pg.wait_for_timeout(200)
        for k in range(6):
            await pg.evaluate("() => { const d = window.__dbg(); d.closeSay(); d.G.notes.pierre = 1; d.G.notes.creux = 1; const S = d.G.site, p = S.poches.find(q => !q.done); d.dig({x: p.x, y: p.y}); }")
            await pg.wait_for_timeout(900)
            info = await pg.evaluate("""() => { const d = window.__dbg(), st = d.G.stone; if (!st) return 'nostone'; const i = st.contents.findIndex(c => c.type === 'os' || c.type === 'eclat'); if (i < 0) return 'no os ' + JSON.stringify(st.contents.map(c=>c.type)); d.show('etabli'); return 'ok ' + st.contents[i].type; }""")
            await pg.wait_for_timeout(900)
            if not info.startswith('ok'):
                print(k, info); await pg.evaluate("() => { const d = window.__dbg(); if (d.G.stone) { d.G.stone = null; d.CUR && (d.CUR.stone = null); } d.show('carte'); }"); continue
            r = await pg.evaluate("""() => { const D = window.__dbg().Bench3D.debug(); const pl = D.ST.planes.find(q => q.C.type === 'os' || q.C.type === 'eclat');
              const pts = pl.contour.pts.slice().sort((a,b)=>D.distToContent(pl,a)-D.distToContent(pl,b)); const P = pts[0];
              const info = { type: pl.C.type, r: +pl.C.r.toFixed(2), dmin: +pl.C.dmin.toFixed(3), dbest: +D.distToContent(pl,P).toFixed(3) };
              D.tap(P); D.strike(P, 1); return info; }""")
            await pg.wait_for_timeout(3200)
            res = await pg.evaluate("() => [document.getElementById('rTitle').textContent, document.getElementById('rSub').textContent]")
            print(k, info, res)
            await pg.screenshot(path=f'shots/v14/best{k}.png')
            await pg.evaluate("() => { const d = window.__dbg(); d.advance && d.advance(); }"); await pg.wait_for_timeout(600)
            await pg.evaluate("() => { const d = window.__dbg(); d.closeSay(); d.show('carte'); }"); await pg.wait_for_timeout(300)
        print(errs)
        await b.close()
asyncio.run(main())
