import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        ctx = await b.new_context(viewport={'width':390,'height':844}, device_scale_factor=1, has_touch=True, is_mobile=True)
        pg = await ctx.new_page()
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/carnet/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(300)
        await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); }"); await pg.wait_for_timeout(200)
        await pg.evaluate("() => { const d = window.__dbg(); d.closeSay(); d.G.money = 500; const S = d.G.site; while (d.digsLeft() > 0) S.holes.push({x: -999 - S.holes.length*50, y: -999, z: 0, k: 'vide'}); d.closeSite(); }")
        await pg.wait_for_timeout(1500)
        await pg.evaluate("() => window.__dbg().closeSay()"); await pg.wait_for_timeout(300)
        await pg.screenshot(path='shots/v14/leave0.png')
        await pg.evaluate("() => document.getElementById('btnLeave').click()"); await pg.wait_for_timeout(500)
        await pg.screenshot(path='shots/v14/leave1.png')
        await pg.locator('#goLeave').tap(); 
        for i in range(8):
            await pg.wait_for_timeout(250)
            st = await pg.evaluate("() => [document.getElementById('scr-musee').scrollTop, !!window.__dbg().G.voyage, !!document.querySelector('.sheet-back, .sheet'), window.__dbg().G.site.num]")
            print(i, st)
            if i in (0, 3, 7): await pg.screenshot(path=f'shots/v14/leave_m{i}.png')
        print(errs)
        await b.close()
asyncio.run(main())
