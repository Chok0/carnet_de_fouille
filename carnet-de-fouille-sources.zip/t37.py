# v35 — lot cœur : pierres jamais vides, qualité unique, plus d'éclat, lunettes dans Outils
import asyncio, json
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl'])
        pg = await b.new_page(viewport={'width':390,'height':844}, device_scale_factor=1)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)+' '+str(e.stack)[:300]))
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/src/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(300)
        await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); }"); await pg.wait_for_timeout(200)
        ev = lambda js: pg.evaluate(js)
        r = await ev("""() => {
          let d = window.__dbg(); const out = { empty: 0, stones: 0, mainRien: 0, eclat: 0, bias: {}, fossilSite1: 0, fossilSite1Bot: 0, osRepli: [0, 0] };
          const rand = () => ({ x: 20 + Math.random() * 520, y: 20 + Math.random() * 520 });
          // 1) 30 fouilles au hasard sur 20 gisements : jamais de trou vide, jamais de fil principal vide
          for (let g = 0; g < 20; g++) {
            d.newSite(d.G.site.epoch, 1); d = window.__dbg(); const S = d.G.site;
            for (let i = 0; i < 30; i++) {
              const pnt = rand(), zi = d.MapView.zoneAt(pnt.x, pnt.y), f = d.holeFind(pnt, d.SITE.zones[zi]);
              if (!f) { out.empty++; continue; }
              out.stones++; out.bias[f.bias] = (out.bias[f.bias] || 0) + 1;
              const st = Object.assign({ seed: (Math.random() * 1e9) >>> 0, rock: d.SITE.zones[zi].rock }, f), cs = d.stoneContents(st);
              if (cs.some(c => c.type === 'eclat')) out.eclat++;
              if (!cs.some(c => c.type !== 'rien')) out.mainRien++;
              if (cs.some(c => c.type === 'os')) { out.osRepli[1]++; if (cs.some(c => c.type === 'veine')) out.osRepli[0]++; }
              if (f.bias === 'geode') d.G.site.geodes.forEach(q => q.done = false);
            }
          }
          // 2) premier gisement : 10 coups de pelle. Bot naïf (au hasard) et bot « lunettes » (la chaleur lue à ±1 case près)
          for (let g = 0; g < 40; g++) {
            d.newSite(d.G.site.epoch, 1); d = window.__dbg(); const S = d.G.site;
            let hit = false;
            for (let i = 0; i < 10 && !hit; i++) { const pnt = rand(); const f = d.holeFind(pnt, d.SITE.zones[d.MapView.zoneAt(pnt.x, pnt.y)]); if (f && (f.bias === 'poche' || (f.bias === 'bord'))) hit = true; }
            if (hit) out.fossilSite1++;
            hit = false;
            const C = d.MapView.zoneAt ? 560 / 7 : 80;
            for (let i = 0; i < 10 && !hit; i++) {
              let pnt = rand();
              if (i >= 2) { const q = S.poches[i % S.poches.length]; pnt = { x: q.x + (Math.random() - 0.5) * 2 * C, y: q.y + (Math.random() - 0.5) * 2 * C }; }
              const f = d.holeFind(pnt, d.SITE.zones[d.MapView.zoneAt(Math.max(1, Math.min(559, pnt.x)), Math.max(1, Math.min(559, pnt.y)))]);
              if (f && (f.bias === 'poche' || f.bias === 'bord')) hit = true;
            }
            if (hit) out.fossilSite1Bot++;
          }
          return out;
        }""")
        print(json.dumps(r))
        # 3) étoiles : ouvrir le bon fil donne toujours au moins une étoile, la fatigue rogne la qualité
        r2 = await ev("""() => { const d = window.__dbg(); return [[0.02,0],[0.3,0],[0.5,0],[0.95,0],[0.95,0.6],[0.95,0.9],[0.6,0.2]].map(([prox, fat]) => { const o = { score: prox * (1 - 0.5 * fat), aim: prox, fatigue: fat }; return [prox, fat, d.starsOf(o, 'os'), d.starsWhy(o, 'os').join(' / ')]; }); }""")
        for x in r2: print('stars', x)
        # 4) parcours réel : creuser, ouvrir l'établi, boutique
        await ev("() => { const d = window.__dbg(); d.closeSay(); d.newSite(d.G.site.epoch, 1); d.show('carte'); }"); await pg.wait_for_timeout(600)
        await ev("() => { const d = window.__dbg(); d.dig({ x: 280, y: 280 }); }"); await pg.wait_for_timeout(1500)
        await pg.screenshot(path='shots/v35-etabli.png')
        print('screen etabli, stone:', await ev("() => { const d = window.__dbg(); return [!!d.G.stone, d.G.stone && d.G.stone.contents.map(c => c.type).join(',')]; }"))
        await ev("() => { const d = window.__dbg(); d.G.money = 2000; d.startVoyage(); }"); await pg.wait_for_timeout(600)
        await ev("() => { const b = document.getElementById('btnChoose'); if (b) b.click(); }"); await pg.wait_for_timeout(500)
        print('shop outils:', await ev("() => [...document.querySelectorAll('#shop h3, #shop b, #shop .name')].map(e => e.textContent).join(' | ').slice(0, 300)"))
        await pg.screenshot(path='shots/v35-shop.png')
        print('errors', errs)
        await b.close()
asyncio.run(main())
