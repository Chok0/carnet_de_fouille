import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl'])
        pg = await b.new_page(viewport={'width':390,'height':844}, device_scale_factor=2)
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/carnet/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        await pg.screenshot(path='shots/v14/ui-intro.png')
        await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(500)
        await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); }"); await pg.wait_for_timeout(200)
        await pg.screenshot(path='shots/v14/ui-carte.png')
        await pg.evaluate("() => { const d = window.__dbg(); d.closeSay(); d.show('musee'); }"); await pg.wait_for_timeout(800)
        await pg.screenshot(path='shots/v14/ui-musee1.png')
        await pg.evaluate("() => document.getElementById('scr-musee').scrollTop = 700"); await pg.wait_for_timeout(300)
        await pg.screenshot(path='shots/v14/ui-musee2.png')
        await b.close()
asyncio.run(main())
