/* ---------- prélèvement et tirage ----------
   Une zone touchée sort plusieurs cailloux d'un coup (ils quittent le stock de la zone) ; on n'en fend que quelques-uns,
   le reste part au déblai. Le contenu de chaque caillou est tiré à la sortie, pour que sa surface puisse le trahir. */
function prelev() {
  const [m, k] = PRELEV[clamp(G.up.quantite, 0, PRELEV.length - 1)];
  /* sur le tout premier gisement, un caillou de moins à comparer : le temps d'apprendre */
  return { m, k: G.site && G.site.num === 1 ? Math.max(m + 1, k - 1) : k };
}
function startLot(zi) {
  if (CUR && CUR.state === 'striking') return;
  if (RECAP) { RECAP.remove(); RECAP = null; }
  $('scr-etabli').classList.remove('recap-open');
  if (MOMENT) { MOMENT.el.remove(); MOMENT = null; }
  closeSay(true);
  const z = SITE.zones[zi], P = prelev(), n = z.stock > 0 ? Math.min(P.k, z.stock) : 1, stones = [];
  G.site.draws = (G.site.draws || 0) + 1;
  let uni = false;
  for (let i = 0; i < n; i++) {
    const seed = (Math.imul(G.site.seed ^ 0x2545f491, 31) + Math.imul(G.site.draws, 2654435761) + i * 40503) >>> 0;
    const roll = z.stock > 0 ? rollStone(z, uni) : { empty: true, draws: [] };
    if (roll.draws.some(d => d.t === 'complet')) uni = true;
    if (z.stock > 0) z.stock--;
    stones.push(makeStone(z, seed, roll));
  }
  z.dug++;
  /* les cailloux sortis montrent la vraie roche : une zone masquée se révèle */
  if (z.mask && !z.revealed) { z.revealed = true; z.vis = z.rock; mapDirty = true; }
  G.lot = normLot({ zone: zi, total: Math.min(P.m, n), done: 0, stones, pick: null });
  G.site.last = zi;
  Sound.play('tap');
  CUR = null; VIS.clear();
  show('etabli');
  save();
}
function pickOre() {
  const w = { cuivre: 0.6, argent: 0.3, or: 0.1 }, set = SITE.ores;
  let r = Math.random() * set.reduce((a, o) => a + w[o], 0);
  for (const o of set) { r -= w[o]; if (r <= 0) return o; }
  return set[0];
}
/* contenu d'un caillou : un os d'une poche proche (d'autant plus probable qu'on est près d'elle), la pièce unique
   près de sa cachette, sinon du minerai ou rien. Le marteau aide un peu. noUni : la pièce unique est déjà sortie de ce prélèvement */
function rollStone(z, noUni) {
  const n = 1 + G.up.taille, M = G.up.marteau, P = SITE.poches || [], draws = [];
  const U = EPOCHS[SITE.epoch].fossils.find(f => FOSSILS[f].kind === 'unique');
  let uniTaken = !!noUni || G.site.uni == null || !U || fos(U).done;
  for (let k = 0; k < n; k++) {
    const w = P.map(p => (p.done ? 0 : SITEGEN.frag[zcheb(p.z, z.i)] || 0));
    const pf = Math.min(0.8, (1 - w.reduce((a, x) => a * (1 - x), 1)) * (1 + 0.05 * M));
    const pu = uniTaken ? 0 : (SITEGEN.uniqP[zcheb(G.site.uni, z.i)] || 0) * (1 + 0.15 * M);
    const r = Math.random();
    if (r < pu) { draws.push({ t: 'complet', fid: U }); uniTaken = true; }
    else if (r < pu + pf) { const pi = weightedIdx(Math.random, w); draws.push({ t: 'fragment', fid: P[pi].fid, pi }); }
    else draws.push(Math.random() < (SITEGEN.vide[z.band] == null ? 0.4 : SITEGEN.vide[z.band]) ? { t: 'vide' } : { t: 'minerai', ore: pickOre() });
  }
  return { empty: false, draws };
}
/* un caillou sorti : son contenu, sa forme, ce que montre sa surface (vrais indices et faux amis),
   ses fausses fissures et l'aspect de son fil. Tout est décidé ici et sauvegardé : il ne change plus. */
function makeStone(z, seed, roll) {
  const rnd = mulberry32((seed ^ 0x51ed) >>> 0);
  const fosD = roll.draws.find(d => d.t === 'complet') || roll.draws.find(d => d.t === 'fragment'), oreD = roll.draws.find(d => d.t === 'minerai');
  const shape = pickShape(z.rock, rnd, G.set.indices && !!fosD), g = stoneGeom(z.rock, seed, { shape }), T = TELLS, tells = [];
  const onFil = p => !!g.fil && rnd() < p;
  if (G.set.indices && !roll.empty) {
    if (fosD) {
      const r = rnd(), pa = fosD.t === 'complet' ? T.affleureU : T.affleure;
      if (r < pa) tells.push({ k: 'affleure', fid: fosD.fid, onFil: onFil(T.surFil.vrai) });
      else if (r < pa + T.marque) tells.push({ k: rnd() < 0.5 ? 'bosse' : 'tache', onFil: onFil(T.surFil.vrai) });
    }
    if (oreD && rnd() < T.minerai) tells.push({ k: oreD.ore === 'cuivre' || rnd() < 0.5 ? 'veine' : 'reflets', ore: oreD.ore });
    /* le bruit : faux indices et pseudo-fossiles, sur n'importe quel caillou (les concrétions aiment les roches à nodules) */
    Object.keys(T.bruit).forEach(k => {
      const p = T.bruit[k] * (k === 'concretion' && NODULES[z.rock] ? 1.6 : 1);
      if (rnd() < p && tells.length < T.max) tells.push({ k, fake: true, onFil: onFil(T.surFil.faux) });
    });
  }
  const lv = crackLevel(g, rnd);
  return { seed, roll, shape, tells, dec: lv.n, lis: Math.round(lv.base * 1000) / 1000, fv: g.fil ? pickFilVis(rnd) : null, done: false };
}
/* aspect du fil : toujours franc au début, puis de plus en plus souvent discret, discontinu ou voilé */
function pickFilVis(rnd) {
  const t = clamp(((G.xpFil || 0) - FILVIS.from) / (FILVIS.to - FILVIS.from), 0, 1), E2 = FILVIS.end;
  if (t <= 0) return 'net';
  const w = { net: 1 - t * (1 - E2.net), discret: t * E2.discret, discontinu: t * E2.discontinu, voile: t * E2.voile };
  let r = rnd() * Object.values(w).reduce((a, b) => a + b, 0);
  for (const k in w) { r -= w[k]; if (r <= 0) return k; }
  return 'net';
}
/* gains selon la fissure frappée (CUTS) : le fil donne un bloc de plus (du même animal) et double le minerai, la veine le triple */
function applyStone(z, roll, cut) {
  const ep = SITE.epoch, L = G.lot, C = CUTS[cut] || CUTS.aucune;
  if (roll.empty) { L.empty++; return [{ t: 'vide', why: z.s0 === 0 ? 'sterile' : 'epuisee' }]; }
  const out = [], mult = C.ore;
  roll.draws.forEach(d => {
    if (d.t === 'complet') { out.push(fos(d.fid).done ? gainOre(pickOre(), mult) : gainUnique(d.fid, z)); return; }
    if (d.t === 'fragment') {
      const p = SITE.poches[d.pi];
      /* la poche a été vidée entre la sortie du caillou et la frappe */
      if (!p || p.done) { out.push(gainOre(pickOre(), mult)); return; }
      if (fos(p.fid).done) { out.push(gainKnown(p)); return; }
      const a = gainFragment(p, z); out.push(a);
      const I = indOf(p.fid, a.k);
      for (let k = 0; k < C.blocs && !fos(p.fid).done && I.found.length < FOSSILS[p.fid].blocks; k++) { const b = gainFragment(p, z, true); b.bonus2 = true; out.push(b); }
      return;
    }
    if (d.t === 'vide') { out.push({ t: 'vide', why: 'roche' }); return; }
    out.push(gainOre(d.ore, mult));
  });
  if (out.every(r => r.t === 'vide')) L.empty++;
  if (EPOCHS[ep].fossils.every(f => fos(f).done) && !G.cols[ep]) {
    G.cols[ep] = true; addMoney(COLUMN_BONUS); G.site.stats.bonus += COLUMN_BONUS; L.bonus += COLUMN_BONUS; L.gain += COLUMN_BONUS; L.col = ep;
    out.push({ t: 'colonne', ep, bonus: COLUMN_BONUS });
  }
  return out;
}
function gainOre(ore, mult) {
  const L = G.lot, gain = ORES[ore].value * (mult || 1);
  addMoney(gain); G.site.stats.ore += gain;
  L.ore[ore] = (L.ore[ore] || 0) + 1; L.oreCoins += gain; L.gain += gain;
  return { t: 'minerai', ore, gain, clean: (mult || 1) > 1 };
}
/* un os de la poche p : il appartient au squelette de cette poche (créé au premier os trouvé).
   forced : bloc garanti neuf (coupe nette) ; sinon, doublon possible quand le squelette est bien avancé */
function gainFragment(p, z, forced) {
  const fid = p.fid, F = FOSSILS[fid], st = fos(fid), n = F.blocks, L = G.lot;
  let I = p.k != null ? indOf(fid, p.k) : null;
  const first = !I;
  if (!I) { I = { k: ++st.nk, site: G.site.seed, num: G.site.num, zone: z.i, found: [], lost: false, hits: {} }; st.ind.push(I); p.k = I.k; }
  /* l'épingle de la carte se pose là où sont sortis le plus de ses os */
  I.hits = I.hits || {}; I.hits[z.i] = (I.hits[z.i] || 0) + 1;
  if (I.hits[z.i] >= (I.hits[I.zone] || 0)) I.zone = z.i;
  G.last = fid; G.lastK = I.k; L.fragK[fid] = I.k;
  if (!G.ev.poche) G.ev.poche = 1;
  if (first && st.ind.filter(J => J.site === G.site.seed).length > 1 && !G.ev.individu) G.ev.individu = 1;
  if (!forced && I.found.length && Math.random() < FRAG.doublon * I.found.length / n) {
    const block = I.found[Math.floor(Math.random() * I.found.length)], gain = RARITY[F.rarity].dup;
    addMoney(gain); st.dup = (st.dup || 0) + 1; G.site.stats.dup = (G.site.stats.dup || 0) + 1;
    L.dup++; L.dupCoins += gain; L.gain += gain;
    if (!G.ev.doublon) G.ev.doublon = 1;
    return { t: 'doublon', fid, block, k: I.k, gain, n: I.found.length, of: n };
  }
  const miss = [];
  for (let i = 0; i < n; i++) if (!I.found.includes(i)) miss.push(i);
  const block = miss[Math.floor(Math.random() * miss.length)], before = I.found.slice();
  I.found.push(block); G.site.stats.frags++;
  L.frags[fid] = (L.frags[fid] || 0) + 1;
  let bonus = 0, done = false;
  if (I.found.length >= n) {
    st.done = true; done = true; p.done = true; st.where = 'Gisement n°' + G.site.num + ', zone ' + zname(SITE.zones[I.zone]);
    bonus = RARITY[F.rarity].bonus; addMoney(bonus); G.site.stats.bonus += bonus; G.site.stats.completes++;
    L.ident.push(fid); L.bonus += bonus; L.gain += bonus;
  }
  return { t: 'fragment', fid, block, before, done, bonus, n: I.found.length, of: n, k: I.k, fresh: first && st.ind.length > 1, first };
}
/* os d'une espèce déjà au musée : revendu comme doublon, et la poche s'use */
function gainKnown(p) {
  const fid = p.fid, F = FOSSILS[fid], st = fos(fid), L = G.lot, gain = RARITY[F.rarity].dup, n = F.blocks;
  addMoney(gain); st.dup = (st.dup || 0) + 1; G.site.stats.dup = (G.site.stats.dup || 0) + 1;
  L.dup++; L.dupCoins += gain; L.gain += gain;
  p.used = (p.used || 0) + 1; if (p.used >= n) p.done = true;
  G.last = fid; G.lastK = null;
  if (!G.ev.doublon) G.ev.doublon = 1;
  return { t: 'doublon', fid, block: Math.floor(Math.random() * n), known: true, gain, n, of: n };
}
function gainUnique(fid, z) {
  const st = fos(fid), L = G.lot;
  st.done = true; st.where = 'Gisement n°' + G.site.num + ', zone ' + zname(z); G.last = fid; G.lastK = null; G.site.uni = null;
  addMoney(UNIQUE_BONUS); G.site.stats.bonus += UNIQUE_BONUS; G.site.stats.uniques++; G.site.stats.completes++;
  L.uniques.push(fid); L.bonus += UNIQUE_BONUS; L.gain += UNIQUE_BONUS;
  return { t: 'complet', fid, bonus: UNIQUE_BONUS };
}
const deOre = o => (/^[aeiouéh]/i.test(ORES[o].name) ? 'd’' : 'de ') + ORES[o].name;
const PRIO = { complet: 5, fragment: 3, doublon: 2.5, minerai: 2, vide: 1, colonne: 0 };
function primaryOf(res) { return res.slice().sort((a, b) => (PRIO[b.t] + (b.done ? 1 : 0)) - (PRIO[a.t] + (a.done ? 1 : 0)))[0]; }
/* 0 rien · 1 minerai ou doublon · 2 fragment · 3 identification · 4 pièce unique */
function tierOf(res) { const m = primaryOf(res); return m.t === 'complet' ? 4 : m.t === 'fragment' ? (m.done ? 3 : 2) : m.t === 'minerai' || m.t === 'doublon' ? 1 : 0; }

