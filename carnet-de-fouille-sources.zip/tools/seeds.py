# précalcule les graines du découpage en blocs à partir des vrais pixels de chaque dessin (k-moyennes sur l'os)
import asyncio, json
from playwright.async_api import async_playwright
JS = r"""async () => {
  const d = window.__dbg(), out = {};
  const ids = Object.keys(d.FOSSILS).filter(f => d.FOSSILS[f].kind === 'frag' && d.ART[f]);
  for (const id of ids) {
    const A = d.ART[id], [vw, vh] = A.vb, n = d.FOSSILS[id].blocks || 1, k = 320 / Math.max(vw, vh);
    const svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + vw + ' ' + vh + '" width="' + Math.round(vw * k) + '" height="' + Math.round(vh * k) + '"><g stroke-linecap="round" stroke-linejoin="round">' + A.fn(d.FPAL[d.FOSSILS[id].epoch]) + '</g></svg>';
    const img = new Image(); img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    await new Promise(r => { img.onload = r; img.onerror = r; });
    const W = Math.round(vw * k), H = Math.round(vh * k), c = document.createElement('canvas'); c.width = W; c.height = H;
    const cx = c.getContext('2d'); cx.drawImage(img, 0, 0, W, H);
    const px = cx.getImageData(0, 0, W, H).data, pts = [];
    for (let y = 0; y < H; y += 2) for (let x = 0; x < W; x += 2) if (px[(y * W + x) * 4 + 3] > 60) pts.push([x / k, y / k]);
    if (pts.length < n * 4) continue;
    /* départ : les graines habituelles, ramenées au point d'os le plus proche */
    let S = d.blockSeeds(n, A.area, d.hashStr(id)).map(s => { let b = pts[0], bd = 1e18; for (const p of pts) { const q = (p[0] - s[0]) ** 2 + (p[1] - s[1]) ** 2; if (q < bd) { bd = q; b = p; } } return b.slice(); });
    for (let it = 0; it < 30; it++) {
      const acc = S.map(() => [0, 0, 0]);
      for (const p of pts) { let bi = 0, bd = 1e18; for (let i = 0; i < S.length; i++) { const q = (p[0] - S[i][0]) ** 2 + (p[1] - S[i][1]) ** 2; if (q < bd) { bd = q; bi = i; } } acc[bi][0] += p[0]; acc[bi][1] += p[1]; acc[bi][2]++; }
      S = S.map((s, i) => acc[i][2] ? [acc[i][0] / acc[i][2], acc[i][1] / acc[i][2]] : pts[Math.floor(Math.random() * pts.length)].slice());
    }
    /* deux graines confondues casseraient le diagramme : on écarte d'un cheveu */
    S = S.map((s, i) => [Math.round(s[0] * 10) / 10 + i * 0.01, Math.round(s[1] * 10) / 10]);
    out[id] = S;
  }
  return out; }"""
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl'])
        pg = await b.new_page(viewport={'width':390,'height':844})
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/carnet/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        out = await pg.evaluate(JS)
        open('/home/claude/carnet/src/seeds.js', 'w').write('/* graines du découpage en blocs, calculées sur les pixels de chaque dessin (tools/seeds.py) */\nconst BLOCK_SEEDS = ' + json.dumps(out, separators=(',', ':')) + ';\n')
        print(len(out), 'fossiles')
        await b.close()
asyncio.run(main())
