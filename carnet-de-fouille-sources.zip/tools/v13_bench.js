/* ---------- écran établi ---------- */
let benchDrawn = false;
const BENCH = { px: null, py: null, lift: 0 };
function renderBench() {
  const empty = !G.lot;
  $('benchEmpty').hidden = !empty;
  ['benchTop', 'stage', 'tray', 'benchBottom'].forEach(id => ($(id).style.visibility = empty ? 'hidden' : ''));
  if (!benchDrawn) paintBench();
  if (empty) { $('tray').innerHTML = ''; return; }
  const L = G.lot;
  if (L.done >= L.total && !RECAP && (!CUR || CUR.state === 'ready')) { if (!CUR) clearStage(''); renderTray(); renderLotInfo(); endLot(); return; }
  if (!CUR) {
    const left = L.stones.filter(s => !s.done);
    /* un seul caillou (roche stérile, zone presque vide) : rien à choisir */
    if (left.length === 1 || left.length <= L.total - L.done) { pickStone(L.stones.indexOf(left[0])); return; }
    clearStage(L.done ? 'Choisissez le caillou suivant' : 'Choisissez le caillou à fendre');
    renderTray(); renderLotInfo();
    const m = pickSay('tray');
    if (m) say(m, 'etabli');
  } else { renderTray(); renderLotInfo(); }
}
function paintBench() {
  const cv = $('benchBg'), r = cv.getBoundingClientRect();
  if (!r.width) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  cv.width = Math.round(r.width * dpr); cv.height = Math.round(r.height * dpr);
  drawBench(cv, 7);
  benchDrawn = true;
}
function layoutBench() {
  const st = $('stage'), r = st.getBoundingClientRect();
  if (!r.width) return;
  if (!benchDrawn || Math.abs($('benchBg').width / Math.min(window.devicePixelRatio || 1, 2) - $('scr-etabli').clientWidth) > 2) paintBench();
  const k = [0.86, 1, 1.12][G.up.taille];
  /* la pierre remonte un peu : le verdict s'affiche sous elle, dans l'établi */
  const lift = BENCH.lift = Math.round(Math.min(26, r.height * 0.08));
  const sw = Math.min(r.width * 0.54, (r.height - 20 - 2 * lift) / 0.9 * 0.8, 250) * k;
  const hw = sw * 0.58, h = hw / 124;
  const cx = r.width / 2, cy = r.height / 2 - lift;
  const ix = cx + 0.14 * sw, iy = cy - 0.25 * sw;
  st.style.setProperty('--sw', sw + 'px'); st.style.setProperty('--hw', hw + 'px'); st.style.setProperty('--lift', lift + 'px');
  st.style.setProperty('--os', Math.min(1, (r.width - 36) / (2 * sw)).toFixed(3));
  BENCH.px = ix + 106 * h; BENCH.py = iy - 8 * h;
  if (!CUR || CUR.state === 'ready') { st.style.setProperty('--px', BENCH.px + 'px'); st.style.setProperty('--py', BENCH.py + 'px'); }
}
function renderLotInfo(skipChip) {
  if (!G.lot) return;
  const L = G.lot, z = SITE.zones[L.zone], n = L.stones.length;
  $('lotTag').innerHTML = '<b>Zone ' + zname(z) + '</b><small>' + (n > 1 ? 'fendre ' + L.total + ' sur ' + n + (L.done && L.total > 1 ? ' · ' + L.done + ' fait' + (L.done > 1 ? 's' : '') : '') : 'un seul caillou') + '</small>';
  const R = ROCKS[z.rock];
  let msg = rockMsg(z.rock, z.band);
  if (z.s0 > 0 && z.stock <= 0) msg = 'La terre a été retournée de fond en comble. Zone épuisée.';
  $('rockLabel').innerHTML = '<img src="' + rockSwatch(z.rock, 48) + '" alt=""><div><b>' + R.name + (z.mask ? '<span class="surprise">Surprise</span>' : '') + '</b><span>' + msg + '</span></div>';
  $('zoneGauge').hidden = !G.up.jauge;
  if (G.up.jauge) { const f = z.s0 ? z.stock / z.s0 : 0; $('zoneGaugeBar').style.width = Math.round(f * 100) + '%'; $('zoneGaugeVal').textContent = z.stock + '/' + z.s0; }
  if (!skipChip) renderChip();
}
function renderChip(bump) {
  const chip = $('fossilChip'), fid = G.last && FOSSILS[G.last].epoch === SITE.epoch ? G.last : null;
  if (!fid) {
    const E2 = EPOCHS[SITE.epoch], done = E2.fossils.filter(f => fos(f).done).length;
    chip.innerHTML = '<div><span class="nm">' + E2.name + '</span><span class="nm" style="font-size:12px;color:var(--ink-3)">' + done + '/' + E2.fossils.length + ' au musée</span></div>';
  } else {
    /* l'individu en cours (celui du dernier fragment), sinon le meilleur */
    const F = FOSSILS[fid], st = fos(fid), of = F.blocks || 1, I = F.kind === 'frag' && !st.done ? indOf(fid, G.lastK) || bestInd(fid) : null;
    const found = st.done ? allBlocks(fid) : I ? I.found : [], n = F.kind === 'unique' ? (st.done ? 1 : 0) : found.length;
    const sub = F.kind === 'unique' ? 'pièce unique' : st.done ? 'identifié' : n + '/' + of + ' blocs' + (I && st.ind.length > 1 ? ' · n°' + I.k : '');
    chip.innerHTML = fossilSVG(fid, F.kind === 'unique' ? (st.done ? 'full' : 'veiled') : 'puzzle', found) +
      '<div style="min-width:0"><span class="nm">' + dispName(fid) + '</span><span class="pbar"><i style="width:' + Math.round(100 * n / of) + '%"></i></span><span class="nm" style="font-size:12px;color:var(--ink-3)">' + sub + '</span></div>';
  }
  if (bump) { chip.classList.remove('pulse'); void chip.offsetWidth; chip.classList.add('pulse'); }
}
/* ---------- fissures multiples : lecture de la pierre ---------- */
const multiOn = () => !!(G.set.visee && G.set.multi);
/* nombre de fausses fissures et lisibilité de base, selon l'expérience de lecture (CRACK) */
function crackLevel(g, rnd) {
  const x = G.xpFil || 0, t = clamp((x - CRACK.fadeFrom) / (CRACK.fadeTo - CRACK.fadeFrom), 0, 1);
  const base = clamp(1 - CRACK.fade * smooth(t) + (rnd() - 0.5) * 0.08, 0, 1);
  let n = 0;
  if (multiOn() && g.fil && x >= CRACK.tuto) n = rnd() < CRACK.p0 ? 0 : x < CRACK.two ? 1 : rnd() < CRACK.p2 ? 2 : 1;
  return { n, base };
}
/* la loupe rend de la lisibilité aux différences entre fissures */
const lisOf = base => clamp(base + CRACK.loupe * G.up.loupe, 0, 1);
/* ---------- les cailloux sortis : on en choisit un, on l'examine en grand, on le fend ---------- */
const VIS = new Map();
function stoneVis(s) {
  let v = VIS.get(s.seed);
  if (v) return v;
  const z = SITE.zones[G.lot.zone], g = stoneGeom(z.rock, s.seed, { shape: s.shape }), rnd = mulberry32((s.seed ^ 0x7a11) >>> 0);
  const tells = G.set.indices ? s.tells.map(t => Object.assign({}, t)) : [];
  const decoys = stoneLayout(g, tells, g.fil && multiOn() ? s.dec : 0, rnd, 1 - s.lis);
  v = { g, tells, decoys, lisBase: s.lis, fv: g.fil ? s.fv || 'net' : null };
  VIS.set(s.seed, v);
  return v;
}
const extOpt = v => ({ fil: G.set.visee, fv: v.fv, tells: v.tells, decoys: v.decoys, lis: lisOf(v.lisBase), calm: v.decoys.length > 0, loupe: G.up.loupe });
const TELL_WORDS = { bosse: 'une bosse', tache: 'une tache sombre', affleure: 'un morceau qui affleure', veine: 'une veine', reflets: 'des reflets', dendrite: 'de petites fougères noires', concretion: 'une boule cerclée', pyrite: 'des paillettes dorées' };
function trayLabel(s, i) {
  const w = (G.set.indices ? s.tells : []).map(t => TELL_WORDS[t.k]).filter(Boolean);
  return 'Caillou ' + (i + 1) + (s.done ? ', déjà fendu' : w.length ? ' : ' + w.join(', ') : ' : rien de particulier');
}
function renderTray() {
  const T = $('tray'), L = G.lot;
  if (!L) { T.innerHTML = ''; return; }
  T.innerHTML = L.stones.map((s, i) => '<button type="button" class="tray-st' + (s.done ? ' done' : '') + (L.pick === i && !s.done ? ' on' : '') + '" data-i="' + i + '" aria-pressed="' + (L.pick === i) + '" aria-label="' + trayLabel(s, i) + '"' + (s.done || L.ended ? ' disabled' : '') + '>' +
    stoneExteriorSVG(stoneVis(s).g, 'tr' + i + (s.seed >>> 0).toString(36), extOpt(stoneVis(s))) + '</button>').join('');
  T.querySelectorAll('.tray-st').forEach(b => (b.onclick = e => { e.stopPropagation(); onTrayTap(+b.dataset.i); }));
  T.classList.toggle('choose', !CUR && !L.ended && L.done < L.total && L.stones.length > 1);
  T.classList.toggle('many', L.stones.length > 3);
}
function onTrayTap(i) {
  if (SAY) { closeSay(); return; }
  if (MOMENT) { tryCloseMoment(); return; }
  if (RECAP || !G.lot || G.lot.ended) return;
  const s = G.lot.stones[i];
  if (!s || s.done || G.lot.done >= G.lot.total) return;
  if (CUR && (CUR.state === 'striking' || CUR.state === 'opening')) return;
  if (CUR && CUR.state === 'ready' && CUR.i === i) return;
  Sound.play('tap');
  pickStone(i);
}
/* un tap sur l'établi vide : les cailloux sursautent pour montrer où choisir */
function nudgeTray() { const T = $('tray'); T.classList.remove('nudge'); void T.offsetWidth; T.classList.add('nudge'); }
function clearStage(msg) {
  CUR = null;
  if (G.lot) G.lot.pick = null;
  ['lidFront', 'face', 'lidBack'].forEach(id => ($(id).innerHTML = ''));
  $('stoneWrap').className = 'stone-wrap';
  $('stage').classList.remove('opened'); $('stage').classList.add('empty');
  $('dim').classList.remove('on'); $('cleanStamp').classList.remove('on');
  $('halo').className = 'halo'; $('halo').innerHTML = '';
  $('result').className = 'result';
  resetHammer();
  const hint = $('benchHint'); hint.textContent = msg || ''; hint.style.opacity = msg ? 1 : 0;
  $('stage').setAttribute('aria-label', msg || 'Établi');
}
function paintStone() {
  if (!CUR) return;
  $('lidFront').innerHTML = stoneExteriorSVG(CUR.g, CUR.id + 'x', extOpt(CUR));
}
/* fissures visables : le fil, la veine et les fausses fissures (ces deux dernières en mode fissures multiples) */
function crackTargets() {
  const c = CUR, out = [];
  if (!c || !G.set.visee) return out;
  if (c.g.fil) out.push({ k: 'fil', pts: c.g.fil });
  if (multiOn()) {
    c.tells.forEach(t => { if (t.k === 'veine' && t.pts) out.push({ k: 'veine', pts: t.pts }); });
    c.decoys.forEach(f => out.push({ k: 'fausse', pts: f }));
  }
  return out;
}
/* la fissure la plus proche du point frappé, dans la tolérance du marteau */
function hitCrack(P) {
  const tol = 15 + 2 * G.up.marteau;
  let best = null, bd = 1e9;
  crackTargets().forEach(c => { const d = distToPolyline(c.pts, P); if (d <= tol && d < bd) { bd = d; best = c; } });
  return best;
}
/* le caillou i passe sur l'établi, en grand ; on peut encore en changer tant qu'on n'a pas frappé */
function pickStone(i) {
  const L = G.lot, s = L && L.stones[i];
  if (!s || s.done) return;
  closeSay(true);
  L.pick = i;
  const v = stoneVis(s), g = v.g;
  CUR = { i, g, roll: s.roll, tells: v.tells, decoys: v.decoys, lisBase: v.lisBase, fv: v.fv, state: 'ready', res: null, id: uid('s'), tier: 0, cut: null, hint: '' };
  paintStone();
  $('face').innerHTML = stoneFaceSVG(g, CUR.id + 'f', '');
  $('lidBack').innerHTML = '';
  let maxY = 0; g.pts.forEach(q => { maxY = Math.max(maxY, q[1]); });
  $('stoneWrap').querySelector('.st-shadow').style.top = r1((maxY + g.side - 12) / 180 * 100) + '%';
  $('stage').classList.remove('opened', 'empty');
  $('dim').classList.remove('on');
  $('cleanStamp').classList.remove('on');
  resetHammer();
  const w = $('stoneWrap');
  w.className = 'stone-wrap';
  void w.offsetWidth;
  w.className = 'stone-wrap drop idle';
  $('halo').className = 'halo'; $('halo').innerHTML = '';
  $('result').className = 'result';
  const fresh = (G.xpFil || 0) - CRACK.tuto, others = L.stones.filter(x => !x.done).length > L.total - L.done;
  CUR.hint = !G.set.visee ? (G.stones < 3 ? 'Touchez la pierre pour frapper' : '')
    : CUR.decoys.length && fresh < 4 ? 'Le fil suit les feuillets, d’un bord à l’autre'
    : g.fil && G.stones < 5 ? 'Touchez le fil de la roche pour une coupe nette'
    : others && G.stones < 9 ? 'Touchez un autre caillou pour comparer'
    : G.stones < 3 ? 'Touchez la pierre pour frapper' : '';
  const hint = $('benchHint');
  hint.textContent = CUR.hint; hint.style.opacity = CUR.hint ? 1 : 0;
  $('hammer').innerHTML = hammerSVG(G.up.marteau);
  $('stage').setAttribute('aria-label', 'Frapper la pierre');
  renderTray();
  renderLotInfo();
  const m = pickSay('stone');
  if (m) say(m, 'etabli');
}
