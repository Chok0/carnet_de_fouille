const fs=require('fs');
process.chdir(__dirname + '/..');
const files=['src/core.js','src/data.js','src/fossils.js','src/assets.js'].concat(process.argv.slice(2));
const code=files.map(f=>fs.readFileSync(f,'utf8')).join('\n')+'\n;return {ART,FPAL,FOSSILS};';
const {ART,FPAL,FOSSILS}=new Function(code)();
let tot=0;
Object.keys(ART).forEach(id=>{const s=ART[id].fn(FPAL[FOSSILS[id].epoch]);tot+=s.length;console.log(id.padEnd(16),s.length)});
console.log('total',tot);
