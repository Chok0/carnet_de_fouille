import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':390,'height':844}, device_scale_factor=1)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/carnet/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(300)
        await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); }"); await pg.wait_for_timeout(200)
        for k in range(18):
            ok = await pg.evaluate("""() => { const d = window.__dbg(); d.closeSay(); Object.keys(d.G.notes||{}); ['pierre','creux','trr','sourd','massive','poche','individu','doublon'].forEach(n => d.G.notes[n] = 1);
              d.G.site.holes = []; d.G.digs = 0; const S = d.G.site, p = S.poches.find(q => !q.done); if (!p) return 'nopoche';
              d.dig({x: p.x + (Math.random()-.5)*4, y: p.y + (Math.random()-.5)*4}); const st = d.G.stone; if (!st) return 'nostone';
              let i = st.contents.findIndex(c => c.type === 'eclat'); if (i < 0) { i = st.contents.findIndex(c => !c.joint); st.contents[i] = { type: 'eclat', joint: false, fid: p.fid }; }
              window.__ei = i; return 'ok pi=' + st.pi + ' bias=' + st.bias + ' fid=' + (st.contents[i].fid) + ' ' + i + ' ' + JSON.stringify(st.contents.map(c => c.type)); }""")
            if not ok.startswith('ok'): print(k, ok); continue
            await pg.wait_for_timeout(300)
            await pg.evaluate("() => window.__dbg().show('etabli')"); await pg.wait_for_timeout(1200)
            r = await pg.evaluate("""() => { const D = window.__dbg().Bench3D.debug(), i = window.__ei, pl = D.ST.planes[i];
              const pts = pl.contour.pts.slice().sort((a,b)=>D.distToContent(pl,a)-D.distToContent(pl,b)); const P = pts[0];
              const others = D.ST.planes.map((q, j) => j === i ? null : +Math.abs(P.dot(q.N) - q.d).toFixed(3));
              D.tap(P); D.strike(P, 1); return { type: pl.C.type, dmin: +pl.C.dmin.toFixed(2), others }; }""")
            await pg.wait_for_timeout(3200)
            res = await pg.evaluate("() => [document.getElementById('rTitle').textContent, document.getElementById('rSub').textContent]")
            print(k, ok, r, res)
            if 'Rien' in res[0] or 'miettes' in res[0]: await pg.screenshot(path=f'shots/v14/eclat{k}.png')
            await pg.evaluate("() => { const d = window.__dbg(); d.advance && d.advance(); }"); await pg.wait_for_timeout(700)
            await pg.evaluate("() => { const d = window.__dbg(); d.closeSay(); d.G.stone = null; d.show('carte'); }"); await pg.wait_for_timeout(300)
        print(errs)
        await b.close()
asyncio.run(main())
