import asyncio, time
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':390,'height':844}, device_scale_factor=1)
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/carnet/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(300)
        await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); }"); await pg.wait_for_timeout(200)
        for run in range(2):
            await pg.evaluate("() => { const d = window.__dbg(); d.closeSay(); d.G.stone = null; d.show('carte'); const S = d.G.site, p = S.poches.find(q => !q.done) ; d.dig({x: p.x + run*3, y: p.y}); }".replace('run', str(run)))
            t0 = time.time(); i = 0
            while time.time() - t0 < 1.6:
                await pg.screenshot(path=f'shots/v14/tr{run}_{i:02d}.png', scale='css'); i += 1
            print('frames', i)
            await pg.evaluate("() => { const d = window.__dbg(); d.G.stone = null; }")
        await b.close()
asyncio.run(main())
