import re
src='src/'
css=open(src+'style.css').read()
body=open(src+'body.html').read()
import os
EXTRA=[f for f in ['fossils-r0.js','fossils-r1.js','fossils-r2.js','fossils-r3.js','fossils-r4.js','fossils-r5.js','fossils-o.js','fossils-s.js','fossils-os.js','fossils-dc.js','fossils-d2.js','fossils-c2.js','fossils-pt.js','fossils-p2.js','fossils-t2.js','fossils-k.js','fossils-pg.js','fossils-kp.js','fossils-nq.js','fossils-q.js'] if os.path.exists(src+f)]
js=''.join(open(src+f).read()+'\n' for f in ['core.js','data.js','fossils.js']+EXTRA+(['seeds.js'] if os.path.exists(src+'seeds.js') else [])+['assets.js','kayou.js','map.js','bench3d.js','tuto.js','handpan-samples.js','ambient.js','log.js','game.js'])
head='''<title>Carnet de Fouille</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Caveat:wght@500;700&family=Special+Elite&family=Spectral:ital,wght@0,400;0,500;1,400&display=swap">
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
'''
out=head+'<style>\n'+css+'</style>\n'+body+'<script>\n(function(){\n"use strict";\n'+js+'})();\n</script>\n'
open('dist/carnet-de-fouille.html','w').write(out)
# local preview wrapper with the publish skeleton
SKEL='<!doctype html><html><head><meta charset=utf8><meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover"><style>:root{color-scheme:light;box-sizing:border-box;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0;padding:0;font:14px -apple-system,BlinkMacSystemFont,sans-serif;background:#faf9f5;color:#141413}img{max-width:100%}[hidden]:not([hidden=until-found i]){display:none!important}</style></head><body>\n'
open('dist/preview.html','w').write(SKEL+out+'</body></html>')
dbg=out.replace('\n})();\n</script>','\n'+open('tools/dbg.js').read()+'})();\n</script>')
# préversion de test : sans écran d'accueil, sauf avec ?title dans l'adresse
dbg=dbg.replace('<script>\n(function(){','<script>window.__NOTITLE = !/[?&]title/.test(location.search);</script>\n<script>\n(function(){',1)
assert dbg!=out
open('dist/preview-debug.html','w').write(SKEL+dbg+'</body></html>')
print(len(out)//1024,'KB')
