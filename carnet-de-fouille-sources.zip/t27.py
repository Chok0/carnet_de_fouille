import asyncio, json
from playwright.async_api import async_playwright
# mesure : sur 30 pierres à os, score au meilleur point de la surface (avant / après)
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':390,'height':844}, device_scale_factor=1)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/carnet/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(300)
        await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); }"); await pg.wait_for_timeout(200)
        out = await pg.evaluate("""async () => { const d = window.__dbg(); d.closeSay(); const r = [];
          for (let s = 1; s <= 30; s++) {
            d.Bench3D.load({ seed: s * 7919, pal: d.G && Object.values(window.__dbg().FOSSILS)[0] ? {base:'#888',light:'#aaa',shade:'#666',ink:'#222',tex:'#555',face:'#bbb',faceShade:'#999',faceTex:'#777'} : null, shape: 'slab', bedded: true, contents: [{type:'rien'},{type:'os',fid:null},{type:'rien'}], loupe:0, marteau:0 });
            const D = d.Bench3D.debug(), pl = D.ST.planes.find(q => q.C.type === 'os');
            let best = 1e9; pl.contour.pts.forEach(P => { best = Math.min(best, D.distToContent(pl, P)); });
            r.push([+(best - pl.C.r).toFixed(3), +(best - pl.C.dmin).toFixed(3)]);
          } return r; }""")
        old = [max(0,1-max(0,a)/0.5) for a,_ in out]; new = [max(0,1-max(0,b-0.04)/0.42) for _,b in out]
        print('ancien score max moyen', round(sum(old)/len(old),2), 'min', round(min(old),2))
        print('nouveau score max moyen', round(sum(new)/len(new),2), 'min', round(min(new),2), errs)
        await b.close()
asyncio.run(main())
