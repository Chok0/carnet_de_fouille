/* ---------- tutoriel : l'établi du professeur ----------
   Deux pierres, un geste chacune : la veine (ting), l'os (pic, pok, gros POK).
   La géode (bong, puis un coup dosé) n'est pas au tutoriel : geste plus technique, elle s'apprend sur le terrain,
   à partir du gisement DESTS.geodeFrom, quand Kayou l'explique au premier bong.
   Chaque étape attend le geste : le fil à écouter s'éclaire, des marques mènent au cœur.
   Pas de fatigue, pas d'échec : un coup mal placé est refusé et Kayou corrige ; le résultat est garanti. */
let TUTO = null;
const TUTO_STONES = [
  { id: 'veine', seed: 4129, rock: 'quartzite', contents: [{ type: 'rien', joint: true }, { type: 'veine', joint: true, ore: 'cuivre' }] },
  { id: 'os', seed: 5813, rock: 'schiste', fat: true, contents: [{ type: 'rien' }, { type: 'os', fid: 'trilobite' }] }
];
function startTuto(then) {
  if (TUTO) return;
  closeSay(true); hideToast(); PENDING = null;
  if (CUR) endStone();
  /* sans WebGL, pas d'établi en 3D : on passe directement au terrain */
  if (!B3) { G.notes.tutoEtabli = 1; save(); if (then) then(); else show('carte'); return; }
  TUTO = { i: 0, step: '', then, fails: 0, noteT: 0, back: $('btnBack').innerHTML, t0: now() };
  Log.ev('tuto_debut');
  Ambient.setMode('joyeux');
  $('scr-etabli').classList.add('tuto'); $('app').classList.add('in-tuto');
  const el = document.createElement('div');
  el.className = 'tuto-coach'; el.setAttribute('role', 'status'); el.setAttribute('aria-live', 'polite');
  el.innerHTML = '<div class="ky-card"><span class="tc-face"></span><div class="ky-body"><div class="ky-name">' + KAYOU.name + '<span class="tc-step"></span>' +
    '<button class="tc-skip" type="button">' + TUTO_TXT.skip + '</button></div><p class="ky-text"></p><p class="tc-note"></p></div></div>';
  /* « Passer » se confirme : un doigt qui frôle le bouton ne fait pas sauter le tutoriel */
  const skip = el.querySelector('.tc-skip');
  skip.onclick = e => {
    e.stopPropagation(); Sound.play('tap');
    if (skip.classList.contains('sure')) { tutoFinish(); return; }
    skip.classList.add('sure'); skip.textContent = TUTO_TXT.skipSure;
    clearTimeout(TUTO.skipT); TUTO.skipT = setTimeout(() => { skip.classList.remove('sure'); skip.textContent = TUTO_TXT.skip; }, 3000);
  };
  /* la consigne vit en bas de l'établi, dans le flux : la pierre garde tout le haut de l'écran */
  $('benchBottom').prepend(el);
  TUTO.el = el;
  tutoLoad(0);
}
function tutoLoad(i) {
  const T = TUTO_STONES[i], R = T.rock ? ROCKS[T.rock] : null;
  TUTO.i = i; TUTO.fails = 0; TUTO.fatSaid = 0;
  /* la dernière pierre montre la fatigue : la jauge s'affiche et monte, sans jamais faire éclater la pierre */
  $('scr-etabli').classList.toggle('tuto-fat', !!T.fat);
  CUR = { tuto: true, stone: { rock: T.rock || 'quartzite', contents: T.contents }, state: 'ready', heard: {} };
  if (SCREEN !== 'etabli') show('etabli'); else renderBench();
  clearStage();
  $('btnBack').innerHTML = TUTO.back;
  Bench3D.load({ seed: T.seed, pal: R ? R.stone : NODULE, shape: R ? R.stone.shape : 'nodule', bedded: R ? !!R.bedded : false, contents: T.contents, loupe: 0, marteau: 0, target: G.set.cible, tuto: true, tutoFat: !!T.fat });
  setFatigue(0, 0);
  $('rockLabel').innerHTML = R ? '<img src="' + rockSwatch(T.rock, 48) + '" alt=""><div><b>' + R.name + '</b><span>' + TUTO_TXT[T.id].rock + '</span></div>'
    : '<div><b>Nodule</b><span>' + TUTO_TXT.geode.rock + '</span></div>';
  TUTO.el.querySelector('.tc-step').textContent = ' · pierre ' + (i + 1) + ' sur ' + TUTO_STONES.length;
  tutoStep(T.id === 'os' ? 'pic' : 'listen');
}
/* une étape : ce que dit le professeur, ce qui s'éclaire */
function tutoStep(step, P) {
  const T = TUTO_STONES[TUTO.i], X = TUTO_TXT[T.id];
  TUTO.step = step; TUTO.fails = 0;
  Log.ev('tuto_etape', { pierre: TUTO.i + 1, etape: step, s: Math.round((now() - TUTO.t0) / 1000) });
  let text = '', expr = 'conseil', g = null;
  if (T.id === 'geode') {
    if (step === 'listen') { text = X.listen; g = { glow: [1] }; }
    else { text = X.strike; expr = 'surpris'; g = { glow: [1] }; }
  } else if (T.id === 'veine') {
    if (step === 'listen') { text = X.listen; g = { glow: [0.7, 0.7] }; }
    else if (step === 'other') { text = X.pic; g = { glow: [0, 1] }; }
    else { text = X.strike; expr = 'content'; g = { glow: [0, 0.6], trail: { idx: 1, from: P } }; }
  } else {
    if (step === 'pic') { text = X.pic; g = { glow: [1, 0] }; }
    else if (step === 'pok') { text = X.pok; g = { glow: [0, 1] }; }
    else if (step === 'follow') { text = X.follow; expr = 'surpris'; g = { glow: [0, 0.6], trail: { idx: 1, from: P } }; }
    else { text = X.strike; expr = 'content'; g = { glow: [0, 0.6], trail: { idx: 1, from: P } }; }
  }
  tutoSay(text, expr);
  /* la pierre se présente : le fil à écouter, ou le cœur vers lequel mènent les marques */
  if (g) g.present = g.trail ? g.trail.idx : g.glow.findIndex(v => v >= 1) >= 0 ? g.glow.findIndex(v => v >= 1) : g.glow.findIndex(v => v > 0);
  Bench3D.guide(g);
}
function tutoSay(text, expr) {
  const el = TUTO.el;
  el.querySelector('.tc-face').innerHTML = kyFace(expr || 'conseil');
  el.querySelector('.ky-text').textContent = nbsp(text);
  el.querySelector('.tc-note').textContent = '';
  el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump');
  Sound.play('note');
}
/* une remarque brève, sous la consigne (la consigne reste) */
function tutoNote(t) {
  const n = TUTO.el.querySelector('.tc-note'); n.textContent = t;
  n.classList.remove('flash'); void n.offsetWidth; n.classList.add('flash');
  clearTimeout(TUTO.noteT); TUTO.noteT = setTimeout(() => { if (TUTO) n.textContent = ''; }, 2800);
}
/* ce qu'on entend en tapotant */
function tutoHeard(k, q, idx, P) {
  if (!TUTO || !CUR || CUR.state !== 'ready') return;
  const T = TUTO_STONES[TUTO.i], X = TUTO_TXT[T.id], st = TUTO.step;
  if (k === 'sourd') { tutoNote(T.fat ? TUTO_TXT.takFat : TUTO_TXT.tak); return; }
  if (T.fat && !TUTO.fatSaid && Bench3D.debug().rock && Bench3D.debug().rock.fatigue > 0.45) { TUTO.fatSaid = 1; tutoNote(TUTO_TXT.fatHigh); }
  if (T.id === 'geode') { if (k === 'bong' && st === 'listen') tutoStep('strike'); return; }
  /* un pic sur le bon fil : le contenu est plus loin, les marques montrent le chemin */
  const along = () => { tutoNote(TUTO_TXT.along); Bench3D.guide({ glow: [0, 1], trail: { idx: 1, from: P } }); };
  if (T.id === 'veine') {
    if (k === 'plein' && idx === 1 && st !== 'strike') along();
    else if (k === 'plein' && st === 'listen') tutoStep('other');
    else if (k === 'plein') tutoNote(X.wrong);
    else if (k === 'ting' && st !== 'strike') tutoStep('strike', P);
    return;
  }
  if (k === 'plein') { if (idx === 0 && st === 'pic') tutoStep('pok'); else if (idx === 1 && st !== 'pic') along(); else tutoNote(idx === 1 ? TUTO_TXT.listenLine : X.wrong); return; }
  if (k === 'creux') {
    if (q > 0.72) { if (st !== 'strike') tutoStep('strike', P); else Bench3D.guide({ glow: [0, 0.6], trail: { idx: 1, from: P } }); }
    else if (st !== 'follow') tutoStep('follow', P);
    else Bench3D.guide({ glow: [0, 0.6], trail: { idx: 1, from: P } });
  }
}
/* le coup : refusé (avec la correction) tant que le geste n'est pas le bon ; true l'accepte */
function tutoGate(o) {
  if (!TUTO) return true;
  const T = TUTO_STONES[TUTO.i], X = TUTO_TXT[T.id], st = TUTO.step, ready = st === 'strike';
  const no = msg => { TUTO.fails++; Log.ev('tuto_refus', { pierre: TUTO.i + 1, etape: st, raison: msg.split(' : ')[0] }); tutoNote(msg); Sound.play('tap'); return msg.split(' : ')[0].replace(/[.!]$/, ''); };
  if (!ready) return no(TUTO_TXT.listenFirst);
  if (o.idx < 0) return no(X.off);
  if (T.id === 'geode') {
    if (TUTO.fails >= 3) return true;
    if (o.soft || o.f < 0.3) return no(X.soft);
    if (o.f > 0.65) return no(X.hard);
    return true;
  }
  if (o.type === 'rien') return no(X.wrong);
  if (o.soft) return no(TUTO_TXT.soft);
  if (o.prox < (T.id === 'os' ? 0.6 : 0.5) && TUTO.fails < 2) return no(X.closer);
  return true;
}
/* la pierre s'ouvre : ce qui sort est garanti */
function tutoSplit(o) {
  const T = TUTO_STONES[TUTO.i];
  CUR.state = 'opening'; TUTO.step = 'opening';
  Bench3D.guide(null);
  TUTO.el.querySelector('.tc-note').textContent = '';
  buzz(T.id === 'os' ? [25, 30, 50] : 14);
  if (T.id === 'geode') return { k: 'geode', colors: GEODES.quartz, cracks: 0, damaged: false, slow: 0, climax: 0 };
  if (T.id === 'veine') return { k: 'ore', colors: ORES.cuivre, cracks: 0, damaged: false, slow: 0, climax: 0 };
  Sound.play('glow');
  /* la récompense du tutoriel : l'animal entier, bien lisible dans la face ouverte */
  return Object.assign(wholeCap(T.contents[1].fid), { cracks: 0, damaged: false, slow: 350, climax: 1 });
}
function tutoOpened() {
  if (!TUTO || !CUR) return;
  const T = TUTO_STONES[TUTO.i], X = TUTO_TXT[T.id], last = TUTO.i === TUTO_STONES.length - 1, halo = $('halo');
  CUR.state = 'open'; CUR.openAt = now(); TUTO.step = 'open';
  $('scr-etabli').classList.add('opened');
  const col = T.id === 'geode' ? GEODES.quartz.hi : T.id === 'veine' ? ORES.cuivre.hi : '#f3c64a';
  halo.className = T.id === 'os' ? 'halo gold big' : 'halo faint'; halo.innerHTML = raysSVG(col, T.id === 'os' ? 24 : 10);
  setTimeout(() => halo.classList.add('on'), 40);
  Sound.play(T.id === 'os' ? 'ident' : 'ore'); sparks(col);
  $('rTitle').textContent = X.title; $('rSub').textContent = X.sub;
  $('result').className = 'result show ' + (T.id === 'os' ? 't2' : 't1');
  tutoSay(X.done, 'content');
  $('btnBack').innerHTML = last ? ic('map') + TUTO_TXT.go : TUTO_TXT.next + ic('arrow');
  $('btnBack').hidden = false;
  setTimeout(() => { if (TUTO && !$('btnBack').hidden) $('btnBack').focus({ preventScroll: true }); }, 300);
}
function tutoNext() {
  if (!TUTO || !CUR || CUR.state !== 'open' || now() - CUR.openAt < 400) return;
  Sound.play('tap');
  if (TUTO.i < TUTO_STONES.length - 1) tutoLoad(TUTO.i + 1); else tutoFinish();
}
/* fin (ou « Passer ») : les mots appris ne seront plus réexpliqués ; on part vers le terrain */
function tutoFinish() {
  if (!TUTO) return;
  const t = TUTO; TUTO = null;
  Log.ev('tuto_fin', { pierre: t.i, passe: !(t.i === TUTO_STONES.length - 1 && t.step === 'open'), duree: Math.round((now() - t.t0) / 1000) });
  clearTimeout(t.noteT); clearTimeout(t.skipT);
  if (B3) { Bench3D.guide(null); Bench3D.clear(); }
  CUR = null;
  clearStage();
  $('btnBack').innerHTML = t.back;
  t.el.remove(); $('scr-etabli').classList.remove('tuto', 'tuto-fat'); $('app').classList.remove('in-tuto');
  Ambient.setMode('calme');
  G.notes.tutoEtabli = 1; G.notes.pierre = 1; G.notes.ting = 1; save();
  if (t.then) t.then(); else show(G.stone ? 'etabli' : 'carte');
}
