/* ============ fossiles : Silurien ============ */

/* calymene — Calymene blumenbachii, « criquet de Dudley », vue dorsale.
   ① glabelle en cloche à 3 paires de lobes ; ② petits yeux ; ③ angles génaux arrondis ; ④ 13 segments, lobe axial fort ;
   ⑤ petit pygidium à ~6 anneaux ; ⑥ granulations */
function artCalymene(p) {
  const cx = 100, rnd = mulberry32(hashStr('calymene'));
  const cephArc = []; for (let i = 0; i <= 18; i++) { const a = lerp(1.5 * Math.PI, Math.PI, i / 18); cephArc.push([cx + 76 * Math.cos(a), 96 + 80 * Math.sin(a)]); }
  const N = 13, y0 = 98, sh = 8.8, aw = k => lerp(25, 17, k / (N - 1)), xs = k => lerp(71, 58, k / (N - 1));
  const pyTop = y0 + N * sh;
  let s = '';
  /* pygidium : bouclier arrondi, côtes pleurales, anneaux axiaux */
  const pyg = col => E.p('M' + (cx - 52) + ' ' + r1(pyTop) + 'Q' + (cx - 54) + ' ' + r1(pyTop + 40) + ' ' + cx + ' ' + r1(pyTop + 46) + 'L' + cx + ' ' + r1(pyTop) + 'Z', col, p.line, 1.2) +
    E.p('M' + (cx - 17) + ' ' + r1(pyTop + 8) + 'Q' + (cx - 34) + ' ' + r1(pyTop + 12) + ' ' + (cx - 44) + ' ' + r1(pyTop + 20) + 'M' + (cx - 15) + ' ' + r1(pyTop + 17) + 'Q' + (cx - 30) + ' ' + r1(pyTop + 23) + ' ' + (cx - 38) + ' ' + r1(pyTop + 31) + 'M' + (cx - 12) + ' ' + r1(pyTop + 26) + 'Q' + (cx - 22) + ' ' + r1(pyTop + 32) + ' ' + (cx - 28) + ' ' + r1(pyTop + 39), null, p.line, 0.8);
  s += pyg(p.body) + mirrorG(pyg(p.body2), cx);
  s += E.p('M' + (cx - 17) + ' ' + r1(pyTop) + 'L' + (cx - 6) + ' ' + r1(pyTop + 38) + 'Q' + cx + ' ' + r1(pyTop + 42) + ' ' + (cx + 6) + ' ' + r1(pyTop + 38) + 'L' + (cx + 17) + ' ' + r1(pyTop) + 'Z', p.relief, p.line, 0.9);
  let pr = ''; for (let k = 1; k <= 6; k++) { const y = pyTop + k * 6, w = lerp(16, 6, k / 6); pr += 'M' + r1(cx - w) + ' ' + r1(y) + 'Q' + cx + ' ' + r1(y - 2) + ' ' + r1(cx + w) + ' ' + r1(y); }
  s += E.p(pr, null, p.line, 0.7);
  /* thorax : plèvres (moitié gauche + miroir), anneaux axiaux bombés */
  const pleurae = col => {
    let o = '', fur = '';
    for (let k = N - 1; k >= 0; k--) {
      const y = y0 + k * sh, a = aw(k), e = xs(k);
      o += E.p(smoothD([[cx - a, y], [cx - e + 4, y + 1.5], [cx - e - 1, y + sh * 0.5 + 1.5], [cx - e + 3, y + sh + 2.2], [cx - a, y + sh]], true), col, p.line, 0.9);
      fur += 'M' + r1(cx - a - 1) + ' ' + r1(y + sh * 0.45) + 'Q' + r1(cx - (a + e) / 2) + ' ' + r1(y + sh * 0.5) + ' ' + r1(cx - e + 4) + ' ' + r1(y + sh * 0.75);
    }
    return o + E.p(fur, null, p.line, 0.7, 'opacity=".8"');
  };
  s += pleurae(p.body) + mirrorG(pleurae(p.body2), cx);
  let ax = '';
  for (let k = N - 1; k >= 0; k--) { const y = y0 + k * sh, a = aw(k); ax += E.p('M' + r1(cx - a) + ' ' + r1(y + 1) + 'Q' + cx + ' ' + r1(y - 4) + ' ' + r1(cx + a) + ' ' + r1(y + 1) + 'L' + r1(cx + a - 1) + ' ' + r1(y + sh) + 'Q' + cx + ' ' + r1(y + sh - 4) + ' ' + r1(cx - a + 1) + ' ' + r1(y + sh) + 'Z', p.relief, p.line, 0.9); }
  s += ax;
  /* céphalon */
  const ceph = col => E.p(polyD([[cx, 100]].concat(cephArc, [[26, 100]]), true), col, p.line, 1.3);
  s += ceph(p.body) + mirrorG(ceph(p.body2), cx);
  const rim = E.p(polyD(cephArc.slice(0, 16).map(q => [cx + (q[0] - cx) * 0.9, 96 + (q[1] - 96) * 0.86])), null, p.line, 0.9);
  s += rim + mirrorG(rim, cx);
  /* joues : yeux, sutures, granulations */
  const cheek = E.el(cx - 44, 62, 7, 5, -20, p.relief, p.line, 0.8) + E.p('M' + (cx - 49) + ' 59Q' + (cx - 51) + ' 64 ' + (cx - 47) + ' 67', null, p.accent, 2.2) +
    E.p('M' + (cx - 40) + ' 56Q' + (cx - 34) + ' 36 ' + (cx - 26) + ' 24M' + (cx - 48) + ' 68Q' + (cx - 62) + ' 86 ' + (cx - 72) + ' 98', null, p.line, 0.6, DASH);
  s += cheek + mirrorG(cheek, cx);
  s += sk_dots(rnd, [[34, 96], [44, 58], [70, 34], [100, 26], [130, 34], [156, 58], [166, 96]], 60, 0.8, p.shade, 0.7);
  /* glabelle en cloche, 3 paires de lobes */
  const gl = [];
  for (let i = 0; i <= 26; i++) { const y = 24 + i * 2.8, t = (y - 24) / 72, w = 13 + 15 * t + 4.5 * Math.exp(-Math.pow((y - 46) / 5, 2)) + 5.5 * Math.exp(-Math.pow((y - 62) / 6, 2)) + 7.5 * Math.exp(-Math.pow((y - 80) / 6.5, 2)); gl.push([cx + w, y]); }
  const glab = [[cx, 20]].concat(gl, gl.slice().reverse().map(q => [2 * cx - q[0], q[1]]));
  s += E.p(smoothD(glab, true), p.relief, p.line, 1.1);
  s += E.p('M' + (cx - 20) + ' 53Q' + (cx - 14) + ' 55 ' + (cx - 11) + ' 60M' + (cx + 20) + ' 53Q' + (cx + 14) + ' 55 ' + (cx + 11) + ' 60M' + (cx - 24) + ' 71Q' + (cx - 17) + ' 73 ' + (cx - 13) + ' 78M' + (cx + 24) + ' 71Q' + (cx + 17) + ' 73 ' + (cx + 13) + ' 78', null, p.line, 1);
  s += E.p('M' + (cx - 30) + ' 94Q' + cx + ' 88 ' + (cx + 30) + ' 94', null, p.line, 0.9);
  s += sk_dots(rnd, glab, 36, 0.7, p.hi, 0.6);
  /* reflet */
  s += E.p('M' + (cx - 8) + ' 30Q' + (cx - 16) + ' 40 ' + (cx - 17) + ' 54', null, p.hi, 2, 'opacity=".75"') + E.p('M36 70Q48 42 80 28', null, p.hi, 2, 'opacity=".6"');
  return s;
}

/* halysites — Halysites catenularia, corail chaînette, colonie vue de dessus.
   ① colonie arrondie avec bord ; ② palissades de corallites ovales soudées en chaînes ; ③ lacunes polygonales ; ④ lumière sombre de chaque tube */
function artHalysites(p) {
  const rnd = mulberry32(hashStr('halysites')), cx = 115, cy = 110;
  const out = []; for (let i = 0; i < 26; i++) { const a = i / 26 * TAU, r = 1 + (fbm(Math.cos(a) * 1.3 + 3, Math.sin(a) * 1.3 + 7, 41, 3) - 0.5) * 0.22; out.push([cx + Math.cos(a) * 98 * r, cy + Math.sin(a) * 92 * r]); }
  let s = E.p(smoothD(out, true), p.body, p.line, 1.4);
  const inner = out.map(q => [cx + (q[0] - cx) * 0.93, cy + (q[1] - cy) * 0.93]);
  s += E.p(smoothD(inner, true), p.shade, p.line, 0.8);
  /* réseau : arêtes de Voronoï de 11 graines, corallites posées le long des arêtes et du bord */
  const seeds = blockSeeds(11, { cx, cy, rx: 82, ry: 76 }, hashStr('halysites-net')), cells = voronoiCells(seeds, 230, 220), edges = voronoiEdges(cells, seeds);
  const ring = smoothD(inner, true) && inner, lim = inner.map(q => [cx + (q[0] - cx) * 0.97, cy + (q[1] - cy) * 0.97]);
  let wall = '', lum = '', chain = '';
  const coral = (a, b) => {
    const L = Math.hypot(b[0] - a[0], b[1] - a[1]), n = Math.max(1, Math.round(L / 7.6)), ux = (b[0] - a[0]) / L, uy = (b[1] - a[1]) / L;
    let run = '', on = false;
    for (let i = 0; i < n; i++) {
      const c = [a[0] + (b[0] - a[0]) * (i + 0.5) / n, a[1] + (b[1] - a[1]) * (i + 0.5) / n];
      if (!pointInPoly(lim, c)) { on = false; continue; }
      run += (on ? 'L' : 'M') + PS(c); on = true;
      const h = L / n / 2 + 1, w = 4, rot = Math.atan2(uy, ux) / D2R;
      const e1 = [c[0] - ux * h, c[1] - uy * h], e2 = [c[0] + ux * h, c[1] + uy * h];
      wall += 'M' + PS(e1) + 'A' + r1(h) + ' ' + w + ' ' + r1(rot) + ' 1 0 ' + PS(e2) + 'A' + r1(h) + ' ' + w + ' ' + r1(rot) + ' 1 0 ' + PS(e1) + 'Z';
      const f1 = [c[0] - ux * h * 0.55, c[1] - uy * h * 0.55], f2 = [c[0] + ux * h * 0.55, c[1] + uy * h * 0.55];
      lum += 'M' + PS(f1) + 'A' + r1(h * 0.55) + ' 1.8 ' + r1(rot) + ' 1 0 ' + PS(f2) + 'A' + r1(h * 0.55) + ' 1.8 ' + r1(rot) + ' 1 0 ' + PS(f1) + 'Z';
    }
    chain += run;
  };
  edges.forEach(e => coral(e[0], e[1]));
  for (let i = 0; i < ring.length; i++) if (i % 2 === 0) coral(ring[i].map((v, k) => (k ? cy : cx) + (v - (k ? cy : cx)) * 0.9), ring[(i + 1) % ring.length].map((v, k) => (k ? cy : cx) + (v - (k ? cy : cx)) * 0.9));
  s += E.p(chain, null, p.line, 9.5) + E.p(chain, null, p.relief, 7.5) + E.p(wall, p.relief, p.line, 0.6) + E.p(lum, p.accent, null, 0, 'opacity="' + (p.flat ? 1 : 0.8) + '"');
  void rnd;
  /* reflet */
  s += E.p('M36 84Q52 40 100 22', null, p.hi, 2.4, 'opacity=".7"');
  return s;
}

/* cooksonia — Cooksonia pertoni, l'une des premières plantes.
   ① tiges fines depuis une base commune ; ② dichotomies en Y ; ③ sporanges réniformes au bout des branches ; ④ film de carbone */
function artCooksonia(p) {
  const rnd = mulberry32(hashStr('cooksonia'));
  let stems = '', spor = '';
  const branch = (b, ang, len, w, depth) => {
    const a = ang * D2R, e = [b[0] + Math.sin(a) * len, b[1] - Math.cos(a) * len], bend = (rnd() - 0.5) * 0.18 * len;
    const m = [lerp(b[0], e[0], 0.5) + Math.cos(a) * bend, lerp(b[1], e[1], 0.5) + Math.sin(a) * bend];
    stems += E.p(taperD(quadPts(b, m, e, 8), w, w * 0.82), p.body, p.line, 0.7);
    if (depth < 2) { const sp = 13 + rnd() * 6; branch(e, ang - sp, len * (0.68 + rnd() * 0.1), w * 0.8, depth + 1); branch(e, ang + sp, len * (0.68 + rnd() * 0.1), w * 0.8, depth + 1); }
    else {
      const c = [e[0] + Math.sin(a) * 4, e[1] - Math.cos(a) * 4];
      spor += E.p('M' + PS([e[0] - Math.cos(a) * 2, e[1] - Math.sin(a) * 2]) + 'L' + PS([c[0] - Math.cos(a) * 6.5, c[1] - Math.sin(a) * 6.5]) + 'L' + PS([c[0] + Math.cos(a) * 6.5, c[1] + Math.sin(a) * 6.5]) + 'L' + PS([e[0] + Math.cos(a) * 2, e[1] + Math.sin(a) * 2]) + 'Z', p.body, p.line, 0.6) +
        E.el(c[0] + Math.sin(a) * 2.5, c[1] - Math.cos(a) * 2.5, 9, 6, ang, p.relief, p.line, 0.9) +
        E.p('M' + PS([c[0] + Math.sin(a) * 6.2 - Math.cos(a) * 6, c[1] - Math.cos(a) * 6.2 - Math.sin(a) * 6]) + 'Q' + PS([c[0] + Math.sin(a) * 9.5, c[1] - Math.cos(a) * 9.5]) + ' ' + PS([c[0] + Math.sin(a) * 6.2 + Math.cos(a) * 6, c[1] - Math.cos(a) * 6.2 + Math.sin(a) * 6]), null, p.line, 0.7) +
        E.p('M' + PS([c[0] - Math.cos(a) * 5, c[1] - Math.sin(a) * 5 - 1]) + 'q2 -3 5 -2', null, p.hi, 1.1, 'opacity=".6"');
    }
  };
  const base = [112, 246];
  branch(base, -21, 80, 5.2, 0);
  branch(base, -4, 96, 5.6, 0);
  branch(base, 19, 78, 5, 0);
  let s = E.p('M84 248Q98 243 110 246Q126 249 142 245M92 252Q104 250 116 252', null, p.line, 1.6, 'opacity=".75"');
  s += stems + spor;
  return s;
}

/* eurypterus — Eurypterus remipes, scorpion de mer, vue dorsale.
   ① prosome trapézoïdal ; ② yeux réniformes, ocelles ; ③ 4 paires de pattes épineuses + grandes rames nageuses ;
   ④ 7 larges segments puis 5 étroits ; ⑤ telson en longue épine */
function artEurypterus(p) {
  const cx = 115;
  const W = [47, 51, 52, 50, 46, 41, 36], PRE = 84, h1 = 12.8, POST = PRE + 7 * h1, h2 = 14.6, pw = [21, 18.5, 16, 14, 13];
  let s = '';
  /* pattes (moitié gauche) : 4 marcheuses épineuses, 1 nageuse à rame */
  const legs = col => {
    let o = '', sp = '';
    for (let i = 0; i < 4; i++) {
      const b = [cx - 30, 40 + i * 10], ang = (196 - i * 16) * D2R, L = 26 + i * 5;
      const j1 = [b[0] + Math.cos(ang) * L * 0.45, b[1] + Math.sin(ang) * L * 0.45], j2 = [b[0] + Math.cos(ang - 0.35) * L * 0.8, b[1] + Math.sin(ang - 0.35) * L * 0.8], e = [b[0] + Math.cos(ang - 0.55) * L, b[1] + Math.sin(ang - 0.55) * L];
      o += 'M' + PS(b) + 'L' + PS(j1) + 'L' + PS(j2) + 'L' + PS(e);
      [j1, j2].forEach(q => { sp += 'M' + PS(q) + 'l' + r1(Math.cos(ang + 1.9) * 4) + ' ' + r1(Math.sin(ang + 1.9) * 4); });
    }
    let r = sk_str(o, 2.6, p, col) + E.p(sp, null, p.line, 0.8);
    const sw = [[cx - 30, 78], [cx - 54, 90], [cx - 72, 110], [cx - 82, 132]];
    for (let i = 0; i < 3; i++) r += E.p(taperD([sw[i], sw[i + 1]], 8.5 - i, 7.5 - i), col, p.line, 0.9);
    r += E.el(cx - 88, 152, 12, 22, 12, col, p.line, 1) + E.p('M' + (cx - 84) + ' 134Q' + (cx - 90) + ' 150 ' + (cx - 92) + ' 168', null, p.line, 0.6, 'opacity=".7"') + E.el(cx - 93, 176, 3.5, 6, 20, col, p.line, 0.7);
    return r;
  };
  s += legs(p.body) + mirrorG(legs(p.body2), cx);
  /* telson */
  s += E.p(taperD([[cx, POST + 5 * h2 - 4], [cx, POST + 5 * h2 + 30], [cx, 314]], 10, 0.8), p.relief, p.line, 0.9);
  /* post-abdomen (5 anneaux étroits), du dernier au premier */
  for (let k = 4; k >= 0; k--) { const y = POST + k * h2, w0 = pw[k], w1 = k < 4 ? pw[k + 1] : 11; s += E.p('M' + r1(cx - w0) + ' ' + r1(y) + 'Q' + cx + ' ' + r1(y - 3) + ' ' + r1(cx + w0) + ' ' + r1(y) + 'L' + r1(cx + w1 + (k === 4 ? 4 : 0)) + ' ' + r1(y + h2 + 1) + 'Q' + cx + ' ' + r1(y + h2 - 2) + ' ' + r1(cx - w1 - (k === 4 ? 4 : 0)) + ' ' + r1(y + h2 + 1) + 'Z', k % 2 ? p.body2 : p.body, p.line, 0.9); }
  /* pré-abdomen (7 tergites larges) */
  let orn = '';
  for (let k = 6; k >= 0; k--) {
    const y = PRE + k * h1, w0 = W[k], w1 = k < 6 ? W[k + 1] : pw[0] + 2;
    const half = col => E.p('M' + cx + ' ' + r1(y - 3) + 'Q' + r1(cx - w0 * 0.6) + ' ' + r1(y - 3) + ' ' + r1(cx - w0) + ' ' + r1(y + 1) + 'Q' + r1(cx - w0 - 3) + ' ' + r1(y + h1 * 0.6) + ' ' + r1(cx - w1 - 1) + ' ' + r1(y + h1 + 1) + 'Q' + r1(cx - w1 * 0.5) + ' ' + r1(y + h1 - 2) + ' ' + cx + ' ' + r1(y + h1 - 2) + 'Z', col, p.line, 0.9);
    s += half(p.body) + mirrorG(half(p.body2), cx);
    for (let j = -3; j <= 3; j++) orn += 'M' + r1(cx + j * w0 * 0.24) + ' ' + r1(y + h1 * 0.62) + 'l1.2 1.6';
  }
  s += E.p(orn, null, p.line, 0.7, 'opacity=".6"');
  /* prosome */
  const pro = col => E.p('M' + cx + ' 16Q' + (cx - 30) + ' 16 ' + (cx - 38) + ' 32Q' + (cx - 48) + ' 56 ' + (cx - 47) + ' 84L' + cx + ' 84Z', col, p.line, 1.3);
  s += pro(p.body) + mirrorG(pro(p.body2), cx);
  s += E.p('M' + (cx - 40) + ' 38Q' + (cx - 44) + ' 58 ' + (cx - 42) + ' 80M' + (cx + 40) + ' 38Q' + (cx + 44) + ' 58 ' + (cx + 42) + ' 80', null, p.line, 0.7, 'opacity=".6"');
  const eye = E.p('M' + (cx - 30) + ' 34Q' + (cx - 40) + ' 40 ' + (cx - 36) + ' 54Q' + (cx - 28) + ' 50 ' + (cx - 26) + ' 42Q' + (cx - 26) + ' 36 ' + (cx - 30) + ' 34Z', p.accent, p.line, 0.9) + E.p('M' + (cx - 34) + ' 40l1 2M' + (cx - 33) + ' 46l1 2', null, p.hi, 1.2, 'opacity=".6"');
  s += eye + mirrorG(eye, cx) + E.c(cx - 3, 50, 1.6, p.accent) + E.c(cx + 3, 50, 1.6, p.accent);
  s += E.p('M' + (cx - 34) + ' 26Q' + (cx - 20) + ' 18 ' + (cx - 4) + ' 19', null, p.hi, 2, 'opacity=".7"') + E.p('M' + (cx - 40) + ' ' + (PRE + 6) + 'Q' + (cx - 46) + ' ' + (PRE + 40) + ' ' + (cx - 40) + ' ' + (PRE + 76), null, p.hi, 1.6, 'opacity=".5"');
  return s;
}

/* guiyu — Guiyu oneiros, pièce unique, plus ancien poisson osseux complet, de profil.
   ① corps fuselé ; ② tête cuirassée de plaques, grand œil ; ③ écailles rhombiques en rangées obliques ;
   ④ nageoires à lobe charnu et épines, dorsale précédée d'une épine ; ⑤ queue hétérocerque */
function artGuiyu(p) {
  const OUT = [[14, 80], [20, 64], [38, 52], [70, 44], [110, 40], [160, 42], [210, 50], [250, 58], [284, 50], [312, 38], [306, 52], [292, 70], [300, 102], [278, 92], [260, 86], [220, 98], [160, 106], [100, 108], [60, 102], [34, 94], [20, 88]];
  let s = '';
  /* nageoires (derrière le corps) */
  const fin = (base, tip, back, col) => E.p(smoothD([base, tip, back], true), p.film, p.line, 0.8, 'fill-opacity="' + (p.flat ? 1 : 0.6) + '"') +
    E.p([0.25, 0.5, 0.75].map(t => 'M' + PS(lerpPt(base, back, t)) + 'L' + PS(lerpPt(tip, back, t * 0.6))).join(''), null, p.line, 0.5, 'opacity=".7"') + (col ? '' : '');
  s += fin([214, 50], [236, 24], [250, 56]) + fin([236, 96], [252, 118], [262, 90]);
  s += fin([150, 40], [168, 12], [184, 44]);
  s += E.p(taperD([[128, 42], [138, 26], [150, 10]], 7, 1), p.relief, p.line, 0.9) + E.p('M118 42Q132 36 148 42', null, p.line, 0.9);
  /* corps */
  s += E.p(smoothD(OUT, true), p.body, p.line, 1.3);
  /* écailles rhombiques (deux familles de lignes obliques, coupées au contour) */
  const body = sk_spline(OUT, 5, true);
  let sc = '';
  const fam = (dx, dy, step) => {
    for (let k = -60; k < 60; k++) {
      let seg = '', on = false;
      for (let t = 0; t <= 1; t += 0.012) {
        const x = 150 + dx * (t - 0.5) * 380 - dy * k * step, y = 75 + dy * (t - 0.5) * 380 + dx * k * step;
        const ins = x > 86 && x < 266 && pointInPoly(body, [x, y]);
        if (ins) { seg += (on ? 'L' : 'M') + r1(x) + ' ' + r1(y); on = true; } else on = false;
      }
      sc += seg;
    }
  };
  fam(0.88, -0.47, 7.5); fam(0.47, 0.88, 7.5);
  s += E.p(sc, null, p.line, 0.5, 'opacity=".55"');
  /* ligne latérale */
  let ll = ''; for (let x = 92; x < 262; x += 6) ll += 'M' + x + ' ' + r1(72 + (x - 92) * -0.04) + 'h.1';
  s += E.p(ll, null, p.hi, 2, 'opacity=".7"');
  /* tête cuirassée */
  s += E.p('M14 80Q18 60 40 50Q64 42 86 44L92 76L86 104Q60 104 34 96Q18 90 14 80Z', p.relief, p.line, 1);
  s += E.p('M40 50Q48 64 44 74M58 46Q70 58 88 58M62 76Q76 72 90 76M50 88Q64 84 88 96M86 44Q98 74 86 104', null, p.line, 0.8);
  s += E.c(40, 66, 8.5, p.accent, p.line, 1) + E.c(37.5, 63.5, 2.2, p.hi, null, 0, 'opacity=".75"') + E.p('M16 82L34 86', null, p.line, 1);
  /* nageoires paires à lobe charnu, avec épines */
  const lobe = (b, e, w) => E.p(taperD([b, lerpPt(b, e, 0.5), e], w, w * 0.35), p.shade, p.line, 0.9) + E.p(taperD([[b[0] - 2, b[1] - 1], lerpPt(b, e, 0.5), [e[0] - 4, e[1] + 3]], 3, 1), p.relief, p.line, 0.6);
  s += lobe([96, 100], [128, 126], 13) + E.p(taperD([[94, 98], [110, 118], [132, 132]], 4, 0.8), p.relief, p.line, 0.7);
  s += lobe([176, 104], [200, 124], 11) + E.p(taperD([[174, 102], [188, 116], [204, 128]], 3.4, 0.8), p.relief, p.line, 0.7);
  /* reflet */
  s += E.p('M24 64Q44 48 74 46', null, p.hi, 2.2, 'opacity=".7"') + E.p('M110 48Q170 44 230 58', null, p.hi, 1.6, 'opacity=".45"');
  return s;
}

Object.assign(ART, {
  calymene: { vb: [200, 290], fn: artCalymene, area: { cx: 100, cy: 140, rx: 76, ry: 124 } },
  halysites: { vb: [230, 220], fn: artHalysites, area: { cx: 115, cy: 110, rx: 96, ry: 90 } },
  cooksonia: { vb: [220, 260], fn: artCooksonia, area: { cx: 110, cy: 132, rx: 96, ry: 118 } },
  eurypterus: { vb: [230, 320], fn: artEurypterus, area: { cx: 115, cy: 160, rx: 92, ry: 148 } },
  guiyu: { vb: [320, 150], fn: artGuiyu, area: { cx: 160, cy: 74, rx: 150, ry: 50 } }
});
