/* ============ fossiles : Néogène & Quaternaire ============ */
/* aides préfixées nq_ (seuls noms de haut niveau avec les art<Id>) */
function nq_op(p, o) { return 'opacity="' + (p.flat ? 1 : o) + '"'; }
/* points (pores, granulations) : segments nuls à bouts ronds, tous dans un seul d */
function nq_dotsD(pts) { let d = ''; for (let i = 0; i < pts.length; i++) d += 'M' + PS(pts[i]) + 'h0'; return d; }
function nq_dots(pts, col, w, extra) { return pts.length ? E.p(nq_dotsD(pts), null, col, w, 'stroke-linecap="round"' + (extra ? ' ' + extra : '')) : ''; }
/* point dans un polygone */
function nq_inPoly(q, poly) {
  let c = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i], b = poly[j];
    if ((a[1] > q[1]) !== (b[1] > q[1]) && q[0] < (b[0] - a[0]) * (q[1] - a[1]) / (b[1] - a[1]) + a[0]) c = !c;
  }
  return c;
}
/* semis de points reproductible dans un polygone (texture mate, os poreux) */
function nq_stipple(poly, n, seed, pad) {
  const rnd = mulberry32(seed), out = [];
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  poly.forEach(q => { x0 = Math.min(x0, q[0]); y0 = Math.min(y0, q[1]); x1 = Math.max(x1, q[0]); y1 = Math.max(y1, q[1]); });
  for (let k = 0; k < n * 8 && out.length < n; k++) {
    const q = [lerp(x0, x1, rnd()), lerp(y0, y1, rnd())];
    if (!nq_inPoly(q, poly)) continue;
    if (pad && poly.some(v => Math.hypot(v[0] - q[0], v[1] - q[1]) < pad)) continue;
    out.push(q);
  }
  return out;
}
/* bord dentelé : dents triangulaires le long de pts, côté normal `side` (±1), hauteur h(t) */
function nq_serrate(pts, n, h, side) {
  const P = resample(pts, n * 2 + 1), out = [];
  for (let i = 0; i < P.length; i++) {
    if (i % 2 === 0) { out.push(P[i]); continue; }
    const t = tangentAt(P, i), k = typeof h === 'function' ? h(i / (P.length - 1)) : h;
    out.push([P[i][0] - t[1] * k * side + t[0] * k * 0.35, P[i][1] + t[0] * k * side + t[1] * k * 0.35]);
  }
  return out;
}
/* décalage d'une polyligne le long de sa normale (distance fixe ou fonction de t) */
function nq_offset(pts, dist) {
  return pts.map((q, i) => { const t = tangentAt(pts, i), k = typeof dist === 'function' ? dist(i / (pts.length - 1)) : dist; return [q[0] - t[1] * k, q[1] + t[0] * k]; });
}

/* ---------------- pecten — Pecten jacobaeus (valve droite, bombée) ----------------
   ① valve en éventail : crochet en haut au centre, bords dorsaux droits (angle apical ~104°), bord ventral en arc de cercle ;
   ② deux oreillettes à peu près égales, bord cardinal droit (le « T » du haut), costules rayonnantes ;
   ③ 15 côtes radiales larges à sommet plat (3 costules), sillons plus étroits : rotation autour du crochet, couleurs alternées ;
   ④ stries de croissance = homothéties du bord (centre : crochet), de plus en plus serrées vers le bord ;
   ⑤ bord ventral festonné : chaque côte fait une festonnure. */
function artPecten(p) {
  const U = [120, 38], h = 83, R = 97, al = 54 * D2R, N = 15, u = 2 * al / N, hw = u * 0.37, A = 2.8;
  const tR = f => h * Math.cos(f) + Math.sqrt(R * R - h * h * Math.sin(f) * Math.sin(f));
  const at = (f, r) => [U[0] + Math.sin(f) * r, U[1] + Math.cos(f) * r];
  const M = [];
  for (let k = 0; k < N; k++) { const fc = -al + u * (k + 0.5); M.push([-al + u * k, -1.2], [fc - hw, A * 0.8], [fc, A], [fc + hw, A * 0.8]); }
  M.push([al, -1.2]);
  const edge = s => M.map(([f, dr]) => at(f, (tR(f) + dr) * s));
  const E1 = edge(1);
  /* oreillettes */
  const ear = col => {
    const a = [68, 33], b = [70.5, 57], c = at(-al, 40);
    let o = E.p('M120 34L' + PS(a) + 'Q67 45 ' + PS(b) + 'L' + PS(c) + 'L' + PS(U) + 'Z', col, p.line, 1.1);
    let r = '';
    for (let k = 1; k <= 4; k++) { const q = lerpPt(a, b, k / 5); r += 'M' + PS(lerpPt([118, 36], q, 0.18)) + 'L' + PS(lerpPt(q, [118, 36], 0.04)); }
    return o + E.p(r, null, p.line, 0.55, 'opacity=".7"');
  };
  let s = ear(p.body) + mirrorG(ear(p.body2), 120);
  const disc = 'M' + PS(U) + smoothD(E1).replace(/^M/, 'L') + 'Z';
  s += E.p(disc, p.shade);
  /* côtes (rotation autour du crochet) */
  let dA = '', dB = '', cost = '';
  for (let i = 0; i < N; i++) {
    const fc = -al + u * (i + 0.5), fL = fc - hw, fR = fc + hw;
    const b0 = at(fL, tR(fL) + A * 0.8 - 0.4), b1 = at(fR, tR(fR) + A * 0.8 - 0.4), m = at(fc, tR(fc) + A - 0.4);
    const cq = [2 * m[0] - (b0[0] + b1[0]) / 2, 2 * m[1] - (b0[1] + b1[1]) / 2];
    const d = 'M' + PS(at(fL, 14)) + 'L' + PS(b0) + 'Q' + PS(cq) + ' ' + PS(b1) + 'L' + PS(at(fR, 14)) + 'Z';
    if (i % 2) dB += d; else dA += d;
    cost += 'M' + PS(at(fc, tR(fc) * 0.5)) + 'L' + PS(at(fc, tR(fc) * 0.97));
  }
  s += E.p(dA, p.relief, p.line, 0.6) + E.p(dB, p.body, p.line, 0.6);
  s += E.p(cost, null, p.line, 0.45, 'opacity=".35"');
  /* stries de croissance, serrées vers le bord */
  let gl = '';
  for (let k = 1; k <= 10; k++) { const x = k / 11, sc = 1 - 0.8 * (1 - x) * (1 - x) - 0.035; gl += polyD(edge(sc)); }
  s += E.p(gl, null, p.line, 0.5, 'opacity=".5"');
  /* ombre bas-droite (valve bombée) */
  const f0 = -0.2, sh = [], shi = [];
  M.forEach(([f, dr]) => {
    if (f < f0) return;
    const w = Math.sin(Math.PI * (f - f0) / (al - f0 + 0.06));
    sh.push(at(f, tR(f) + dr)); shi.push(at(f, (tR(f) + dr) * (1 - 0.2 * w)));
  });
  s += E.p(polyD(sh.concat(shi.reverse()), true), p.shade, null, 0, nq_op(p, 0.35));
  s += E.p(disc, null, p.line, 1.3);
  /* crochet lisse */
  s += E.p('M' + PS(at(-al, 19)) + 'L' + PS(U) + 'L' + PS(at(al, 19)) + 'Q' + PS(at(0, 27)) + ' ' + PS(at(-al, 19)) + 'Z', p.relief, p.line, 0.8);
  /* reflet : lustre sur le sommet d'une côte, en haut à gauche */
  const fh = -al + u * 3.5;
  s += E.p('M' + PS(at(fh, 30)) + 'L' + PS(at(fh, tR(fh) * 0.62)), null, p.hi, 2.4, 'opacity=".72"');
  return s;
}

/* ---------------- clypeaster — Clypeaster altus (vu de dessus) ----------------
   ① contour pentagonal aux coins arrondis (coins au bout des pétales), rebord épais ;
   ② fleur de 5 pétales larges en feuille, presque fermés au bout, sur ~60 % du rayon (rotation de 72°) ;
   ③ zones porifères : deux rangées de pores le long de chaque bord de pétale, reliées par des sillons (pores conjugués) ;
   ④ disque apical central pentagonal, 5 gonopores entre les pétales ;
   ⑤ fines granulations régulières ; dôme bombé : ombre en bas à droite, reflet en haut à gauche.
   (≠ oursin cœur : contour pentagonal, symétrie d'ordre 5, pétales égaux, pas de sillon antérieur) */
function artClypeaster(p) {
  const O = [115, 120], R0 = 99, th0 = -Math.PI / 2;
  const rad = th => R0 * (1 + 0.068 * Math.cos(5 * (th - th0)) + 0.006 * Math.cos(10 * (th - th0)));
  const at = (th, r) => [O[0] + Math.cos(th) * r, O[1] + Math.sin(th) * r];
  const ring = (k, n) => { const o = []; for (let i = 0; i < n; i++) { const th = th0 + i / n * TAU; o.push(at(th, rad(th) * k)); } return o; };
  let s = E.p(smoothD(ring(1, 30), true), p.body, p.line, 1.4);
  /* granulation : tubercules en rangs concentriques */
  let gr = '';
  for (let k = 0.2; k < 0.97; k += 0.075) gr += polyD(ring(k, 30), true);
  s += E.p(gr, null, p.shade, 1.3, 'stroke-linecap="round" stroke-dasharray="0 4.8" ' + nq_op(p, 0.7));
  /* dôme : face éclairée (haut-gauche) et ombre propre (bas-droite) */
  const band = (a0, a1, k0, k1) => {
    const o = [], q = [];
    for (let i = 0; i <= 30; i++) { const th = lerp(a0, a1, i / 30), w = Math.sin(Math.PI * i / 30); o.push(at(th, rad(th) * k0)); q.push(at(th, rad(th) * (k0 - k1 * w))); }
    return polyD(o.concat(q.reverse()), true);
  };
  s += E.p(band(-3.55, -0.75, 0.87, 0.2), p.relief, null, 0, nq_op(p, 0.45));
  s += E.p(smoothD(ring(0.885, 30), true), null, p.line, 0.8, 'opacity=".7"');
  s += E.p(band(-0.55, 2.65, 0.992, 0.3), p.shade, null, 0, nq_op(p, 0.32));
  /* pétales : feuilles larges, presque fermées au bout */
  const L = 67, r0 = 7, Wm = 16.5;
  const wf = t => 1.2 + (Wm - 1.2) * Math.sqrt(Math.sin(Math.PI * Math.pow(t, 1.15)));
  let leaf = '', inner = '', rungs = '', pores = [];
  for (let j = 0; j < 5; j++) {
    const a = th0 + j * TAU / 5, d = [Math.cos(a), Math.sin(a)], n = [-d[1], d[0]];
    const P = (t, off) => [O[0] + d[0] * (r0 + L * t) + n[0] * off, O[1] + d[1] * (r0 + L * t) + n[1] * off];
    const Lp = [], Rp = [], Li = [], Ri = [];
    for (let i = 0; i <= 20; i++) {
      const t = i / 20, w = wf(t), z = 0.3 * w + 0.6;
      Lp.push(P(t, -w)); Rp.push(P(t, w)); Li.push(P(t, -(w - z))); Ri.push(P(t, w - z));
    }
    leaf += polyD(Lp.concat(Rp.reverse()), true);
    inner += polyD(Li.concat(Ri.reverse()), true);
    for (let i = 1; i < 17; i++) {
      const t = 0.03 + 0.9 * i / 17, w = wf(t), z = 0.3 * w + 0.6;
      [-1, 1].forEach(sd => {
        const o = P(t, sd * (w - z * 0.18)), q = P(t, sd * (w - z * 0.82));
        rungs += 'M' + PS(o) + 'L' + PS(q); pores.push(o, q);
      });
    }
  }
  s += E.p(leaf, p.shade, p.line, 0.9) + E.p(rungs, null, p.line, 0.5, 'opacity=".6"') + nq_dots(pores, p.accent, 1.5) + E.p(inner, p.relief, p.line, 0.6);
  /* disque apical */
  const ap = [];
  for (let j = 0; j < 5; j++) ap.push(at(th0 + j * TAU / 5, 8.5));
  s += E.p(polyD(ap, true), p.relief, p.line, 0.9);
  const gon = [];
  for (let j = 0; j < 5; j++) gon.push(at(th0 + (j + 0.5) * TAU / 5, 5.2));
  s += nq_dots(gon, p.accent, 2.2) + E.c(O[0], O[1], 2.2, p.shade, p.line, 0.5);
  /* reflet */
  const hl = [];
  for (let th = -2.95; th <= -1.85; th += 0.05) hl.push(at(th, rad(th) * 0.8));
  s += E.p(polyD(hl), null, p.hi, 2.4, 'opacity=".7"');
  return s;
}

/* ---------------- megalodon — Otodus megalodon (dent antérieure, face linguale) ----------------
   ① grande couronne triangulaire, large et symétrique, bords légèrement convexes ;
   ② dentelures fines et régulières sur les deux tranchants (générées le long des bords) ;
   ③ bourrelet : bande sombre en chevron entre couronne et racine ;
   ④ racine épaisse à deux lobes arrondis, échancrure basale en U, texture mate (points) ;
   ⑤ émail brillant : zone claire et long reflet unique. */
function artMegalodon(p) {
  const cx = 110, T = [110, 12], S = [21, 166], ap = [110, 122];
  const edge = quadPts(T, [52, 82], S, 40);
  const serr = nq_serrate(edge, 44, t => 1.9 * Math.min(1, t * 6, (1 - t) * 5), 1);
  const band = [[23, 176], [110, 145]];
  /* racine */
  const rootL = [[cx, 145], [23, 176], [18, 190], [21, 208], [32, 222], [48, 226], [66, 220], [88, 204], [cx, 198]];
  const root = col => E.p(smoothD(rootL.slice(1, 8)).replace(/^M/, 'M' + PS(rootL[0]) + 'L') + 'L' + PS(rootL[8]) + 'Z', col, p.line, 1.2);
  let s = root(p.relief) + mirrorG(root(p.relief), cx);
  const rootPoly = rootL.concat(rootL.slice(1, 8).reverse().map(q => [2 * cx - q[0], q[1]]));
  s += nq_dots(nq_stipple(rootPoly, 110, hashStr('megalodon'), 2.5), p.shade, 1.3, nq_op(p, 0.85));
  s += E.p('M' + (cx - 5) + ' 199Q' + cx + ' 188 ' + (cx + 5) + ' 199', null, p.line, 0.9);
  /* couronne : moitié gauche body, miroir body2 */
  const crown = col => E.p(polyD([ap].concat([T], serr, [S]), true), col, p.line, 1.1);
  s += crown(p.body) + mirrorG(crown(p.body2), cx);
  /* émail éclairé (bande claire le long du bord gauche) */
  const lit = edge.slice(3, 37);
  s += E.p(polyD(nq_offset(lit, -5).concat(nq_offset(lit, t => -5 - 26 * Math.sin(Math.PI * Math.pow(t, 0.8))).reverse()), true), p.relief, null, 0, nq_op(p, 0.75));
  /* bourrelet */
  const chev = 'M' + PS(S) + 'L' + PS(ap) + 'L' + (2 * cx - S[0]) + ' ' + S[1] + 'L' + (2 * cx - band[0][0]) + ' ' + band[0][1] + 'L' + PS(band[1]) + 'L' + PS(band[0]) + 'Z';
  s += E.p(chev, p.line, p.line, 1);
  let st = '';
  for (let k = 1; k < 14; k++) { const t = k / 14, a = lerpPt(S, ap, t), b = lerpPt(band[0], band[1], t); st += 'M' + PS(lerpPt(a, b, 0.2)) + 'L' + PS(lerpPt(a, b, 0.8)); }
  s += E.p(st, null, p.shade, 0.6) + mirrorG(E.p(st, null, p.shade, 0.6), cx);
  s += E.p('M' + PS(T) + 'L' + PS(ap), null, p.line, 0.5, 'opacity=".35"');
  /* reflet */
  s += E.p(polyD(nq_offset(edge.slice(5, 31), -12)), null, p.hi, 3, 'opacity=".72"');
  return s;
}

/* orbite ouverte vers l'arrière : cavité sombre + rebord osseux en arc (a0 → a1 en passant par l'avant) */
function nq_orbit(p, c, r, a0, a1, rim) {
  const P = a => PS([c[0] + Math.cos(a * D2R) * r, c[1] + Math.sin(a * D2R) * r]);
  return E.c(c[0], c[1], r, p.accent) + E.p('M' + P(a0) + 'A' + r + ' ' + r + ' 0 1 0 ' + P(a1), null, p.relief, rim || 3) + E.p('M' + P(a0) + 'A' + r + ' ' + r + ' 0 1 0 ' + P(a1), null, p.line, 0.8);
}
/* dent conique : base b0-b1, pointe tip, renflement k (0 = droite) */
function nq_toothD(b0, b1, tip, k) {
  const m0 = lerpPt(b0, tip, 0.55), m1 = lerpPt(b1, tip, 0.55), n0 = [b0[0] - b1[0], b0[1] - b1[1]], L = Math.hypot(n0[0], n0[1]) || 1;
  const c0 = [m0[0] + n0[0] / L * k, m0[1] + n0[1] / L * k], c1 = [m1[0] - n0[0] / L * k, m1[1] - n0[1] / L * k];
  return 'M' + PS(b0) + 'Q' + PS(c0) + ' ' + PS(tip) + 'Q' + PS(c1) + ' ' + PS(b1) + 'Z';
}

/* ---------------- machairodus — Machairodus aphanistus, crâne de profil (museau à gauche) ----------------
   ① crâne long et bas : museau haut (loge de la canine), profil qui monte vers la crête sagittale, crête occipitale en surplomb ;
      grande orbite ouverte en arrière (apophyses postorbitaires qui ne se rejoignent pas), arcade zygomatique forte sous l'orbite ;
   ② canine supérieure : très longue lame aplatie (large de profil), courbée vers l'arrière, finement dentelée sur ses deux bords,
      qui descend bien sous la ligne de la mandibule — la signature ;
   ③ mandibule : rebord descendant (apophyse) à l'avant, le long de la lame ; petite canine inférieure ; carnassières en lames (P4 / m1) ;
   ④ ouverture nasale à l'avant, incisives procombantes (I3 plus forte) ;
   ⑤ région occipitale (condyle, mastoïde saillante), articulation de la mâchoire (glène basse), méat auditif.
   Repères : longueur du crâne L = 250 (prosthion x = 24 → occiput x = 274), glène à 0,8 L, orbite au-dessus de la carnassière. */
function artMachairodus(p) {
  const cran = [[24, 117], [21, 104], [25, 90], [33, 76], [50, 66], [80, 58], [108, 52], [138, 44], [170, 37], [204, 33], [238, 36], [262, 44], [276, 52], [273, 68], [268, 88], [270, 104], [266, 114], [257, 118], [251, 128], [243, 121], [232, 118], [190, 112], [160, 113], [156, 118], [110, 118], [60, 118]];
  let s = E.p(smoothD(cran, true), p.body, p.line, 1.3);
  /* face dorsale éclairée */
  const dors = cran.slice(3, 12);
  s += E.p(polyD(dors.concat(nq_offset(dors, 8).reverse()), true), p.relief, null, 0, nq_op(p, 0.6));
  /* fosse temporale (creux) */
  s += E.p(smoothD([[150, 56], [174, 45], [206, 41], [238, 44], [258, 55], [262, 74], [257, 97], [242, 107], [222, 107], [196, 101], [174, 97], [160, 86], [152, 70]], true), p.shade, p.line, 0.7);
  s += E.p(smoothD([[172, 50], [206, 45], [238, 48], [254, 60], [240, 66], [206, 64], [178, 66]], true), p.body, null, 0, nq_op(p, 0.55));
  /* ouverture nasale */
  s += E.p('M35 75Q27 84 25 99Q30 102 33 96Q36 84 43 77Z', p.accent, p.line, 0.7);
  /* bosse de la racine de la canine + sutures */
  s += E.p('M54 117Q56 92 70 84Q84 82 90 94Q92 106 90 117Z', p.relief, null, 0, nq_op(p, 0.55)) + E.p('M70 84Q84 82 90 94Q92 106 90 117', null, p.line, 0.6, 'opacity=".6"');
  s += E.p('M40 96Q46 106 49 117M80 58Q84 64 83 76M138 44Q134 50 132 54', null, p.line, 0.6, DASH);
  s += E.el(108, 86, 3, 2, -20, p.accent);
  /* mandibule (derrière l'arcade) */
  const mand = [[31, 125], [35, 140], [40, 155], [46, 167], [54, 174], [64, 172], [74, 164], [90, 160], [124, 159], [162, 157], [198, 153], [224, 147], [239, 141], [242, 135], [236, 129], [231, 121], [224, 117], [214, 117], [207, 110], [202, 94], [195, 97], [184, 108], [170, 120], [156, 127], [110, 129], [74, 127], [50, 126]];
  s += E.p(smoothD(mand, true), p.body2, p.line, 1.2);
  s += E.p(smoothD([[186, 124], [206, 116], [226, 124], [231, 136], [214, 145], [192, 147], [181, 136]], true), p.shade, null, 0, nq_op(p, 0.7));
  const lb = mand.slice(4, 13);
  s += E.p(polyD(lb.concat(nq_offset(lb, t => -1 - 6 * Math.sin(Math.PI * t)).reverse()), true), p.shade, null, 0, nq_op(p, 0.6));
  s += nq_dots([[80, 143], [97, 146]], p.accent, 2.6);
  /* dents inférieures (derrière les supérieures) */
  let lo = nq_toothD([33, 127], [39, 128], [31, 117], 1) + nq_toothD([39, 128], [45, 129], [39, 117], 1);
  lo += nq_toothD([46, 128], [58, 129], [52, 104], 2.5);
  lo += 'M100 132L104 122L108 120L113 131ZM112 132L117 118L122 117L128 132Z';
  lo += 'M128 132L133 121L138 125L145 116L150 121L154 131Z';
  s += E.p(lo, p.relief, p.line, 0.8);
  /* arcade zygomatique */
  const zyU = [[112, 90], [126, 88], [146, 92], [155, 85], [160, 77], [166, 88], [186, 96], [210, 100], [232, 104], [236, 112]], zyL = [[236, 112], [210, 113], [180, 112], [150, 112], [126, 113], [108, 109], [100, 102]];
  s += E.p(smoothD(zyU.concat(zyL.slice(1)), true), p.relief) + E.p(smoothD(zyU) + smoothD(zyL), null, p.line, 1);
  s += E.p('M120 107Q170 104 226 108', null, p.line, 0.5, 'opacity=".5"');
  /* orbite ouverte vers l'arrière + apophyse postorbitaire du frontal */
  s += E.p('M' + PS([134 + 15 * Math.cos(-48 * D2R), 72 + 15 * Math.sin(-48 * D2R)]) + 'A15 15 0 1 0 ' + PS([134 + 15 * Math.cos(42 * D2R), 72 + 15 * Math.sin(42 * D2R)]) + 'L158 84L154 66Z', p.accent);
  s += E.p('M' + PS([134 + 15 * Math.cos(-48 * D2R), 72 + 15 * Math.sin(-48 * D2R)]) + 'A15 15 0 1 0 ' + PS([134 + 15 * Math.cos(42 * D2R), 72 + 15 * Math.sin(42 * D2R)]), null, p.relief, 3) + E.p('M' + PS([134 + 15 * Math.cos(-48 * D2R), 72 + 15 * Math.sin(-48 * D2R)]) + 'A15 15 0 1 0 ' + PS([134 + 15 * Math.cos(42 * D2R), 72 + 15 * Math.sin(42 * D2R)]), null, p.line, 0.8);
  s += E.p('M141 59Q150 58 157 68Q150 67 144 65Z', p.relief, p.line, 0.8);
  /* région occipitale : condyle, méat auditif */
  s += E.el(267, 110, 6, 8, 0, p.relief, p.line, 0.9) + E.el(242, 110, 3.4, 2.6, 0, p.accent);
  s += E.p('M262 50Q266 80 258 100', null, p.line, 0.7, 'opacity=".6"');
  /* dents supérieures : incisives, P3, P4 carnassière en lame */
  let up = nq_toothD([23, 117], [29, 117], [22, 127], 1) + nq_toothD([29, 117], [36, 117], [29, 128], 1) + nq_toothD([36, 117], [46, 117], [37, 132], 2);
  up += 'M97 118L105 130L113 118Z';
  up += 'M115 118L118 126L123 124L132 138L139 126L151 134L158 119Z';
  s += E.p(up, p.relief, p.line, 0.8);
  s += E.p('M123 124L127 130M139 126L143 131', null, p.line, 0.5, 'opacity=".6"');
  /* canine supérieure : lame courbe dentelée */
  const cl = cubicPts([71, 116], [69, 150], [77, 184], [99, 204], 40);
  const wf = t => 12.5 * Math.pow(1 - Math.pow(t, 2.4), 0.72) + 0.3;
  const fr = nq_offset(cl, t => -wf(t)), bk = nq_offset(cl, t => wf(t));
  const frS = nq_serrate(fr.slice(3), 30, t => 0.9 * Math.min(1, t * 8), 1), bkS = nq_serrate(bk.slice(3), 26, t => 0.8 * Math.min(1, t * 8), -1);
  s += E.p(polyD(fr.slice(0, 3).concat(frS, bkS.reverse(), bk.slice(0, 3).reverse()), true), p.relief, p.line, 1);
  s += E.p(polyD(nq_offset(cl.slice(4, 36), -1.5)), null, p.line, 0.5, 'opacity=".4"');
  /* rebord alvéolaire (cache la base des dents) */
  s += E.p('M24 117L62 118Q70 115 86 118L158 118', null, p.line, 1.1);
  /* reflet unique */
  s += E.p(polyD(nq_offset(fr.slice(4, 22), 3.2)), null, p.hi, 2, 'opacity=".7"');
  s += E.p('M42 70Q80 56 128 47', null, p.hi, 1.6, 'opacity=".6"');
  return s;
}

/* molaires à crêtes vues de profil : couronnes posées sur le bord alvéolaire y0, surface d'usure en y1 ;
   segs = [[x0, x1, nbCrêtes], …] ; renvoie { d : couronnes, l : crêtes } */
function nq_lophs(segs, y0, y1) {
  let d = '', l = '';
  const dir = Math.sign(y1 - y0);
  segs.forEach(([x0, x1, n]) => {
    const w = (x1 - x0) / n;
    d += 'M' + r1(x0 + 0.8) + ' ' + y0 + 'L' + r1(x0) + ' ' + r1(y1 - dir * 3);
    for (let k = 0; k < n; k++) {
      const a = x0 + w * k, b = a + w;
      d += 'Q' + r1(a + w * 0.08) + ' ' + r1(y1 + dir * 1.5) + ' ' + r1(a + w / 2) + ' ' + r1(y1 + dir * 1.2) + 'Q' + r1(b - w * 0.08) + ' ' + r1(y1 + dir * 1.5) + ' ' + r1(b) + ' ' + r1(y1 - dir * 3);
      if (k) l += 'M' + r1(a) + ' ' + r1(y1 - dir * 3) + 'L' + r1(a + 0.6) + ' ' + r1(lerp(y1, y0, 0.75));
    }
    d += 'L' + r1(x1 - 0.8) + ' ' + y0 + 'Z';
  });
  return { d: d, l: l };
}

/* ---------------- deinotherium — Deinotherium giganteum, crâne et mandibule de profil (museau à gauche) — pièce unique ----------------
   ① crâne court et bas, toit plat ; ouverture nasale immense, haute et reculée (échancrure du profil devant les orbites : trompe) ;
      petite orbite au-dessus des premières molaires ; rostre prémaxillaire court, incliné vers le bas, SANS défenses ;
   ② molaires à crêtes transverses (bilophodontes, M1 à trois crêtes), rangée haute et basse en occlusion ;
   ③ mandibule : longue symphyse recourbée presque à angle droit vers le bas, portant DEUX DÉFENSES (incisives inférieures)
      recourbées vers le bas puis vers l'arrière, en crochets — la signature ; elles descendent nettement sous le crâne ;
   ④ arcade zygomatique longue et basse, fosse temporale ;
   ⑤ occiput haut et large, condyle occipital, glène de l'articulation. */
function artDeinotherium(p) {
  const cran = [[66, 118], [61, 106], [66, 88], [77, 71], [90, 58], [103, 49], [114, 57], [126, 61], [138, 47], [150, 40], [184, 37], [222, 35], [254, 33], [272, 31], [284, 38], [285, 56], [281, 78], [277, 94], [281, 102], [272, 110], [262, 115], [255, 108], [244, 110], [214, 108], [180, 108], [150, 111], [134, 116], [100, 118], [80, 121]];
  let s = E.p(smoothD(cran, true), p.body, p.line, 1.3);
  /* toit plat éclairé */
  const top = cran.slice(8, 15);
  s += E.p(polyD(top.concat(nq_offset(top, 7).reverse()), true), p.relief, null, 0, nq_op(p, 0.6));
  /* fosse temporale + paroi du neurocrâne */
  s += E.p(smoothD([[158, 54], [194, 47], [234, 46], [262, 53], [270, 74], [262, 96], [240, 101], [206, 97], [176, 95], [160, 86], [154, 68]], true), p.shade, p.line, 0.7);
  s += E.p(smoothD([[176, 56], [210, 51], [244, 53], [256, 62], [236, 67], [204, 65], [182, 67]], true), p.body, null, 0, nq_op(p, 0.5));
  /* ouverture nasale haute et reculée */
  s += E.p('M103 51Q110 55 116 60Q128 66 138 49Q134 62 128 70Q116 73 108 62Z', p.accent, p.line, 0.8);
  /* rostre : face dorsale creusée (insertion de la trompe) */
  s += E.p('M101 56Q84 68 72 92Q68 104 66 114', null, p.line, 0.7, 'opacity=".6"');
  /* sutures, foramens, texture */
  s += E.p('M92 58Q98 84 96 118M150 41Q155 58 157 64M222 36Q226 44 228 48', null, p.line, 0.6, DASH);
  s += E.el(118, 94, 4.2, 2.8, -15, p.accent);
  s += nq_dots(nq_stipple([[66, 114], [64, 94], [76, 76], [96, 62], [104, 88], [98, 114]], 24, hashStr('deino-r'), 3), p.shade, 1.1, nq_op(p, 0.8));
  /* défense lointaine (derrière, décalée) */
  const tk = cubicPts([94, 204], [90, 230], [108, 246], [146, 238], 30);
  const tusk = (pts, col, w) => E.p(taperD(pts, w, 1.8, t => 1 - 0.3 * t * t), col, p.line, 1);
  s += tusk(tk.map(q => [q[0] + 13, q[1] - 8]), p.shade, 16);
  /* mandibule : rameau horizontal, rameau montant, symphyse coudée à angle droit */
  const mand = [[102, 136], [150, 137], [226, 136], [236, 128], [232, 114], [240, 106], [251, 108], [256, 124], [258, 146], [254, 162], [240, 170], [206, 172], [168, 172], [142, 174], [124, 182], [112, 196], [106, 210], [100, 216], [88, 214], [80, 202], [80, 182], [85, 162], [93, 146]];
  s += E.p(smoothD(mand, true), p.body2, p.line, 1.3);
  s += E.p(smoothD([[212, 140], [234, 134], [248, 142], [250, 158], [236, 166], [214, 166], [204, 154]], true), p.shade, null, 0, nq_op(p, 0.55));
  const lb = mand.slice(10, 17);
  s += E.p(polyD(lb.concat(nq_offset(lb, t => -1 - 6 * Math.sin(Math.PI * t)).reverse()), true), p.shade, null, 0, nq_op(p, 0.6));
  s += nq_dots([[128, 158], [106, 170]], p.accent, 2.8);
  s += E.p('M91 150Q84 176 90 204', null, p.line, 0.6, 'opacity=".5"');
  /* défense proche : crochet vers le bas et l'arrière, stries de croissance */
  s += tusk(tk, p.relief, 18);
  let gl = '';
  for (let i = 3; i < 27; i += 3) { const t = tangentAt(tk, i), u = i / 30, w = (18 * (1 - u) + 1.8 * u) * (1 - 0.3 * u * u) / 2 - 0.8; gl += 'M' + PS([tk[i][0] - t[1] * w, tk[i][1] + t[0] * w]) + 'L' + PS([tk[i][0] + t[1] * w, tk[i][1] - t[0] * w]); }
  s += E.p(gl, null, p.line, 0.5, 'opacity=".55"');
  s += E.p(polyD(nq_offset(tk.slice(2, 22), -3.8)), null, p.hi, 1.8, 'opacity=".65"');
  s += E.p('M83 206Q95 214 106 208', null, p.line, 1);
  /* molaires à crêtes (haut et bas) */
  const up = nq_lophs([[106, 121, 2], [122, 139, 2], [140, 163, 3], [164, 188, 2], [189, 214, 2]], 117, 126);
  const lo = nq_lophs([[104, 120, 2], [121, 139, 2], [140, 164, 3], [165, 190, 2], [191, 218, 2]], 136, 126.5);
  s += E.p(lo.d + up.d, p.relief, p.line, 0.7) + E.p(lo.l + up.l, null, p.line, 0.5, 'opacity=".7"');
  /* arcade zygomatique */
  const zyU = [[126, 102], [146, 98], [170, 99], [200, 98], [228, 98], [246, 101]], zyL = [[248, 109], [222, 110], [190, 109], [160, 110], [138, 111], [124, 108]];
  s += E.p(smoothD(zyU.concat(zyL), true), p.relief) + E.p(smoothD(zyU) + smoothD(zyL), null, p.line, 1);
  /* orbite */
  s += E.c(140, 84, 9.5, p.accent) + E.p('M149.5 80A9.5 9.5 0 1 0 148 91', null, p.relief, 2.6) + E.p('M149.5 80A9.5 9.5 0 1 0 148 91', null, p.line, 0.8);
  /* occiput : condyle, méat */
  s += E.el(276, 102, 6, 7.5, 0, p.relief, p.line, 0.9) + E.el(258, 102, 3, 2.4, 0, p.accent);
  s += E.p('M272 36Q279 68 268 98', null, p.line, 0.7, 'opacity=".6"');
  s += E.p('M152 44Q200 36 262 36', null, p.hi, 1.8, 'opacity=".65"');
  return s;
}

Object.assign(ART, {
  pecten: { vb: [240, 230], fn: artPecten, area: { cx: 120, cy: 126, rx: 94, ry: 86 } },
  clypeaster: { vb: [230, 230], fn: artClypeaster, area: { cx: 115, cy: 120, rx: 92, ry: 92 } },
  megalodon: { vb: [220, 240], fn: artMegalodon, area: { cx: 110, cy: 122, rx: 78, ry: 100 } },
  machairodus: { vb: [300, 220], fn: artMachairodus, area: { cx: 148, cy: 112, rx: 128, ry: 70 } },
  deinotherium: { vb: [300, 260], fn: artDeinotherium, area: { cx: 168, cy: 124, rx: 120, ry: 96 } }
});
