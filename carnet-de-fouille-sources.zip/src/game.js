/* ============ jeu : état, carte, établi, musée ============ */
const $ = id => document.getElementById(id);
const SAVE_KEY = 'carnet-de-fouille-v2';
let UIDN = 0;
const uid = p => (p || 'u') + (++UIDN);
const fmt = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
const zname = z => COLS[z.x] + (z.y + 1);
const now = () => performance.now();
const reduceMotion = () => window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ---------- sprites : icônes + fossiles (symboles créés à la demande, 60 fossiles × 4 variantes) ---------- */
const SYM = {}, VARIANT = { sil: '#cdc1a6', w: '#ffffff', ink: '#2a2016' };
function buildSprites() {
  Object.keys(FOSSILS).forEach(id => { if (!ART[id]) ART[id] = placeholderArt(); });
  $('sprites').innerHTML = iconSprite() + '<svg width="0" height="0" style="position:absolute;overflow:hidden" aria-hidden="true"><defs id="fzDefs"></defs></svg>';
}
function ensureSym(id, v) {
  const key = id + (v ? '-' + v : '');
  if (SYM[key]) return;
  SYM[key] = 1;
  const A = ART[id], pal = v ? flatPal(VARIANT[v]) : FPAL[FOSSILS[id].epoch];
  $('fzDefs').insertAdjacentHTML('beforeend', '<symbol id="fz-' + key + '" viewBox="0 0 ' + A.vb[0] + ' ' + A.vb[1] + '"><g stroke-linecap="round" stroke-linejoin="round">' + A.fn(pal) + '</g></symbol>');
}
/* filet de sécurité : un fossile sans dessin reste jouable (galet gravé) */
function placeholderArt() {
  return { vb: [220, 200], area: { cx: 110, cy: 100, rx: 90, ry: 76 }, fn: p => E.el(110, 100, 94, 80, -6, p.body, p.line, 1.4) + E.el(110, 100, 60, 46, -6, p.relief, p.line, 1) + E.el(96, 84, 30, 12, -20, null, p.hi, 2.2, 'opacity=".6"') };
}
const BLK = {};
function blocksOf(id) {
  if (BLK[id]) return BLK[id];
  const A = ART[id], [W, H] = A.vb, n = FOSSILS[id].blocks || 1;
  const seeds = (typeof BLOCK_SEEDS !== 'undefined' && BLOCK_SEEDS[id] && BLOCK_SEEDS[id].length === n) ? BLOCK_SEEDS[id] : blockSeeds(n, A.area, hashStr(id)), cells = voronoiCells(seeds, W, H), edges = voronoiEdges(cells, seeds);
  const m = Math.max(W, H);
  return (BLK[id] = { cells, cracks: edges.map(e => polyD(jagPts(e[0], e[1], m / 180, m / 45))).join('') });
}
/* bloc recadré sur la zone utile du fossile (sert à la face de la pierre et aux envols) */
function cellBox(fid, bi) {
  const ar = ART[fid].area;
  let cell = blocksOf(fid).cells[bi];
  const X0 = ar.cx - ar.rx * 1.08, X1 = ar.cx + ar.rx * 1.08, Y0 = ar.cy - ar.ry * 1.08, Y1 = ar.cy + ar.ry * 1.08;
  cell = clipHalf(clipHalf(clipHalf(clipHalf(cell, -1, 0, -X0), 1, 0, X1), 0, -1, -Y0), 0, 1, Y1);
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  cell.forEach(p => { x0 = Math.min(x0, p[0]); x1 = Math.max(x1, p[0]); y0 = Math.min(y0, p[1]); y1 = Math.max(y1, p[1]); });
  return { cell, x0, y0, bw: x1 - x0, bh: y1 - y0 };
}
const fUse = (id, v) => { ensureSym(id, v); const [W, H] = ART[id].vb; return '<use href="#fz-' + id + (v ? '-' + v : '') + '" width="' + W + '" height="' + H + '"/>'; };
function fossilSVG(id, mode, found, cls, q) {
  const [W, H] = ART[id].vb, u = uid('f');
  let s = '<svg class="fz' + (cls ? ' ' + cls : '') + '" viewBox="0 0 ' + W + ' ' + H + '" aria-hidden="true">';
  if (mode === 'full') s += fUse(id);
  else if (mode === 'veiled') s += '<g opacity=".6">' + fUse(id, 'sil') + '</g><text x="' + W / 2 + '" y="' + r1(H / 2 + W * 0.11) + '" text-anchor="middle" font-family="Special Elite, Courier New, monospace" font-size="' + r1(W * 0.3) + '" fill="#7d705a">?</text>';
  else {
    const B = blocksOf(id), clip = (found || []).map(i => polyD(B.cells[i], true)).join('');
    s += '<defs><clipPath id="' + u + 'c"><path d="' + (clip || 'M0 0Z') + '"/></clipPath><mask id="' + u + 'm" maskUnits="userSpaceOnUse" x="0" y="0" width="' + W + '" height="' + H + '">' + fUse(id, 'w') + '</mask></defs>';
    s += fUse(id, 'sil') + (clip ? '<g clip-path="url(#' + u + 'c)">' + fUse(id) + '</g>' : '');
    s += '<path class="cracks-l" d="' + B.cracks + '" fill="none" stroke="#8c7f64" stroke-width="' + r1(Math.max(W, H) / 140) + '" stroke-linecap="round" mask="url(#' + u + 'm)" opacity=".9"/>';
    /* conservation : un bloc mal conservé porte ses fêlures et ses lacunes (des morceaux d'os perdus), une par étoile perdue */
    if (q) {
      let d = '', holes = '';
      const m = Math.max(W, H), ar = ART[id].area;
      const inP = (x, y, P) => { let c = false; for (let a = 0, b = P.length - 1; a < P.length; b = a++) if ((P[a][1] > y) !== (P[b][1] > y) && x < (P[b][0] - P[a][0]) * (y - P[a][1]) / (P[b][1] - P[a][1]) + P[a][0]) c = !c; return c; };
      (found || []).forEach(i => {
        const st = q[i] == null ? 2 : q[i]; if (st >= 3) return;
        const cell = B.cells[i], rr = mulberry32(hashStr(id) + i * 97), cb = cellBox(id, i);
        for (let k = 0; k < 3 - st; k++) { const a = cell[Math.floor(rr() * cell.length)], b = cell[Math.floor(rr() * cell.length)]; if (a !== b) d += polyD(jagPts(a, b, m / 90, m / 30)); }
        for (let k = 0; k < 3 - st; k++) {
          let cx = null, cy = null;
          for (let t = 0; t < 30 && cx == null; t++) { const x = cb.x0 + rr() * cb.bw, y = cb.y0 + rr() * cb.bh, ex = (x - ar.cx) / ar.rx, ey = (y - ar.cy) / ar.ry; if (inP(x, y, cb.cell) && ex * ex + ey * ey < 0.8) { cx = x; cy = y; } }
          if (cx == null) continue;
          const R = Math.min(cb.bw, cb.bh) * (0.2 + rr() * 0.12), n = 10, pts = [];
          for (let s2 = 0; s2 < n; s2++) { const an = s2 / n * Math.PI * 2, rad = R * (0.6 + rr() * 0.55); pts.push([cx + Math.cos(an) * rad, cy + Math.sin(an) * rad * 0.85]); }
          holes += polyD(pts, true);
        }
      });
      if (holes) {
        /* la lacune garde l'empreinte : on voit encore le fossile, mais délavé et grisé à cet endroit, cerné d'un bord cassé */
        s += '<g clip-path="url(#' + u + 'c)"><path d="' + holes + '" fill="#d9d0bc" fill-opacity=".72" mask="url(#' + u + 'm)"/><path d="' + holes + '" fill="none" stroke="#6b5a42" stroke-width="' + r1(m / 160) + '" stroke-dasharray="' + r1(m / 60) + ' ' + r1(m / 200) + '" mask="url(#' + u + 'm)"/></g>';
      }
      if (d) s += '<g clip-path="url(#' + u + 'c)"><path d="' + d + '" fill="none" stroke="#3a2412" stroke-width="' + r1(m / 110) + '" stroke-linecap="round" mask="url(#' + u + 'm)" opacity=".75"/></g>';
    }
  }
  return s + '</svg>';
}
/* position écran d'un point de viewBox dans un <svg> (preserveAspectRatio « meet ») */
function svgFrame(svg, W, H) {
  const r = svg.getBoundingClientRect(), k = Math.min(r.width / W, r.height / H);
  return { left: r.left + (r.width - W * k) / 2, top: r.top + (r.height - H * k) / 2, k };
}

/* ---------- noms : un fossile à fragments reste anonyme jusqu'à son identification ---------- */
const known = fid => fos(fid).done;
const shortNo = fid => { const F = FOSSILS[fid]; return EPOCHS[F.epoch].code + '-' + String(EPOCHS[F.epoch].fossils.indexOf(fid) + 1).padStart(2, '0'); };
const specimenNo = fid => 'CF-' + shortNo(fid);
function dispName(fid) {
  if (known(fid)) return FOSSILS[fid].name;
  return FOSSILS[fid].kind === 'unique' ? 'Pièce unique' : 'Spécimen ' + shortNo(fid);
}

/* ---------- son (synthèse WebAudio) et vibrations ---------- */
const Sound = {
  ctx: null, nb: null,
  ensure() {
    if (!this.ctx) { try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return null; } }
    if (this.ctx.state === 'suspended') this.ctx.resume();
    return this.ctx;
  },
  noise() {
    if (this.nb) return this.nb;
    const c = this.ctx, b = c.createBuffer(1, c.sampleRate * 0.6, c.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return (this.nb = b);
  },
  env(g, t, a, peak, dur) { g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + dur); },
  tone(type, f0, f1, dur, peak, delay) {
    const c = this.ctx, t = c.currentTime + (delay || 0), o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t); if (f1) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    this.env(g, t, 0.005, peak, dur); o.connect(g).connect(c.destination); o.start(t); o.stop(t + dur + 0.05);
  },
  hiss(type, freq, q, dur, peak, delay, sweep) {
    const c = this.ctx, t = c.currentTime + (delay || 0), s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.noise(); f.type = type; f.frequency.setValueAtTime(freq, t); if (sweep) f.frequency.exponentialRampToValueAtTime(sweep, t + dur); f.Q.value = q;
    this.env(g, t, 0.004, peak, dur); s.connect(f).connect(g).connect(c.destination); s.start(t); s.stop(t + dur + 0.05);
  },
  play(name, lvl) {
    if (!G.set.son || !this.ensure()) return;
    try {
      if (name === 'impact') {
        this.tone('sine', 150, 46, 0.2, 0.9); this.hiss('bandpass', 1700, 0.9, 0.07, 0.55);
        if (lvl) this.tone('triangle', 1250 + lvl * 190, 0, 0.08 + lvl * 0.03, 0.06 + lvl * 0.025);
      } else if (name === 'split') this.hiss('highpass', 2400, 0.7, 0.07, 0.28);
      else if (name === 'ore') [2350, 3050, 3700].forEach((f, i) => this.tone('sine', f, 0, 0.16, 0.12, i * 0.045));
      else if (name === 'coin') { this.tone('sine', 1900, 0, 0.1, 0.1); this.tone('sine', 2850, 0, 0.14, 0.08, 0.05); }
      else if (name === 'frag') { this.tone('triangle', 660, 0, 0.26, 0.2); this.tone('triangle', 990, 0, 0.34, 0.16, 0.11); }
      else if (name === 'snap') { this.hiss('bandpass', 1300, 3, 0.05, 0.45); this.tone('sine', 1320, 0, 0.18, 0.12, 0.02); }
      else if (name === 'glow') this.tone('sine', 220, 440, 0.7, 0.1);
      else if (name === 'clean') { this.tone('sine', 1760, 0, 0.12, 0.12); this.tone('sine', 2640, 0, 0.2, 0.1, 0.06); }
      else if (name === 'ident') { [523, 659, 784, 1047].forEach((f, i) => this.tone('triangle', f, 0, 0.55, 0.2, i * 0.1)); this.tone('sine', 2093, 0, 1, 0.06, 0.42); }
      else if (name === 'unique') {
        this.tone('sine', 70, 40, 1.2, 0.8); this.hiss('lowpass', 400, 0.7, 0.9, 0.3);
        [392, 523, 659, 784, 1047, 1319].forEach((f, i) => this.tone('triangle', f, 0, 0.8, 0.18, 0.25 + i * 0.12));
        this.tone('sine', 2637, 0, 1.6, 0.05, 1);
      } else if (name === 'stamp') { this.tone('sine', 120, 50, 0.18, 0.7); this.hiss('bandpass', 600, 1, 0.08, 0.35); }
      else if (name === 'type') this.hiss('bandpass', 2600, 4, 0.02, 0.12);
      else if (name === 'vide') this.hiss('lowpass', 700, 0.5, 0.28, 0.32);
      else if (name === 'tap') this.tone('sine', 1150, 0, 0.03, 0.08);
      else if (name === 'buy') { this.tone('sine', 1800, 0, 0.12, 0.14); this.tone('sine', 2650, 0, 0.18, 0.12, 0.07); }
      else if (name === 'fly') this.hiss('bandpass', 500, 1.2, 0.32, 0.12, 0, 2600);
      else if (name === 'cassure') { this.hiss('lowpass', 900, 0.6, 0.22, 0.42); this.tone('sine', 95, 50, 0.16, 0.3); }
      else if (name === 'note') { this.hiss('bandpass', 3400, 1.4, 0.05, 0.07); this.hiss('bandpass', 2300, 1.4, 0.07, 0.05, 0.08); }
      else if (name === 'clonk') { this.hiss('bandpass', 1300, 3, 0.05, 0.5, 0.18); this.hiss('lowpass', 260, 0.7, 0.12, 0.5, 0.18); }
      else if (name === 'pelle') {
        /* la pelle mord la terre (chunk sourd), racle en basculant, puis les mottes retombent en pluie */
        this.hiss('lowpass', 420, 0.8, 0.09, 0.32, 0.18); this.tone('sine', 88, 52, 0.09, 0.16, 0.18); this.hiss('bandpass', 1900, 1.1, 0.035, 0.07, 0.18);
        this.hiss('bandpass', 650, 2.2, 0.17, 0.09, 0.27, 320);
        for (let i = 0; i < 6; i++) this.hiss('bandpass', 1700 + Math.random() * 1900, 3, 0.025 + Math.random() * 0.02, 0.03 + Math.random() * 0.03, 0.44 + i * 0.035 + Math.random() * 0.03);
      }
      else if (name === 'deblai') { this.hiss('bandpass', 850, 0.9, 0.22, 0.22); this.hiss('bandpass', 1500, 1.4, 0.1, 0.14, 0.13); this.tone('sine', 110, 60, 0.12, 0.12, 0.2); }
    } catch (e) { /* audio indisponible */ }
  }
};
function buzz(p) { if (G.set.vib && navigator.vibrate) { try { navigator.vibrate(p); } catch (e) { } } }

/* ---------- état et sauvegarde ---------- */
const DEFAULT = () => ({
  v: 8, money: 0, stones: 0, xpFil: 0, noteAt: null,
  up: { marteau: 0, quantite: 0, taille: 0, chaleur: 0, jauge: 0, loupe: 0 },
  set: { son: true, vib: true, rapide: false, mots: true, cible: 'pok', amb: true },
  fos: {}, cols: {}, site: null, stone: null, tuto: 0, last: null, lastK: null, seen: {}, notes: {}, ev: {}, voyage: null, streak: null, hintAt: null, courageAt: null
});
let G = DEFAULT(), SITE = null, CUR = null, LEDGER = null, mapDirty = false;
let MOMENT = null, mapGuardUntil = 0, hudHold = false, shownMoney = null, B3 = false;
/* fossile : done, where (lieu de l'identification), ind : individus [{ k, site (graine du gisement), num, zone, found, lost }], nk, dup */
const fos = id => { const f = G.fos[id] || (G.fos[id] = { done: false, where: '', ind: [], nk: 0, dup: 0 }); if (!f.ind) f.ind = []; return f; };
const indOf = (fid, k) => fos(fid).ind.find(I => I.k === k) || null;
/* individus en cours sur ce gisement */
const indsHere = fid => (G.site ? fos(fid).ind.filter(I => !I.lost && I.site === G.site.seed && I.found.length < FOSSILS[fid].blocks) : []);
const bestInd = fid => fos(fid).ind.reduce((b, I) => (!b || I.found.length > b.found.length ? I : b), null);
const allBlocks = fid => Array.from({ length: FOSSILS[fid].blocks || 1 }, (_, i) => i);
/* blocs à montrer pour une espèce : tout si identifiée, sinon le meilleur individu */
function foundOf(fid) { if (fos(fid).done) return allBlocks(fid); const b = bestInd(fid); return b ? b.found : []; }
function serialize() {
  if (SITE && G.site) {
    G.site.dug = SITE.zones.map(z => z.dug);
    G.site.rev = SITE.zones.map(z => (z.revealed ? 1 : 0));
  }
  return JSON.parse(JSON.stringify(G));
}
function save() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(serialize())); } catch (e) { } }
function merge(data) {
  const d = DEFAULT();
  G = Object.assign(d, data);
  G.up = Object.assign(DEFAULT().up, data.up || {});
  G.set = Object.assign(DEFAULT().set, data.set || {});
  G.fos = data.v === 2 ? migrateFos(data) : data.fos || {};
  G.cols = data.cols || {}; G.seen = data.seen || {}; G.ev = data.ev || {};
  G.notes = data.notes || {};
  if (G.stone && G.stone.contents) G.stone.contents = legacyContents(G.stone.contents);
  /* la pièce unique n'existe plus : sa cachette disparaît des gisements en cours */
  if (G.site) { G.site.uni = null; G.site.uniXY = null; }
  if (G.stone && G.stone.bias === 'unique') G.stone.bias = 'caillou';
  /* v4 : le Sac ne grossissait plus les lots ; les niveaux se convertissaient, le trop-payé était rendu */
  if (data.v < 4) {
    const q = clamp(G.up.quantite || 0, 0, 5), paid = [0, 80, 280, 680, 1330, 2280][q], nl = q >= 3 ? 2 : q >= 1 ? 1 : 0;
    G.money += Math.max(0, paid - [0, 350, 1250][nl]);
    G.up.quantite = nl;
  }
  /* v5 : la pelle et les lunettes remplacent les prélèvements ; un lot en cours est abandonné */
  if (data.v < 5) G.stone = null;
  /* v6 : plus de ciblage d'époque (on choisit sa destination à l'escale) : il est remboursé */
  if (G.up.ciblage) G.money += 1200;
  delete G.up.ciblage;
  if (G.voyage && !G.voyage.offers) G.voyage.offers = null;
  delete G.lot;
  G.up.quantite = clamp(G.up.quantite || 0, 0, DIG.digs.length - 1);
  /* v8 : l'ancienne Pelle (bords des poches) disparaît, remboursée ; la nouvelle Pelle donne les coups (ancien niveau des crédits) */
  if (data.v < 8 && G.up.taille) G.money += [0, 350, 1250][clamp(G.up.taille, 0, 2)];
  G.up.taille = 0;
  G.up.chaleur = clamp(G.up.chaleur || 0, 0, DIG.glass.length - 1);
  G.set.cible = 'pok';
  /* v7 : les onomatopées font partie du jeu, actives par défaut */
  if (data.v < 7) G.set.mots = true;
  G.v = 8;
}
/* v2 → v3 : les blocs trouvés deviennent un individu (même proportion, sur les nouveaux découpages).
   Il reste en cours si le gisement actuel est de son époque, sinon il part en réserve. */
function migrateFos(data) {
  const out = {}, site = data.site;
  Object.keys(data.fos || {}).forEach(fid => {
    const o = data.fos[fid], F = FOSSILS[fid]; if (!F || !o) return;
    const st = { done: !!o.done, where: o.where || '', ind: [], nk: 0, dup: 0 };
    if (!o.done && F.kind === 'frag' && o.found && o.found.length) {
      const n0 = OLD_BLOCKS[fid] || F.blocks, m = clamp(Math.round(o.found.length / n0 * F.blocks), 1, F.blocks - 1);
      const blocks = shuffle(mulberry32(hashStr(fid) ^ 0x5eed), allBlocks(fid)).slice(0, m), here = !!site && site.epoch === F.epoch;
      st.ind.push({ k: 1, site: here ? site.seed : 0, num: site ? site.num : 0, zone: here && site.last != null ? site.last : 24, found: blocks, lost: !here });
      st.nk = 1;
    }
    out[fid] = st;
  });
  return out;
}
/* le registre de la pierre en cours (ce que rapportent les gains) */
function normLot(L) {
  L.ore = L.ore || {}; L.frags = L.frags || {}; L.fragK = L.fragK || {}; L.ident = L.ident || []; L.uniques = L.uniques || [];
  L.oreCoins = L.oreCoins || 0; L.bonus = L.bonus || 0; L.gain = L.gain || 0; L.empty = L.empty || 0; L.dup = L.dup || 0; L.dupCoins = L.dupCoins || 0;
  return L;
}
const ledger = () => LEDGER || (LEDGER = normLot({}));
function addMoney(n) { G.money += n; if (!hudHold) syncMoney(true); }
function syncMoney(bump) {
  hudHold = false; shownMoney = G.money;
  updateHud();
  if (bump) { const m = $('hudMoney'); m.classList.remove('bump'); void m.offsetWidth; m.classList.add('bump'); }
}

/* ---------- navigation ---------- */
let SCREEN = 'carte';
function show(name) {
  /* quitter l'établi pendant le tutoriel, c'est le passer */
  if (TUTO && name !== 'etabli') { tutoFinish(); return; }
  if (G.voyage && !TUTO) name = 'musee';
  if (SAY && SAY.scope !== name) closeSay(true);
  if (name !== SCREEN) { hideToast(); Log.ev('ecran', { s: name }); }
  /* on quitte l'établi : une pierre déjà ouverte est rangée, une pierre entière attend */
  if (name !== 'etabli' && SCREEN === 'etabli') { if (CUR && CUR.state !== 'ready') endStone(); else if (B3) Bench3D.pause(); }
  /* l'établi n'existe que pendant la casse d'une pierre */
  if (name === 'etabli' && !G.stone && !CUR) name = 'carte';
  SCREEN = name;
  ['carte', 'etabli', 'musee'].forEach(n => {
    $('scr-' + n).hidden = n !== name;
    $('tab-' + n).setAttribute('aria-selected', n === name ? 'true' : 'false');
  });
  if (name === 'musee') { renderMuseum(); }
  if (name === 'etabli') { renderBench(); }
  if (name === 'carte') { if (mapDirty) { mapDirty = false; renderMapCanvas(); } else drawMapLayers(); renderTip(); if (!flushSay('carte')) { const m = pickSay('carte'); if (m) say(m, 'carte'); } }
  updateBadges(); updateTabs();
  Ambient.screen();
}
/* escale : la carte et l'établi sont fermés, l'étiquette d'époque devient « Escale » */
function updateTabs() {
  ['carte', 'etabli'].forEach(n => { const t = $('tab-' + n); t.classList.toggle('locked', !!G.voyage); t.setAttribute('aria-disabled', G.voyage ? 'true' : 'false'); });
  if (G.site) $('hudEpochName').textContent = G.voyage ? 'Escale' : EPOCHS[G.site.epoch].name;
  $('app').classList.toggle('in-escale', !!G.voyage);
}
function updateHud() {
  if (!hudHold || shownMoney === null) shownMoney = G.money;
  $('moneyVal').textContent = fmt(shownMoney);
  const all = Object.keys(FOSSILS), done = all.filter(id => fos(id).done).length;
  $('collVal').textContent = done + '/' + all.length;
}
function updateBadges() {
  const b = $('badgeBench');
  if (G.stone && SCREEN !== 'etabli') { b.hidden = false; b.textContent = '1'; } else b.hidden = true;
  const fresh = Object.keys(FOSSILS).some(id => fos(id).done && !G.seen[id]);
  $('badgeMuseum').hidden = !(fresh && SCREEN !== 'musee');
}
let toastT = 0;
/* un message bref : il s'efface vite, et dès qu'on change d'écran (il ne doit jamais traîner sur l'écran suivant) */
function toast(msg, ms) {
  const t = $('toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), ms || Math.min(2400, 1100 + msg.length * 22));
}
function hideToast() { clearTimeout(toastT); $('toast').classList.remove('show'); }
function applyEpochTheme() {
  const E2 = EPOCHS[G.site.epoch], st = $('app').style;
  st.setProperty('--epoch', E2.color); st.setProperty('--epoch-deep', E2.deep); st.setProperty('--epoch-wash', E2.wash);
  $('hudEpochName').textContent = E2.name;
}

/* ---------- gisement ---------- */
function newSite(epoch, num, offer) {
  /* une destination choisie à l'escale fixe le nombre de poches : on cherche une graine qui le donne */
  let seed = Math.floor(Math.random() * 1e9) + 1, S0 = generateSite(seed, epoch, num, null);
  for (let k = 0; offer && S0.poches.length !== offer.poches && k < 60; k++) { seed = Math.floor(Math.random() * 1e9) + 1; S0 = generateSite(seed, epoch, num, null); }
  G.site = { want: offer ? { veins: offer.veins, geodes: offer.geodes } : null, seed, epoch, num, dug: null, rev: null, last: null, stats: { ore: 0, bonus: 0, frags: 0, uniques: 0, completes: 0, dup: 0 }, holes: [], glass: 0, closed: false, empty: 0, tier: offer ? offer.tier : null };
  G.stone = null; CUR = null; if (B3) Bench3D.clear();
  /* on ne revient jamais sur un gisement : ses squelettes inachevés partent en réserve */
  let lost = 0;
  Object.keys(G.fos).forEach(fid => fos(fid).ind.forEach(I => { if (!I.lost && I.site !== G.site.seed) { I.lost = true; if (!fos(fid).done) lost++; } }));
  G.site.lostBefore = lost;
  /* ce que cache le gisement : un squelette par poche (espèces encore absentes du musée plus souvent) */
  const rng = mulberry32((seed ^ 0x5bd1e995) >>> 0), taken = {};
  G.site.poches = S0.poches.map(p => { const fid = pocheSpecies(epoch, rng, taken); taken[fid] = (taken[fid] || 0) + 1; return { z: p.z, fid, k: null, used: 0, done: false }; });
  G.site.uni = null;
  openSite();
  save();
}
function pocheSpecies(epoch, rng, taken) {
  const pool = EPOCHS[epoch].fossils.filter(f => FOSSILS[f].kind === 'frag');
  return pool[weightedIdx(rng, pool.map(f => RARITY[FOSSILS[f].rarity].weight * (fos(f).done ? 0.5 : 1.6) * (taken[f] >= 2 ? 0 : taken[f] ? 0.4 : 1)))];
}
/* partie d'avant la v4 : le gisement en cours est relevé à nouveau ; ses squelettes commencés gardent chacun leur poche */
function migrateSite() {
  const old = G.site, carry = [];
  EPOCHS[old.epoch].fossils.forEach(fid => { if (FOSSILS[fid].kind === 'frag' && !fos(fid).done) fos(fid).ind.forEach(I => { if (!I.lost && I.site === old.seed && I.found.length) carry.push({ fid, I }); }); });
  newSite(old.epoch, old.num);
  G.site.stats = Object.assign(G.site.stats, old.stats || {});
  G.site.lostBefore = 0;
  const zones = SITE.zones;
  carry.forEach(({ fid, I }) => {
    I.lost = false; I.site = G.site.seed;
    let p = G.site.poches.find(q => q.fid === fid && q.k == null);
    if (!p) {
      const pool = zones.filter(z => z.band === 'propice' && !z.patch && G.site.poches.every(q => zcheb(q.z, z.i) >= 2));
      const z = pool.length ? pool[Math.floor(Math.random() * pool.length)] : zones[I.zone] || zones[24];
      p = { z: z.i, fid, k: null, used: 0, done: false }; G.site.poches.push(p);
    }
    p.k = I.k; I.zone = p.z; I.hits = {}; I.hits[p.z] = 1;
  });
  siteV5(G.site);
  openSite();
  save();
}
/* v5 : les poches ont une position précise, le sous-sol a ses veines, la pièce unique sa cachette, et le séjour ses journées */
function siteV5(S) {
  const rng = mulberry32((S.seed ^ 0x2f6b) >>> 0);
  const at = (zi, j) => ({ x: Math.round(((zi % GRID) + 0.5 + (rng() - 0.5) * j) * CELL), y: Math.round((Math.floor(zi / GRID) + 0.5 + (rng() - 0.5) * j) * CELL) });
  S.poches.forEach(p => { const q = at(p.z, 0.5); if (p.x == null) { p.x = q.x; p.y = q.y; } p.used = p.used || 0; });
  if (!S.veins) {
    const n = S.want && S.want.veins != null ? S.want.veins : 5 + Math.floor(rng() * 4), w = { cuivre: 0.6, argent: 0.3, or: 0.1 }, set = SITE.ores;
    S.veins = [];
    for (let i = 0; i < n; i++) {
      let r = rng() * set.reduce((a, o) => a + w[o], 0), ore = set[0];
      for (const o of set) { r -= w[o]; if (r <= 0) { ore = o; break; } }
      S.veins.push({ x: Math.round((0.08 + rng() * 0.84) * MAPPX), y: Math.round((0.08 + rng() * 0.84) * MAPPX), ore });
    }
  }
  if (S.uni != null && !S.uniXY) S.uniXY = at(S.uni, 0.4);
  /* les géodes dorment loin des poches, dans la roche pauvre ou massive : elles rendent ces zones intéressantes */
  if (!S.geodes) {
    const want = S.want && S.want.geodes != null ? S.want.geodes : 2 + Math.floor(rng() * 2), far = SITE.zones.filter(z => z.band !== 'propice');
    const pool = far.length ? far : SITE.zones, ids = Object.keys(GEODES);
    S.geodes = [];
    for (let i = 0; i < want; i++) {
      const z = pool[Math.floor(rng() * pool.length)];
      let r = rng() * ids.reduce((a, k) => a + GEODES[k].w, 0), gem = ids[0];
      for (const k of ids) { r -= GEODES[k].w; if (r <= 0) { gem = k; break; } }
      S.geodes.push(Object.assign(at(z.i, 0.6), { gem, done: false }));
    }
  }
  if (!S.holes) { S.holes = []; S.closed = false; S.empty = 0; }
  if (S.glass == null) S.glass = 0;
}
/* squelettes en cours sur ce gisement (espèces pas encore identifiées) */
function openInds() {
  const out = [];
  if (!G.site) return out;
  EPOCHS[G.site.epoch].fossils.forEach(fid => { if (FOSSILS[fid].kind === 'frag' && !fos(fid).done) indsHere(fid).forEach(I => out.push({ fid, I })); });
  return out;
}
function openSite() {
  SITE = generateSite(G.site.seed, G.site.epoch, G.site.num, G.site.poches);
  SITE.poches = G.site.poches;
  siteV5(G.site);
  applySiteState(SITE, G.site);
  applyEpochTheme();
  renderMapChrome();
  renderMapCanvas();
}

/* ---------- l'expédition : fouilles financées, lunettes fragiles ---------- */
const maxDigs = () => DIG.digs[clamp(G.up.quantite, 0, DIG.digs.length - 1)];
const digsLeft = () => Math.max(0, maxDigs() - G.site.holes.length);
const glassMax = () => DIG.glass[clamp(G.up.chaleur, 0, DIG.glass.length - 1)];
const glassLeft = () => Math.max(0, glassMax() - (G.site.glass || 0));
const reach = () => DIG.reach;
const bordP = () => DIG.bordP;
const glassTime = () => DIG.glassT[clamp(G.up.chaleur, 0, DIG.glassT.length - 1)];
const siteOver = () => !!(G.site && G.site.closed);
const GL = { on: false };

/* ---------- écran carte ---------- */
function zoneLabel(z) {
  let look;
  if (z.mask && !z.revealed) look = z.mask === 'foret' ? 'couverte d’un bosquet' : 'couverte d’éboulis, ' + ROCKS[z.vis].look;
  else look = ROCKS[z.vis].look;
  const n = G.site.holes.filter(h => h.z === z.i).length;
  let st = n ? ', ' + n + ' trou' + (n > 1 ? 's' : '') : '';
  if (openInds().some(o => o.I.zone === z.i)) st += ', squelette en cours';
  return 'Zone ' + zname(z) + ' : ' + look + st + '. Creuser ici';
}
function renderMapChrome() {
  const E2 = EPOCHS[G.site.epoch];
  $('mapTitle').textContent = 'Gisement n°' + G.site.num;
  $('mapSub').textContent = E2.name + ' · ' + RELIEF_NAMES[SITE.relief];
  const grid = $('zoneGrid');
  if (!grid.children.length) {
    for (let i = 0; i < GRID * GRID; i++) { const b = document.createElement('button'); b.type = 'button'; b.dataset.z = i; grid.appendChild(b); }
  }
  refreshMapInfo();
  renderTip();
}
function refreshMapInfo() {
  const S = G.site;
  [...$('zoneGrid').children].forEach((b, i) => b.setAttribute('aria-label', zoneLabel(SITE.zones[i])));
  const left = digsLeft(), gl = glassLeft(), on = GL.on || S.closed;
  $('mapStamp').textContent = S.closed ? 'Expédition finie' : 'Fouilles ' + S.holes.length + ' / ' + maxDigs();
  const eb = $('eyeBtn');
  eb.setAttribute('aria-pressed', GL.on ? 'true' : 'false');
  eb.hidden = S.closed;
  eb.classList.toggle('broken', gl <= 0);
  eb.setAttribute('aria-label', gl > 0 ? 'Lunettes du professeur : maintenir pour lire le sous-sol autour des trous (' + gl + ' coup' + (gl > 1 ? 's' : '') + ' d’œil restant' + (gl > 1 ? 's' : '') + ')' : 'Lunettes cassées');
  $('eyeN').textContent = gl;
  $('heatLegend').hidden = !on;
  /* les coups de pelle : une case par coup, qui saute quand on creuse */
  const sg = $('siteGauge'), pips = $('digPips'), mx = maxDigs();
  sg.classList.toggle('low', left <= 3 && !S.closed); sg.classList.toggle('done', !!S.closed);
  $('dayLabel').innerHTML = S.closed ? 'Expédition terminée' : ic('shovel') + '<b id="digN">' + left + '</b>';
  if (pips.children.length !== mx) pips.innerHTML = '<i></i>'.repeat(mx);
  [...pips.children].forEach((el, i) => el.classList.toggle('on', i < left));
  if (refreshMapInfo.prev != null && left < refreshMapInfo.prev && left >= 0 && pips.children[left]) {
    const el = pips.children[left]; el.classList.remove('out'); void el.offsetWidth; el.classList.add('out');
    const n = $('digN'); if (n) { n.classList.remove('bump'); void n.offsetWidth; n.classList.add('bump'); }
  }
  refreshMapInfo.prev = left;
  $('siteGaugeVal').textContent = S.closed || left > 1 ? '' : left === 1 ? 'la dernière !' : 'épuisées';
  $('siteBones').hidden = !G.up.jauge;
  if (G.up.jauge) { const P = S.poches || [], left = P.filter(q => !q.done).length; $('siteBones').textContent = left ? 'Squelettes encore enfouis : ' + left + ' sur ' + P.length : 'Plus aucun squelette enfoui ici.'; }
  let note;
  if (S.closed) note = 'Les crédits de fouille sont épuisés : rentrez au musée choisir une nouvelle destination.';
  else if (!S.holes.length) note = 'Touchez la carte pour creuser. La bonne roche dit où chercher, pas où trouver.';
  else note = ['Touchez les lunettes : un instant, elles lisent le sous-sol près de vos trous.', 'Plus c’est chaud sous les lunettes, plus un squelette est proche.', 'Les lunettes sont fragiles : gardez vos coups d’œil pour les moments qui comptent.', 'Une poche donne plusieurs pierres : creusez tout autour.'][S.holes.length % 4];
  $('mapNote').textContent = note;
  $('mapOres').textContent = 'Minerais : ' + SITE.ores.map(o => ORES[o].name).join(', ');
  $('btnLeave').innerHTML = ic('museum') + 'Rentrer au musée';
  $('btnLeave').hidden = !S.closed;
  const mc = $('mapClosed'); mc.hidden = !S.closed;
  if (S.closed) mc.innerHTML = '<span class="stamp">Expédition terminée</span>';
}

/* ---------- scène d'introduction : le professeur Kayou dans la salle vide du musée ---------- */
function introScene(then) {
  if (document.querySelector('.intro')) return;
  closeSay(true);
  const el = document.createElement('div');
  el.className = 'intro'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', 'Introduction');
  el.innerHTML = '<div class="in-scene">' + museumHallSVG() + '<div class="in-prof"></div></div>' +
    '<div class="in-box"><div class="in-name">' + KAYOU.name + '<small>' + KAYOU.role + '</small></div><p class="in-text" aria-live="polite"></p>' +
    '<div class="in-foot"><span class="in-dots" aria-hidden="true">' + INTRO.map(() => '<i></i>').join('') + '</span><button class="btn ghost" type="button" id="inSkip">Passer</button><button class="btn primary" type="button" id="inNext">Suivant</button></div></div>';
  $('app').appendChild(el);
  Ambient.setMode('joyeux');
  let page = -1, typing = null;
  const txt = el.querySelector('.in-text'), prof = el.querySelector('.in-prof'), next = el.querySelector('#inNext');
  const finish = () => {
    if (!el.isConnected || el.classList.contains('leaving')) return;
    if (typing) typing.skip();
    G.notes.intro = 1; G.notes.kayou = 1; G.tuto = 1; save();
    el.classList.add('leaving'); setTimeout(() => el.remove(), 300);
    Sound.play('tap');
    if (then) then(); else Ambient.setMode('calme');
  };
  const go = () => {
    if (typing && typing.busy) { typing.skip(); return; }
    page++;
    if (page >= INTRO.length) { finish(); return; }
    const P = INTRO[page];
    prof.innerHTML = kayouSVG(P.expr, 'bust');
    prof.classList.remove('talk'); void prof.offsetWidth; prof.classList.add('talk');
    el.querySelectorAll('.in-dots i').forEach((d, i) => d.classList.toggle('on', i <= page));
    next.innerHTML = page === INTRO.length - 1 ? (then ? ic('hammer') + 'À l’établi' : ic('map') + 'En route') : 'Suivant' + ic('arrow');
    typing = typeLine(txt, nbsp(P.text));
  };
  el.querySelector('.in-scene').onclick = go;
  next.onclick = go;
  el.querySelector('#inSkip').onclick = finish;
  el.querySelector('.in-box').addEventListener('click', e => { if (!e.target.closest('button')) go(); });
  el.addEventListener('keydown', e => { if (e.key === 'Escape') finish(); });
  go();
  setTimeout(() => next.focus({ preventScroll: true }), 50);
}
/* texte qui s'écrit ; un tap le termine d'un coup */
function typeLine(el, text) {
  const st = { busy: true, t: 0 };
  st.skip = () => { clearTimeout(st.t); el.textContent = text; st.busy = false; };
  if (reduceMotion()) { st.skip(); return st; }
  let i = 0;
  const step = () => { i = Math.min(text.length, i + 2); el.textContent = text.slice(0, i); if (i % 8 === 0) Sound.play('type'); if (i < text.length) st.t = setTimeout(step, 20); else st.busy = false; };
  step();
  return st;
}
/* arrivée sur un gisement : le professeur donne le ton (et un indice de roche sur les premiers) */
function sayArrival(covered) {
  if (!G.site || !SITE) return;
  const ep = EPOCHS[G.site.epoch], propices = ROCK_WORDS[ep.rocks.propice][1];
  let t = G.site.num === 1 ? ARRIVEE.premier : kyFill(ARRIVEE.suivant, { n: G.site.num, epoque: ep.name }) + ' ' + ARRIVEE.relief[SITE.relief];
  if (G.site.num <= 3) t += ' ' + kyFill(ARRIVEE.roche, { propices });
  /* au deuxième gisement : le professeur pousse à remplir les caisses pour s'équiper */
  if (G.site.num === 2 && !G.notes.equipe) { G.notes.equipe = 1; t += ' ' + ARRIVEE.equipe; save(); }
  if (G.site.lostBefore && !G.notes.reserve) { G.notes.reserve = 1; t += ' ' + ARRIVEE.reserve; save(); }
  if (covered) t = ARRIVEE.avance + ' ' + t;
  say({ id: 'arrivee', expr: covered ? 'soucieux' : 'content', text: t }, 'carte');
}
/* messages du professeur sous la carte : dernier jour, ou il est temps de s'équiper */
function renderTip() {
  const box = $('tipBox');
  let key = null, msg = null;
  if (!G.voyage && G.site && SITE && !G.site.closed) {
    const said = G.site.said || (G.site.said = {});
    const open = UPGRADES.filter(u => G.up[u.id] < u.max).map(u => u.cost[G.up[u.id]]), cheapest = open.length ? Math.min(...open) : Infinity;
    if (digsLeft() <= 3 && digsLeft() > 0 && !said.dernier) { key = 'dernier'; msg = ESCALE.dernier; }
    else if (!G.notes.equipe && G.stones >= 8 && G.money >= 60 + cheapest) { key = 'equipe'; msg = ESCALE.equipe; }
  }
  $('mapNote').hidden = !!msg;
  if (!msg) { box.innerHTML = ''; return; }
  box.innerHTML = '<div class="tip ky-tip">' + kyInline(msg, '<div class="tip-actions"><button class="btn" id="tipOk">' + ic('check') + 'Compris</button></div>') + '</div>';
  $('tipOk').onclick = () => { if (key === 'dernier') G.site.said.dernier = 1; else G.notes.equipe = 1; save(); renderTip(); };
}
let renderToken = 0;
function renderMapCanvas() {
  const tok = ++renderToken;
  /* le panneau « chargement » seulement au premier dessin d'un gisement : un redessin (zone dévoilée par un trou) ne doit pas flasher */
  const first = renderMapCanvas.seed !== (G.site && G.site.seed);
  if (first) $('mapLoading').hidden = false;
  const go = () => {
    if (tok !== renderToken) return;
    MapView.render(SITE);
    drawMapLayers();
    $('mapLoading').hidden = true;
    renderMapCanvas.seed = G.site && G.site.seed;
  };
  const fontsReady = document.fonts && document.fonts.ready ? Promise.race([document.fonts.ready, new Promise(r => setTimeout(r, 1200))]) : Promise.resolve();
  fontsReady.then(() => requestAnimationFrame(() => setTimeout(go, 20)));
}
/* ce que lisent les lunettes : la chaleur des poches (encore pleines), un peu les veines, et la cachette de la pièce unique */
function heatSources() {
  const S = G.site, out = [];
  S.poches.forEach(p => out.push({ x: p.x, y: p.y, w: p.done ? 0.3 : 1, s: 2.2 }));
  (S.veins || []).forEach(v => out.push({ x: v.x, y: v.y, w: 0.38, s: 0.4 }));
  if (S.uni != null && S.uniXY) out.push({ x: S.uniXY.x, y: S.uniXY.y, w: 0.75, s: 0.8 });
  (S.geodes || []).forEach(q => { if (!q.done) out.push({ x: q.x, y: q.y, w: 0.42, s: 0.45 }); });
  return out;
}
function drawMapLayers() {
  if (!MapView.zm || !G.site) return;
  const S = G.site, pins = [];
  openInds().forEach(o => {
    const p = S.poches.find(q => q.fid === o.fid && q.k === o.I.k), z = SITE.zones[o.I.zone];
    pins.push({ x: p ? p.x : (z.x + 0.5) * CELL, y: p ? p.y : (z.y + 0.5) * CELL, f: o.I.found.length / FOSSILS[o.fid].blocks });
  });
  const spent = G.up.jauge ? S.poches.filter(p => p.done) : [];
  MapView.drawOverlay({ holes: S.holes, pins, spent, color: EPOCHS[S.epoch].deep, dusk: 0 });
  MapView.drawGlasses({ on: GL.on, all: S.closed, holes: S.holes, reach: reach() * CELL, sources: heatSources() });
  refreshMapInfo();
}
/* ---------- le coup de pelle sur la carte ---------- */
const SHOVEL_SVG = '<svg viewBox="0 0 34 84" width="34" height="84" aria-hidden="true"><g stroke="#2a2318" stroke-linejoin="round" stroke-linecap="round">' +
  '<path d="M11 13 L11 5 Q17 0 23 5 L23 13" fill="none" stroke-width="5"/><path d="M11 13 L11 5 Q17 0 23 5 L23 13" fill="none" stroke="#b07d4c" stroke-width="2.4"/>' +
  '<path d="M9.5 13 H24.5" stroke-width="2.6"/>' +
  '<rect x="15" y="12" width="4" height="34" rx="1" fill="#a8774a" stroke-width="1.3"/>' +
  '<path d="M13.5 44 H20.5 L21 53 H13 Z" fill="#7f7a6e" stroke-width="1.3"/>' +
  '<path d="M7 52 H27 V69 Q27 79 17 84 Q7 79 7 69 Z" fill="#b9b4a8" stroke-width="1.7"/>' +
  '<path d="M10.5 56 V70 Q11 75 14 78" fill="none" stroke="#ece8de" stroke-width="1.6"/></g></svg>';
function shovelFx(box, x, y) {
  const fx = document.createElement('div');
  fx.className = 'dig-fx'; fx.style.left = x + 'px'; fx.style.top = y + 'px';
  fx.innerHTML = '<i class="dig-crater"></i><div class="dig-clip">' + SHOVEL_SVG + '</div>';
  box.appendChild(fx);
  Sound.play('pelle');
  const sv = fx.querySelector('svg'), fast = G.set.rapide ? 0.7 : 1;
  if (!sv.animate) { setTimeout(() => fx.remove(), 600); return; }
  /* vue de côté, à la Zelda : la pelle se lève sur place, s'enfonce d'un coup sec (la lame disparaît sous le sol), fait levier, ressort */
  sv.animate([
    { transform: 'translate(0,-9px) rotate(7deg)', opacity: 0 },
    { transform: 'translate(0,-8px) rotate(7deg)', opacity: 1, offset: 0.14 },
    { transform: 'translate(0,-10px) rotate(7deg)', opacity: 1, offset: 0.2, easing: 'cubic-bezier(.6,0,1,.6)' },
    { transform: 'translate(0,10px) rotate(5deg)', opacity: 1, offset: 0.3 },
    { transform: 'translate(0,10px) rotate(5deg)', opacity: 1, offset: 0.42, easing: 'cubic-bezier(.3,0,.3,1)' },
    { transform: 'translate(-1px,8px) rotate(-30deg)', opacity: 1, offset: 0.6 },
    { transform: 'translate(-3px,-5px) rotate(-36deg)', opacity: 1, offset: 0.8 },
    { transform: 'translate(-3px,-9px) rotate(-36deg)', opacity: 0 }
  ], { duration: 620 * fast, fill: 'forwards' });
  fx.querySelector('.dig-crater').animate([{ transform: 'scale(0)', opacity: 0 }, { transform: 'scale(.5)', opacity: 0.7, offset: 0.3 }, { transform: 'scale(1)', opacity: 1, offset: 0.6 }, { transform: 'scale(1.05)', opacity: 0 }], { duration: 700 * fast, fill: 'forwards' });
  /* les mottes : jetées vers l'arrière par la bascule, elles retombent */
  setTimeout(() => {
    for (let i = 0; i < 8; i++) {
      const c = document.createElement('i'), s = 2 + Math.random() * 2.2;
      c.className = 'dig-clod'; c.style.width = s + 'px'; c.style.height = (s * (0.7 + Math.random() * 0.4)) + 'px';
      c.style.background = ['#5f4426', '#7a5a36', '#94714a', '#4a3520'][i % 4];
      fx.appendChild(c);
      const vx = -8 - Math.random() * 22, vy = -20 - Math.random() * 16, kf = [];
      for (let k = 0; k <= 6; k++) { const t = k / 6; kf.push({ transform: 'translate(' + (vx * t).toFixed(1) + 'px,' + (vy * t + 46 * t * t).toFixed(1) + 'px) rotate(' + Math.round(t * 260 * (Math.random() < 0.5 ? -1 : 1)) + 'deg)', opacity: t > 0.85 ? 0 : 1 }); }
      c.animate(kf, { duration: (340 + Math.random() * 120) * fast, easing: 'linear', fill: 'forwards' });
    }
  }, 370 * fast);
  setTimeout(() => fx.remove(), 900 * fast);
}
function setupMap() {
  const box = $('mapBox'), grid = $('zoneGrid');
  grid.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b || !SITE || !MapView.zm) return;
    if (now() < mapGuardUntil) return;
    if (SAY && SAY.scope === 'carte') closeSay(true);
    let p = null;
    if (e.detail > 0 && (e.clientX || e.clientY)) {
      p = MapView.pointAtClient($('cvTerrain'), e.clientX, e.clientY);
      const S = G.site, r = box.getBoundingClientRect();
      /* un vrai coup de pelle : elle se plante, bascule, et la terre saute ; le trou s'ouvre quand la terre part */
      if (p && S && !G.stone && !G.voyage && !S.closed && digsLeft() > 0 && !S.holes.some(h => Math.hypot(h.x - p.x, h.y - p.y) < CELL * 0.3)) {
        mapGuardUntil = now() + 620;
        shovelFx(box, e.clientX - r.left, e.clientY - r.top);
        const pp = p; setTimeout(() => dig(pp, true), 370);
        return;
      }
      const ring = document.createElement('i');
      ring.className = 'tap-ring'; ring.style.left = (e.clientX - r.left) + 'px'; ring.style.top = (e.clientY - r.top) + 'px';
      box.appendChild(ring); setTimeout(() => ring.remove(), 420);
    }
    if (!p) { const zi = +b.dataset.z, z = SITE.zones[zi]; p = { x: (z.x + 0.5 + (Math.random() - 0.5) * 0.5) * CELL, y: (z.y + 0.5 + (Math.random() - 0.5) * 0.5) * CELL }; }
    mapGuardUntil = now() + 220;
    dig(p);
  });
  if (window.matchMedia && matchMedia('(hover: hover)').matches) {
    box.addEventListener('pointermove', e => { if (!MapView.zm || !G.site || G.site.closed) return; MapView.drawHover(MapView.pointAtClient($('cvTerrain'), e.clientX, e.clientY), GL.on); });
    box.addEventListener('pointerleave', () => MapView.drawHover(null));
  }
  /* les lunettes ne voient que tant qu'on les tient ; chaque coup d'œil les use */
  const eb = $('eyeBtn');
  eb.addEventListener('click', e => { e.preventDefault(); glassOn(); });
  eb.addEventListener('contextmenu', e => e.preventDefault());
  window.addEventListener('keydown', e => { if ((e.key === 'l' || e.key === 'L') && !e.repeat && SCREEN === 'carte' && !document.querySelector('.intro,.sheet-back')) glassOn(); });
  $('btnLeave').onclick = openLeave;
}

function glassOn() {
  const S = G.site;
  if (GL.on || !S || S.closed || G.voyage || !SITE) return;
  if (SAY && SAY.scope === 'carte') closeSay(true);
  if (!S.holes.length) { toast('Creusez d’abord : les lunettes lisent autour des trous.'); return; }
  if (glassLeft() <= 0) { toast('Lunettes cassées : le musée les réparera à l’escale.'); return; }
  S.glass = (S.glass || 0) + 1; GL.on = true; save();
  Log.ev('lunettes', { g: S.num, trous: S.holes.length });
  Sound.play('glow'); buzz(8);
  MapView.drawHover(null);
  drawMapLayers();
  /* un coup d'œil : la chaleur reste le temps des lunettes, l'anneau du bouton se vide */
  const T = glassTime() * 1000, t0 = now(), eb = $('eyeBtn');
  const tick = () => { if (!GL.on) { eb.style.removeProperty('--g'); return; } const k = (now() - t0) / T; if (k >= 1) { eb.style.removeProperty('--g'); glassOff(); return; } eb.style.setProperty('--g', (1 - k).toFixed(3)); requestAnimationFrame(tick); };
  requestAnimationFrame(tick);
}
function glassOff() {
  if (!GL.on) return;
  GL.on = false;
  drawMapLayers();
  if (!G.notes.lunettes) { G.notes.lunettes = 1; save(); toast('Plus c’est chaud, plus un squelette est proche.'); }
  if (glassLeft() <= 0) { Sound.play('cassure'); buzz([20, 30, 20]); const b = $('eyeBtn'); b.classList.remove('crack'); void b.offsetWidth; b.classList.add('crack'); toast(FIN.casse); }
}
/* ---------- creuser ----------
   Un toucher, un trou, n'importe où. Chaque coup de pelle sort une pierre : c'est l'endroit qui décide de ce qu'elle cache.
   Près d'une poche, un os ; ailleurs, du minerai ou une géode. Les lunettes disent où sont les fossiles. */
const EMPTY = ['Rien que de la terre.', 'Un trou de plus. Rien dedans.', 'De la caillasse, et c’est tout.', 'Rien. La terre est muette ici.'];
function dig(p, quiet) {
  if (!p || G.voyage || !G.site) return;
  const S = G.site;
  if (G.stone) { show('etabli'); return; }
  if (S.closed || digsLeft() <= 0) { toast('Plus de coups de pelle sur ce gisement.'); return; }
  if (S.holes.some(h => Math.hypot(h.x - p.x, h.y - p.y) < CELL * 0.3)) { toast('Déjà creusé ici.'); return; }
  const zi = MapView.zoneAt(p.x, p.y), z = SITE.zones[zi];
  /* le trou montre la vraie roche : une zone masquée se révèle */
  if (z.mask && !z.revealed) { z.revealed = true; z.vis = z.rock; mapDirty = true; }
  z.dug++;
  G.site.last = zi;
  const f = holeFind(p, z);
  Log.ev('pelle', { g: S.num, zone: zi, bande: z.band, trouve: f ? f.bias : 'rien', reste: digsLeft() - 1 });
  const h = { x: Math.round(p.x), y: Math.round(p.y), z: zi, k: f ? 'pierre' : 'vide' };
  S.holes.push(h);
  if (!quiet) Sound.play('deblai'); buzz(12);
  if (f) {
    /* une série de pierres loin des poches : le professeur pourra encourager au retour sur la carte */
    if (f.bias === 'poche' || f.bias === 'bord') S.empty = 0; else S.empty = (S.empty || 0) + 1;
    const seed = (Math.imul(S.seed ^ 0x2545f491, 31) + Math.imul(S.holes.length, 2654435761)) >>> 0;
    G.stone = Object.assign({ seed, hole: S.holes.length - 1, zone: zi, rock: z.rock }, f);
    G.stone.contents = stoneContents(G.stone);
    Sound.play('clonk');
    save();
    if (mapDirty) { mapDirty = false; renderMapCanvas(); } else drawMapLayers();
    setTimeout(() => { if (G.stone && SCREEN === 'carte') show('etabli'); }, 620);
    return;
  }
  S.empty = (S.empty || 0) + 1;
  const spent = S.poches.some(q => q.done && Math.hypot(q.x - p.x, q.y - p.y) < CELL * 0.5);
  toast(spent ? 'Plus rien : cette poche est vidée.' : EMPTY[Math.floor(Math.random() * EMPTY.length)]);
  save();
  if (mapDirty) { mapDirty = false; renderMapCanvas(); } else drawMapLayers();
  if (!G.notes.trou && S.holes.length >= 2) { G.notes.trou = 1; save(); say(Object.assign({ id: 'trou' }, NOTES.trou), 'carte'); }
  else holeStreak(z);
  if (digsLeft() <= 0) setTimeout(closeSite, 900);
  else if (digsLeft() <= 3) renderTip();
}
function holeFind(p, z) {
  const S = G.site, d = q => Math.hypot(q.x - p.x, q.y - p.y) / CELL;
  const gi = (S.geodes || []).findIndex(q => !q.done && d(q) < 0.5);
  if (gi >= 0) { S.geodes[gi].done = true; return { bias: 'geode', gem: S.geodes[gi].gem }; }
  let pi = -1, bd = 1e9;
  S.poches.forEach((q, i) => { if (q.done) return; const dd = d(q); if (dd < bd) { bd = dd; pi = i; } });
  if (pi >= 0 && bd < DIG.pocheR) return { bias: 'poche', pi };
  if (pi >= 0 && bd < DIG.bordR && Math.random() < bordP()) return { bias: 'bord', pi };
  const v = (S.veins || []).find(q => d(q) < DIG.veinR);
  if (v) return { bias: 'veine', ore: v.ore };
  /* chaque coup de pelle sort une pierre : loin des poches, c'est la zone qui décide (minerai, plus riche en roche pauvre) */
  return { bias: 'caillou', ore: pickOre(z.band) };
}
/* ce que cache chaque fil de la pierre. Décidé à la sortie et sauvegardé : la pierre ne change plus.
   Roche litée : 2 ou 3 feuillets, parfois un joint oblique ; roche massive : deux joints. */
function stoneContents(st) {
  const rnd = mulberry32((st.seed ^ 0x6c8e) >>> 0), bedded = !!ROCKS[st.rock].bedded, out = [];
  const nb = bedded ? (rnd() < 0.45 ? 3 : 2) : 0, joint = bedded ? rnd() < 0.3 : true;
  for (let i = 0; i < nb; i++) out.push({ type: 'rien', joint: false });
  if (joint) out.push({ type: 'rien', joint: true });
  if (!bedded) out.push({ type: 'rien', joint: true });
  const p = st.pi != null ? G.site.poches[st.pi] : null, fid = p ? p.fid : null;
  /* le fil principal n'est jamais vide : chaque pierre a quelque chose à gagner */
  let main;
  if (st.bias === 'poche') main = { type: 'os', fid };
  else if (st.bias === 'bord') main = rnd() < DIG.bordOs ? { type: 'os', fid } : { type: 'veine', ore: pickOre() };
  else if (st.bias === 'geode') return [{ type: 'geode', gem: st.gem, joint: true }];
  else main = { type: 'veine', ore: st.ore || pickOre() };
  /* les veines aiment les joints */
  const joints = out.map((c, i) => (c.joint ? i : -1)).filter(i => i >= 0), beds = out.map((c, i) => (!c.joint ? i : -1)).filter(i => i >= 0);
  let mi = main.type === 'veine' && joints.length && rnd() < 0.6 ? joints[0] : beds.length ? beds[Math.floor(rnd() * beds.length)] : joints[Math.floor(rnd() * joints.length)];
  out.forEach((c, i) => {
    if (i === mi) { Object.assign(c, main); return; }
    const r = rnd();
    if (r < 0.45 || (c.joint && r < 0.7)) Object.assign(c, { type: 'veine', ore: pickOre() });
  });
  /* une pierre à os garde presque toujours une veine de repli : le joueur qui ne trouve pas l'os peut sécuriser un gain */
  if (main.type === 'os' && !out.some(c => c.type === 'veine') && out.length > 1 && rnd() < DIG.repli) {
    const free = out.map((c, i) => (c.type === 'rien' ? i : -1)).filter(i => i >= 0);
    if (free.length) Object.assign(out[free[Math.floor(rnd() * free.length)]], { type: 'veine', ore: pickOre() });
  }
  return out;
}
/* les anciennes sauvegardes : l'éclat n'existe plus, c'est un os comme les autres */
/* les anciennes sauvegardes : l'éclat n'existe plus (c'est un os), la pièce unique non plus (sa cachette devient une veine) */
const legacyContents = cs => (cs || []).map(c => (c.type === 'eclat' ? Object.assign({}, c, { type: 'os' }) : c.type === 'unique' ? { type: 'veine', joint: c.joint, ore: 'cuivre' } : c));
/* les fouilles financées sont épuisées : tout le sous-sol se dévoile, puis retour au musée */
function closeSite() {
  const S = G.site; if (!S || S.closed || G.stone || G.voyage || digsLeft() > 0) return;
  S.closed = true; GL.on = false; save();
  Log.ev('fin_gisement', Object.assign({ g: S.num, epoque: S.epoch, pelles: S.holes.length, lunettes: S.glass || 0, argent: G.money }, S.stats));
  drawMapLayers();
  renderTip();
  Sound.play('glow');
  say({ id: 'fin', expr: 'content', text: FIN.fouilles }, 'carte');
}
function pickOre(band) {
  const w = band === 'sterile' ? { cuivre: 0.45, argent: 0.35, or: 0.2 } : { cuivre: 0.6, argent: 0.3, or: 0.1 }, set = SITE.ores;
  let r = Math.random() * set.reduce((a, o) => a + w[o], 0);
  for (const o of set) { r -= w[o]; if (r <= 0) return o; }
  return set[0];
}

/* ---------- ce que la pierre rend, selon le fil ouvert et la qualité du coup ----------
   os : un bloc du squelette de la poche, de 1 à 3 étoiles selon la proximité du gros POK et la fatigue (jamais 0 sur le bon fil).
   Parfois l'os sort avec ses voisins : plusieurs blocs du même squelette d'un coup, jusqu'au squelette entier (voir PIECES).
   veine : du minerai, plus ou moins selon la proximité du ting le plus clair.
   La pierre éclatée de travers ne rend rien ; si la cassure traverse un os, il est perdu. */
function stoneResult(o) {
  const st = CUR.stone, z = SITE.zones[st.zone], C = (o.plane >= 0 && st.contents[o.plane]) || { type: 'rien' }, good = o.quality === 'intact';
  const p = st.pi != null ? G.site.poches[st.pi] : null;
  let res;
  if (o.quality === 'eclatee') res = [{ t: 'vide', why: 'eclat' }];
  else if (o.quality === 'casse') { res = [{ t: 'vide', why: C.type === 'unique' ? 'casse_u' : 'casse', fid: C.fid }]; if (p && C.type !== 'unique') p.used = (p.used || 0) + 1; }
  else if (C.type === 'os' && p) {
    if (p.done) res = [gainOre(pickOre(), starsOf(o, 'veine'))];
    else if (fos(p.fid).done) res = [gainKnown(p, starsOf(o, C.type))];
    else {
      p.used = (p.used || 0) + 1;
      const stars = starsOf(o, C.type);
      res = stars ? [gainFragment(p, z, stars)] : [{ t: 'vide', why: 'miettes', fid: p.fid }];
      /* rarement, l'os sort d'un seul tenant avec ses voisins : une pièce double, triple… jusqu'au squelette entier */
      if (stars && res[0].t === 'fragment' && !res[0].done) {
        const k = rollPieces(p.fid, stars), I = indOf(p.fid, res[0].k);
        for (let i = 1; i < k && I && I.found.length < FOSSILS[p.fid].blocks; i++) { const b = gainFragment(p, z, stars, true); b.extra = true; res.push(b); }
        if (res.length > 1) res.forEach(r => (r.pieces = res.length));
      }
    }
    if (!p.done && p.used >= FOSSILS[p.fid].blocks + DIG.extra) p.done = true;
  }
  else if (C.type === 'geode') { const s = starsOf(o, 'geode'); res = [gainGeode(C.gem || 'quartz', s, o.force)]; }
  else if (C.type === 'veine') res = [gainOre(C.ore || pickOre(), starsOf(o, 'veine'))];
  else res = [{ t: 'vide', why: 'roche' }];
  const L = ledger(), ep = SITE.epoch;
  if (res.every(r => r.t === 'vide')) L.empty++;
  if (EPOCHS[ep].fossils.every(f => fos(f).done) && !G.cols[ep]) {
    G.cols[ep] = true; addMoney(COLUMN_BONUS); G.site.stats.bonus += COLUMN_BONUS; L.bonus += COLUMN_BONUS; L.gain += COLUMN_BONUS; L.col = ep;
    res.push({ t: 'colonne', ep, bonus: COLUMN_BONUS });
  }
  const lost = starsWhy(o, C.type);
  if (lost.length) res.forEach(r => { if ((r.stars != null && r.stars < 3) || r.why === 'miettes') r.lost = lost; });
  return res;
}
/* une géode : revendue selon l'état de ses cristaux, et comptée pour la future aile géologie */
function gainGeode(gem, stars, force) {
  const L = ledger(), Gd = GEODES[gem], gain = Math.round(Gd.val * (0.5 + 0.25 * stars));
  addMoney(gain); G.site.stats.ore += gain; L.gain += gain;
  G.gems = G.gems || {}; G.gems[gem] = (G.gems[gem] || 0) + 1;
  G.gemBest = G.gemBest || {}; G.gemBest[gem] = Math.max(G.gemBest[gem] || 0, stars || 0);
  return { t: 'geode', gem, stars, gain, force };
}
/* le minerai : 1 à 3 étoiles selon la proximité du ting (×0,6 / ×1 / ×1,4 de la valeur) */
function gainOre(ore, stars) {
  stars = clamp(stars == null ? 2 : stars, 1, 3);
  const L = ledger(), gain = Math.round(ORES[ore].value * ORE_MULT[stars]);
  addMoney(gain); G.site.stats.ore += gain;
  L.ore[ore] = (L.ore[ore] || 0) + 1; L.oreCoins += gain; L.gain += gain;
  G.ores = G.ores || {}; G.ores[ore] = (G.ores[ore] || 0) + 1;
  return { t: 'minerai', ore, gain, stars, clean: stars >= 3 };
}
/* un os de la poche p : il appartient au squelette de cette poche (créé au premier os trouvé).
   stars : sa conservation. Un bloc déjà dégagé est un doublon : le meilleur des deux reste au squelette, l'autre est revendu. */
function gainFragment(p, z, stars, fresh) {
  const fid = p.fid, F = FOSSILS[fid], st = fos(fid), n = F.blocks, L = ledger();
  stars = stars == null ? 2 : stars;
  let I = p.k != null ? indOf(fid, p.k) : null;
  const first = !I;
  if (!I) { I = { k: ++st.nk, site: G.site.seed, num: G.site.num, zone: p.z, found: [], q: {}, lost: false, hits: {} }; st.ind.push(I); p.k = I.k; }
  I.q = I.q || {};
  I.zone = p.z;
  G.last = fid; G.lastK = I.k; L.fragK[fid] = I.k;
  if (!G.ev.poche) G.ev.poche = 1;
  if (first && st.ind.filter(J => J.site === G.site.seed).length > 1 && !G.ev.individu) G.ev.individu = 1;
  if (!fresh && I.found.length && Math.random() < FRAG.doublon * I.found.length / n) {
    const block = I.found[Math.floor(Math.random() * I.found.length)], old = I.q[block] == null ? 2 : I.q[block], better = stars > old;
    if (better) I.q[block] = stars;
    const gain = dupVal(fid, better ? old : stars);
    addMoney(gain); st.dup = (st.dup || 0) + 1; G.site.stats.dup = (G.site.stats.dup || 0) + 1;
    L.dup++; L.dupCoins += gain; L.gain += gain;
    if (!G.ev.doublon) G.ev.doublon = 1;
    return { t: 'doublon', fid, block, k: I.k, gain, stars, old, better, n: I.found.length, of: n };
  }
  const miss = [];
  for (let i = 0; i < n; i++) if (!I.found.includes(i)) miss.push(i);
  const block = miss[Math.floor(Math.random() * miss.length)], before = I.found.slice(), beforeQ = Object.assign({}, I.q);
  I.found.push(block); I.q[block] = stars; G.site.stats.frags++;
  L.frags[fid] = (L.frags[fid] || 0) + 1;
  let bonus = 0, done = false, mean = 0;
  if (I.found.length >= n) {
    /* identification : la prime suit la conservation moyenne du squelette */
    mean = I.found.reduce((a, b) => a + (I.q[b] == null ? 2 : I.q[b]), 0) / n;
    st.done = true; done = true; p.done = true; st.where = 'Gisement n°' + G.site.num + ', zone ' + zname(SITE.zones[I.zone]);
    st.q = Object.assign({}, I.q); st.stars = Math.round(mean * 10) / 10;
    bonus = Math.round(RARITY[F.rarity].bonus * (0.5 + 0.25 * mean)); addMoney(bonus); G.site.stats.bonus += bonus; G.site.stats.completes++;
    L.ident.push(fid); L.bonus += bonus; L.gain += bonus;
  }
  return { t: 'fragment', fid, block, before, beforeQ, stars, done, bonus, mean, n: I.found.length, of: n, k: I.k, fresh: first && st.ind.length > 1, first };
}
/* os d'une espèce déjà au musée : s'il est mieux conservé que le nôtre, il le remplace ; l'autre est revendu */
function gainKnown(p, stars) {
  const fid = p.fid, F = FOSSILS[fid], st = fos(fid), L = ledger(), n = F.blocks, block = Math.floor(Math.random() * n);
  stars = stars == null ? 2 : stars;
  st.q = st.q || {};
  const old = st.q[block] == null ? 2 : st.q[block], better = stars > old;
  if (better) { st.q[block] = stars; st.stars = Math.round(allBlocks(fid).reduce((a, b) => a + (st.q[b] == null ? 2 : st.q[b]), 0) / n * 10) / 10; }
  const gain = dupVal(fid, better ? old : stars);
  addMoney(gain); st.dup = (st.dup || 0) + 1; G.site.stats.dup = (G.site.stats.dup || 0) + 1;
  L.dup++; L.dupCoins += gain; L.gain += gain;
  p.used = (p.used || 0) + 1; if (p.used >= n + DIG.extra) p.done = true;
  G.last = fid; G.lastK = null;
  if (!G.ev.doublon) G.ev.doublon = 1;
  return { t: 'doublon', fid, block, known: true, gain, stars, old, better, n, of: n };
}
/* ---------- conservation : de 0 (brisé) à 3 étoiles ---------- */
const STARS = s => '★'.repeat(s) + '☆'.repeat(Math.max(0, 3 - s));
function starsOf(o, type) {
  if (!o || o.score == null) return 2;
  /* score = proximité × (1 − fatigue/2) : le bon fil ouvert rend toujours au moins une étoile ; zéro, c'est la pierre éclatée */
  return o.score >= STAR_AT[1] ? 3 : o.score >= STAR_AT[0] ? 2 : 1;
}
/* pourquoi des étoiles se sont perdues : le joueur doit pouvoir le comprendre */
function starsWhy(o, type) {
  if (!o || type === 'geode') return [];
  const w = [], mot = type === 'veine' ? 'ting le plus clair' : 'plus gros POK';
  if (o.aim != null && o.aim < 0.8) w.push(o.aim < 0.45 ? 'frappé loin du ' + mot : 'frappé un peu à côté du ' + mot);
  if ((o.fatigue || 0) > 0.35) w.push(o.fatigue > 0.7 ? 'pierre très fatiguée' : 'pierre fatiguée');
  return w;
}
const dupVal = (fid, s) => Math.round(RARITY[FOSSILS[fid].rarity].dup * [0.3, 0.6, 1, 1.5][clamp(s, 0, 3)]);
const qualOf = fid => { const st = fos(fid); if (st.done) return st.q || null; const b = bestInd(fid); return b ? b.q || null : null; };
/* pièces multiples : 2 % de pièces doubles, 0,5 % de triples, 0,1 % de quadruples… plus fréquent chez les espèces communes */
/* plusieurs blocs d'un coup : l'os sort de la pierre avec ses voisins. C'est le grand coup de chance du jeu.
   p : chance d'au moins 2, 3, 4, 5, 6 blocs ; au-delà, chaque bloc de plus a une chance sur trois, jusqu'au squelette entier.
   mult : selon la rareté (les petites espèces sortent plus souvent entières) ; star : selon la conservation (une coupe nette libère mieux l'os). */
const PIECES = { p: [0.06, 0.02, 0.006, 0.002, 0.0006], more: 0.33, mult: { commun: 1.5, 'peu commun': 1, rare: 0.7, exceptionnel: 0.5 }, star: [0, 0.5, 1, 1.6] };
let PIECES_FORCE = 0;
function rollPieces(fid, stars) {
  if (PIECES_FORCE) { const k = PIECES_FORCE; PIECES_FORCE = 0; return k; }
  const m = (PIECES.mult[FOSSILS[fid].rarity] || 1) * PIECES.star[clamp(stars == null ? 2 : stars, 0, 3)], r = Math.random();
  let k = 1;
  PIECES.p.forEach((q, i) => { if (r < q * m) k = i + 2; });
  /* au-delà de la table : toujours plus rare, jusqu'au squelette entier */
  if (k === PIECES.p.length + 1) while (k < FOSSILS[fid].blocks && Math.random() < PIECES.more) k++;
  return k;
}
const deOre = o => (/^[aeiouéh]/i.test(ORES[o].name) ? 'd’' : 'de ') + ORES[o].name;
const PRIO = { complet: 5, fragment: 3, geode: 2.8, doublon: 2.5, minerai: 2, vide: 1, colonne: 0 };
function primaryOf(res) { return res.slice().sort((a, b) => (PRIO[b.t] + (b.done ? 1 : 0)) - (PRIO[a.t] + (a.done ? 1 : 0)))[0]; }
/* 0 rien · 1 minerai ou doublon · 2 fragment · 3 identification */
function tierOf(res) { const m = primaryOf(res); return m.t === 'fragment' ? (m.done ? 3 : 2) : m.t === 'minerai' || m.t === 'doublon' || m.t === 'geode' ? 1 : 0; }

/* ---------- écran établi : la pierre en 3D ---------- */
let benchDrawn = false;
const BENCH = { lift: 0 };
function renderBench() {
  const empty = !G.stone && !CUR;
  $('benchEmpty').hidden = !empty;
  ['benchTop', 'stage', 'benchBottom'].forEach(id => ($(id).style.visibility = empty ? 'hidden' : ''));
  paintBench();
  if (empty) { if (B3) Bench3D.clear(); return; }
  if (!CUR) loadStone();
  else { if (B3) Bench3D.resume(); if (!CUR.tuto) renderLotInfo(); }
}
function paintBench() {
  const cv = $('benchBg'), r = cv.getBoundingClientRect();
  if (!r.width) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 2), w = Math.round(r.width * dpr), h = Math.round(r.height * dpr);
  if (benchDrawn && cv.width === w && cv.height === h) return;
  cv.width = w; cv.height = h;
  drawBench(cv, 7);
  benchDrawn = true;
}
function renderLotInfo(skipChip) {
  const st = CUR ? CUR.stone : G.stone; if (!st) return;
  const z = SITE.zones[st.zone], R = ROCKS[st.rock];
  const dl = digsLeft();
  $('lotTag').innerHTML = '<b>Trou en ' + zname(z) + '</b><small>' + (st.contents && st.contents[0] && st.contents[0].type === 'geode' ? 'un nodule tout rond' : R.bedded ? 'roche litée' : 'roche massive') + ' · ' + (dl ? dl + ' coup' + (dl > 1 ? 's' : '') + ' de pelle restant' + (dl > 1 ? 's' : '') : 'dernière pierre') + '</small>';
  $('rockLabel').innerHTML = '<img src="' + rockSwatch(st.rock, 48) + '" alt=""><div><b>' + R.name + '</b><span>' + rockMsg(st.rock, z.band) + '</span></div>';
  if (!skipChip) renderChip();
}
function renderChip(bump) {
  const chip = $('fossilChip'), fid = G.last && FOSSILS[G.last].epoch === SITE.epoch ? G.last : null;
  if (!fid) {
    const E2 = EPOCHS[SITE.epoch], done = E2.fossils.filter(f => fos(f).done).length;
    chip.innerHTML = '<div><span class="nm">' + E2.name + '</span><span class="nm" style="font-size:12px;color:var(--ink-3)">' + done + '/' + E2.fossils.length + ' au musée</span></div>';
  } else {
    /* l'individu en cours (celui du dernier fragment), sinon le meilleur */
    const F = FOSSILS[fid], st = fos(fid), of = F.blocks || 1, I = F.kind === 'frag' && !st.done ? indOf(fid, G.lastK) || bestInd(fid) : null;
    const found = st.done ? allBlocks(fid) : I ? I.found : [], n = F.kind === 'unique' ? (st.done ? 1 : 0) : found.length;
    const sub = F.kind === 'unique' ? 'pièce unique' : st.done ? 'identifié' : n + '/' + of + ' blocs' + (I && st.ind.length > 1 ? ' · n°' + I.k : '');
    chip.innerHTML = fossilSVG(fid, F.kind === 'unique' ? (st.done ? 'full' : 'veiled') : 'puzzle', found, null, st.done ? st.q : I && I.q) +
      '<div style="min-width:0"><span class="nm">' + dispName(fid) + '</span><span class="pbar"><i style="width:' + Math.round(100 * n / of) + '%"></i></span><span class="nm" style="font-size:12px;color:var(--ink-3)">' + sub + '</span></div>';
  }
  if (bump) { chip.classList.remove('pulse'); void chip.offsetWidth; chip.classList.add('pulse'); }
}
function setFatigue(f, coups) {
  $('fatBar').style.width = Math.round(clamp(f, 0, 1) * 100) + '%';
  $('fatBar').classList.toggle('hot', f > 0.65);
  $('fatVal').textContent = coups + (coups > 1 ? ' coups' : ' coup');
}
function clearStage() {
  $('result').className = 'result';
  $('halo').className = 'halo'; $('halo').innerHTML = '';
  $('cleanStamp').classList.remove('on');
  $('dim').classList.remove('on');
  $('btnBack').hidden = true;
  $('scr-etabli').classList.remove('opened');
}
/* une pierre sortie du trou passe sur l'établi */
function loadStone() {
  const st = G.stone; if (!st) return;
  closeSay(true);
  LEDGER = normLot({});
  CUR = { stone: st, state: 'ready', res: null, tier: 0, heard: {}, t0: now(), miss: 0 };
  clearStage();
  const R = ROCKS[st.rock];
  paintBench();
  const nod = st.contents && st.contents[0] && st.contents[0].type === 'geode';
  if (B3) Bench3D.load({ seed: st.seed, pal: nod ? NODULE : R.stone, shape: nod ? 'nodule' : R.stone.shape, bedded: nod ? false : !!R.bedded, contents: st.contents, loupe: G.up.loupe, marteau: G.up.marteau, target: G.set.cible });
  setFatigue(0, 0);
  const hint = $('benchHint');
  hint.textContent = !B3 ? 'Touchez la pierre pour la fendre' : G.stones < 2 ? 'Glissez pour tourner · touchez pour tapoter · maintenez pour frapper' : G.stones < 5 ? 'Tapotez les fils et écoutez' : '';
  hint.style.opacity = hint.textContent ? 1 : 0;
  renderLotInfo();
  const m = pickSay('stone');
  if (m) say(m, 'etabli');
}
/* ce qu'on entend en tapotant : aux premières fois, le professeur explique */
function heard(k, n) {
  if (!CUR || CUR.state !== 'ready') return;
  CUR.heard[k] = (CUR.heard[k] || 0) + 1;
  const id = { creux: 'creux', ting: 'ting', bong: 'geode' }[k] || (k === 'sourd' && n >= 3 ? 'sourd' : null);
  if (!id || G.notes[id] || SAY) return;
  G.notes[id] = 1; G.noteAt = G.stones; save();
  setTimeout(() => { if (CUR && CUR.state === 'ready' && !SAY) say(Object.assign({ id }, NOTES[id]), 'etabli'); }, 450);
}
/* la face ouverte : le dessin du bloc (ou de la pièce entière) tel qu'il sortira de la pierre */
function capSVG(fid, vb, inner, pal, clip) {
  const [x0, y0, w, h] = vb, k = 512 / Math.max(w, h);
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + vb.map(r1).join(' ') + '" width="' + Math.round(w * k) + '" height="' + Math.round(h * k) + '">' +
    (clip ? '<defs><clipPath id="c"><path d="' + clip + '"/></clipPath></defs><g clip-path="url(#c)"' : '<g') + ' stroke-linecap="round" stroke-linejoin="round">' + ART[fid].fn(pal) + '</g>' + (inner || '') + '</svg>';
}
function pieceCap(fid, blocks) {
  blocks = [].concat(blocks);
  const cbs = blocks.map(b => cellBox(fid, b));
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  cbs.forEach(c => { x0 = Math.min(x0, c.x0); y0 = Math.min(y0, c.y0); x1 = Math.max(x1, c.x0 + c.bw); y1 = Math.max(y1, c.y0 + c.bh); });
  const bw = x1 - x0, bh = y1 - y0, pad = Math.max(bw, bh) * 0.05, vb = [x0 - pad, y0 - pad, bw + 2 * pad, bh + 2 * pad], d = cbs.map(c => polyD(c.cell, true)).join('');
  /* pas de contour géométrique : la pièce, c'est la part du dessin que contient le bloc */
  const edge = '';
  return { k: 'piece', fid, block: blocks[0], blocks, aspect: vb[2] / vb[3], scale: Math.sqrt(blocks.length), svg: capSVG(fid, vb, edge, FPAL[FOSSILS[fid].epoch], d), svgInk: capSVG(fid, vb, '', flatPal(VARIANT.ink), d) };
}
function wholeCap(fid) {
  const [W, H] = ART[fid].vb, vb = [0, 0, W, H];
  return { k: 'whole', fid, aspect: W / H, svg: capSVG(fid, vb, '', FPAL[FOSSILS[fid].epoch]), svgInk: capSVG(fid, vb, '', flatPal(VARIANT.ink)) };
}
function capFor(res, o, tier) {
  const main = primaryOf(res);
  let cap;
  if (main.t === 'fragment' || main.t === 'doublon') cap = pieceCap(main.fid, res.filter(r => (r.t === 'fragment' || r.t === 'doublon') && r.fid === main.fid).map(r => r.block));
  else if (main.t === 'complet') cap = wholeCap(main.fid);
  else if (main.t === 'minerai') cap = { k: 'ore', colors: ORES[main.ore] };
  else if (main.t === 'geode') cap = { k: 'geode', colors: GEODES[main.gem] };
  else if ((main.why === 'casse' || main.why === 'miettes' || main.why === 'casse_u') && main.fid) cap = main.why === 'casse_u' ? wholeCap(main.fid) : pieceCap(main.fid, Math.floor(Math.random() * (FOSSILS[main.fid].blocks || 1)));
  else cap = { k: 'rien' };
  const s = main.stars != null ? main.stars : main.why === 'miettes' || main.why === 'casse' ? 0 : 3;
  cap.cracks = 3 - s; cap.damaged = s < 3;
  cap.slow = tier === 4 ? 700 : tier === 3 ? 350 : 0;
  cap.climax = tier === 4 ? 2 : tier === 3 || main.pieces > 1 ? 1 : 0;
  if (main.pieces > 1 && !cap.slow) cap.slow = 250;
  return cap;
}
/* le coup a porté : la pierre s'ouvre, le jeu tranche ce qui sort */
function split(o) {
  if (!CUR) return { k: 'rien' };
  CUR.state = 'opening'; CUR.outcome = o;
  hudHold = true;
  $('benchHint').style.opacity = 0;
  const res = stoneResult(o);
  CUR.res = res; G.stones++; G.xpFil = (G.xpFil || 0) + 1;
  { const m = primaryOf(res), H = CUR.heard;
    Log.ev('pierre', { g: G.site.num, n: G.stones, origine: CUR.stone.bias, contenu: (CUR.stone.contents || []).map(c => c.type).join(','), ouvert: o.type || 'rien', qualite: o.quality,
      score: o.score != null ? Math.round(o.score * 100) / 100 : null, proximite: o.aim != null ? Math.round(o.aim * 100) / 100 : null, fatigue: Math.round((o.fatigue || 0) * 100) / 100,
      taps: Object.values(H).reduce((a, b) => a + b, 0), entendus: H, rates: CUR.miss || 0, duree: Math.round((now() - CUR.t0) / 1000),
      res: m.t === 'vide' ? 'rien:' + (m.why || '') : m.t, etoiles: m.stars, morceaux: m.pieces || (m.t === 'fragment' ? 1 : undefined), fid: m.fid, gain: res.reduce((a, r) => a + (r.gain || 0) + (r.bonus || 0), 0), argent: G.money });
    res.filter(r => r.done).forEach(r => Log.ev('identification', { fid: r.fid, moyenne: r.mean })); }
  const tier = CUR.tier = tierOf(res), h = G.site.holes[CUR.stone.hole];
  if (h) h.t = tier;
  G.stone = null;
  trackStreaks(res, o);
  save();
  if (tier >= 3 || res.some(r => r.pieces > 1)) {
    /* la grande trouvaille s'annonce avant même l'ouverture : lumière, assombrissement */
    Sound.play('glow'); $('dim').classList.add('on');
    const halo = $('halo'); halo.className = 'halo gold big'; halo.innerHTML = raysSVG('#f3c64a', tier === 4 ? 32 : 24); setTimeout(() => halo.classList.add('on'), 60);
  }
  buzz(tier === 4 ? [30, 40, 90] : tier === 3 ? [25, 30, 50] : 14);
  return capFor(res, o, tier);
}
function raysSVG(col, n) {
  let s = '<svg viewBox="-100 -70 200 140" aria-hidden="true"><g stroke="' + col + '" stroke-linecap="round" fill="none" opacity=".85">';
  for (let i = 0; i < n; i++) { const a = i / n * TAU, r0 = 46, r1v = 64 + (i % 2) * 18; s += '<path d="M' + r1(Math.cos(a) * r0) + ' ' + r1(Math.sin(a) * r0 * 0.7) + 'L' + r1(Math.cos(a) * r1v) + ' ' + r1(Math.sin(a) * r1v * 0.7) + '" stroke-width="' + (i % 2 ? 2.2 : 3.4) + '"/>'; }
  return s + '</g></svg>';
}
const WHY = {
  roche: 'Ce fil ne cachait que de la roche.', eclat: 'À bout de fatigue, la pierre a éclaté de travers.',
  casse: 'Elle a cédé en plein dans l’os : il n’en reste que des miettes.', miettes: 'Coup mal placé, ou pierre trop martelée : l’os s’est émietté.',
  casse_u: 'La cassure a traversé la pièce… Mais sa cachette n’est pas vide : recreusez tout près.'
};
/* l'ouverture est jouée : le verdict, puis le moment de la trouvaille */
function reveal(o) {
  if (!CUR || !CUR.res) return;
  CUR.state = 'open'; CUR.openAt = now();
  $('scr-etabli').classList.add('opened');
  const res = CUR.res, main = primaryOf(res), tier = CUR.tier, halo = $('halo');
  let title = '', sub = '';
  const dupCoins = res.filter(r => r.t === 'doublon').reduce((a, r) => a + r.gain, 0);
  if (main.t === 'geode') {
    const Gd = GEODES[main.gem], f = main.force == null ? 0.5 : main.force;
    title = cap1(Gd.name) + ' ' + STARS(main.stars) + ' · +' + main.gain;
    sub = main.stars === 3 ? 'Cristaux intacts : un coup parfaitement dosé.' : f > 0.65 ? 'Frappée un peu fort : des cristaux se sont brisés.' : f < 0.3 ? 'Frappée trop doucement : la croûte s’est mal ouverte.' : 'Quelques cristaux abîmés.';
    Sound.play('ore'); sparks(Gd.hi); coinFloat(main.gain);
  } else if (tier === 1 && main.t === 'doublon') {
    title = 'Doublon ' + STARS(main.stars) + ' · +' + dupCoins;
    sub = main.better ? 'Mieux conservé que le nôtre (' + STARS(main.old) + ') : on le garde, l’ancien est revendu.' : (main.known ? FOSSILS[main.fid].name + ' : déjà au musée' : 'Ce bloc est déjà dégagé') + ', et le nôtre est plus beau. Revendu aux collectionneurs.';
    Sound.play('snap'); coinFloat(dupCoins);
  } else if (tier === 1) {
    title = 'Minerai ' + STARS(main.stars || 2) + ' · +' + main.gain + (main.clean ? ' · veine ouverte en plein' : ''); sub = 'Une veine ' + deOre(main.ore) + '.';
    Sound.play('ore'); sparks(ORES[main.ore].hi); coinFloat(main.gain);
  } else if (tier === 0) {
    title = main.why === 'casse' || main.why === 'casse_u' ? 'Cassé' : main.why === 'miettes' ? 'En miettes' : main.why === 'eclat' ? 'Pierre éclatée' : 'Rien';
    sub = main.why === 'miettes' && main.lost ? 'L’os s’est émietté : ' + main.lost.join(', ') + '.' : WHY[main.why] || WHY.roche;
    syncMoney(false);
  } else if (tier === 2) {
    title = (main.fresh ? 'Nouveau spécimen · ' : 'Fragment · ') + dispName(main.fid); sub = STARS(main.stars) + (main.pieces > 1 ? ' · ' + main.pieces + ' blocs d’un coup · ' + res.filter(r => r.t === 'fragment').pop().n + ' sur ' + main.of : ' · bloc ' + main.n + ' sur ' + main.of) + (fos(main.fid).ind.length > 1 ? ' · individu n°' + main.k : '');
    if (dupCoins) sub += ' · doublon +' + dupCoins;
    if (main.lost) sub += ' · ' + main.lost.join(', ');
  } else if (tier === 3) { title = FOSSILS[main.fid].name + ' identifié'; sub = 'Conservation ' + String(Math.round(main.mean * 10) / 10).replace('.', ',') + ' / 3 · +' + main.bonus; }
  const col = res.find(r => r.t === 'colonne');
  if (col) sub += ' · Colonne ' + EPOCHS[col.ep].name + ' complète : +' + col.bonus;
  const pc = main.pieces > 1 ? main.pieces : 0;
  if (pc || ((main.stars === 3) && tier >= 2)) { const cs = $('cleanStamp'); cs.textContent = pc ? 'Pièce ' + (['', '', 'double', 'triple', 'quadruple', 'quintuple'][pc] || '×' + pc) : 'Coupe nette'; cs.classList.remove('on'); void cs.offsetWidth; cs.classList.add('on'); Sound.play('clean'); }
  if (tier >= 3) { halo.className = 'halo gold big'; halo.innerHTML = raysSVG('#f3c64a', 24); }
  else if (tier === 2) { halo.className = 'halo'; halo.innerHTML = raysSVG(EPOCHS[SITE.epoch].color, 14); }
  else if (tier === 1) { halo.className = 'halo faint'; halo.innerHTML = raysSVG(main.t === 'doublon' ? '#f1e3c2' : main.t === 'geode' ? GEODES[main.gem].hi : ORES[main.ore].hi, 10); }
  setTimeout(() => halo.classList.add('on'), 40);
  $('rTitle').textContent = title; $('rSub').textContent = sub;
  $('result').className = 'result show t' + tier + (tier >= 3 ? ' gold' : '');
  renderLotInfo(tier >= 2);
  if (tier === 2) momentFragment(main, res);
  else if (tier === 3) momentIdent(main, res);
  else { if (col) toast('Colonne ' + EPOCHS[col.ep].name + ' complète : +' + col.bonus); $('btnBack').hidden = false; setTimeout(() => { if (!$('btnBack').hidden) $('btnBack').focus({ preventScroll: true }); }, 300); }
}
/* la pierre est rangée : retour au terrain */
function endStone() {
  if (MOMENT) { MOMENT.el.remove(); MOMENT = null; }
  closeSay(true);
  CUR = null; LEDGER = null;
  if (B3) Bench3D.clear();
  clearStage();
  syncMoney(false);
}
function advance() {
  if (TUTO) { tutoNext(); return; }
  if (!CUR || CUR.state !== 'open' || MOMENT) return;
  Sound.play('tap');
  endStone();
  mapGuardUntil = now() + 350;
  show('carte');
  if (G.site && digsLeft() <= 0 && !G.site.closed) setTimeout(closeSite, 450);
  else if (G.site && !SAY) {
    /* deux pierres sans os : le professeur présente ses lunettes ; plus tard, une longue série appelle un encouragement */
    if (!G.notes.trou && G.site.holes.length >= 2 && !G.site.stats.frags) { G.notes.trou = 1; save(); say(Object.assign({ id: 'trou' }, NOTES.trou), 'carte'); }
    else { const z = SITE.zones[G.site.last]; if (z) holeStreak(z); }
  }
}
/* sans WebGL : la pierre s'ouvre d'un toucher, sur un fil au hasard */
function fallbackSplit() {
  if (!CUR || CUR.state !== 'ready') return;
  const st = CUR.stone, i = Math.floor(Math.random() * st.contents.length);
  const o = { kind: 'fil', plane: i, type: st.contents[i].type, quality: Math.random() < 0.6 ? 'intact' : 'abime', coups: 1 };
  split(o);
  setTimeout(() => reveal(o), 400);
}

/* ---------- effets ---------- */
function stagePoint(fx, fy) {
  const st = $('stage').getBoundingClientRect(), sw = parseFloat($('stage').style.getPropertyValue('--sw')) || 200;
  return [st.width / 2 + fx * sw, st.height * 0.42 + fy * sw];
}
function dustBurst(n, spread, at) {
  const fx = $('fx'), [ox, oy] = at || stagePoint(0.14, -0.25);
  const S = CUR ? ROCKS[CUR.g.rockId].stone : ROCKS.gres.stone;
  for (let i = 0; i < n; i++) {
    const p = document.createElement('i'), s = 3 + Math.random() * 6, a = -Math.PI * (0.1 + Math.random() * 0.8) * (spread > 0.8 ? 1 : 1.3), d = 30 + Math.random() * 60;
    p.style.cssText = 'left:' + ox + 'px;top:' + oy + 'px;width:' + s + 'px;height:' + s + 'px;background:' + (i % 3 ? S.light : S.base) + ';border:1px solid ' + S.ink;
    fx.appendChild(p);
    try {
      p.animate([{ transform: 'translate(-50%,-50%)', opacity: 1 }, { transform: 'translate(calc(-50% + ' + r1(Math.cos(a) * d) + 'px),calc(-50% + ' + r1(Math.sin(a) * d * 0.8 + 40) + 'px)) rotate(' + Math.round(Math.random() * 300) + 'deg)', opacity: 0 }], { duration: 520 + Math.random() * 300, easing: 'cubic-bezier(.2,.6,.4,1)' }).onfinish = () => p.remove();
    } catch (e) { p.remove(); }
  }
}
function sparks(col) {
  const fx = $('fx'), sw = parseFloat($('stage').style.getPropertyValue('--sw')) || 200, [ox, oy] = stagePoint(-0.5, 0);
  for (let i = 0; i < 12; i++) {
    const p = document.createElement('i'), a = Math.random() * TAU, d = 40 + Math.random() * 50;
    p.style.cssText = 'left:' + ox + 'px;top:' + oy + 'px;width:4px;height:4px;border-radius:1px;background:' + col + ';box-shadow:0 0 6px ' + col;
    fx.appendChild(p);
    try { p.animate([{ transform: 'translate(-50%,-50%) scale(1)', opacity: 1 }, { transform: 'translate(calc(-50% + ' + r1(Math.cos(a) * d) + 'px),calc(-50% + ' + r1(Math.sin(a) * d * 0.7) + 'px)) scale(.3)', opacity: 0 }], { duration: 600, easing: 'ease-out' }).onfinish = () => p.remove(); } catch (e) { p.remove(); }
  }
  void sw;
}
function coinFloat(amount) {
  const cs = (B3 && Bench3D.capScreen()) || (() => { const r = $('stage').getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height * 0.42 }; })(), hud = $('hudMoney').getBoundingClientRect();
  const el = document.createElement('div');
  el.className = 'coin-float'; el.innerHTML = ic('coin') + '+' + amount;
  const sx = cs.x - 24, sy = cs.y - 20;
  el.style.left = sx + 'px'; el.style.top = sy + 'px';
  document.body.appendChild(el);
  const done = () => { el.remove(); syncMoney(true); Sound.play('coin'); };
  if (reduceMotion()) { done(); return; }
  try {
    el.animate([{ transform: 'translate(0,8px) scale(.8)', opacity: 0 }, { transform: 'translate(0,-14px) scale(1.1)', opacity: 1, offset: 0.3 }, { transform: 'translate(' + r1(hud.left + 6 - sx) + 'px,' + r1(hud.top - sy) + 'px) scale(.7)', opacity: 0.9 }], { duration: 820, easing: 'cubic-bezier(.45,0,.3,1)', fill: 'forwards' }).onfinish = done;
  } catch (e) { done(); }
}
/* envol d'un bloc de la face de la pierre jusqu'à sa place dans le puzzle */
function flyBlock(fid, bi, targetSvg, onDone) {
  const [W, H] = ART[fid].vb, cb = cellBox(fid, bi), cs = B3 ? Bench3D.capScreen() : null;
  const fr = svgFrame(targetSvg, W, H);
  const ex = fr.left + cb.x0 * fr.k, ey = fr.top + cb.y0 * fr.k, ew = cb.bw * fr.k, eh = cb.bh * fr.k;
  const u = uid('fl'), el = document.createElement('div');
  el.className = 'fly';
  el.style.cssText = 'left:' + ex + 'px;top:' + ey + 'px;width:' + ew + 'px;height:' + eh + 'px';
  el.innerHTML = '<svg viewBox="' + r1(cb.x0) + ' ' + r1(cb.y0) + ' ' + r1(cb.bw) + ' ' + r1(cb.bh) + '" width="100%" height="100%"><defs><clipPath id="' + u + '"><path d="' + polyD(cb.cell, true) + '"/></clipPath></defs><g clip-path="url(#' + u + ')">' + fUse(fid) + '</g></svg>';
  document.body.appendChild(el);
  const finish = () => { el.remove(); onDone(); };
  if (!cs || reduceMotion()) { finish(); return; }
  /* le bloc part de la face ouverte de la pierre */
  const k0 = clamp(cs.k * 1.1 / Math.max(ew, eh), 0.25, 3), sx = cs.x - ew * k0 / 2, sy = cs.y - eh * k0 / 2;
  Sound.play('fly');
  try {
    el.animate([
      { transform: 'translate(' + r1(sx - ex) + 'px,' + r1(sy - ey) + 'px) scale(' + k0.toFixed(3) + ')', opacity: 0.5 },
      { transform: 'translate(' + r1((sx - ex) * 0.55) + 'px,' + r1((sy - ey) * 0.55 - 40) + 'px) scale(' + ((k0 + 1) / 2 * 1.15).toFixed(3) + ')', opacity: 1, offset: 0.45 },
      { transform: 'translate(0,0) scale(1)', opacity: 1 }
    ], { duration: 720, easing: 'cubic-bezier(.45,0,.25,1)', fill: 'forwards' }).onfinish = finish;
  } catch (e) { finish(); }
}
function flashBlock(svg, fid, bi) {
  /* l'éclat du bloc qui se pose suit la forme du dessin, pas le polygone du découpage */
  const [W, H] = ART[fid].vb, d = polyD(blocksOf(fid).cells[bi], true), u = uid('fb');
  svg.insertAdjacentHTML('beforeend', '<defs><mask id="' + u + '" maskUnits="userSpaceOnUse" x="0" y="0" width="' + W + '" height="' + H + '">' + fUse(fid, 'w') + '</mask><clipPath id="' + u + 'c"><path d="' + d + '"/></clipPath></defs><g class="snap-flash" clip-path="url(#' + u + 'c)"><rect width="' + W + '" height="' + H + '" fill="rgba(255,214,100,.55)" mask="url(#' + u + ')"/></g>');
}
function typeText(el, text, speed, done) {
  if (reduceMotion()) { el.textContent = text; if (done) done(); return; }
  let i = 0; el.textContent = '';
  const step = () => { i++; el.textContent = text.slice(0, i); if (i % 2) Sound.play('type'); if (i < text.length) setTimeout(step, speed); else if (done) done(); };
  step();
}

/* ---------- moments : chaque trouvaille a son poids ---------- */
function openMoment(kind, html, lockMs) {
  const el = document.createElement('div');
  el.className = 'moment m-' + kind;
  el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true');
  el.innerHTML = html;
  $('scr-etabli').appendChild(el);
  const lock = lockMs * (G.set.rapide ? 0.5 : 1);
  MOMENT = { el, kind, until: now() + lock };
  el.addEventListener('click', e => { e.stopPropagation(); tryCloseMoment(); });
  setTimeout(() => { if (MOMENT && MOMENT.el === el) { el.classList.add('ready'); const b = el.querySelector('.btn'); if (b) b.focus({ preventScroll: true }); } }, lock);
  return el;
}
function tryCloseMoment() {
  if (!MOMENT || now() < MOMENT.until) return false;
  const el = MOMENT.el; MOMENT = null;
  el.classList.add('leaving');
  setTimeout(() => el.remove(), 180);
  syncMoney(false);
  renderChip(true);
  advance();
  return true;
}
function momentFragment(r, res) {
  const F = FOSSILS[r.fid], same = (res || []).filter(x => x !== r && x.t === 'fragment' && x.fid === r.fid && x.k === r.k);
  const I = indOf(r.fid, r.k), nEnd = I ? I.found.length : r.n, left = F.blocks - nEnd, many = fos(r.fid).ind.length > 1;
  const el = openMoment('frag',
    '<div class="m-sheet"><div class="m-kicker">' + (r.fresh ? 'Nouveau spécimen' : 'Fragment dégagé') + '</div><div class="m-title">' + dispName(r.fid) + (many ? '<small> · n°' + r.k + '</small>' : '') + '</div>' +
    '<div class="m-art">' + fossilSVG(r.fid, 'puzzle', r.before, null, r.beforeQ) + '</div>' + '<div class="m-stars">' + STARS(r.stars) + (r.lost ? '<small>' + r.lost.join(' · ') + '</small>' : '') + '</div>' +
    '<div class="m-count"><b>' + (r.n - 1) + '</b> / ' + r.of + ' blocs</div>' +
    '<div class="m-sub">' + (r.fresh ? 'Un autre animal de la même espèce ! ' : '') + (same.length ? 'Une pièce de ' + (same.length + 1) + ' blocs d’un seul tenant ! ' : '') + 'Encore ' + left + ' bloc' + (left > 1 ? 's' : '') + ' pour l’identifier</div>' +
    '<div class="m-hint">Touchez pour continuer</div></div>', 900);
  Sound.play('frag'); buzz(18);
  setTimeout(() => {
    const svg = el.querySelector('.m-art svg'); if (!svg) return;
    flyBlock(r.fid, r.block, svg, () => {
      if (!el.isConnected) return;
      el.querySelector('.m-art').innerHTML = fossilSVG(r.fid, 'puzzle', I ? I.found : r.before.concat([r.block]), null, I ? I.q : null);
      const s2 = el.querySelector('.m-art svg');
      flashBlock(s2, r.fid, r.block); same.forEach(x => flashBlock(s2, r.fid, x.block));
      el.querySelector('.m-count b').textContent = nEnd;
      el.querySelector('.m-count').classList.add('pop');
      Sound.play('snap'); buzz(10);
    });
  }, 260);
}
function momentIdent(r) {
  const F = FOSSILS[r.fid];
  const el = openMoment('ident',
    '<div class="m-card"><div class="m-kicker">' + ic('star') + 'Fossile identifié</div>' +
    '<div class="m-art big"><div class="m-slab" style="--slab:' + ROCKS[EPOCHS[F.epoch].rocks.propice].stone.face + '">' + fossilSVG(r.fid, 'puzzle', r.before, null, r.beforeQ) + '<span class="m-stamp">Identifié</span></div></div>' +
    '<div class="m-name" aria-live="polite">' + dispName(r.fid) + '</div><div class="m-latin">&nbsp;</div>' +
    '<p class="m-note">' + nbsp(F.note) + '</p>' +
    '<div class="m-foot"><span class="m-bonus">' + ic('coin') + '+' + r.bonus + '</span><button class="btn primary" type="button">' + ic('museum') + 'Exposer au musée</button></div></div>', 1900);
  buzz([20, 40, 40]);
  setTimeout(() => {
    const svg = el.querySelector('.m-art svg'); if (!svg) return;
    flyBlock(r.fid, r.block, svg, () => {
      if (!el.isConnected) return;
      const art = el.querySelector('.m-slab');
      art.querySelector('svg').outerHTML = fossilSVG(r.fid, 'puzzle', allBlocks(r.fid), null, fos(r.fid).q);
      const s2 = art.querySelector('svg'); flashBlock(s2, r.fid, r.block);
      Sound.play('snap');
      setTimeout(() => {
        el.classList.add('solved'); Sound.play('ident');
        const nm = el.querySelector('.m-name');
        typeText(nm, F.name, 70, () => { el.querySelector('.m-latin').textContent = F.latin; el.querySelector('.m-stamp').classList.add('on'); Sound.play('stamp'); syncMoney(true); });
      }, 380);
    });
  }, 320);
}
function sparkleIn(host) {
  if (reduceMotion()) return;
  for (let i = 0; i < 26; i++) {
    const p = document.createElement('i');
    p.className = 'spark';
    p.style.left = (10 + Math.random() * 80) + '%'; p.style.top = (12 + Math.random() * 50) + '%';
    p.style.animationDelay = (Math.random() * 1.6).toFixed(2) + 's';
    host.appendChild(p);
  }
}

/* ---------- le professeur Kayou : son visage et ses messages ---------- */
let SAY = null, PENDING = null;
const kyFill = (t, v) => t.replace(/\{(\w+)\}/g, (m, k) => (v && v[k] != null ? v[k] : m));
const nbsp = t => t.replace(/ ([!?:;»])/g, '\u00a0$1').replace(/« /g, '«\u00a0');
const kyFace = expr => '<span class="ky-face" aria-hidden="true">' + kayouSVG(expr, 'face') + '</span>';
function kyInline(msg, extra) {
  return '<div class="ky-inline">' + kyFace(msg.expr) + '<div class="ky-body"><div class="ky-name">' + KAYOU.name + '</div><p class="ky-text">' + nbsp(msg.text) + '</p>' + (extra || '') + '</div></div>';
}
/* message épinglé en bas de l'écran. scope 'etabli' : un tap le ferme avant de frapper ; 'carte' : un tap sur la carte le ferme */
function say(msg, scope) {
  closeSay(true);
  const el = document.createElement('div');
  el.className = 'kayou-say'; el.dataset.say = msg.id || '';
  Log.ev('kayou', { id: msg.id || '' }); el.setAttribute('role', 'status');
  el.innerHTML = '<div class="ky-card">' + kyFace(msg.expr) + '<div class="ky-body"><div class="ky-name">' + KAYOU.name + '</div>' +
    (msg.sketch ? '<span class="ky-sk">' + sketchSVG(msg.sketch) + '</span>' : '') + '<p class="ky-text">' + nbsp(msg.text) + '</p></div><p class="ky-hint">Touchez pour continuer</p></div>';
  document.querySelector('main').appendChild(el);
  const lock = scope === 'etabli' ? (G.set.rapide ? 450 : 800) : 350;
  SAY = { el, scope, until: now() + lock };
  if (scope === 'etabli') $('benchHint').style.opacity = 0;
  el.addEventListener('click', e => { e.stopPropagation(); closeSay(); });
  setTimeout(() => { if (SAY && SAY.el === el) el.classList.add('ready'); }, lock);
  Sound.play('note');
}
function closeSay(force) {
  if (!SAY || (!force && now() < SAY.until)) return false;
  const el = SAY.el, scope = SAY.scope; SAY = null;
  el.classList.add('leaving'); setTimeout(() => el.remove(), 200);
  if (!force && scope === 'etabli' && CUR && CUR.state === 'ready' && CUR.hint) $('benchHint').style.opacity = 1;
  if (!force) Sound.play('tap');
  return true;
}
/* un encouragement ou une astuce attend le prochain écran où il a du sens */
function flushSay(scope) { if (!PENDING || SAY) return false; const m = PENDING; PENDING = null; G.noteAt = G.stones; say(m, scope); return true; }
/* ctx 'stone' : une pierre arrive sur l'établi ; 'carte' : retour au terrain après une trouvaille */
function pickSay(ctx) {
  if (SAY) return null;
  const seen = id => !!G.notes[id];
  const note = id => { G.notes[id] = 1; G.noteAt = G.stones; save(); return Object.assign({ id }, NOTES[id]); };
  const pending = () => { const m = PENDING; PENDING = null; G.noteAt = G.stones; return m; };
  /* un premier os, un autre individu, un premier doublon : on explique juste après */
  const events = () => { for (const id of ['poche', 'individu', 'doublon']) if (G.ev[id] && !seen(id)) return id; return null; };
  if (ctx === 'carte') { if (CUR) return null; const ev = events(); return ev ? note(ev) : null; }
  const st = CUR && CUR.stone; if (!st) return null;
  if (!seen('pierre')) return note('pierre');
  if (!ROCKS[st.rock].bedded && !(st.contents && st.contents[0] && st.contents[0].type === 'geode') && !seen('massive')) return note('massive');
  if (PENDING) return pending();
  return null;
}
/* trop d'ouvertures sur un fil moins riche qu'un autre de la même pierre → astuce d'écoute ; une pierre éclatée → astuce de fatigue */
const VALUE = { unique: 4, os: 3, geode: 2.5, veine: 1, rien: 0 };
function trackStreaks(res, o) {
  const S = G.streak || (G.streak = { miss: 0 });
  const best = Math.max(...CUR.stone.contents.map(c => VALUE[c.type] || 0)), got = o.plane >= 0 ? VALUE[CUR.stone.contents[o.plane].type] || 0 : -1;
  if (o.quality === 'eclatee' && !G.notes.astFatigue) { G.notes.astFatigue = 1; PENDING = Object.assign({ id: 'astuce-fatigue' }, ASTUCES.fatigue); return; }
  if (got >= best) { S.miss = 0; return; }
  S.miss = (S.miss || 0) + 1;
  if (S.miss >= 3 && !PENDING && G.stones - (G.hintAt == null ? -99 : G.hintAt) >= 8) { S.miss = 0; G.hintAt = G.stones; PENDING = Object.assign({ id: 'astuce-ecoute' }, ASTUCES.ecoute); }
}
/* une longue série de trous vides : le professeur encourage (au plus toutes les 12 pierres ou trous) */
function holeStreak(z) {
  const S = G.site; if ((S.empty || 0) < 6 || SAY) return;
  const ep = SITE.epoch, said = S.said || (S.said = {}), n = G.stones + S.holes.length;
  const poolEmpty = !EPOCHS[ep].fossils.some(f => FOSSILS[f].kind === 'frag' && !fos(f).done);
  const tari = S.poches.length > 0 && S.poches.every(p => p.done), found = S.stats.frags + (S.stats.dup || 0) > 0;
  const why = z.band === 'sterile' ? 'sterile' : tari ? 'tari' : poolEmpty ? 'epoque' : z.band !== 'propice' ? 'pauvre' : !found ? 'chercher' : 'patience';
  const once = why === 'epoque' || why === 'tari' || why === 'chercher';
  if (n - (G.courageAt == null ? -99 : G.courageAt) < 12 || (once && said[why])) return;
  S.empty = 0; G.courageAt = n; if (once) said[why] = 1;
  say(courage(why, z), 'carte');
}
function courage(why, z) {
  const C = COURAGE[why] || COURAGE.patience, ep = EPOCHS[SITE.epoch];
  return { id: 'courage-' + why, expr: C.expr, text: kyFill(C.text, { Roche: cap1(ROCK_WORDS[z.rock][0]), propices: ROCK_WORDS[ep.rocks.propice][1], Propices: cap1(ROCK_WORDS[ep.rocks.propice][1]), epoque: ep.name, du: ep.du }) };
}

function setupBench() {
  const st = $('stage');
  B3 = !!(window.THREE && Bench3D.init({
    host: st, room: 0.6,
    audio: () => (G.set.son ? Sound.ensure() : null), words: () => !!G.set.mots, background: () => $('benchBg'), buzz,
    blocked: () => { if (SAY) { closeSay(); return true; } if (MOMENT) { tryCloseMoment(); return true; } return false; },
    onTouch: () => { $('benchHint').style.opacity = 0; },
    onTap: (k, n, q, idx, P) => (TUTO ? tutoHeard(k, q, idx, P) : heard(k, n)), onFatigue: setFatigue,
    gate: o => (TUTO ? tutoGate(o) : true),
    onMiss: () => { if (CUR && !TUTO) CUR.miss = (CUR.miss || 0) + 1; },
    onSplit: o => (TUTO ? tutoSplit(o) : split(o)), onOpened: o => (TUTO ? tutoOpened(o) : reveal(o))
  }));
  /* après l'ouverture, un toucher sur l'établi (ou le bouton) ramène au terrain */
  st.addEventListener('click', () => {
    if (SAY) { closeSay(); return; }
    if (MOMENT) { tryCloseMoment(); return; }
    if (!B3 && CUR && CUR.state === 'ready') { fallbackSplit(); return; }
    if (CUR && CUR.state === 'open' && now() - CUR.openAt > 600) advance();
  });
  $('btnBack').onclick = advance;
  document.addEventListener('keydown', e => { if ((SAY || MOMENT) && (e.key === 'Enter' || e.key === ' ' || e.key === 'Escape') && !document.querySelector('.intro,.sheet-back')) { e.preventDefault(); if (SAY) closeSay(); else tryCloseMoment(); } });
  window.addEventListener('resize', () => { if (SCREEN === 'etabli') { paintBench(); if (B3) Bench3D.resize(); } });
}

/* ---------- fiche de spécimen ---------- */
function ficheHTML(fid) {
  const F = FOSSILS[fid], st = fos(fid), E2 = EPOCHS[F.epoch], slab = ROCKS[E2.rocks.propice].stone.face, isKnown = st.done;
  const best = bestInd(fid), found = foundOf(fid);
  const art = F.kind === 'unique' ? fossilSVG(fid, isKnown ? 'full' : 'veiled') : fossilSVG(fid, 'puzzle', found, null, qualOf(fid));
  let txt;
  if (isKnown) txt = F.note;
  else if (F.kind === 'unique') txt = 'Pièce unique : elle ne se trouve qu’entière, et seulement dans certains gisements ' + E2.du + ', cachée quelque part dans la bonne roche. Un marteau plus lourd augmente vos chances.';
  else if (best) { const left = F.blocks - found.length; txt = 'Spécimen non identifié. Il manque encore ' + left + ' bloc' + (left > 1 ? 's' : '') + ' à un même squelette pour savoir de quel animal il s’agit. Les os d’un animal restent dans son gisement : complétez-le avant de partir.'; }
  else txt = 'Aucun fragment pour l’instant. On le trouve dans les gisements ' + E2.du + '.';
  let inds = '';
  if (F.kind === 'frag' && !isKnown && st.ind.length) {
    inds = '<ul class="inds">' + st.ind.slice().sort((x, y) => y.found.length - x.found.length).slice(0, 5).map(I =>
      '<li><span class="nm">Individu n°' + I.k + '</span><span class="bar"><b style="width:' + Math.round(100 * I.found.length / F.blocks) + '%"></b></span><span class="v">' + I.found.length + '/' + F.blocks + '</span>' +
      '<small>' + (I.lost ? 'en réserve · gisement n°' + I.num : 'en cours · zone ' + COLS[I.zone % GRID] + (Math.floor(I.zone / GRID) + 1)) + '</small></li>').join('') + '</ul>';
  }
  return '<div class="fiche"><div class="slab" style="--slab:' + slab + '">' + art + (isKnown ? '<span class="stamp">Au musée</span>' : '') + '</div>' +
    '<div class="tag-card"><span class="no">' + specimenNo(fid) + '</span><b>' + (isKnown ? F.name : F.kind === 'unique' ? 'Pièce unique non découverte' : 'Spécimen ' + shortNo(fid) + ' · non identifié') + '</b>' +
    (isKnown ? '<i>' + F.latin + '</i>' : '') +
    '<div class="meta">' + E2.name + ' · ' + (F.kind === 'unique' ? 'pièce unique' : F.blocks + ' blocs' + (isKnown ? ', ' + F.rarity : '')) + '</div>' +
    (isKnown ? '<div class="meta">Référence : ' + F.ref + '</div><div class="meta">Récolté : ' + st.where + '</div>' : '') +
    (st.dup ? '<div class="meta">Doublons revendus : ' + st.dup + '</div>' : '') + '</div>' + inds + '<p class="note-txt">' + nbsp(txt) + '</p></div>';
}

/* ---------- musée : frise des 12 périodes ---------- */
let shopTab = 'outils', friseIO = null;
/* ---------- le musée : deux ailes, visitables à tout moment ---------- */
let musWing = 'fossiles';
function geodeSVG(gem, found) {
  const Gd = GEODES[gem], r = mulberry32(hashStr(gem)), ink = '#2a2016';
  if (!found) return '<svg viewBox="0 0 100 100" aria-hidden="true"><ellipse cx="50" cy="52" rx="38" ry="34" fill="#d8cfbb" stroke="#b9ae96" stroke-width="2"/><text x="50" y="62" text-anchor="middle" font-family="Special Elite, monospace" font-size="28" fill="#9a8f78">?</text></svg>';
  let s = '<svg viewBox="0 0 100 100" aria-hidden="true"><g stroke-linejoin="round">';
  s += '<ellipse cx="50" cy="52" rx="40" ry="36" fill="#a8977e" stroke="' + ink + '" stroke-width="2.4"/>';
  [[34, 30, Gd.band[0]], [31, 27, Gd.band[1]], [28, 24.5, Gd.band[2]]].forEach(([rx, ry, c]) => (s += '<ellipse cx="50" cy="52" rx="' + rx + '" ry="' + ry + '" fill="' + c + '"/>'));
  s += '<ellipse cx="50" cy="52" rx="24" ry="21" fill="' + Gd.dark + '"/>';
  for (let i = 0; i < 26; i++) { const a = i / 26 * Math.PI * 2, bx = 50 + Math.cos(a) * 24, by = 52 + Math.sin(a) * 21, L = 9 + r() * 9, tx = 50 + Math.cos(a) * (24 - L), ty = 52 + Math.sin(a) * (21 - L * 0.88), px = -Math.sin(a) * 3, py = Math.cos(a) * 3; s += '<path d="M' + r1(bx + px) + ' ' + r1(by + py) + 'L' + r1(tx) + ' ' + r1(ty) + 'L' + r1(bx - px) + ' ' + r1(by - py) + 'Z" fill="' + (r() < 0.5 ? Gd.col : Gd.hi) + '" stroke="rgba(40,25,50,.4)" stroke-width=".8"/>'; }
  return s + '</g></svg>';
}
function oreSVG(ore, found) {
  const O = ORES[ore], ink = '#2a2016';
  if (!found) return '<svg viewBox="0 0 100 100" aria-hidden="true"><path d="M22 66L30 38L52 26L74 36L80 60L60 76L34 76Z" fill="#d8cfbb" stroke="#b9ae96" stroke-width="2"/><text x="52" y="62" text-anchor="middle" font-family="Special Elite, monospace" font-size="26" fill="#9a8f78">?</text></svg>';
  return '<svg viewBox="0 0 100 100" aria-hidden="true"><g stroke-linejoin="round"><path d="M18 68L26 40L48 24L76 32L84 58L64 78L34 80Z" fill="#8f877a" stroke="' + ink + '" stroke-width="2.2"/>' +
    '<path d="M32 62L38 44L52 36L66 42L68 58L54 66Z" fill="' + O.color + '" stroke="' + O.dark + '" stroke-width="1.4"/><path d="M40 46L52 39L58 44L46 50Z" fill="' + O.hi + '" opacity=".85"/><path d="M58 60L64 50L66 57Z" fill="' + O.dark + '" opacity=".6"/>' +
    '<path d="M26 44L34 36" stroke="#b9b1a2" stroke-width="2" stroke-linecap="round"/></g></svg>';
}
function renderGeoWing() {
  const gems = G.gems || {}, best = G.gemBest || {}, ores = G.ores || {};
  const card = (art, name, sub, found) => '<div class="vit' + (found ? '' : ' empty') + '"><div class="vit-art">' + art + '</div><b>' + name + '</b><span>' + sub + '</span></div>';
  $('geoWing').innerHTML = '<div class="sec-head"><div><h1>Musée</h1><p>Aile géologie : géodes et minerais</p></div></div>' +
    '<h2 class="vit-h">Géodes</h2><div class="vits">' + Object.keys(GEODES).map(k => { const n = gems[k] || 0; return card(geodeSVG(k, n), n ? GEODES[k].name[0].toUpperCase() + GEODES[k].name.slice(1) : 'Géode inconnue', n ? STARS(best[k] || 0) + ' · ' + n + ' trouvée' + (n > 1 ? 's' : '') : 'Pas encore trouvée', n); }).join('') + '</div>' +
    '<h2 class="vit-h">Minerais</h2><div class="vits">' + Object.keys(ORES).map(k => { const n = ores[k] || 0; return card(oreSVG(k, n), n ? ORES[k].name[0].toUpperCase() + ORES[k].name.slice(1) : 'Minerai inconnu', n ? n + ' veine' + (n > 1 ? 's' : '') + ' ouverte' + (n > 1 ? 's' : '') : 'Pas encore trouvé', n); }).join('') + '</div>';
}
function setWing(w) {
  musWing = w;
  $('wingTabs').querySelectorAll('button').forEach(b => b.setAttribute('aria-selected', b.dataset.w === w ? 'true' : 'false'));
  $('scr-musee').classList.toggle('wing-geo', w === 'geologie');
  $('geoWing').hidden = w !== 'geologie';
  if (w === 'geologie') renderGeoWing();
}
function renderMuseum() {
  const all = Object.keys(FOSSILS), done = all.filter(id => fos(id).done).length;
  const freshF = all.find(id => fos(id).done && !G.seen[id]), focusEp = freshF ? FOSSILS[freshF].epoch : G.site ? G.site.epoch : EPOCH_IDS[0];
  $('musCount').textContent = done + '/' + all.length + ' exposés';
  $('timeline').innerHTML = timelineHTML();
  $('timeline').querySelectorAll('.tl-cell').forEach(b => (b.onclick = () => { Sound.play('tap'); scrollFrise(b.dataset.ep, true); }));
  $('frise').innerHTML = EPOCH_IDS.map(ep => {
    const E2 = EPOCHS[ep], n = E2.fossils.filter(f => fos(f).done).length;
    return '<div class="col" id="col-' + ep + '" style="--c:' + E2.head + ';--cs:' + E2.color + '"><div class="col-head' + (G.cols[ep] ? ' is-done' : '') + '"><b>' + E2.name + '</b><span>' + E2.age + '</span><span class="n">' + n + '/' + E2.fossils.length + '</span>' + (G.cols[ep] ? '<span class="done">Complète</span>' : '') + '</div><div class="col-body">' +
      E2.fossils.map(fid => slotHTML(fid)).join('') + '</div></div>';
  }).join('');
  $('frise').querySelectorAll('.slot').forEach(b => (b.onclick = () => openFiche(b.dataset.f)));
  /* les vignettes se dessinent quand leur colonne approche de l'écran */
  const fill = col => col.querySelectorAll('.art[data-f]').forEach(a => { a.innerHTML = slotArt(a.dataset.f); a.removeAttribute('data-f'); });
  if (friseIO) friseIO.disconnect();
  const sc = document.querySelector('.frise-scroll');
  if ('IntersectionObserver' in window) {
    friseIO = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { fill(e.target); friseIO.unobserve(e.target); } }), { root: sc, rootMargin: '0px 260px' });
    $('frise').querySelectorAll('.col').forEach(c => friseIO.observe(c));
  } else $('frise').querySelectorAll('.col').forEach(fill);
  requestAnimationFrame(() => scrollFrise(focusEp, false));
  Object.keys(FOSSILS).forEach(id => { if (fos(id).done) G.seen[id] = true; });
  $('wingTabs').querySelectorAll('button').forEach(b => (b.onclick = () => { Sound.play('tap'); setWing(b.dataset.w); }));
  setWing(musWing);
  renderEscale();
  renderShop();
  updateHud();
  save();
}
function scrollFrise(ep, smooth) {
  const sc = document.querySelector('.frise-scroll'), col = $('col-' + ep);
  if (!sc || !col) return;
  const left = sc.scrollLeft + col.getBoundingClientRect().left - sc.getBoundingClientRect().left - 16;
  try { sc.scrollTo({ left, behavior: smooth && !reduceMotion() ? 'smooth' : 'auto' }); } catch (e) { sc.scrollLeft = left; }
}
function slotArt(fid) {
  const F = FOSSILS[fid], st = fos(fid);
  return F.kind === 'unique' ? fossilSVG(fid, st.done ? 'full' : 'veiled') : fossilSVG(fid, 'puzzle', foundOf(fid), null, qualOf(fid));
}
function slotHTML(fid) {
  const F = FOSSILS[fid], st = fos(fid), fresh = st.done && !G.seen[fid], found = foundOf(fid), inds = st.ind.length;
  let extra;
  if (F.kind === 'unique') extra = '<span class="kind">' + (st.done ? 'Pièce unique' : 'À découvrir entière') + '</span>';
  else extra = '<span class="pips">' + Array.from({ length: F.blocks }, (_, i) => '<i class="' + (i < found.length ? 'on' : '') + '"></i>').join('') + '</span>';
  const prog = F.kind === 'unique' || st.done ? (st.done && st.stars && F.kind !== 'unique' ? '<small class="cons" title="Conservation">' + STARS(Math.round(st.stars)) + '</small>' : '') : '<small>' + found.length + '/' + F.blocks + '</small>';
  const badge = F.kind === 'frag' && !st.done && inds > 1 ? '<span class="ind-badge" title="' + inds + ' individus trouvés">×' + inds + '</span>' : '';
  return '<button class="slot' + (fresh ? ' new' : '') + (st.done ? '' : ' unknown') + '" data-f="' + fid + '" aria-label="' + dispName(fid) + (st.done ? '' : ', non identifié') + '"><span class="art" data-f="' + fid + '"></span>' + badge +
    '<span class="nm">' + (st.done || F.kind === 'unique' ? dispName(fid) : '<span>Spécimen ' + shortNo(fid) + '</span>') + prog + '</span>' + extra + '</button>';
}
/* échelle des temps : 12 cases égales (symboles de la carte géologique), ères au-dessus, âges en dessous */
function timelineHTML() {
  const cur = G.site && !G.voyage ? G.site.epoch : null;
  return '<div class="tl-eras">' + ERAS.map(([n, k]) => '<span style="grid-column:span ' + k + '">' + n + '</span>').join('') + '</div>' +
    '<div class="tl-cells" role="group" aria-label="Échelle des temps : aller à une période">' + EPOCH_IDS.map(ep => {
      const E2 = EPOCHS[ep], n = E2.fossils.filter(f => fos(f).done).length;
      return '<button type="button" class="tl-cell' + (ep === cur ? ' cur' : '') + (G.cols[ep] ? ' full' : '') + '" data-ep="' + ep + '" style="--cs:' + E2.color + ';--p:' + (n / E2.fossils.length).toFixed(2) + '" aria-label="' + E2.name + ' : ' + n + ' fossiles sur ' + E2.fossils.length + (ep === cur ? ', gisement actuel' : '') + '"><b>' + E2.code + '</b><i></i></button>';
    }).join('') + '</div>' +
    '<div class="tl-ages" aria-hidden="true"><span style="left:0">539 Ma</span><span style="left:50%">252</span><span style="left:75%">66</span><span style="left:100%">0</span></div>';
}
/* ---------- voyage et escale au musée ---------- */
/* à l'escale, tout l'argent est disponible : pour la boutique, puis pour la destination */
const shopBudget = () => (G.voyage ? G.money : 0);
/* trois destinations : époque, richesse (poches, rumeur de pièce unique), nouveauté pour le musée, et le prix qui va avec */
function makeOffers(num) {
  const eps = [];
  for (let k = 0; eps.length < 3 && k < 40; k++) { const e = pickEpoch(); if (!eps.includes(e)) eps.push(e); }
  while (eps.length < 3) eps.push(pickEpoch());
  return DESTS.tiers.map((T, i) => {
    const ep = eps[i], uni = false;
    const fresh = EPOCHS[ep].fossils.filter(f => !fos(f).done).length;
    const price = Math.round((DESTS.base + DESTS.perPoche * (T.poches - 2) + DESTS.perNew * fresh + DESTS.perNum * Math.max(0, num - 2)) / 5) * 5;
    const pk = Object.keys(DESTS.profils), prof = pk[Math.floor(Math.random() * pk.length)], P = DESTS.profils[prof];
    const price2 = Math.round((price + DESTS.perGeode * P.geodes + DESTS.perVein * (P.veins - 5)) / 5) * 5;
    return { tier: i, name: T.name, epoch: ep, poches: T.poches, uni, fresh, prof, veins: P.veins, geodes: P.geodes, price: Math.max(15, price2) };
  });
}
function startVoyage() {
  closeSay(true); PENDING = null;
  endStone();
  G.stone = null; GL.on = false;
  const next = G.site.num + 1;
  G.voyage = { num: next, offers: makeOffers(next), pick: 0 };
  shopTab = 'outils';
  save();
  Sound.play('fly');
  show('musee');
  $('scr-musee').scrollTop = 0;
}
/* premier temps de l'escale : on choisit (et on règle) la destination ; la boutique ouvre ensuite avec ce qui reste */
function chooseDest() {
  const V = G.voyage; if (!V) return;
  if (!V.offers) V.offers = makeOffers(V.num);
  const O = V.offers[V.pick] || V.offers[0];
  /* le musée avance toujours la destination la plus modeste ; les autres, il faut pouvoir les payer */
  if (G.money < O.price && O.tier !== 0) { toast('Pas assez de pièces pour cette destination.'); return; }
  if (G.money < O.price && V.atelier && !V.atelier.done) { toast('Les caisses sont vides : acceptez d’abord la mission de l’atelier.'); return; }
  const paid = Math.min(G.money, O.price);
  G.money -= paid; V.paid = paid; V.covered = O.price - paid; V.step = 'boutique';
  Sound.play('buy'); syncMoney(false); updateHud(); save();
  renderMuseum(); $('scr-musee').scrollTop = 0;
}
function unchooseDest() {
  const V = G.voyage; if (!V || V.step !== 'boutique') return;
  G.money += V.paid || 0; V.paid = 0; V.covered = 0; V.step = 'choix';
  Sound.play('tap'); syncMoney(false); updateHud(); save();
  renderMuseum(); $('scr-musee').scrollTop = 0;
}
function depart() {
  const V = G.voyage; if (!V) return;
  if (V.step !== 'boutique') { chooseDest(); return; }
  const O = V.offers[V.pick] || V.offers[0], covered = V.covered || 0;
  Log.ev('depart', { vers: O.epoch, gisement: O.name, prix: O.price, argent: G.money });
  G.voyage = null;
  $('toast').classList.remove('show');
  Sound.play('fly');
  newSite(O.epoch, V.num, O);
  syncMoney(false); updateHud();
  show('carte');
  sayArrival(covered > 0);
}
/* ---------- l'atelier : un bloc à nettoyer pour un musée voisin ----------
   Petit moment sans grand enjeu : on époussette la terre autour d'un os. La brosse est sûre mais lente,
   le grattoir rapide mais il raye l'os. Payé selon la propreté ; au joueur fauché, il paie au moins le voyage le plus modeste. */
const ATELIER = { time: 35, brush: 17, scrape: 25, villes: ['Lyon', 'Bruxelles', 'Genève', 'Toulouse', 'Lille', 'Strasbourg', 'Nantes', 'Turin'] };
const atelierPay = V => { const base = 30 + 8 * V.num; return { base, max: base * 2 }; };
function atelierCard(V) {
  const A = V.atelier || (V.atelier = { ville: ATELIER.villes[Math.floor(Math.random() * ATELIER.villes.length)], done: false, paid: 0 });
  const P = atelierPay(V);
  if (A.done) return '<div class="atelier done">' + ic('check') + '<div><b>Bloc rendu au musée de ' + A.ville + '</b><span>Propreté ' + A.clean + ' %' + (A.scr ? ' · ' + A.scr + ' rayure' + (A.scr > 1 ? 's' : '') : '') + ' · +' + A.paid + '</span></div></div>';
  return '<div class="atelier">' + ic('stone') + '<div><b>Atelier · un bloc du musée de ' + A.ville + '</b><span>Leur machine de nettoyage est en panne. Dégagez l’os pour eux : ' + P.base + ' à ' + P.max + ' pièces selon le soin.</span></div><button class="btn" type="button" id="btnAtelier">Nettoyer</button></div>';
}
function openAtelier() {
  const V = G.voyage; if (!V || !V.atelier || V.atelier.done || document.querySelector('.atelier-scene')) return;
  const A = V.atelier, P = atelierPay(V);
  const pool = Object.keys(FOSSILS).filter(f => FOSSILS[f].kind === 'frag'), fid = pool[Math.floor(Math.random() * pool.length)];
  const el = document.createElement('div');
  el.className = 'atelier-scene'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); el.setAttribute('aria-label', 'Atelier de nettoyage');
  el.innerHTML = '<div class="at-head"><b>Atelier · musée de ' + A.ville + '</b><span class="at-time"><i id="atTime"></i></span></div>' +
    '<div class="at-board"><canvas id="atBase"></canvas><canvas id="atDirt"></canvas><canvas id="atFx"></canvas></div>' +
    '<div class="at-tools" role="group" aria-label="Outil"><button type="button" data-t="brosse" aria-pressed="true">Brosse <small>la poussière, sans risque</small></button><button type="button" data-t="grattoir" aria-pressed="false">Grattoir <small>les croûtes, mais raye l’os à nu</small></button></div>' +
    '<p class="at-note" id="atNote">Brossez la poussière. Les croûtes sombres résistent : grattez-les, mais pas l’os dégagé !</p><div class="at-prog"><span>Propreté</span><b id="atProg">0 %</b><span>Rayures</span><b id="atScr">0</b><button class="btn" type="button" id="atDone">Rendre le bloc</button></div>';
  document.body.appendChild(el);
  const board = el.querySelector('.at-board'), base = el.querySelector('#atBase'), dirt = el.querySelector('#atDirt'), fxc = el.querySelector('#atFx');
  const S = Math.round(Math.min(window.innerWidth - 32, window.innerHeight - 300, 440)), dpr = Math.min(window.devicePixelRatio || 1, 2), W = Math.round(S * dpr);
  board.style.width = board.style.height = S + 'px';
  [base, dirt, fxc].forEach(c => { c.width = c.height = W; });
  fxc.style.pointerEvents = 'none';
  const bc = base.getContext('2d'), dc = dirt.getContext('2d'), fc = fxc.getContext('2d');
  /* la dalle et l'os */
  const slab = ROCKS[EPOCHS[FOSSILS[fid].epoch].rocks.propice].stone;
  bc.fillStyle = slab.face; bc.fillRect(0, 0, W, W);
  const g = mulberry32(hashStr(fid) ^ (V.num * 7919));
  for (let i = 0; i < 700; i++) { bc.fillStyle = g() < 0.6 ? slab.faceShade : slab.faceTex; bc.globalAlpha = 0.2 + g() * 0.25; bc.beginPath(); bc.ellipse(g() * W, g() * W, (1 + g() * 2.2) * dpr, (0.8 + g() * 1.6) * dpr, g() * 3, 0, TAU); bc.fill(); }
  bc.globalAlpha = 1;
  const [vw, vh] = ART[fid].vb, k = Math.min(W * 0.84 / vw, W * 0.84 / vh), ox = (W - vw * k) / 2, oy = (W - vh * k) / 2;
  const svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + vw + ' ' + vh + '" width="' + Math.round(vw * k) + '" height="' + Math.round(vh * k) + '"><g stroke-linecap="round" stroke-linejoin="round">' + ART[fid].fn(FPAL[FOSSILS[fid].epoch]) + '</g></svg>';
  /* la terre : une grille de mottes nettes. Poussière (1 couche, part à la brosse) ou croûte (dure, la brosse y peine) */
  const C = Math.max(6, Math.round(7 * dpr)), N = Math.ceil(W / C);
  const hp = new Float32Array(N * N), crust = new Uint8Array(N * N), bone = new Uint8Array(N * N), tint = new Float32Array(N * N);
  const blobs = []; for (let i = 0; i < 5; i++) blobs.push([g() * N, g() * N, N * (0.07 + g() * 0.08)]);
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const i = y * N + x; tint[i] = g();
    const inC = blobs.some(([bx, by, br]) => { const dx = x - bx, dy = y - by, wob = 1 + 0.25 * Math.sin(Math.atan2(dy, dx) * 3 + bx); return dx * dx + dy * dy < br * br * wob * wob; });
    crust[i] = inC ? 1 : 0; hp[i] = inC ? 4 : 1;
  }
  const DUST = ['#7a5a36', '#6b4d2c', '#8a6640', '#73532f'], CR = ['#a39578', '#978a6f', '#ab9e82'];
  /* des mottes rondes et irrégulières, nettes, avec une petite ombre : le style dessiné du jeu, pas des pixels */
  const jx = new Float32Array(N * N), jy = new Float32Array(N * N);
  for (let q = 0; q < N * N; q++) { jx[q] = (g() - 0.5) * C * 0.5; jy[q] = (g() - 0.5) * C * 0.5; }
  const paintRegion = (cx0, cy0, cx1, cy1) => {
    cx0 = Math.max(0, cx0 - 2); cy0 = Math.max(0, cy0 - 2); cx1 = Math.min(N - 1, cx1 + 2); cy1 = Math.min(N - 1, cy1 + 2);
    const px0 = cx0 * C, py0 = cy0 * C, pw = (cx1 - cx0 + 1) * C, ph = (cy1 - cy0 + 1) * C;
    dc.save(); dc.beginPath(); dc.rect(px0 + C, py0 + C, pw - 2 * C, ph - 2 * C); if (cx0 === 0 || cy0 === 0 || cx1 === N - 1 || cy1 === N - 1) { dc.restore(); dc.save(); dc.beginPath(); dc.rect(cx0 === 0 ? 0 : px0 + C, cy0 === 0 ? 0 : py0 + C, pw - (cx0 === 0 ? 0 : C) - (cx1 === N - 1 ? 0 : C), ph - (cy0 === 0 ? 0 : C) - (cy1 === N - 1 ? 0 : C)); }
    dc.clip(); dc.clearRect(px0, py0, pw, ph);
    for (let pass = 0; pass < 3; pass++) for (let y = cy0; y <= cy1; y++) for (let x = cx0; x <= cx1; x++) {
      const q = y * N + x; if (hp[q] <= 0) continue;
      const cxp = x * C + C / 2 + jx[q], cyp = y * C + C / 2 + jy[q], cr = crust[q], r = C * (cr ? 1.0 : 0.82) * (0.85 + tint[q] * 0.3) * (cr && hp[q] < 2.2 ? 0.82 : 1);
      dc.beginPath(); dc.ellipse(cxp + (pass === 0 ? C * 0.12 : 0), cyp + (pass === 0 ? C * 0.18 : 0), r, r * 0.86, tint[q] * 3, 0, TAU);
      if (pass === 0) dc.fillStyle = cr ? 'rgba(70,58,40,.35)' : 'rgba(40,26,12,.38)';
      else if (pass === 1) dc.fillStyle = cr ? CR[Math.floor(tint[q] * 3)] : DUST[Math.floor(tint[q] * 4)];
      else { if (tint[q] < 0.82) continue; dc.beginPath(); dc.ellipse(cxp - r * 0.25, cyp - r * 0.28, r * 0.22, r * 0.12, -0.5, 0, TAU); dc.fillStyle = cr ? 'rgba(255,250,235,.22)' : 'rgba(255,230,190,.12)'; }
      dc.fill();
    }
    dc.restore();
  };
  let dmin = null;
  const drawCell = i => { const x = i % N, y = Math.floor(i / N); if (!dmin) dmin = [x, y, x, y]; else { dmin[0] = Math.min(dmin[0], x); dmin[1] = Math.min(dmin[1], y); dmin[2] = Math.max(dmin[2], x); dmin[3] = Math.max(dmin[3], y); } };
  const flush = () => { if (dmin) { paintRegion(dmin[0], dmin[1], dmin[2], dmin[3]); dmin = null; } };
  paintRegion(0, 0, N - 1, N - 1);
  let boneIdx = [];
  const img = new Image();
  img.onload = () => {
    bc.drawImage(img, ox, oy, vw * k, vh * k);
    const m = document.createElement('canvas'); m.width = m.height = W; const mc = m.getContext('2d'); mc.drawImage(img, ox, oy, vw * k, vh * k);
    const md = mc.getImageData(0, 0, W, W).data;
    for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) { const px = Math.min(W - 1, x * C + C / 2 | 0), py = Math.min(W - 1, y * C + C / 2 | 0); if (md[(py * W + px) * 4 + 3] > 60) { bone[y * N + x] = 1; boneIdx.push(y * N + x); } }
    /* les croûtes collent surtout à l'os */
    boneIdx.forEach(i => { if (!crust[i] && g() < 0.18) { const x0 = i % N, y0 = Math.floor(i / N); for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const j = (y0 + dy) * N + x0 + dx; if (j >= 0 && j < N * N) { crust[j] = 1; hp[j] = 4; } } } });
    paintRegion(0, 0, N - 1, N - 1);
  };
  img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  /* les particules : la terre qui saute */
  const parts = [];
  const spawn = (i, dirx, diry) => {
    if (parts.length > 260) return;
    const x = (i % N) * C + C / 2, y = Math.floor(i / N) * C + C / 2, n = crust[i] ? 2 : 1;
    for (let q = 0; q < n; q++) parts.push({ x, y, vx: (dirx * 0.6 + (Math.random() - 0.5)) * 260 * dpr, vy: (diry * 0.6 - 0.6 - Math.random() * 0.6) * 260 * dpr, s: C * (0.35 + Math.random() * 0.4), c: crust[i] ? CR[q % 3] : DUST[Math.floor(Math.random() * 4)], t: 0 });
  };
  let lastF = now(), raf = 0;
  const tickFx = () => {
    const t = now(), dt = Math.min(0.05, (t - lastF) / 1000); lastF = t;
    fc.clearRect(0, 0, W, W);
    for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.t += dt; p.vy += 1400 * dpr * dt; p.x += p.vx * dt; p.y += p.vy * dt; if (p.t > 0.5 || p.y > W + 20) { parts.splice(i, 1); continue; } fc.globalAlpha = 1 - p.t / 0.5; fc.fillStyle = p.c; fc.beginPath(); fc.ellipse(p.x, p.y, p.s / 2, p.s * 0.4, p.t * 9, 0, TAU); fc.fill(); }
    fc.globalAlpha = 1;
    raf = requestAnimationFrame(tickFx);
  };
  raf = requestAnimationFrame(tickFx);
  let tool = 'brosse', scr = 0, lastScr = 0, prog = 0, over = false, last = null, lastSnd = 0, resistT = 0;
  const t0 = now(), T = ATELIER.time * 1000;
  el.querySelectorAll('.at-tools button').forEach(b => (b.onclick = () => { tool = b.dataset.t; el.querySelectorAll('.at-tools button').forEach(x => x.setAttribute('aria-pressed', x === b ? 'true' : 'false')); Sound.play('tap'); }));
  const pt = e => { const r = dirt.getBoundingClientRect(); return [(e.clientX - r.left) / r.width * W, (e.clientY - r.top) / r.height * W]; };
  const note = $q => { el.querySelector('#atNote').textContent = $q; };
  const scrub = (x, y, dx, dy) => {
    const br = tool === 'brosse', R = (br ? 2.4 : 1.4) * C, cx = x / C, cy = y / C, r = R / C;
    const L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L;
    let exposedBone = 0, resisted = 0, removed = 0;
    for (let yy = Math.floor(cy - r); yy <= Math.ceil(cy + r); yy++) for (let xx = Math.floor(cx - r); xx <= Math.ceil(cx + r); xx++) {
      if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue;
      if ((xx + 0.5 - cx) ** 2 + (yy + 0.5 - cy) ** 2 > r * r) continue;
      const i = yy * N + xx;
      if (hp[i] <= 0) { if (bone[i]) exposedBone++; continue; }
      const before = hp[i];
      hp[i] -= br ? (crust[i] ? 0.035 : 0.34) : (crust[i] ? 0.55 : 0.7);
      if (br && crust[i]) resisted++;
      if (hp[i] <= 0) { hp[i] = 0; removed++; spawn(i, ux, uy); }
      else if (Math.floor(before) !== Math.floor(hp[i]) && crust[i]) spawn(i, ux, uy);
      drawCell(i);
    }
    /* le grattoir sur l'os à nu le raye */
    if (!br && exposedBone >= 3 && now() - lastScr > 280) {
      lastScr = now(); scr++; el.querySelector('#atScr').textContent = scr; buzz(12); Sound.play('cassure');
      const a = Math.random() * TAU, Ls = (10 + Math.random() * 14) * dpr; bc.strokeStyle = 'rgba(250,244,230,.9)'; bc.lineWidth = 1.6 * dpr; bc.beginPath(); bc.moveTo(x - Math.cos(a) * Ls, y - Math.sin(a) * Ls); bc.lineTo(x + Math.cos(a) * Ls, y + Math.sin(a) * Ls); bc.stroke();
      note('Aïe, le grattoir raye l’os à nu ! Reprenez la brosse.');
    }
    flush();
    if (resisted > 3 && now() - resistT > 2500) { resistT = now(); note('Cette croûte résiste à la brosse : prenez le grattoir.'); }
    if (now() - lastSnd > 90 && (removed || resisted)) { lastSnd = now(); Sound.play(br ? 'type' : 'tap'); }
  };
  const measure = () => {
    if (!boneIdx.length) return;
    let clear = 0; for (const i of boneIdx) if (hp[i] <= 0) clear++;
    prog = clear / boneIdx.length;
    el.querySelector('#atProg').textContent = Math.round(prog * 100) + ' %';
    if (prog > 0.95) finish();
  };
  dirt.addEventListener('pointerdown', e => { if (over) return; e.preventDefault(); try { dirt.setPointerCapture(e.pointerId); } catch (x) { } last = pt(e); scrub(last[0], last[1], 0, -1); });
  dirt.addEventListener('pointermove', e => {
    if (!last || over) return;
    const p = pt(e), dx = p[0] - last[0], dy = p[1] - last[1], n = Math.max(1, Math.ceil(Math.hypot(dx, dy) / (C * 0.8)));
    for (let i = 1; i <= n; i++) scrub(last[0] + dx * i / n, last[1] + dy * i / n, dx, dy);
    last = p;
  });
  ['pointerup', 'pointercancel'].forEach(t => dirt.addEventListener(t, () => { last = null; measure(); }));
  const timer = setInterval(() => {
    const kk = (now() - t0) / T;
    el.querySelector('#atTime').style.width = Math.max(0, 100 * (1 - kk)) + '%';
    measure();
    if (kk >= 1) finish();
  }, 250);
  function finish() {
    if (over) return; over = true; clearInterval(timer); measure();
    const clean = Math.round(prog * 100), q = clamp((prog - 0.45) / 0.48, 0, 1);
    let pay = Math.round((P.base + (P.max - P.base) * q) * (1 - Math.min(0.5, scr * 0.07)));
    pay = Math.max(Math.round(P.base * 0.5), pay);
    /* filet du joueur fauché : de quoi payer au moins le voyage le plus modeste */
    const need = (V.offers ? V.offers[0].price : 0) - G.money;
    if (need > pay) pay = need;
    A.done = true; A.paid = pay; A.clean = clean; A.scr = scr;
    Log.ev('atelier', { proprete: clean, rayures: scr, paye: pay });
    addMoney(pay); save();
    Sound.play(clean >= 85 ? 'ident' : 'coin');
    note(clean >= 85 ? 'Impeccable ! Le musée de ' + A.ville + ' vous remercie : +' + pay + ' pièces.' : 'Bloc rendu : +' + pay + ' pièces.');
    const b = el.querySelector('#atDone'); b.textContent = 'Retour à l’escale'; b.classList.add('primary');
    b.onclick = () => { cancelAnimationFrame(raf); el.remove(); renderMuseum(); };
  }
  el.querySelector('#atDone').onclick = finish;
}
function renderEscale() {
  const V = G.voyage, box = $('escale'), dep = $('depart');
  box.hidden = !V; dep.hidden = !V;
  $('app').classList.toggle('esc-shop', !!(V && V.step === 'boutique'));
  if (!V) { box.innerHTML = ''; dep.innerHTML = ''; return; }
  if (!V.offers) { V.offers = makeOffers(V.num); save(); }
  if (V.step === 'boutique') {
    /* deuxième temps : la destination est réglée, la boutique est ouverte, puis on part */
    const O = V.offers[V.pick] || V.offers[0], E2 = EPOCHS[O.epoch];
    box.innerHTML = '<div class="esc-head"><span class="stamp">Escale au musée</span><span class="esc-from">Retour du gisement n°' + (V.num - 1) + '</span></div>' +
      kyInline({ expr: ESCALE.boutique.expr, text: kyFill(ESCALE.boutique.text, { dest: 'le ' + O.name.toLowerCase() + ' ' + E2.du }) }) +
      '<div class="esc-sum"><span>Caisse<b>' + fmt(G.money) + '</b></span><span class="bud">Voyage<b>' + (V.covered ? 'avancé par le musée' : 'réglé') + '</b></span></div>';
    dep.innerHTML = '<div class="dest-chosen" style="--c:' + E2.color + '"><span class="dest-ep"><i></i>' + E2.name + '</span><b>' + O.name + ' · gisement n°' + V.num + '</b><button class="link" type="button" id="btnBackDest">Changer de destination</button></div>' +
      '<button class="btn primary" type="button" id="btnDepart">' + ic('arrow') + 'Partir vers le gisement n°' + V.num + '</button>';
    $('btnBackDest').onclick = unchooseDest;
    $('btnDepart').onclick = depart;
    return;
  }
  const broke = G.money < V.offers[0].price, m = broke ? ESCALE.fauche : ESCALE.bienvenue;
  box.innerHTML = '<div class="esc-head"><span class="stamp">Escale au musée</span><span class="esc-from">Retour du gisement n°' + (V.num - 1) + '</span></div>' +
    kyInline({ expr: m.expr, text: kyFill(m.text, { n: V.num }) }) +
    '<div class="esc-sum"><span>Caisse<b>' + fmt(G.money) + '</b></span><span class="bud">Lunettes<b>réparées</b></span></div>';
  const bars = (l, n, m) => '<span class="pbar-row"><em>' + l + '</em>' + Array.from({ length: m }, (_, i) => '<i class="' + (i < n ? 'on' : '') + '"></i>').join('') + '</span>';
  const bones = n => '<span class="dest-bones" aria-label="' + n + ' poches">' + Array.from({ length: 4 }, (_, i) => '<i class="' + (i < n ? 'on' : '') + '"></i>').join('') + '</span>';
  const cards = V.offers.map((O, i) => {
    const E2 = EPOCHS[O.epoch], ok = G.money >= O.price || O.tier === 0, sel = V.pick === i;
    return '<button type="button" class="dest' + (sel ? ' on' : '') + (ok ? '' : ' poor') + '" data-i="' + i + '" aria-pressed="' + sel + '"' + (ok ? '' : ' aria-disabled="true"') + ' style="--c:' + E2.color + '">' +
      '<span class="dest-ep"><i></i>' + E2.name + '</span><b>' + O.name + '</b>' + bones(O.poches) +
      (O.prof ? '<span class="dest-prof">' + bars('Fossiles', O.poches, 4) + bars('Minerai', Math.round(O.veins / 2.5), 4) + bars('Géodes', O.geodes, 4) + '</span>' : '') +
      '<span class="dest-l">' + (O.fresh ? O.fresh + ' espèce' + (O.fresh > 1 ? 's' : '') + ' encore absente' + (O.fresh > 1 ? 's' : '') + ' du musée' : 'Époque déjà complète au musée') + '</span>' +
      '<span class="price">' + ic('coin') + fmt(O.price) + (O.tier === 0 && G.money < O.price ? ' · après l’atelier' : '') + '</span></button>';
  }).join('');
  const O = V.offers[V.pick] || V.offers[0];
  dep.innerHTML = atelierCard(V) + '<h2 class="dest-h">Prochaine destination</h2><div class="dests" role="group" aria-label="Destinations">' + cards + '</div>' +
    '<button class="btn primary" type="button" id="btnChoose">' + ic('arrow') + 'Choisir cette destination<span class="price">' + ic('coin') + fmt(O.price) + '</span></button>';
  dep.querySelectorAll('.dest').forEach(b => (b.onclick = () => {
    const i = +b.dataset.i, Oi = V.offers[i];
    if (G.money < Oi.price && Oi.tier !== 0) { toast('Il manque ' + fmt(Oi.price - G.money) + ' pièces.'); return; }
    V.pick = i; save(); Sound.play('tap'); renderEscale();
  }));
  $('btnChoose').onclick = chooseDest;
  const ba = $('btnAtelier'); if (ba) ba.onclick = openAtelier;
}
function renderShop() {
  const V = G.voyage, budget = shopBudget();
  $('shopHead').innerHTML = V ? ic('coin') + '<span>' + fmt(budget) + '</span>' : ic('lock') + '<span>Fermée</span>';
  $('shopHead').classList.toggle('closed', !V);
  const closed = $('shopClosed');
  closed.hidden = !!V;
  if (!V && G.site) closed.innerHTML = kyInline({ expr: ESCALE.fermee.expr, text: ESCALE.fermee.text });
  $('shopTabs').innerHTML = TABS.map(([id, n]) => '<button class="shop-tab" role="tab" data-t="' + id + '" aria-selected="' + (id === shopTab) + '">' + n + '</button>').join('');
  $('shopTabs').querySelectorAll('.shop-tab').forEach(b => (b.onclick = () => { shopTab = b.dataset.t; renderShop(); }));
  $('shop').innerHTML = UPGRADES.filter(u => u.tab === shopTab).map(u => {
    const l = G.up[u.id], max = l >= u.max, cost = max ? 0 : u.cost[l], ok = !!V && budget >= cost;
    const pic = u.id === 'marteau' ? hammerSVG(Math.min(u.max, l + (max ? 0 : 1))) : ic(u.icon);
    const pips = u.max > 1 ? '<span class="lvl" aria-label="Niveau ' + l + ' sur ' + u.max + '">' + Array.from({ length: u.max }, (_, i) => '<i class="' + (i < l ? 'on' : '') + '"></i>').join('') + '</span>' : '';
    const btn = !V ? '<button class="btn buy" disabled>' + ic('lock') + 'À l’escale<span class="price">' + ic('coin') + fmt(cost) + '</span></button>'
      : '<button class="btn ' + (ok ? 'primary' : '') + ' buy" data-u="' + u.id + '"' + (ok ? '' : ' disabled') + '>' + (ok ? 'Acheter' : 'Il manque ' + fmt(cost - budget)) + '<span class="price">' + ic('coin') + fmt(cost) + '</span></button>';
    return '<div class="item' + (max ? ' max' : V && !ok ? ' locked' : '') + '"><span class="pic">' + pic + '</span><h3>' + u.name + pips + '</h3>' +
      '<p>' + (l || u.id === 'marteau' || u.id === 'quantite' || u.id === 'taille' || u.id === 'chaleur' ? '<b>Actuel :</b> ' + u.now(l) : 'Pas encore acquis.') + '</p>' +
      (max ? '<p><b>Niveau maximum.</b></p>' : '<p><b>Suivant :</b> ' + u.next(l) + '</p>' + btn) + '</div>';
  }).join('');
  $('shop').querySelectorAll('.buy[data-u]').forEach(b => (b.onclick = () => buy(b.dataset.u)));
}
function buy(id) {
  const u = UPGRADES.find(x => x.id === id), l = G.up[id];
  if (!G.voyage || l >= u.max || shopBudget() < u.cost[l]) return;
  G.money -= u.cost[l]; G.up[id]++;
  Log.ev('achat', { id, niveau: G.up[id], prix: u.cost[l], argent: G.money });
  Sound.play('buy');
  toast(u.name + (u.max > 1 ? ' · niveau ' + G.up[id] : ' acquis'));
  if (id === 'chaleur') G.set.chaleur = true;
  if (G.voyage && G.voyage.offers) { const P = G.voyage.offers[G.voyage.pick]; if (P && P.tier && G.money < P.price) G.voyage.pick = 0; }
  syncMoney(false); updateHud(); renderEscale(); renderShop(); save();
}
function openFiche(fid) {
  G.seen[fid] = true;
  openSheet('<h2 class="sr">' + dispName(fid) + '</h2>' + ficheHTML(fid) + '<div class="actions"><button class="btn" data-close>Fermer</button></div>');
  document.querySelectorAll('.slot.new').forEach(s => { if (G.seen[s.dataset.f]) s.classList.remove('new'); });
  updateBadges(); save();
}

/* ---------- feuilles modales ---------- */
function openSheet(inner, onMount) {
  const back = document.createElement('div');
  back.className = 'sheet-back';
  back.innerHTML = '<div class="sheet" role="dialog" aria-modal="true">' + inner + '</div>';
  document.body.appendChild(back);
  const prev = document.activeElement;
  const close = () => { back.remove(); document.removeEventListener('keydown', key); if (prev && prev.focus) prev.focus(); };
  const key = e => { if (e.key === 'Escape') close(); };
  back.addEventListener('click', e => { if (e.target === back || e.target.closest('[data-close]')) close(); });
  document.addEventListener('keydown', key);
  const f = back.querySelector('button,input'); if (f) f.focus();
  if (onMount) onMount(back, close);
  return close;
}
/* bilan de l'expédition, puis l'escale */
function openLeave() {
  const S = G.site, s = S.stats, open = openInds(), stones = S.holes.filter(h => h.k === 'pierre').length;
  const inner = '<h2>Bilan du gisement n°' + S.num + '</h2><p>On ne revient jamais sur un gisement quitté.</p>' +
    '<table class="bilan"><tr><td>Fouilles</td><td>' + S.holes.length + '</td></tr><tr><td>Pierres fendues</td><td>' + stones + '</td></tr><tr><td>Minerai vendu</td><td>+' + s.ore + '</td></tr><tr><td>Primes de fossiles</td><td>+' + s.bonus + '</td></tr><tr><td>Fragments trouvés</td><td>' + s.frags + '</td></tr>' + (s.dup ? '<tr><td>Doublons revendus</td><td>' + s.dup + '</td></tr>' : '') + '<tr><td>Pièces uniques</td><td>' + s.uniques + '</td></tr><tr><td>Fossiles complétés</td><td>' + s.completes + '</td></tr></table>' +
    (open.length ? '<div class="trip warn">' + ic('puzzle') + '<div><b>' + open.length + ' squelette' + (open.length > 1 ? 's' : '') + ' inachevé' + (open.length > 1 ? 's' : '') + '</b><span>' + open.map(o => dispName(o.fid) + ' ' + o.I.found.length + '/' + FOSSILS[o.fid].blocks).join(', ') + '. Ils partent en réserve, incomplets.</span></div></div>' : '') +
    '<div class="trip">' + ic('museum') + '<div><b>Escale au musée</b><span>La boutique y est ouverte, puis vous choisirez la prochaine destination.</span></div></div>' +
    '<div class="actions"><button class="btn" data-close>Revoir la carte</button><button class="btn primary" id="goLeave">' + ic('museum') + 'Rentrer au musée</button></div>';
  openSheet(inner, (back, close) => { back.querySelector('#goLeave').onclick = () => { close(); startVoyage(); }; });
}
/* destination au hasard, pondérée vers les époques qui ont encore des fossiles à trouver (et rarement la même) */
function pickEpoch() {
  const cur = G.site && G.site.epoch;
  const w = EPOCH_IDS.map(e => { const miss = EPOCHS[e].fossils.filter(f => !fos(f).done).length; return (miss ? 1 + miss : 0.4) * (e === cur ? 0.35 : 1); });
  let r = Math.random() * w.reduce((a, b) => a + b, 0);
  for (let i = 0; i < w.length; i++) { r -= w[i]; if (r <= 0) return EPOCH_IDS[i]; }
  return EPOCH_IDS[EPOCH_IDS.length - 1];
}
function openSettings() {
  const row = (id, icn, label, on) => '<label class="toggle">' + ic(icn) + '<span>' + label + '</span><input type="checkbox" id="' + id + '"' + (on ? ' checked' : '') + '></label>';
  const inner = '<h2>Réglages</h2>' + row('setSon', 'sound', 'Sons', G.set.son) + row('setAmb', 'sound', 'Nappe sonore', G.set.amb !== false) + row('setVib', 'vibrate', 'Vibrations', G.set.vib) + row('setFast', 'fast', 'Animation accélérée', G.set.rapide) +
    row('setMots', 'sound', 'Onomatopées sur l’établi (pic, pok, ting…)', G.set.mots) +
    '<div class="confirm-row"><button class="btn" id="btnIntro">' + ic('museum') + 'Revoir l’introduction</button><button class="btn" id="btnTuto">' + ic('hammer') + 'Revoir le tutoriel</button></div>' +
    '<div class="confirm-row"><button class="btn" id="btnLog">' + ic('book') + 'Journal de partie (playtest)</button></div>' +
    '<div class="confirm-row" id="resetRow"><button class="btn danger" id="btnReset">' + ic('reset') + 'Recommencer la partie</button></div>' +
    '<div class="actions"><button class="btn primary" data-close>Fermer</button></div>';
  openSheet(inner, back => {
    const bind = (id, key, after) => { const el = back.querySelector('#' + id); if (el) el.onchange = () => { G.set[key] = el.checked; save(); if (after) after(); }; };
    bind('setSon', 'son', () => { Sound.play('tap'); Ambient.sync(); }); bind('setAmb', 'amb', () => Ambient.sync()); bind('setVib', 'vib', () => buzz(20)); bind('setFast', 'rapide'); bind('setMots', 'mots');
    back.querySelector('#btnIntro').onclick = () => { back.remove(); introScene(); };
    back.querySelector('#btnTuto').onclick = () => { back.remove(); startTuto(); };
    back.querySelector('#btnLog').onclick = () => { back.remove(); openJournal(); };
    back.querySelector('#btnReset').onclick = () => {
      back.querySelector('#resetRow').innerHTML = '<span style="flex:1 1 100%;font-size:15px">Tout effacer : collection, outils et gisement ?</span><button class="btn" id="rsNo">Annuler</button><button class="btn danger" id="rsYes">Effacer</button>';
      back.querySelector('#rsNo').onclick = () => { back.remove(); openSettings(); };
      back.querySelector('#rsYes').onclick = () => { back.remove(); newGame(); };
    };
  });
}

/* une partie neuve : tout s'efface, puis l'introduction, l'établi du professeur et le premier gisement */
function newGame() {
  if (TUTO) tutoFinish();
  endStone(); closeSay(true); PENDING = null;
  G = DEFAULT(); CUR = null; try { localStorage.removeItem(SAVE_KEY); } catch (e) { }
  Log.reset(); Log.ev('nouvelle_partie');
  newSite('cambrien', 1); show('carte'); syncMoney(false); updateHud(); renderTip();
  introScene(() => startTuto(() => { show('carte'); sayArrival(false); }));
}
/* ---------- journal de partie : les trois questions, puis l'envoi ---------- */
function openJournal() {
  const pl = (n, w) => n + ' ' + w + (n > 1 ? 's' : ''), D = Log.load(), S = Log.summary(), esc = t => String(t == null ? '' : t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  const inner = '<h2>Journal de partie</h2><p class="jr-lead">Ta partie est notée dans ce navigateur, rien n’est envoyé tout seul. ' + (PLAYTEST_ASK ? 'Réponds aux trois questions, puis envoie le journal.' : 'Envoie-le au développeur quand tu as fini de jouer.') + '</p>' +
    '<p class="jr-stats">' + String(S.temps_de_jeu_min).replace('.', ',') + ' min de jeu · ' + pl(S.pierres, 'pierre') + ' · ' + pl(S.coups_de_pelle, 'coup') + ' de pelle · ' + pl(D.ev.length, 'événement') + '</p>' +
    (PLAYTEST_ASK ? PLAYTEST_Q : []).map((q, i) => '<label class="jr-q"><span>' + (i + 1) + '. ' + q + '</span><textarea rows="3" data-q="' + i + '">' + esc(D.reponses['q' + (i + 1)]) + '</textarea></label>').join('') +
    '<div class="jr-actions"><button class="btn primary" id="jrSend">' + ic('arrow') + 'Envoyer le journal</button><button class="btn" id="jrCopy">Copier</button></div>' +
    '<p class="jr-done" id="jrDone" aria-live="polite"></p>' +
    '<div class="actions"><button class="btn ghost" id="jrWipe">Effacer le journal</button><button class="btn" data-close>Fermer</button></div>';
  openSheet(inner, back => {
    const keep = () => { back.querySelectorAll('textarea').forEach(t => { D.reponses['q' + (+t.dataset.q + 1)] = { question: PLAYTEST_Q[+t.dataset.q], reponse: t.value }; }); Log.save(); };
    back.querySelectorAll('textarea').forEach(t => { const v = D.reponses['q' + (+t.dataset.q + 1)]; t.value = v && v.reponse != null ? v.reponse : ''; t.oninput = keep; });
    const done = m => { back.querySelector('#jrDone').textContent = m; };
    const name = 'carnet-de-fouille-' + D.id + '-' + new Date().toISOString().slice(0, 10) + '.json';
    back.querySelector('#jrSend').onclick = async () => {
      keep(); Log.ev('journal_envoye'); const txt = JSON.stringify(Log.file(), null, 1);
      /* sur téléphone : la feuille de partage (messagerie, mail…) ; sinon, un fichier téléchargé */
      try { const f = new File([txt], name, { type: 'application/json' }); if (navigator.canShare && navigator.canShare({ files: [f] })) { await navigator.share({ files: [f], title: 'Carnet de Fouille · journal' }); done('Envoyé, merci !'); return; } } catch (e) { if (e && e.name === 'AbortError') return; }
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([txt], { type: 'application/json' })); a.download = name; document.body.appendChild(a); a.click(); a.remove();
      done('Fichier « ' + name + ' » téléchargé : envoie-le au développeur. Merci !');
    };
    back.querySelector('#jrCopy').onclick = async () => { keep(); try { await navigator.clipboard.writeText(JSON.stringify(Log.file())); done('Copié : colle-le dans un message. Merci !'); } catch (e) { done('Copie impossible ici : utilise « Envoyer ».'); } };
    const w = back.querySelector('#jrWipe');
    w.onclick = () => { if (!w.classList.contains('sure')) { w.classList.add('sure'); w.textContent = 'Vraiment tout effacer ?'; return; } Log.wipe(); back.remove(); openJournal(); };
  });
}

/* ---------- écran d'accueil : l'établi ----------
   Un carnet de fouille fermé, posé sur l'établi entre une ammonite, une géode et le marteau. On touche le carnet :
   la couverture s'ouvre, on plonge dans la page, et le jeu commence. Le premier toucher réveille aussi le son. */
function titleScreen(go) {
  const el = document.createElement('div'), saved = !!(G.stones || G.notes.kayou), n = Object.keys(FOSSILS).filter(f => fos(f).done).length;
  const today = new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
  el.className = 'title-screen'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-label', 'Carnet de Fouille');
  el.innerHTML = '<canvas class="ts-wood" aria-hidden="true"></canvas><div class="ts-desk">' +
    '<span class="ts-prop ts-ammo" aria-hidden="true">' + fossilSVG('ammonite', 'full') + '</span>' +
    '<span class="ts-prop ts-trilo" aria-hidden="true">' + fossilSVG('trilobite', 'full') + '</span>' +
    '<span class="ts-prop ts-geode" aria-hidden="true">' + geodeSVG('amethyste', true) + '</span>' +
    '<span class="ts-prop ts-hammer" aria-hidden="true">' + hammerSVG(1) + '</span>' +
    '<button class="nb" type="button" aria-label="' + (saved ? TITLE_TXT.cont : TITLE_TXT.start) + '">' +
      '<span class="nb-pages"></span>' +
      '<span class="nb-inside"><span class="nb-hand">' + TITLE_TXT.page + '<small>' + TITLE_TXT.pageSub + '</small></span><span class="nb-date">' + today + '</span></span>' +
      '<span class="nb-cover"><span class="nb-front"><span class="nb-title">Carnet<br>de<br>Fouille</span><span class="nb-sub">' + TITLE_TXT.cover + '</span></span><span class="nb-back"></span></span>' +
      '<span class="nb-strap"></span><span class="nb-tag">' + (saved ? TITLE_TXT.cont : TITLE_TXT.start) + '</span>' +
    '</button>' +
    '<p class="ts-hint">' + TITLE_TXT.hint + '</p>' +
    (saved ? '<div class="ts-foot"><span class="ts-save">' + kyFill(TITLE_TXT.save, { n, s: n > 1 ? 's' : '', g: G.site ? G.site.num : 1 }) + '</span><button class="ts-new" type="button">' + TITLE_TXT.fresh + '</button></div>' : '') +
    '</div><div class="ts-fade"></div>';
  $('app').appendChild(el);
  /* le bois de l'établi, peint comme celui où l'on fend les pierres */
  const cv = el.querySelector('.ts-wood'), paint = () => { const r = el.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 2); if (!r.width) return; cv.width = Math.round(r.width * dpr); cv.height = Math.round(r.height * dpr); drawBench(cv, 11); };
  paint(); window.addEventListener('resize', paint);
  let busy = false;
  const open = then => {
    if (busy) return; busy = true;
    /* partie neuve : la musique enjouée de l'introduction ; partie en cours : la musique calme du jeu */
    Ambient.mode = saved && G.notes.kayou ? 'calme' : 'joyeux';
    Sound.ensure(); Ambient.sync(); Sound.play('fly');
    const nb = el.querySelector('.nb'), r = nb.getBoundingClientRect(), R = el.getBoundingClientRect();
    el.querySelector('.ts-desk').style.transformOrigin = (r.left - R.left + r.width / 2) + 'px ' + (r.top - R.top + r.height / 2) + 'px';
    el.classList.add('opening');
    const fast = reduceMotion() ? 0.2 : 1;
    setTimeout(() => el.classList.add('zoom'), 950 * fast);
    setTimeout(() => { window.removeEventListener('resize', paint); el.remove(); then(); }, 1900 * fast);
  };
  el.querySelector('.nb').onclick = () => open(() => { Log.ev('accueil', { choix: saved ? 'continuer' : 'commencer' }); go(); });
  const nb = el.querySelector('.ts-new');
  if (nb) nb.onclick = () => {
    if (!nb.classList.contains('sure')) { nb.classList.add('sure'); nb.textContent = TITLE_TXT.sure; return; }
    open(() => { Log.ev('accueil', { choix: 'nouvelle' }); newGame(); });
  };
  setTimeout(() => el.querySelector('.nb').focus({ preventScroll: true }), 50);
}

/* ---------- démarrage ---------- */
function start(hot) {
  buildSprites();
  const okV = d => d && d.v >= 2 && d.v <= 8;
  let data = okV(hot) ? hot : null;
  if (!data) { try { const raw = localStorage.getItem(SAVE_KEY); if (raw) data = JSON.parse(raw); } catch (e) { data = null; } }
  /* une sauvegarde illisible ne doit jamais laisser l'écran vide : on repart de zéro plutôt que de planter */
  if (okV(data)) { try { merge(data); } catch (e) { G = DEFAULT(); toast('Sauvegarde illisible : nouvelle partie.'); } }
  MapView.init({ terrain: $('cvTerrain'), exhaust: $('cvExhaust'), overlay: $('cvOverlay'), heat: $('cvHeat'), hover: $('cvHover') });
  setupMap(); setupBench();
  document.querySelectorAll('[data-go]').forEach(b => (b.onclick = () => {
    if (G.voyage && b.dataset.go !== 'musee') { toast('Escale au musée : repartez depuis le musée.'); return; }
    Sound.play('tap'); show(b.dataset.go);
  }));
  $('btnMenu').onclick = openSettings;
  if (G.site && !G.site.poches) migrateSite(); else if (G.site) openSite(); else newSite('cambrien', 1);
  if (G.stone && (!G.stone.contents || !SITE.zones[G.stone.zone])) G.stone = null;
  syncMoney(false); updateHud();
  show(G.voyage ? 'musee' : G.stone ? 'etabli' : 'carte');
  if (!G.voyage && !G.stone && G.site && digsLeft() <= 0 && !G.site.closed) setTimeout(closeSite, 600);
  /* première partie : l'introduction, puis l'établi du professeur, puis le premier gisement */
  const arrive = () => { show('carte'); sayArrival(false); };
  const firstSteps = () => {
    if (!G.notes.kayou) { const fresh = !G.stones; introScene(fresh ? () => startTuto(arrive) : null); }
    else if (!G.notes.tutoEtabli && !G.stones && !G.voyage && !G.stone) startTuto(arrive);
  };
  Log.ev('ouverture', { pierres: G.stones || 0, gisement: G.site ? G.site.num : 0, argent: G.money });
  /* l'écran d'accueil d'abord (les tests de la préversion le sautent) */
  if (window.__NOTITLE) firstSteps(); else titleScreen(firstSteps);
  if (window.claude && window.claude.hot && window.claude.hot.snapshot) { try { window.claude.hot.snapshot(serialize); } catch (e) { } }
  /* en arrière-plan : on sauve, et la nappe se tait (le contexte audio est suspendu) */
  Log.tick();
  document.addEventListener('visibilitychange', () => { Log.tick(); if (document.hidden) { save(); if (Sound.ctx) Sound.ctx.suspend(); } else if (Sound.ctx && Ambient.on) Sound.ctx.resume(); });
}
try {
  if (window.claude && window.claude.hot && window.claude.hot.ready) window.claude.hot.ready(start);
  else start(window.claude && window.claude.hot ? window.claude.hot.data : null);
} catch (e) { start(null); }
