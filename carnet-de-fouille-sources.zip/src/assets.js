/* ============ assets : icônes, pierres, marteaux, minerais, établi ============ */
const ICONS = {
  coin: '<circle cx="12" cy="12" r="9.2"/><path d="M12.9 12a.9 .9 0 0 0-1.8 0a2.1 2.1 0 0 0 4.2 0a3.3 3.3 0 0 0-6.6 0a4.5 4.5 0 0 0 9 0"/>',
  trilo: '<path d="M5.4 10a6.6 5.6 0 0 1 13.2 0z"/><path d="M7.6 10v6.4a4.4 3.6 0 0 0 8.8 0V10"/><path d="M12 6.8v13M7.6 13h8.8M7.6 16h8.8M5.4 10l-1.1 4M18.6 10l1.1 4"/>',
  map: '<path d="M3.5 6.5l5.5-2 6 2 5.5-2v13l-5.5 2-6-2-5.5 2z"/><path d="M9 4.5v13M15 6.5v13"/>',
  hammer: '<path d="M5 19.5l8.2-8.2"/><path d="M8.6 8.2l4.1-4.1 2.3 2.3 4.6 1-1.3 1.3-3.3-.2.6 1.9-3.9 3.9z"/>',
  museum: '<path d="M3 9.5l9-5 9 5z"/><path d="M5.5 9.5v7.8M9.8 9.5v7.8M14.2 9.5v7.8M18.5 9.5v7.8M3.5 20h17M4.5 17.3h15"/>',
  eye: '<path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6z"/><circle cx="12" cy="12" r="2.8"/>',
  eyeoff: '<path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6z"/><circle cx="12" cy="12" r="2.8"/><path d="M4 4l16 16"/>',
  gauge: '<path d="M4 16.5a8 8 0 0 1 16 0"/><path d="M12 16.5l4-5"/><circle cx="12" cy="16.5" r="1.1"/>',
  menu: '<path d="M4.5 7h15M4.5 12h15M4.5 17h15"/>',
  glasses: '<circle cx="6.8" cy="13.2" r="3.9"/><circle cx="17.2" cy="13.2" r="3.9"/><path d="M10.7 12.6c.8-.9 1.8-.9 2.6 0M2.9 12.4L2 8.3M21.1 12.4l.9-4.1"/>',
  shovel: '<path d="M14.2 9.8l5.3-5.3M17.6 2.6l3.8 3.8"/><path d="M14.2 9.8l-1.9-1.9-5.8 5.8c-1.6 1.6-1.6 4.2 0 5.8s4.2 1.6 5.8 0l5.8-5.8-1.9-1.9"/>',
  close: '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
  lock: '<rect x="6" y="11" width="12" height="9" rx="1.5"/><path d="M8.5 11V8.5a3.5 3.5 0 0 1 7 0V11"/>',
  check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  sound: '<path d="M4 9.5h3.5l4.5-4v13l-4.5-4H4z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11"/>',
  mute: '<path d="M4 9.5h3.5l4.5-4v13l-4.5-4H4z"/><path d="M15.5 9.5l5 5M20.5 9.5l-5 5"/>',
  vibrate: '<rect x="8" y="4" width="8" height="16" rx="1.5"/><path d="M4.5 8.5v7M19.5 8.5v7"/>',
  fast: '<path d="M4 6.5l7 5.5-7 5.5zM12.5 6.5l7 5.5-7 5.5z"/>',
  target: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><path d="M12 2.5v4M12 17.5v4M2.5 12h4M17.5 12h4"/>',
  bag: '<path d="M5.5 9.5h13l-1 10.5h-11z"/><path d="M9 9.5V7.5a3 3 0 0 1 6 0v2"/>',
  stone: '<path d="M4.5 14.5c0-4.5 3.5-8 8-8s7 2.8 7 6-3.2 7-8.2 7-6.8-2-6.8-5z"/><path d="M9 11l2.5 1.5M13.5 14.5l2 .5"/>',
  reset: '<path d="M4.5 12a7.5 7.5 0 1 0 2.3-5.4"/><path d="M4.5 4.5v4h4"/>',
  arrow: '<path d="M5 12h14M13.5 6.5L19 12l-5.5 5.5"/>',
  puzzle: '<path d="M5 8h4.5a2 2 0 1 1 4 0H18v4.5a2 2 0 1 1 0 4V20H5z"/>',
  star: '<path d="M12 4l2.3 5 5.4.6-4 3.7 1.1 5.3L12 16l-4.8 2.6 1.1-5.3-4-3.7 5.4-.6z"/>',
  north: '<path d="M12 3l4.5 16L12 15.5 7.5 19z"/><path class="f" d="M12 3v12.5L7.5 19z"/>',
  flag: '<path d="M6 20V4.5M6 5h11l-2.5 3.5L17 12H6"/>',
  loupe: '<circle cx="10" cy="10" r="6.2"/><path d="M14.6 14.6L20.5 20.5"/><path d="M7.2 9.2a3.2 3.2 0 0 1 2.4-2.2"/>',
  fissure: '<path d="M4.5 14.5c0-4.5 3.5-8 8-8s7 2.8 7 6-3.2 7-8.2 7-6.8-2-6.8-5z"/><path d="M5.2 13.4l4.6-.4 3.4.6 5.9-1.1"/><path d="M11.6 6.8l.9 2.6-.6 1.6"/>'
};
function iconSprite() {
  let s = '<svg width="0" height="0" style="position:absolute;overflow:hidden" aria-hidden="true"><defs>';
  for (const k in ICONS) s += '<symbol id="i-' + k + '" viewBox="0 0 24 24">' + ICONS[k] + '</symbol>';
  return s + '</defs></svg>';
}
const ic = (name, cls) => '<svg class="ic' + (cls ? ' ' + cls : '') + '" aria-hidden="true"><use href="#i-' + name + '"/></svg>';

/* ---------------- pierres ---------------- */
/* familles de formes par roche ; le calcaire à fossile sort plus souvent en nodule */
const STONE_SHAPES = {
  schiste: [['slab', 0.55], ['plate', 0.45]], gresfin: [['round', 0.6], ['pebble', 0.4]], gres: [['round', 0.5], ['pebble', 0.5]],
  calcaire: [['block', 1]], quartzite: [['angular', 1]], granite: [['boulder', 1]],
  ardoise: [['slab', 0.6], ['plate', 0.4]], calcrecif: [['block', 0.6], ['round', 0.4]], gresrouge: [['round', 0.55], ['pebble', 0.45]],
  houiller: [['slab', 0.6], ['plate', 0.4]], marne: [['block', 0.7], ['round', 0.3]], craie: [['block', 0.6], ['round', 0.4]],
  schistebit: [['plate', 0.6], ['slab', 0.4]], falun: [['round', 0.6], ['pebble', 0.4]], loess: [['round', 0.7], ['pebble', 0.3]],
  basalte: [['boulder', 0.6], ['angular', 0.4]]
};
/* roches à nodules : quand la pierre cache un fossile, elle sort plus souvent en nodule [avec fossile, sans] */
const NODULES = { calcaire: [0.6, 0.35], marne: [0.5, 0.28], loess: [0.42, 0.24] };
function pickShape(rockId, rnd, fossilBias) {
  const nd = NODULES[rockId];
  if (nd && rnd() < (fossilBias ? nd[0] : nd[1])) return 'nodule';
  let r = rnd();
  for (const [sh, w] of STONE_SHAPES[rockId]) { if ((r -= w) <= 0) return sh; }
  return STONE_SHAPES[rockId][0][0];
}
function pointInPoly(pts, p) {
  let ins = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const a = pts[i], b = pts[j];
    if ((a[1] > p[1]) !== (b[1] > p[1]) && p[0] < (b[0] - a[0]) * (p[1] - a[1]) / (b[1] - a[1]) + a[0]) ins = !ins;
  }
  return ins;
}
function distToPolyline(pts, p) {
  let best = 1e9;
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i], b = pts[i + 1], dx = b[0] - a[0], dy = b[1] - a[1], L = dx * dx + dy * dy || 1;
    const t = clamp(((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L, 0, 1);
    best = Math.min(best, Math.hypot(a[0] + dx * t - p[0], a[1] + dy * t - p[1]));
  }
  return best;
}
function stoneGeom(rockId, seed, opt) {
  opt = opt || {};
  const rnd = mulberry32(seed), sd = Math.floor(rnd() * 900) + 7, cx = 100;
  const shape = opt.shape || pickShape(rockId, rnd, false);
  let cy = 80, side = 0, pts = [], rx = 78, ry = 60;
  const bump = (a, amp, fq) => 1 + (fbm(Math.cos(a) * fq + 5, Math.sin(a) * fq + 9, sd, 3) - 0.5) * 2 * amp;
  const sup = (a, X, Y, e) => { const c = Math.cos(a), s = Math.sin(a); return [Math.sign(c) * Math.pow(Math.abs(c), 2 / e) * X, Math.sign(s) * Math.pow(Math.abs(s), 2 / e) * Y]; };
  const rot = (rnd() - 0.5) * 0.3;
  const ring = (X, Y, e, amp, fq, n, r0) => { rx = X; ry = Y; for (let i = 0; i < n; i++) { const a = i / n * TAU, b = bump(a, amp, fq), q = sup(a, X, Y, e); pts.push(rotPt([cx + q[0] * b, cy + q[1] * b], [cx, cy], r0)); } };
  let fr = rot;
  switch (shape) {
    case 'slab': cy = 68; side = 17; fr = rot * 0.3; ring(88, 42, 2.7, 0.05, 1.3, 44, fr); break;
    case 'plate': cy = 72; side = 9; fr = rot * 0.3; ring(92, 36, 3.1, 0.07, 1.7, 44, fr); break;
    case 'round': ring(78, 60, 2, 0.07, 1.1, 40, rot); break;
    case 'pebble': fr = rot * 0.7; ring(88, 46, 2, 0.05, 0.9, 40, fr); break;
    case 'boulder': ring(76, 64, 2.2, 0.06, 1.8, 40, rot); break;
    case 'block': fr = rot * 0.5; ring(84, 56, 3.4, 0.04, 1.2, 44, fr); break;
    case 'nodule': fr = rot * 0.6; ring(80, 57, 2, 0.02, 0.7, 40, fr); break;
    case 'angular': {
      rx = 80; ry = 66;
      for (let i = 0; i < 8; i++) { const a = (i + 0.5) / 8 * TAU + (rnd() - 0.5) * 0.4, r = 70 + rnd() * 14; pts.push(rotPt([cx + Math.cos(a) * r * 1.14, cy + Math.sin(a) * r * 0.9], [cx, cy], rot)); }
      break;
    }
  }
  const angular = shape === 'angular';
  const d = angular ? polyD(pts, true) : smoothD(pts, true);
  /* fil de la roche : le plan selon lequel la pierre se fend proprement */
  let fil = null, filAng = fr;
  const across = (off, ang, curve) => {
    const o = [], c = Math.cos(ang), s2 = Math.sin(ang);
    filAng = ang;
    for (let i = 0; i <= 18; i++) { const t = i / 18 - 0.5, x = t * 2 * rx * 1.05, y = off + curve * (1 - 4 * t * t); o.push([cx + x * c - y * s2, cy + x * s2 + y * c]); }
    return o;
  };
  if (shape === 'nodule') fil = across((rnd() - 0.5) * ry * 0.25, fr, ry * 0.2);
  else if (shape === 'slab' || shape === 'plate') fil = across((rnd() - 0.5) * ry * 0.95, fr + (rnd() - 0.5) * 0.06, (rnd() - 0.5) * 4);
  else if (shape === 'block') fil = across((rnd() - 0.5) * ry * 0.85, fr + (rnd() - 0.5) * 0.05, (rnd() - 0.5) * 6);
  else if (shape === 'round' || shape === 'pebble') fil = across((rnd() - 0.5) * ry * 0.8, fr + (rnd() - 0.5) * 0.9, (rnd() - 0.5) * 12);
  if (fil) fil = fil.filter(q => pointInPoly(pts, q) || distToPolyline(pts.concat([pts[0]]), q) < 3);
  if (fil && fil.length < 4) fil = null;
  /* filAng : direction des feuillets (le fil les suit, les fausses fissures les coupent) */
  return { rockId, shape, W: 200, H: 160, cx, cy, rx, ry, pts, d, side, angular, sd, rot: fr, filAng, fil, seed };
}
function stoneTexture(g, S, rnd) {
  const tex = ROCKS[g.rockId].tex;
  let s = '';
  if (g.shape === 'nodule') {
    let r = '';
    for (let k = 1; k <= 4; k++) { const f = 1 - k * 0.17; r += E.el(g.cx + 4, g.cy + 3, g.rx * f, g.ry * f, g.rot / D2R, null, S.tex, 0.8, 'opacity="' + (0.14 + k * 0.03) + '"'); }
    let po = ''; for (let i = 0; i < 40; i++) po += 'M' + r1(g.cx + (rnd() - 0.5) * g.rx * 1.8) + ' ' + r1(g.cy + (rnd() - 0.5) * g.ry * 1.8) + 'h0';
    return r + E.p(po, null, S.tex, 1.4, 'opacity=".3"');
  }
  if (tex === 'foliation') {
    let l = '';
    for (let k = -6; k <= 6; k++) {
      const y0 = g.cy + k * (g.shape === 'plate' ? 6 : 7.2);
      let seg = '', on = true;
      for (let x = 4; x <= 196; x += 6) {
        const y = y0 + Math.sin(x * 0.045 + k * 0.7) * 1.6 + (fbm(x * 0.05, k, g.sd, 2) - 0.5) * 3 + (x - 100) * Math.tan(g.rot);
        if (rnd() < 0.08) on = !on;
        seg += (on ? (seg ? 'L' : 'M') : 'M') + r1(x) + ' ' + r1(y);
      }
      l += seg;
    }
    s += E.p(l, null, S.tex, 1, 'opacity=".34"');
  } else if (tex === 'grain') {
    let a = '', b = '';
    for (let i = 0; i < 320; i++) { const x = rnd() * 200, y = rnd() * 160; if (rnd() < 0.7) a += 'M' + r1(x) + ' ' + r1(y) + 'h0'; else b += 'M' + r1(x) + ' ' + r1(y) + 'h0'; }
    s += E.p(a, null, S.tex, 1.3, 'opacity=".45"') + E.p(b, null, S.light, 2, 'opacity=".55"');
  } else if (tex === 'blocks') {
    s += E.p('M' + r1(g.cx + 24) + ' ' + r1(g.cy - 16) + 'L' + r1(g.cx + 20) + ' ' + r1(g.cy + 16) + 'M' + r1(g.cx - 40) + ' ' + r1(g.cy + 17) + 'L' + r1(g.cx - 44) + ' ' + r1(g.cy + 60), null, S.tex, 0.9, 'opacity=".18"');
    let sh = '';
    for (let i = 0; i < 14; i++) { const x = 30 + rnd() * 140, y = g.cy - 40 + rnd() * 80; sh += 'M' + r1(x) + ' ' + r1(y) + 'q2.5 -2.5 5 0'; }
    s += E.p(sh, null, S.tex, 0.9, 'opacity=".4"');
    let po = ''; for (let i = 0; i < 60; i++) po += 'M' + r1(rnd() * 200) + ' ' + r1(rnd() * 160) + 'h0';
    s += E.p(po, null, S.tex, 1.2, 'opacity=".3"');
  } else if (tex === 'speckle') {
    let k = '', w = '', p = '';
    for (let i = 0; i < 170; i++) k += 'M' + r1(rnd() * 200) + ' ' + r1(rnd() * 160) + 'l' + r1(rnd() * 2.4) + ' ' + r1(rnd() * 1.6);
    for (let i = 0; i < 110; i++) w += 'M' + r1(rnd() * 200) + ' ' + r1(rnd() * 160) + 'l' + r1(rnd() * 2) + ' ' + r1(rnd() * 1.2);
    for (let i = 0; i < 46; i++) p += E.el(rnd() * 200, rnd() * 160, 2.4 + rnd() * 2.6, 1.6 + rnd() * 1.8, rnd() * 180, '#cc9a8c', null, 0, 'opacity=".75"');
    s += p + E.p(k, null, S.tex, 3.2, 'opacity=".8"') + E.p(w, null, '#f6f3ee', 3, 'opacity=".9"');
  } else if (tex === 'fracture') {
    let f = '';
    for (let i = 0; i < 4; i++) { const x = 30 + rnd() * 140, y = 30 + rnd() * 100; f += 'M' + r1(x) + ' ' + r1(y) + 'l' + r1(10 + rnd() * 14) + ' ' + r1(4 + rnd() * 8) + 'l' + r1(4 + rnd() * 8) + ' ' + r1(8 + rnd() * 6); }
    s += E.p(f, null, S.tex, 0.9, 'opacity=".55"');
    let gl = '';
    for (let i = 0; i < 6; i++) { const x = 40 + rnd() * 120, y = 35 + rnd() * 90; gl += 'M' + r1(x - 2.5) + ' ' + r1(y) + 'h5M' + r1(x) + ' ' + r1(y - 2.5) + 'v5'; }
    s += E.p(gl, null, '#ffffff', 1.1, 'opacity=".9"');
  } else if (tex === 'reef') {
    /* calcaire récifal : amas de petits coraux en anneaux */
    let rings = '', dots = '';
    for (let c = 0; c < 5; c++) {
      const cc = stonePoint(g, rnd, 16);
      for (let i = 0; i < 7; i++) { const a = rnd() * TAU, d = rnd() * 11, x = cc[0] + Math.cos(a) * d, y = cc[1] + Math.sin(a) * d * 0.8, r = 1.8 + rnd() * 1.8; rings += 'M' + r1(x + r) + ' ' + r1(y) + 'a' + r1(r) + ' ' + r1(r) + ' 0 1 0 ' + r1(-2 * r) + ' 0a' + r1(r) + ' ' + r1(r) + ' 0 1 0 ' + r1(2 * r) + ' 0'; }
    }
    for (let i = 0; i < 70; i++) dots += 'M' + r1(rnd() * 200) + ' ' + r1(rnd() * 160) + 'h0';
    s += E.p(dots, null, S.tex, 1.2, 'opacity=".3"') + E.p(rings, null, S.tex, 0.9, 'opacity=".55"');
  } else if (tex === 'coal') {
    /* schiste houiller : lamines, filets de charbon brillants, diaclases courtes */
    const c = Math.cos(g.filAng), sn = Math.sin(g.filAng);
    let lam = '', glint = '', cleat = '';
    for (let k = -8; k <= 8; k++) {
      const off = k * 6.2 + (rnd() - 0.5) * 2;
      let seg = '', on = rnd() < 0.6;
      for (let x = -110; x <= 110; x += 10) { const y = off + (fbm((x + 200) * 0.02, k, g.sd, 2) - 0.5) * 3, q = [g.cx + x * c - y * sn, g.cy + x * sn + y * c]; if (rnd() < 0.15) on = !on; seg += (on ? (seg ? 'L' : 'M') : 'M') + PS(q); }
      lam += seg;
      if (rnd() < 0.3) { const x0 = -60 + rnd() * 100, y = off - 1.2, L = 14 + rnd() * 20; glint += 'M' + PS([g.cx + x0 * c - y * sn, g.cy + x0 * sn + y * c]) + 'l' + r1(c * L) + ' ' + r1(sn * L); }
    }
    for (let i = 0; i < 16; i++) { const p0 = stonePoint(g, rnd, 8), L = 4 + rnd() * 6; cleat += 'M' + PS(p0) + 'l' + r1(-sn * L) + ' ' + r1(c * L); }
    s += E.p(lam, null, S.tex, 1.1, 'opacity=".55"') + E.p(glint, null, S.light, 1.3, 'opacity=".7"') + E.p(cleat, null, S.tex, 0.8, 'opacity=".45"');
  } else if (tex === 'chalk') {
    /* craie : pâte blanche, rognons de silex alignés dans un banc */
    const c = Math.cos(g.filAng), sn = Math.sin(g.filAng), band = (rnd() - 0.5) * g.ry * 0.9;
    let fl = '', po = '';
    for (let i = 0, n = 3 + Math.floor(rnd() * 2); i < n; i++) {
      const x = (rnd() - 0.5) * g.rx * 1.5, y = band + (rnd() - 0.5) * 10, p0 = [g.cx + x * c - y * sn, g.cy + x * sn + y * c];
      if (pointInPoly(g.pts, p0)) fl += blob(p0, 6 + rnd() * 6, rnd, 9);
    }
    for (let i = 0; i < 50; i++) po += 'M' + r1(rnd() * 200) + ' ' + r1(rnd() * 160) + 'h0';
    s += E.p(po, null, S.tex, 1.1, 'opacity=".25"') + E.p(fl, null, '#fbfaf6', 3.2, 'opacity=".8"') + E.p(fl, '#55565a', '#2c2c2f', 0.9, 'opacity=".88"');
  } else if (tex === 'shells') {
    /* falun : débris de coquilles */
    let sh = '', dots = '';
    for (let i = 0; i < 22; i++) {
      const p0 = stonePoint(g, rnd, 8), r = 2.5 + rnd() * 4, a0 = rnd() * TAU;
      sh += 'M' + r1(p0[0] + Math.cos(a0) * r) + ' ' + r1(p0[1] + Math.sin(a0) * r) + 'A' + r1(r) + ' ' + r1(r * 0.8) + ' 0 0 1 ' + r1(p0[0] + Math.cos(a0 + 2.4) * r) + ' ' + r1(p0[1] + Math.sin(a0 + 2.4) * r);
      if (rnd() < 0.4) sh += 'M' + PS(p0) + 'l' + r1(Math.cos(a0 + 1.2) * r * 0.8) + ' ' + r1(Math.sin(a0 + 1.2) * r * 0.8);
    }
    for (let i = 0; i < 200; i++) dots += 'M' + r1(rnd() * 200) + ' ' + r1(rnd() * 160) + 'h0';
    s += E.p(dots, null, S.tex, 1.2, 'opacity=".35"') + E.p(sh, null, S.light, 2.4, 'opacity=".8"') + E.p(sh, null, S.tex, 0.9, 'opacity=".7"');
  } else if (tex === 'vesicle') {
    /* basalte : bulles de gaz figées, joints de prismes */
    let ho = '', lip = '', jt = '';
    for (let i = 0; i < 26; i++) {
      const x = rnd() * 200, y = rnd() * 160, rx = 1 + rnd() * 2.6, ry = rx * (0.6 + rnd() * 0.3);
      ho += E.el(x, y, rx, ry, rnd() * 40 - 20, S.tex, null);
      lip += 'M' + r1(x - rx) + ' ' + r1(y + ry * 0.4) + 'Q' + r1(x) + ' ' + r1(y + ry * 1.5) + ' ' + r1(x + rx) + ' ' + r1(y + ry * 0.4);
    }
    for (let i = 0; i < 3; i++) { let q = stonePoint(g, rnd, 20), d = 'M' + PS(q); for (let k = 0; k < 3; k++) { const a = rnd() * TAU; q = [q[0] + Math.cos(a) * 18, q[1] + Math.sin(a) * 14]; d += 'L' + PS(q); } jt += d; }
    s += ho + E.p(lip, null, S.light, 1, 'opacity=".6"') + E.p(jt, null, S.tex, 0.9, 'opacity=".4"');
  }
  if (ROCKS[g.rockId].bedded && tex !== 'foliation' && tex !== 'coal') s += litageSVG(g, S, rnd);
  return s;
}
/* litage discret : bandes et fines lignes dans le sens des feuillets (grès, calcaire) */
function litageSVG(g, S, rnd) {
  const a = g.filAng, c = Math.cos(a), sn = Math.sin(a), step = 8.5 + rnd() * 3;
  let light = '', dark = '', lines = '';
  for (let k = -9; k <= 9; k++) {
    const off = k * step + (rnd() - 0.5) * 2.5, pts = [];
    for (let x = -112; x <= 112; x += 8) {
      const y = off + (fbm((x + 300) * 0.018, k * 1.7 + 3, g.sd, 2) - 0.5) * (g.shape === 'nodule' ? 2 : 4.5);
      pts.push([g.cx + x * c - y * sn, g.cy + x * sn + y * c]);
    }
    const d = polyD(pts);
    if (k % 2) dark += d; else light += d;
    let seg = '', on = rnd() < 0.7;
    pts.forEach((q, i) => { if (rnd() < 0.12) on = !on; seg += (on ? (i && seg ? 'L' : 'M') : 'M') + PS(q); });
    lines += seg;
  }
  if (g.shape === 'nodule') return E.p(lines, null, S.tex, 0.6, 'opacity=".12"');
  return E.p(light, null, S.light, step * 0.5, 'opacity=".13"') + E.p(dark, null, S.shade, step * 0.42, 'opacity=".1"') + E.p(lines, null, S.tex, 0.7, 'opacity=".24"');
}
/* point au hasard dans la pierre, à l'écart des bords */
function stonePoint(g, rnd, margin) {
  for (let k = 0; k < 30; k++) {
    const p = [g.cx + (rnd() - 0.5) * g.rx * 1.5, g.cy + (rnd() - 0.5) * g.ry * 1.4];
    if (pointInPoly(g.pts, p) && distToPolyline(g.pts.concat([g.pts[0]]), p) > (margin || 14)) return p;
  }
  return [g.cx, g.cy];
}
function blob(c, r, rnd, n) { const o = []; for (let i = 0; i < (n || 11); i++) { const a = i / (n || 11) * TAU, rr = r * (0.72 + rnd() * 0.5); o.push([c[0] + Math.cos(a) * rr, c[1] + Math.sin(a) * rr * 0.8]); } return smoothD(o, true); }
function star(c, L) { return 'M' + r1(c[0] - L) + ' ' + r1(c[1]) + 'h' + r1(2 * L) + 'M' + r1(c[0]) + ' ' + r1(c[1] - L) + 'v' + r1(2 * L); }
/* détails sans signification : lichen, terre, piqûres (tout ne doit pas être un indice) */
function neutralSVG(g, S, rnd, calm) {
  let s = '';
  const k = calm ? 0.45 : 1;
  if (rnd() < 0.5 * k) {
    const c = stonePoint(g, rnd, 10); let ro = '';
    for (let i = 0; i < 7; i++) { const a = rnd() * TAU, d = rnd() * 7; ro += E.c(c[0] + Math.cos(a) * d, c[1] + Math.sin(a) * d * 0.8, 2.2 + rnd() * 2.6, '#c4caa9', null, 0, 'opacity=".85"'); }
    s += ro + E.p(star(c, 0.1), null, '#7f8866', 2.2);
  }
  if (rnd() < 0.45 * k) { let sm = ''; for (let i = 0; i < 3; i++) { const c = stonePoint(g, rnd, 8), a = rnd() * Math.PI, L = 5 + rnd() * 7; sm += 'M' + r1(c[0]) + ' ' + r1(c[1]) + 'l' + r1(Math.cos(a) * L) + ' ' + r1(Math.sin(a) * L); } s += E.p(sm, null, 'rgba(96,70,44,.3)', 2.2); }
  if (rnd() < 0.4 * k) { let p = ''; for (let i = 0; i < 5; i++) { const c = stonePoint(g, rnd, 8); p += 'M' + r1(c[0]) + ' ' + r1(c[1]) + 'h.1'; } s += E.p(p, null, S.shade, 2.6, 'opacity=".6"'); }
  return s;
}
/* indices liés au contenu (probabilistes, tirés dans game.js) */
function tellSVG(g, t, S, rnd, uid) {
  if (t.k === 'veine') {
    const O = ORES[t.ore];
    let pts = t.pts;
    if (!pts) {
      const c = stonePoint(g, rnd, 16), a = rnd() * Math.PI, L = g.rx * (0.5 + rnd() * 0.3); pts = [];
      for (let i = 0; i <= 8; i++) { const u = (i / 8 - 0.5) * L; pts.push([c[0] + Math.cos(a) * u + (rnd() - 0.5) * 5, c[1] + Math.sin(a) * u + (rnd() - 0.5) * 5]); }
    }
    let gl = ''; [2, 5].forEach(i => { gl += star(pts[i], 2.6); });
    return E.p(polyD(pts), null, O.dark, 3.6, 'opacity=".5"') + E.p(polyD(pts), null, O.color, 1.9) + E.p(gl, null, '#fffbe8', 1);
  }
  if (t.k === 'reflets') {
    const O = ORES[t.ore]; let gl = '', dots = '';
    const c = t.at || stonePoint(g, rnd, 18);
    for (let i = 0; i < 6; i++) { const p = [c[0] + (rnd() - 0.5) * 34, c[1] + (rnd() - 0.5) * 24]; if (!pointInPoly(g.pts, p)) continue; if (i < 3) gl += star(p, 2 + rnd() * 1.6); dots += 'M' + r1(p[0]) + ' ' + r1(p[1]) + 'h.1'; }
    return E.p(dots, null, O.color, 2.6) + E.p(gl, null, O.hi, 1.1);
  }
  if (t.k === 'bosse') {
    const c = t.at || stonePoint(g, rnd, 22), R = 15 + rnd() * 7, ang = rnd() * 180;
    return E.el(c[0], c[1], R, R * 0.72, ang, S.light, null, 0, 'opacity=".32"') +
      E.p('M' + r1(c[0] - R * 0.8) + ' ' + r1(c[1] + R * 0.1) + 'Q' + r1(c[0] - R * 0.6) + ' ' + r1(c[1] - R * 0.75) + ' ' + r1(c[0] + R * 0.25) + ' ' + r1(c[1] - R * 0.6), null, S.light, 2.4, 'opacity=".9"') +
      E.p('M' + r1(c[0] + R * 0.85) + ' ' + r1(c[1] - R * 0.1) + 'Q' + r1(c[0] + R * 0.6) + ' ' + r1(c[1] + R * 0.75) + ' ' + r1(c[0] - R * 0.25) + ' ' + r1(c[1] + R * 0.6), null, S.shade, 2.4, 'opacity=".7"');
  }
  if (t.k === 'tache') {
    const c = t.at || stonePoint(g, rnd, 18), R = 13 + rnd() * 7;
    const d0 = blob(c, R, rnd);
    return E.p(d0, S.shade, null, 0, 'opacity=".26"') + E.p(d0, null, '#4a3218', 2.6, 'opacity=".38"') + E.p(blob(c, R * 0.5, rnd), '#3b2a18', null, 0, 'opacity=".18"');
  }
  if (t.k === 'dendrite') {
    /* dendrite de manganèse : de fines ramures noires en éventail, comme une fougère… qui n'en est pas une */
    const c = t.at || stonePoint(g, rnd, 20), a0 = rnd() * TAU, segs = ['', '', ''];
    const br = (p, a, L, d) => {
      const q = [p[0] + Math.cos(a) * L, p[1] + Math.sin(a) * L * 0.85];
      segs[d >= 3 ? 0 : d === 2 ? 1 : 2] += 'M' + PS(p) + 'L' + PS(q);
      if (d > 0) { const n = rnd() < 0.3 ? 3 : 2; for (let i = 0; i < n; i++) br(q, a + (i - (n - 1) / 2) * (0.55 + rnd() * 0.25) + (rnd() - 0.5) * 0.3, L * (0.62 + rnd() * 0.12), d - 1); }
    };
    for (let k = 0; k < 3; k++) br(c, a0 + (k - 1) * 0.5 + (rnd() - 0.5) * 0.2, 9 + rnd() * 4, 3);
    return E.p(segs[0], null, '#23180f', 1.5, 'opacity=".85"') + E.p(segs[1], null, '#23180f', 1, 'opacity=".8"') + E.p(segs[2], null, '#23180f', 0.6, 'opacity=".75"');
  }
  if (t.k === 'concretion') {
    /* concrétion : une boule cerclée, qu'on prend pour un os ou un œuf */
    const c = t.at || stonePoint(g, rnd, 20), R = 9 + rnd() * 4, ang = rnd() * 180, e = 0.7 + rnd() * 0.2;
    let o = E.el(c[0] + 1.5, c[1] + 2, R, R * e, ang, S.shade, null, 0, 'opacity=".45"') + E.el(c[0], c[1], R, R * e, ang, S.light, S.ink, 1, 'stroke-opacity=".5"');
    for (let k = 1; k <= 2; k++) o += E.el(c[0], c[1], R * (1 - k * 0.3), R * e * (1 - k * 0.3), ang, null, S.tex, 0.8, 'opacity=".55"');
    return o + E.p('M' + r1(c[0] - R * 0.55) + ' ' + r1(c[1] - R * e * 0.3) + 'q' + r1(R * 0.3) + ' ' + r1(-R * e * 0.45) + ' ' + r1(R * 0.7) + ' ' + r1(-R * e * 0.35), null, '#fffaf0', 1.4, 'opacity=".7"');
  }
  if (t.k === 'pyrite') {
    /* pyrite, l'or des fous : de petits cubes dorés, bien carrés */
    const c = t.at || stonePoint(g, rnd, 16), n = 4 + Math.floor(rnd() * 4);
    let cubes = '', glint = '';
    for (let i = 0; i < n; i++) {
      const p = [c[0] + (rnd() - 0.5) * 22, c[1] + (rnd() - 0.5) * 15], s2 = 1.6 + rnd() * 2.2, a = rnd() * 90;
      if (!pointInPoly(g.pts, p)) continue;
      cubes += '<rect x="' + r1(p[0] - s2) + '" y="' + r1(p[1] - s2) + '" width="' + r1(2 * s2) + '" height="' + r1(2 * s2) + '" transform="rotate(' + r1(a) + ' ' + r1(p[0]) + ' ' + r1(p[1]) + ')" fill="#c9a332" stroke="#6e5410" stroke-width=".7"/>';
      if (i < 2) glint += star([p[0] - s2 * 0.3, p[1] - s2 * 0.4], 1.6);
    }
    return cubes + E.p(glint, null, '#fff6c8', 0.9);
  }
  if (t.k === 'affleure' && t.fid) {
    const A = ART[t.fid], [W, H] = A.vb, c = t.at || stonePoint(g, rnd, 20), R = 14, k = (R * 3.2) / Math.max(W, H);
    const fx = A.area.cx + (rnd() - 0.5) * A.area.rx * 0.8, fy = A.area.cy + (rnd() - 0.5) * A.area.ry * 0.8;
    return '<clipPath id="' + uid + 'a"><ellipse cx="' + r1(c[0]) + '" cy="' + r1(c[1]) + '" rx="' + R + '" ry="' + r1(R * 0.75) + '"/></clipPath>' +
      E.el(c[0], c[1], R + 1.5, R * 0.75 + 1.5, 0, S.shade, null, 0, 'opacity=".5"') +
      '<g clip-path="url(#' + uid + 'a)"><rect x="' + r1(c[0] - R) + '" y="' + r1(c[1] - R) + '" width="' + 2 * R + '" height="' + 2 * R + '" fill="' + S.face + '"/>' +
      '<g opacity=".85" transform="translate(' + r1(c[0] - fx * k) + ' ' + r1(c[1] - fy * k) + ') scale(' + k.toFixed(3) + ')">' + fUse(t.fid) + '</g></g>' +
      E.el(c[0], c[1], R, R * 0.75, 0, null, S.ink, 1, 'opacity=".55"');
  }
  return '';
}
/* ---------- fissures : le fil, la veine, les fausses fissures ---------- */
/* micro-craquelures le long d'une fissure (p : proportion de sommets qui en portent) */
function microCracks(f, rnd, p) {
  let micro = '';
  for (let i = 1; i < f.length - 1; i++) {
    if (rnd() > p) continue;
    const t = tangentAt(f, i), n = [-t[1], t[0]], sd = rnd() < 0.5 ? -1 : 1, L = 2.5 + rnd() * 4;
    const a = [f[i][0] + n[0] * sd * 0.8, f[i][1] + n[1] * sd * 0.8];
    micro += 'M' + PS(a) + 'l' + r1((n[0] * sd * 0.8 + t[0] * (rnd() - 0.5)) * L) + ' ' + r1((n[1] * sd * 0.8 + t[1] * (rnd() - 0.5)) * L);
  }
  return micro;
}
/* le fil : une fine fissure bordée de micro-craquelures, d'un bord à l'autre, dans le sens des feuillets */
/* fv : aspect du fil — net ; discret (fin et pâle) ; discontinu (des tronçons à relier du regard) ;
   voile (en partie sous le lichen ou la terre). La loupe rend du contraste et referme les trous. */
function filSVG(g, S, rnd, fv, loupe) {
  const f = g.fil, lip = f.map(q => [q[0] + 0.9, q[1] + 1.1]), L = loupe || 0;
  const net = a => E.p(polyD(lip), null, S.light, 1.3, 'opacity="' + (0.75 * a).toFixed(2) + '"') + E.p(polyD(f), null, S.ink, 1.2, 'opacity="' + (0.85 * a).toFixed(2) + '"') + E.p(microCracks(f, rnd, 0.55), null, S.ink, 0.7, 'opacity="' + (0.75 * a).toFixed(2) + '"');
  if (fv === 'discret') {
    const a = Math.min(0.92, 0.48 + 0.14 * L);
    return E.p(polyD(lip), null, S.light, 0.9, 'opacity="' + (a * 0.6).toFixed(2) + '"') + E.p(polyD(f), null, S.ink, 0.95, 'opacity="' + a.toFixed(2) + '"') + E.p(microCracks(f, rnd, 0.12), null, S.ink, 0.6, 'opacity="' + (a * 0.8).toFixed(2) + '"');
  }
  if (fv === 'discontinu') {
    const len = arcLen(f), dash = [];
    for (let acc = 0; acc < len + 40;) { const on = 11 + rnd() * 15, off = (10 + rnd() * 13) * (1 - 0.22 * L); dash.push(r1(on), r1(off)); acc += on + off; }
    const da = 'stroke-dasharray="' + dash.join(' ') + '" stroke-dashoffset="' + r1(rnd() * 12) + '"';
    return E.p(polyD(lip), null, S.light, 1.3, 'opacity=".7" ' + da) + E.p(polyD(f), null, S.ink, 1.2, 'opacity=".85" ' + da);
  }
  if (fv === 'voile') {
    let o = net(0.9);
    const n = 2 + (rnd() < 0.45 ? 1 : 0), used = [];
    for (let k = 0; k < n; k++) {
      let i = 0;
      for (let t = 0; t < 8; t++) { i = Math.floor(f.length * (0.12 + rnd() * 0.76)); if (used.every(u => Math.abs(u - i) > 3)) break; }
      used.push(i);
      const c = f[i], R = (8 + rnd() * 5) * (1 - 0.12 * L);
      if (rnd() < 0.55) {
        let ro = '', dots = '';
        for (let j = 0; j < 9; j++) { const a = rnd() * TAU, d = rnd() * R * 0.7; ro += E.c(c[0] + Math.cos(a) * d, c[1] + Math.sin(a) * d * 0.8, R * (0.28 + rnd() * 0.22), '#bfc79f', null, 0, 'opacity=".95"'); }
        for (let j = 0; j < 6; j++) { const a = rnd() * TAU, d = rnd() * R * 0.6; dots += 'M' + r1(c[0] + Math.cos(a) * d) + ' ' + r1(c[1] + Math.sin(a) * d * 0.8) + 'h.1'; }
        o += ro + E.p(dots, null, '#7f8866', 2);
      } else {
        o += E.p(blob(c, R, rnd, 10), '#8a6a45', null, 0, 'opacity=".92"') + E.p(blob([c[0] - 1, c[1] - 1.5], R * 0.55, rnd, 8), '#a88660', null, 0, 'opacity=".8"');
      }
    }
    return o;
  }
  return net(1);
}
/* fausse fissure. lis = 1 : béante, sombre, auréolée de rouille ; lis = 0 : même trait que le fil,
   seules sa direction (en travers des feuillets) et sa fin en pointe la trahissent */
function decoySVG(f, S, lis, rnd) {
  const d = clamp(lis, 0, 1), lip = f.map(q => [q[0] + 0.9, q[1] + 1.1]);
  let s = '';
  if (d > 0.04) s += E.p(polyD(f), null, '#98511f', 2 + 7 * d, 'opacity="' + (0.3 * d).toFixed(2) + '"');
  s += E.p(polyD(lip), null, S.light, 1.3, 'opacity="' + (0.75 - 0.25 * d).toFixed(2) + '"');
  s += E.p(polyD(taperPts(f, 1.2 + 3.6 * d, 0.5), true), mixHex(S.ink, '#0d0703', 0.6 * d), null, 0, 'opacity="' + (0.85 + 0.15 * d).toFixed(2) + '"');
  s += E.p(microCracks(f, rnd, 0.55 * (1 - d)), null, S.ink, 0.7, 'opacity=".75"');
  return s;
}
/* point près du fil : le fossile repose sur le plan du fil, ses indices affleurent le long */
function nearFil(g, rnd, off, margin) {
  const f = g.fil, ring = g.pts.concat([g.pts[0]]);
  for (let k = 0; k < 24; k++) {
    const i = Math.floor(f.length * (0.22 + rnd() * 0.56)), t = tangentAt(f, i), sd = rnd() < 0.5 ? -1 : 1, o = off[0] + rnd() * (off[1] - off[0]);
    const p = [f[i][0] - t[1] * o * sd, f[i][1] + t[0] * o * sd];
    if (pointInPoly(g.pts, p) && distToPolyline(ring, p) > margin) return p;
  }
  return null;
}
/* veine de minerai : coupe les feuillets en biais (35° à 87°) */
function veinPath(g, rnd) {
  let best = null;
  for (let k = 0; k < 30; k++) {
    const c = stonePoint(g, rnd, 16), ang = g.filAng + (rnd() < 0.5 ? -1 : 1) * (0.62 + rnd() * 0.9), L = g.rx * (0.55 + rnd() * 0.3), pts = [];
    for (let i = 0; i <= 8; i++) { const u = (i / 8 - 0.5) * L; pts.push([c[0] + Math.cos(ang) * u + (rnd() - 0.5) * 5, c[1] + Math.sin(ang) * u + (rnd() - 0.5) * 5]); }
    const inside = pts.filter(q => pointInPoly(g.pts, q)).length;
    if (inside >= 8) return pts;
    if (!best || inside > best.n) best = { pts, n: inside };
  }
  return best.pts;
}
/* fausse fissure : part d'un bord, coupe les feuillets en travers et s'éteint avant d'atteindre le fil */
function decoyPath(g, rnd, avoid, hard) {
  const sx = Math.cos(g.filAng), sy = Math.sin(g.filAng), h = hard || 0;
  for (let k = 0; k < 60; k++) {
    const p0 = g.pts[Math.floor(rnd() * g.pts.length)];
    const toC = [g.cx - p0[0], g.cy - p0[1]], lc = Math.hypot(toC[0], toC[1]) || 1;
    let nx = -sy, ny = sx;
    if (nx * toC[0] + ny * toC[1] < 0) { nx = -nx; ny = -ny; }
    const a0 = Math.atan2(ny, nx) + (rnd() < 0.5 ? -1 : 1) * (0.08 + rnd() * (0.62 + 0.22 * h));
    if ((Math.cos(a0) * toC[0] + Math.sin(a0) * toC[1]) / lc < 0.4) continue;
    const maxL = 34 + rnd() * 34 + 22 * h, pts = [[p0[0] - Math.cos(a0) * 4, p0[1] - Math.sin(a0) * 4]];
    let q = pts[0], L = 0, ang = a0;
    while (L < maxL) {
      ang = lerp(ang + (rnd() - 0.5) * 0.34, a0, 0.18);
      const nq = [q[0] + Math.cos(ang) * 4, q[1] + Math.sin(ang) * 4];
      if (L > 6 && !pointInPoly(g.pts, nq)) break;
      if (avoid.some(A => distToPolyline(A.pts, nq) < A.gap)) break;
      pts.push(nq); q = nq; L += 4;
    }
    if (L >= 26) return pts;
  }
  return null;
}
/* place les indices et trace les fausses fissures (pur : même graine, même pierre).
   hard (0 à 1) : plus la lecture est difficile, plus les fausses fissures sont longues et obliques */
function stoneLayout(g, tells, nDecoy, rnd, hard) {
  const avoid = [];
  if (g.fil) avoid.push({ pts: g.fil, gap: 22 });
  tells.forEach(t => {
    if (t.k === 'veine') { t.pts = veinPath(g, rnd); avoid.push({ pts: t.pts, gap: 14 }); return; }
    const m = t.k === 'bosse' || t.k === 'dendrite' ? 22 : t.k === 'affleure' || t.k === 'concretion' ? 20 : 18;
    if (t.onFil && g.fil) t.at = nearFil(g, rnd, t.k === 'affleure' ? [7, 12] : [0, 6], m);
    if (!t.at) t.at = stonePoint(g, rnd, m);
    avoid.push({ pts: [t.at, t.at], gap: t.k === 'reflets' || t.k === 'pyrite' ? 12 : 17 });
  });
  const decoys = [];
  if (g.fil) for (let i = 0; i < nDecoy; i++) { const f = decoyPath(g, rnd, avoid, hard); if (!f) break; decoys.push(f); avoid.push({ pts: f, gap: 20 }); }
  return decoys;
}
function stoneExteriorSVG(g, uid, opt) {
  opt = opt || {};
  const S = ROCKS[g.rockId].stone, rnd = mulberry32(g.sd * 7 + 3), rnd2 = mulberry32(g.seed ^ 0x2f6b), rnd3 = mulberry32(g.seed ^ 0x6d1);
  let s = '<svg class="st-svg" viewBox="0 0 200 180" aria-hidden="true"><defs><clipPath id="' + uid + 'k"><path d="' + g.d + '"/></clipPath></defs>';
  s += E.p(g.d, S.shade);
  s += '<g clip-path="url(#' + uid + 'k)">';
  if (g.angular) {
    const I = [g.cx - 10, g.cy - 12], L = [-0.62, -0.78];
    g.pts.forEach((a, i) => {
      const b = g.pts[(i + 1) % g.pts.length];
      let nx = b[1] - a[1], ny = -(b[0] - a[0]); const nl = Math.hypot(nx, ny); nx /= nl; ny /= nl;
      const k = clamp((nx * L[0] + ny * L[1]) * 0.5 + 0.5, 0, 1);
      s += E.p(polyD([I, a, b], true), mixHex(S.shade, S.light, k), S.ink, 0.7, 'stroke-opacity=".35"');
    });
  } else {
    s += '<path d="' + g.d + '" fill="' + S.base + '" transform="translate(-7 -9)"/>';
    const px = g.cx - g.rx * 0.42, py = g.cy - g.ry * 0.4;
    s += '<path d="' + g.d + '" fill="' + S.light + '" opacity=".75" transform="translate(' + r1(px) + ' ' + r1(py) + ') scale(.42) translate(' + r1(-px) + ' ' + r1(-py) + ')"/>';
  }
  s += stoneTexture(g, S, rnd);
  s += neutralSVG(g, S, rnd2, opt.calm);
  /* les faux indices pâlissent sous la loupe */
  (opt.tells || []).forEach((t, i) => { const o = tellSVG(g, t, S, rnd2, uid + 't' + i); s += t.fake && opt.loupe ? '<g opacity="' + (1 - TELLS.loupe * opt.loupe).toFixed(2) + '">' + o + '</g>' : o; });
  (opt.decoys || []).forEach(f => { s += decoySVG(f, S, opt.lis == null ? 1 : opt.lis, rnd3); });
  if (opt.fil && g.fil) s += filSVG(g, S, rnd2, opt.fv, opt.loupe);
  s += '</g>';
  s += E.p(g.d, null, S.ink, 2.4);
  s += '<g class="cracks" clip-path="url(#' + uid + 'k)" stroke-linecap="round" stroke-linejoin="round"></g></svg>';
  return s;
}
/* fissure qui part du point frappé : le long du fil ou de la veine (coupe franche),
   le long d'une fausse fissure puis en travers de la pierre, ou en zigzag hors de toute fissure */
function crackSVG(g, P, hit, rnd) {
  const S = ROCKS[g.rockId].stone;
  const cr = (pts, cls, w) => '<path class="' + cls + '" d="' + polyD(pts) + '" fill="none" stroke="' + S.ink + '" stroke-width="' + w + '"/><path class="' + cls + '" d="' + polyD(pts.map(q => [q[0] + 1.4, q[1] + 1.1])) + '" fill="none" stroke="' + S.light + '" stroke-width="1" opacity=".8"/>';
  const dirTo = (a, b) => { const x = a[0] - b[0], y = a[1] - b[1], l = Math.hypot(x, y) || 1; return [x / l, y / l]; };
  const outward = (q, dir, jag) => { const o = [q]; let p = q; for (let i = 0; i < 40; i++) { p = [p[0] + dir[0] * 8 + (rnd() - 0.5) * jag, p[1] + dir[1] * 8 + (rnd() - 0.5) * jag]; o.push(p); if (i > 1 && !pointInPoly(g.pts, p)) break; } return o; };
  const nearest = f => { let k = 0, bd = 1e9; f.forEach((q, i) => { const dd = Math.hypot(q[0] - P[0], q[1] - P[1]); if (dd < bd) { bd = dd; k = i; } }); return k; };
  if (hit && (hit.k === 'fil' || hit.k === 'veine')) {
    const f = hit.pts, n = f.length, k = nearest(f), jag = hit.k === 'veine' ? 5 : 1.2, w = hit.k === 'veine' ? 2.2 : 2;
    const ext = (a, b) => { const o = []; for (let i = a; i <= b; i++) o.push(f[clamp(i, 0, n - 1)]); return o; };
    const tail0 = outward(f[0], dirTo(f[0], f[1]), jag), tail1 = outward(f[n - 1], dirTo(f[n - 1], f[n - 2]), jag);
    return cr([P].concat(ext(k - 2, k + 2)), 'c1', w) + cr(ext(k - 6, k + 6), 'c2', w) + cr(f, 'c3', w) + cr(tail0, 'c3', w) + cr(tail1, 'c3', w);
  }
  if (hit && hit.k === 'fausse') {
    const f = hit.pts, n = f.length, k = nearest(f), dir = dirTo(f[n - 1], f[Math.max(0, n - 3)]);
    const run = outward(f[n - 1], dir, 14), nx = -dir[1], ny = dir[0], m = run[Math.min(3, run.length - 1)], sg = rnd() < 0.5 ? -1 : 1;
    const br = [m, [m[0] + nx * sg * 22 + dir[0] * 8, m[1] + ny * sg * 22 + dir[1] * 8], [m[0] + nx * sg * 50 + dir[0] * 20 + (rnd() - 0.5) * 10, m[1] + ny * sg * 50 + dir[1] * 20 + (rnd() - 0.5) * 10], [m[0] + nx * sg * 95 + dir[0] * 30, m[1] + ny * sg * 95 + dir[1] * 30]];
    return cr([P].concat(f.slice(k)), 'c1', 2.4) + cr(f.slice(0, k + 1), 'c2', 2.4) + cr(run, 'c2', 2.4) + cr(br, 'c3', 2.4);
  }
  let dx = g.cx - P[0], dy = g.cy - P[1]; const L = Math.hypot(dx, dy);
  if (L < 6) { const a = rnd() * TAU; dx = Math.cos(a); dy = Math.sin(a); } else { dx /= L; dy /= L; }
  const main = [P];
  for (let i = 1; i <= 10; i++) main.push([P[0] + dx * i * 24 + (rnd() - 0.5) * 16, P[1] + dy * i * 24 + (rnd() - 0.5) * 16]);
  const nx = -dy, ny = dx;
  const br = (q, sg) => [q, [q[0] + nx * sg * 20 + dx * 10, q[1] + ny * sg * 20 + dy * 10], [q[0] + nx * sg * 46 + dx * 16 + (rnd() - 0.5) * 10, q[1] + ny * sg * 46 + dy * 16 + (rnd() - 0.5) * 10], [q[0] + nx * sg * 90 + dx * 30, q[1] + ny * sg * 90 + dy * 30]];
  return cr(main.slice(0, 4), 'c1', 2.4) + cr(main.slice(3, 8), 'c2', 2.4) + cr(br(main[3], 1), 'c2', 2.4) + cr(main.slice(7), 'c3', 2.4) + cr(br(main[6], -1), 'c3', 2.4);
}
/* croquis à la plume pour les notes de la conservatrice */
let SKN = 0;
function sketchSVG(kind) {
  const ink = '#2c3a66', rnd = mulberry32(hashStr(kind) + 11), id = 'sk' + (++SKN);
  const wob = (pts, a) => pts.map(p => [p[0] + (rnd() - 0.5) * a, p[1] + (rnd() - 0.5) * a]);
  const pen = (d, w, extra) => E.p(d, null, ink, w || 1.6, extra);
  const txt = (x, y, t, fs) => '<text x="' + x + '" y="' + y + '" font-family="Caveat, \'Segoe Print\', cursive" font-size="' + (fs || 12) + '" fill="' + ink + '" stroke="none">' + t + '</text>';
  const check = (x, y) => pen('M' + x + ' ' + y + 'l3.5 3.8 7.5-8.6', 2.2);
  const cross = (x, y) => pen('M' + x + ' ' + y + 'l7.5 7.5M' + (x + 7.5) + ' ' + y + 'l-7.5 7.5', 2.2);
  const outline = ellipsePts(50, 41, 40, 24, -0.05, 28), od = smoothD(wob(outline, 1.4), true);
  const inside = x => '<g clip-path="url(#' + id + ')">' + x + '</g>';
  const filD = polyD(wob(linePts([4, 43.5], [96, 38.5], 9), 0.7));
  let strata = '';
  for (let k = -3; k <= 3; k++) { if (!k) continue; const y = 41 + k * 6.4; strata += polyD(wob(linePts([4, y + 2.5], [96, y - 2.5], 8), 0.9)); }
  let s = '<svg class="sk" viewBox="0 0 100 80" aria-hidden="true"><defs><clipPath id="' + id + '"><path d="' + smoothD(outline, true) + '"/></clipPath></defs><g stroke-linecap="round" stroke-linejoin="round">';
  const base = pen(od, 1.8) + inside(pen(strata, 0.8, 'opacity=".42"'));
  if (kind === 'carnet') {
    const book = wob([[14, 22], [50, 16], [86, 22], [86, 66], [50, 60], [14, 66]], 0.8);
    let lines = ''; for (let k = 0; k < 5; k++) { lines += polyD(wob(linePts([20, 30 + k * 7], [45, 26 + k * 7], 4), 0.6)) + polyD(wob(linePts([56, 26 + k * 7], [80, 30 + k * 7], 4), 0.6)); }
    const ham = 'M60 58L78 36M72 31l9 8M69 34l6-6 9 8-6 6';
    s += pen(polyD(book, true), 1.8) + pen('M50 16V60', 1.4) + pen(lines, 0.8, 'opacity=".45"') + pen(smoothD(wob(ellipsePts(30, 58, 11, 7, 0.1, 12), 0.8), true), 1.6, 'fill="#fbf6e8"') + pen('M22 57l6 1.5 5-1 5 1', 1) + pen(ham, 2, 'fill="#fbf6e8"');
  } else if (kind === 'massive') {
    const poly = []; for (let i = 0; i < 8; i++) { const a = (i + 0.5) / 8 * TAU + (rnd() - 0.5) * 0.4, r = 26 + rnd() * 8; poly.push([50 + Math.cos(a) * r * 1.35, 41 + Math.sin(a) * r * 0.85]); }
    let dots = ''; for (let i = 0; i < 46; i++) { const p = [16 + rnd() * 68, 20 + rnd() * 42]; if (pointInPoly(poly, p)) dots += 'M' + PS(p) + 'h.1'; }
    let st = ''; [[34, 30], [62, 48], [58, 26]].forEach(c => { st += star(c, 3.4) + 'M' + (c[0] - 2.4) + ' ' + (c[1] - 2.4) + 'l4.8 4.8M' + (c[0] + 2.4) + ' ' + (c[1] - 2.4) + 'l-4.8 4.8'; });
    s += pen(polyD(wob(poly, 1.2), true), 1.8) + pen(dots, 2, 'opacity=".55"') + pen(st, 1.2) + txt(48, 77, 'où tu veux', 12);
  } else if (kind === 'fil') {
    s += base + inside(pen(filD, 2.4)) + pen('M77 72Q80 60 74 46', 1.5) + pen('M70.5 49.5L74 45l3.4 5', 1.5) + txt(70, 79, 'le fil', 13);
  } else if (kind === 'fausses') {
    const dec = wob(linePts([37, 13], [42.5, 34], 5), 0.9);
    s += base + inside(pen(filD, 2.4) + E.p(polyD(taperPts(dec, 5.5, 0.8), true), ink, ink, 0.8)) + check(86, 25) + cross(24, 4);
  } else if (kind === 'veine') {
    const v = wob(linePts([30, 18], [64, 63], 9), 3.2);
    s += base + inside(pen(filD, 1.4, 'opacity=".55"') + E.p(polyD(v), null, '#6b3419', 4.2, 'opacity=".45"') + E.p(polyD(v), null, '#c26d38', 2.4)) +
      pen(star(v[3], 2.8) + star(v[6], 2.4), 1.1) + txt(70, 20, '×3', 15);
  } else if (kind === 'indice') {
    s += base + inside(pen(filD, 2.2) + E.el(57, 38.5, 10, 6.5, -6, 'rgba(44,58,102,.08)', null) + pen('M48.5 37Q50 31.5 58 32.2', 1.4) + pen('M65.5 40Q64 45.5 56 45', 1.4, 'opacity=".6"')) +
      pen('M84 9Q76 12 67 29', 1.5) + pen('M63.5 25.5L67 30l4.2-4.3', 1.5) + txt(74, 8, 'ici ?', 12);
  } else if (kind === 'choix') {
    const peb = (x, y) => pen(smoothD(wob(ellipsePts(x, y, 12, 8.5, 0.1, 12), 0.9), true), 1.6, 'fill="#fbf6e8"');
    s += peb(20, 46) + peb(50, 44) + peb(80, 46) + pen('M44 42q3 -4 9 -3', 1.2) + pen(smoothD(wob(ellipsePts(50, 44, 19, 15, 0, 14), 1.2), true), 1.4) + check(45, 20) +
      pen('M14 60l4 5M26 60l-4 5M74 60l4 5M86 60l-4 5', 1.1, 'opacity=".6"') + txt(30, 78, 'lequel ?', 13);
  } else if (kind === 'pseudo') {
    let dd = '';
    const br = (p, a, L, d) => { const q = [p[0] + Math.cos(a) * L, p[1] + Math.sin(a) * L]; dd += 'M' + PS(p) + 'L' + PS(q); if (d > 0) { br(q, a - 0.5, L * 0.66, d - 1); br(q, a + 0.45, L * 0.66, d - 1); } };
    br([27, 62], -Math.PI / 2, 12, 3);
    let sp = ''; for (let t = 0; t <= 36; t++) { const a = t * 0.45, r = 1 + t * 0.34; sp += (t ? 'L' : 'M') + r1(73 + Math.cos(a) * r) + ' ' + r1(42 + Math.sin(a) * r * 0.9); }
    s += pen(dd, 1.2) + pen(sp, 1.4) + cross(34, 10) + check(80, 14) + txt(12, 78, 'faux', 12) + txt(62, 78, 'vrai', 12);
  } else if (kind === 'filvar') {
    s += base + inside(pen(filD, 2.2, 'stroke-dasharray="9 7"')) + pen('M77 72Q80 60 74 46', 1.5) + pen('M70.5 49.5L74 45l3.4 5', 1.5) + txt(40, 79, 'à prolonger', 12);
  } else if (kind === 'individus') {
    /* la carte en zones : le squelette est dans la case du milieu, un autre traîne plus loin */
    let grid = '';
    for (let i = 0; i <= 3; i++) grid += polyD(wob(linePts([18, 10 + i * 20], [78, 10 + i * 20], 4), 0.7)) + polyD(wob(linePts([18 + i * 20, 10], [18 + i * 20, 70], 4), 0.7));
    const fish = (x, y, k) => 'M' + (x - 7 * k) + ' ' + y + 'h' + (13 * k) + [-3.5, 0, 3.5].map(d => 'M' + (x + d * k) + ' ' + (y - 3.6 * k) + 'v' + (7.2 * k)).join('') + 'M' + (x - 7 * k) + ' ' + y + 'l' + (-3.2 * k) + ' ' + (-3.2 * k) + 'M' + (x - 7 * k) + ' ' + y + 'l' + (-3.2 * k) + ' ' + (3.2 * k);
    s += pen(grid, 1, 'opacity=".5"') + pen(fish(48, 40, 1), 1.6) + E.c(56.5, 40, 2.2, 'none', ink, 1.4) + pen(fish(68, 60, 0.6), 1.1, 'opacity=".5"') +
      pen('M93 22Q88 34 62 36', 1.5) + pen('M66.5 32.4L61.8 36.1l4.6 3.2', 1.5) + txt(52, 79, 'même zone', 12);
  } else if (kind === 'loupe') {
    const dec = wob([[36, 16], [38, 22], [39.5, 28], [40.5, 33]], 0.4);
    s += base + inside(pen(filD, 1.5) + pen(polyD(dec), 1.5)) +
      '<clipPath id="' + id + 'l"><circle cx="41" cy="27" r="13"/></clipPath>' +
      E.c(41, 27, 13, 'rgba(251,246,232,.72)', null) +
      '<g clip-path="url(#' + id + 'l)">' + E.p(polyD(dec.map(q => [41 + (q[0] - 41) * 1.6, 27 + (q[1] - 27) * 1.6])), null, '#98511f', 7, 'opacity=".35"') + pen(polyD(taperPts(dec.map(q => [41 + (q[0] - 41) * 1.6, 27 + (q[1] - 27) * 1.6]), 5, 1), true), 1, 'fill="' + ink + '"') + '</g>' +
      pen('M41 14a13 13 0 1 1 -0.1 0', 2) + pen('M50.5 36.5L62 49', 4.2);
  }
  return s + '</g></svg>';
}
/* point frappé par défaut (sans visée) : le haut de la pierre, côté marteau */
function defaultImpact(g) {
  const top = g.pts.filter(q => q[1] < g.cy).sort((a, b) => Math.abs(a[0] - g.cx - g.rx * 0.3) - Math.abs(b[0] - g.cx - g.rx * 0.3))[0] || [g.cx, g.cy - g.ry];
  return [lerp(top[0], g.cx, 0.12), lerp(top[1], g.cy, 0.12)];
}
/* face intérieure (part) ou contre-empreinte (miroir) */
function stoneFaceSVG(g, uid, content, mirror) {
  const S = ROCKS[g.rockId].stone, rnd = mulberry32(g.sd * 13 + 1);
  let s = '<svg class="st-svg" viewBox="0 0 200 180" aria-hidden="true"><defs><clipPath id="' + uid + 'f"><path d="' + g.d + '"/></clipPath></defs>';
  let inner = '';
  if (g.side && !mirror) {
    const sp = g.pts.map(q => [q[0], q[1] + g.side]);
    inner += E.p(smoothD(sp, true), S.side, S.ink, 2.2);
    let st = '';
    const lower = g.pts.filter(q => q[1] >= g.cy - 4).sort((a, b) => a[0] - b[0]);
    for (let k = 1; k <= 4; k++) st += polyD(lower.map(q => [q[0], q[1] + k * 3.6]));
    inner += '<g clip-path="url(#' + uid + 's)">' + E.p(st, null, S.ink, 0.8, 'opacity=".45"') + '</g>';
    s = s.replace('</defs>', '<clipPath id="' + uid + 's"><path d="' + smoothD(sp, true) + '"/></clipPath></defs>');
  }
  inner += E.p(g.d, S.face);
  inner += '<g clip-path="url(#' + uid + 'f)">';
  let dots = '';
  for (let i = 0; i < 140; i++) dots += 'M' + r1(rnd() * 200) + ' ' + r1(rnd() * 160) + 'h0';
  inner += E.p(dots, null, S.faceTex, 1.3, 'opacity=".35"');
  const tx = ROCKS[g.rockId].tex;
  if (tx === 'speckle') {
    let k = '', w = '';
    for (let i = 0; i < 150; i++) k += 'M' + r1(rnd() * 200) + ' ' + r1(rnd() * 160) + 'l' + r1(rnd() * 2) + ' ' + r1(rnd() * 1.4);
    for (let i = 0; i < 40; i++) w += E.el(rnd() * 200, rnd() * 160, 2 + rnd() * 2, 1.4 + rnd() * 1.4, rnd() * 180, '#d6b0a4', null, 0, 'opacity=".7"');
    inner += w + E.p(k, null, S.tex, 2.6, 'opacity=".55"');
  } else if (tx === 'fracture') {
    let f = '';
    for (let i = 0; i < 5; i++) { const x = 40 + rnd() * 120, y = 40 + rnd() * 80, r = 6 + rnd() * 10; f += 'M' + r1(x - r) + ' ' + r1(y) + 'a' + r1(r) + ' ' + r1(r * 0.7) + ' 0 0 1 ' + r1(2 * r) + ' 0'; }
    inner += E.p(f, null, S.faceTex, 0.9, 'opacity=".6"');
  }
  if (tx === 'foliation' || tx === 'coal') {
    let l = '';
    for (let k = -5; k <= 5; k++) l += 'M0 ' + r1(g.cy + k * 8 + 3) + 'Q100 ' + r1(g.cy + k * 8 - 2) + ' 200 ' + r1(g.cy + k * 8 + 4);
    inner += E.p(l, null, S.faceTex, 0.8, 'opacity=".25"');
  } else if (tx === 'vesicle' || tx === 'reef') {
    let o = '';
    for (let i = 0; i < 14; i++) { const x = 20 + rnd() * 160, y = 20 + rnd() * 130, r = 1.2 + rnd() * 2; o += 'M' + r1(x + r) + ' ' + r1(y) + 'a' + r1(r) + ' ' + r1(r) + ' 0 1 0 ' + r1(-2 * r) + ' 0a' + r1(r) + ' ' + r1(r) + ' 0 1 0 ' + r1(2 * r) + ' 0'; }
    inner += E.p(o, null, S.faceTex, 0.9, 'opacity=".5"');
  } else if (tx === 'shells') {
    let o = '';
    for (let i = 0; i < 10; i++) { const x = 20 + rnd() * 160, y = 20 + rnd() * 130, r = 2 + rnd() * 3, a = rnd() * TAU; o += 'M' + r1(x + Math.cos(a) * r) + ' ' + r1(y + Math.sin(a) * r) + 'A' + r1(r) + ' ' + r1(r * 0.8) + ' 0 0 1 ' + r1(x + Math.cos(a + 2.4) * r) + ' ' + r1(y + Math.sin(a + 2.4) * r); }
    inner += E.p(o, null, S.faceTex, 0.9, 'opacity=".55"');
  }
  inner += E.p(g.d, null, S.faceShade, 18, 'opacity=".75"') + E.p(g.d, null, S.shade, 5, 'opacity=".5"');
  inner += '<g class="face-content">' + (content || '') + '</g>';
  inner += '</g>';
  inner += E.p(g.d, null, S.ink, 2.4);
  s += mirror ? '<g transform="matrix(-1 0 0 1 200 0)">' + inner + '</g>' : inner;
  return s + '</svg>';
}
/* boîte utile de la face pour poser un contenu */
function faceBox(g) {
  let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
  g.pts.forEach(q => { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); y0 = Math.min(y0, q[1]); y1 = Math.max(y1, q[1]); });
  const w = x1 - x0, h = y1 - y0;
  return { x: x0 + w * 0.13, y: y0 + h * 0.14, w: w * 0.74, h: h * 0.72 };
}
/* petit caillou pour la rangée du lot */
function pebbleSVG(rockId, seed, state) {
  const S = ROCKS[rockId].stone, rnd = mulberry32(seed), pts = [];
  for (let i = 0; i < 12; i++) { const a = i / 12 * TAU, r = 1 + (rnd() - 0.5) * 0.22; pts.push([16 + Math.cos(a) * 12 * r, 12 + Math.sin(a) * 8.5 * r]); }
  const d = smoothD(pts, true);
  const fill = state === 'done' ? S.face : S.base;
  let s = '<svg viewBox="0 0 32 24" aria-hidden="true">' + E.p(d, fill, S.ink, 1.3);
  if (state === 'done') s += E.p('M15 4l1.5 5-2 4 1.5 6', null, S.ink, 1.1);
  else s += E.p('M9 9q4 -3 8 -2', null, S.light, 1.4, 'opacity=".8"');
  return s + '</svg>';
}

/* ---------------- marteaux (6 niveaux) ---------------- */
const HSTYLE = [
  { handle: '#b98b57', grain: '#8a6036', head: '#5d5c58', hi: '#9a9994', edge: null, grip: null },
  { handle: '#b98b57', grain: '#8a6036', head: '#5d5c58', hi: '#a3a29c', edge: null, grip: '#7a4a2a', gripLine: '#4d2c16' },
  { handle: '#8f959a', grain: null, head: '#6f757a', hi: '#d6dbde', edge: null, grip: '#2d2d2d', gripLine: '#555' },
  { handle: '#a4abb0', grain: null, head: '#8a9297', hi: '#f2f5f6', edge: null, grip: '#2c5f8a', gripLine: '#1a3c5a' },
  { handle: '#2f3134', grain: null, head: '#3b3d40', hi: '#8d9296', edge: '#d2a43a', grip: '#1c1c1c', gripLine: '#c07a3a' },
  { handle: '#2f3134', grain: null, head: '#44403a', hi: '#b8b1a4', edge: '#e7bd4c', grip: '#1c1c1c', gripLine: '#d08a3c', rings: true }
];
function hammerSVG(level) {
  const M = HSTYLE[clamp(level, 0, 5)], ink = '#1d1712';
  let s = '<svg class="hm-svg" viewBox="-62 -132 124 146" aria-hidden="true"><g stroke-linejoin="round" stroke-linecap="round">';
  s += E.p('M-4.6 2L-4.2 -96L4.2 -96L4.6 2Q0 6 -4.6 2Z', M.handle, ink, 1.8);
  if (M.grain) s += E.p('M-1.6 -6Q-2.2 -40 -1.2 -90M1.8 -12Q2.6 -52 1.3 -86M-0.2 -30Q0.4 -44 -0.4 -60', null, M.grain, 0.9);
  else s += E.p('M-2.3 -4L-2 -92', null, M.hi, 1.5, 'opacity=".85"');
  if (M.grip) {
    s += E.p('M-6.2 3L-5.8 -40L5.8 -40L6.2 3Q0 8 -6.2 3Z', M.grip, ink, 1.8);
    let gl = '';
    for (let y = -34; y < 0; y += 6) gl += level === 1 ? 'M-5.8 ' + (y + 4) + 'L5.8 ' + y : 'M-5.4 ' + y + 'H5.4';
    s += E.p(gl, null, M.gripLine, 1.1);
  }
  if (M.rings) s += E.p('M-4.4 -60H4.4M-4.4 -64H4.4', null, M.edge, 1.6);
  s += E.p('M-9 -113L9 -113L9 -91L-9 -91Z', M.head, ink, 2);
  s += E.p('M-9 -111L-25 -113L-30 -110.5L-30 -93.5L-25 -91L-9 -93Z', M.head, ink, 2);
  s += E.p('M9 -112Q28 -110 47 -101Q28 -97 9 -92Z', M.head, ink, 2);
  s += E.p('M-27 -109.5L6 -110Q24 -108.5 38 -103', null, M.hi, 1.7, 'opacity=".85"');
  if (M.edge) s += E.p('M-30 -110V-94M40 -102.5L47 -101', null, M.edge, 2.4);
  s += E.p('M-9 -91L-7 -87L7 -87L9 -91', M.head, ink, 1.6);
  return s + '</g></svg>';
}

/* ---------------- minerai, poussière ---------------- */
function oreSVG(oreId, box, rnd, small) {
  const O = ORES[oreId], k = small ? 0.55 : 1;
  const x0 = box.x + box.w * (small ? 0.62 : 0.05), y0 = box.y + box.h * (small ? 0.95 : 0.9);
  const x1 = box.x + box.w * (small ? 1.02 : 0.95), y1 = box.y + box.h * (small ? 0.55 : 0.1);
  const n = 9, cl = [];
  for (let i = 0; i <= n; i++) { const t = i / n; cl.push([lerp(x0, x1, t) + (rnd() - 0.5) * 10 * k, lerp(y0, y1, t) + (rnd() - 0.5) * 10 * k]); }
  const band = taperPts(cl, 6 * k, 5 * k, t => 0.7 + 0.6 * Math.sin(t * Math.PI));
  let s = E.p(polyD(band, true), O.color, O.dark, 1.3);
  s += E.p(polyD(cl.map(q => [q[0] - 1, q[1] - 1.2])), null, O.hi, 1.3 * k, 'opacity=".9"');
  let br = '';
  [3, 6].forEach(i => { const q = cl[i]; br += 'M' + PS(q) + 'l' + r1((rnd() - 0.2) * 16 * k) + ' ' + r1((rnd() + 0.3) * 12 * k); });
  s += E.p(br, null, O.color, 2.2 * k) + E.p(br, null, O.dark, 0.6 * k, 'opacity=".6"');
  let gl = '';
  for (let j = 0; j < (small ? 2 : 4); j++) { const q = cl[1 + Math.floor(rnd() * (n - 1))], L = (3 + rnd() * 3) * k; gl += 'M' + r1(q[0] - L) + ' ' + r1(q[1]) + 'h' + r1(2 * L) + 'M' + r1(q[0]) + ' ' + r1(q[1] - L) + 'v' + r1(2 * L); }
  s += E.p(gl, null, '#fffbe8', 1.2);
  return s;
}
function dustSVG(box, rnd, S) {
  let s = '', d = '';
  for (let i = 0; i < 28; i++) d += 'M' + r1(box.x + rnd() * box.w) + ' ' + r1(box.y + rnd() * box.h) + 'h0';
  s += E.p(d, null, S.faceShade, 3, 'opacity=".55"');
  let c = '';
  for (let i = 0; i < 3; i++) { const x = box.x + box.w * (0.2 + rnd() * 0.6), y = box.y + box.h * (0.25 + rnd() * 0.5); c += 'M' + r1(x) + ' ' + r1(y) + 'l' + r1(6 + rnd() * 8) + ' ' + r1(2 + rnd() * 4) + 'l' + r1(3 + rnd() * 5) + ' ' + r1(-4 - rnd() * 3); }
  s += E.p(c, null, S.ink, 0.9, 'opacity=".45"');
  return s;
}

/* ---------------- établi : planches de bois peintes ---------------- */
function drawBench(cv, seed) {
  const w = cv.width, h = cv.height, ctx = cv.getContext('2d'), rnd = mulberry32(seed);
  const k = w / 480;
  ctx.fillStyle = '#6e4a2b'; ctx.fillRect(0, 0, w, h);
  const planks = [];
  let y = -rnd() * 30 * k;
  while (y < h) { const ph = (74 + rnd() * 28) * k; planks.push([y, ph]); y += ph; }
  planks.forEach(([py, ph], i) => {
    const base = ['#a0754a', '#976c43', '#a87c50', '#94693f'][i % 4];
    ctx.fillStyle = base; ctx.fillRect(0, py, w, ph);
    ctx.save(); ctx.beginPath(); ctx.rect(0, py, w, ph); ctx.clip();
    for (let g = 0; g < 26; g++) {
      const gy = py + rnd() * ph, amp = (2 + rnd() * 5) * k, fr = 0.004 + rnd() * 0.01, ph0 = rnd() * 9;
      ctx.beginPath();
      for (let x = -10; x <= w + 10; x += 8 * k) { const yy = gy + Math.sin(x * fr / k + ph0) * amp + (fbm(x * 0.01 / k, g, seed + i * 17, 2) - 0.5) * 6 * k; x < 0 ? ctx.moveTo(x, yy) : ctx.lineTo(x, yy); }
      ctx.strokeStyle = rnd() < 0.5 ? 'rgba(90,56,28,.35)' : 'rgba(196,150,100,.28)';
      ctx.lineWidth = (0.8 + rnd() * 1.6) * k; ctx.stroke();
    }
    if (rnd() < 0.7) {
      const kx = rnd() * w, ky = py + ph * (0.3 + rnd() * 0.4);
      for (let r = 3; r < 16; r += 3) { ctx.beginPath(); ctx.ellipse(kx, ky, r * 1.9 * k, r * 0.7 * k, 0, 0, TAU); ctx.strokeStyle = 'rgba(80,48,22,' + (0.5 - r * 0.02) + ')'; ctx.lineWidth = 1.2 * k; ctx.stroke(); }
      ctx.beginPath(); ctx.ellipse(kx, ky, 4 * k, 2 * k, 0, 0, TAU); ctx.fillStyle = 'rgba(70,40,18,.7)'; ctx.fill();
    }
    ctx.restore();
    ctx.fillStyle = 'rgba(40,24,10,.75)'; ctx.fillRect(0, py - 1.5 * k, w, 3 * k);
    ctx.fillStyle = 'rgba(214,170,120,.35)'; ctx.fillRect(0, py + 1.5 * k, w, 1.2 * k);
    [0.06, 0.94].forEach(fx => {
      const nx = w * fx, ny = py + ph / 2;
      ctx.beginPath(); ctx.arc(nx, ny, 3.4 * k, 0, TAU); ctx.fillStyle = '#3b3129'; ctx.fill();
      ctx.beginPath(); ctx.arc(nx - 1 * k, ny - 1 * k, 1.2 * k, 0, TAU); ctx.fillStyle = 'rgba(220,210,190,.6)'; ctx.fill();
    });
  });
  for (let i = 0; i < 9; i++) {
    const x = rnd() * w, yy = rnd() * h, L = (20 + rnd() * 40) * k;
    ctx.beginPath(); ctx.moveTo(x, yy); ctx.lineTo(x + L, yy + (rnd() - 0.5) * 4 * k);
    ctx.strokeStyle = 'rgba(60,34,14,.45)'; ctx.lineWidth = 1 * k; ctx.stroke();
  }
  /* poussière de roche au centre */
  for (let i = 0; i < 900; i++) {
    const a = rnd() * TAU, r = Math.pow(rnd(), 0.6) * 150 * k;
    const x = w / 2 + Math.cos(a) * r * 1.3, yy = h * 0.54 + Math.sin(a) * r * 0.55;
    ctx.fillStyle = 'rgba(235,222,196,' + (0.12 + rnd() * 0.2) + ')';
    ctx.fillRect(x, yy, (1 + rnd() * 1.6) * k, (1 + rnd() * 1.6) * k);
  }
  /* vignette douce */
  const gr = ctx.createRadialGradient(w / 2, h * 0.52, h * 0.2, w / 2, h * 0.52, h * 0.85);
  gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(30,16,6,.45)');
  ctx.fillStyle = gr; ctx.fillRect(0, 0, w, h);
}
