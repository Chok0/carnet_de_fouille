/* ============ fossiles : Permien (mésosaure, dimétrodon), Trias (nothosaure) ============ */

/* ---------- aides (préfixe p2_) ---------- */
function p2_fo(p, o) { return 'fill-opacity="' + (p.flat ? 1 : o) + '"'; }
function p2_op(p, o) { return 'opacity="' + (p.flat ? 1 : o) + '"'; }
function p2_n(v) { let s = String(Math.round(v * 10) / 10); if (s === '-0') s = '0'; return s.replace(/^(-?)0\./, '$1.'); }
/* chemin compact : commandes relatives arrondies au dixième, sans dérive */
function p2_B() {
  let d = '', cx = 0, cy = 0, sx = 0, sy = 0, last = '';
  const R = v => Math.round(v * 10) / 10;
  const nums = a => a.map((v, i) => { const s = p2_n(v); return i && s[0] !== '-' ? ' ' + s : s; }).join('');
  const cmd = (c, a) => { const s = nums(a); d += c === last ? (s[0] === '-' ? '' : ' ') + s : c + s; last = c; };
  const P = {
    M(q) { const x = R(q[0]), y = R(q[1]); d += d ? 'm' + nums([x - cx, y - cy]) : 'M' + nums([x, y]); last = 'm'; cx = sx = x; cy = sy = y; return P; },
    L(q) { const x = R(q[0]), y = R(q[1]); cmd('l', [x - cx, y - cy]); cx = x; cy = y; return P; },
    Q(c, q) { const x = R(q[0]), y = R(q[1]); cmd('q', [R(c[0]) - cx, R(c[1]) - cy, x - cx, y - cy]); cx = x; cy = y; return P; },
    C(a, b, q) { const x = R(q[0]), y = R(q[1]); cmd('c', [R(a[0]) - cx, R(a[1]) - cy, R(b[0]) - cx, R(b[1]) - cy, x - cx, y - cy]); cx = x; cy = y; return P; },
    Z() { d += 'z'; last = 'z'; cx = sx; cy = sy; return P; },
    pl(pts, close) { P.M(pts[0]); for (let i = 1; i < pts.length; i++) P.L(pts[i]); if (close) P.Z(); return P; },
    sm(pts, close) {
      const n = pts.length;
      if (n < 3) return P.pl(pts, close);
      const g = i => (close ? pts[(i + n) % n] : pts[clamp(i, 0, n - 1)]);
      P.M(pts[0]);
      for (let i = 0; i < (close ? n : n - 1); i++) {
        const a = g(i - 1), b = g(i), c = g(i + 1), e = g(i + 2);
        P.C([b[0] + (c[0] - a[0]) / 6, b[1] + (c[1] - a[1]) / 6], [c[0] - (e[0] - b[0]) / 6, c[1] - (e[1] - b[1]) / 6], c);
      }
      if (close) P.Z();
      return P;
    },
    d() { return d; }
  };
  return P;
}
function p2_sm(pts, close) { return p2_B().sm(pts, close).d(); }
/* courbe de Catmull-Rom échantillonnée (k points par segment) */
function p2_cr(keys, k) {
  const n = keys.length, g = i => keys[clamp(i, 0, n - 1)], o = [keys[0]];
  for (let i = 0; i < n - 1; i++) {
    const a = g(i - 1), b = g(i), c = g(i + 1), e = g(i + 2);
    cubicPts(b, [b[0] + (c[0] - a[0]) / 6, b[1] + (c[1] - a[1]) / 6], [c[0] - (e[0] - b[0]) / 6, c[1] - (e[1] - b[1]) / 6], c, k).slice(1).forEach(q => o.push(q));
  }
  return o;
}
/* abscisse curviligne le long d'une polyligne dense : at(s) → {x, y, tx, ty} ;
   P(s, u, v) : point décalé de u le long de la tangente et de v sur la normale gauche (le dos quand la courbe va vers la droite) ;
   D(s, a) : direction d'angle a (degrés) dans ce repère (0 = vers l'arrière, 90 = vers le dos) */
function p2_trk(pts) {
  const acc = [0];
  for (let i = 1; i < pts.length; i++) acc.push(acc[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  const L = acc[acc.length - 1];
  const at = s => {
    s = clamp(s, 0, L);
    let lo = 0, hi = acc.length - 1;
    while (hi - lo > 1) { const m = (lo + hi) >> 1; if (acc[m] <= s) lo = m; else hi = m; }
    const a = pts[Math.max(0, lo - 1)], b = pts[Math.min(pts.length - 1, hi + 1)], l = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
    const t = (s - acc[lo]) / (acc[hi] - acc[lo] || 1);
    return { x: lerp(pts[lo][0], pts[hi][0], t), y: lerp(pts[lo][1], pts[hi][1], t), tx: (b[0] - a[0]) / l, ty: (b[1] - a[1]) / l };
  };
  const P = (s, u, v) => { const f = at(s); return [f.x + f.tx * u + f.ty * v, f.y + f.ty * u - f.tx * v]; };
  const D = (s, a) => { const f = at(s), c = Math.cos(a * D2R), n = Math.sin(a * D2R); return [c * f.tx + n * f.ty, c * f.ty - n * f.tx]; };
  return { L, at, P, D };
}
/* repère rigide (crâne) : origine o, axe avant d'angle a (degrés), v vers le dos */
function p2_frame(o, a) {
  const f = [Math.cos(a * D2R), Math.sin(a * D2R)];
  return (u, v) => [o[0] + f[0] * u - f[1] * v, o[1] + f[1] * u + f[0] * v];
}
function p2_add(a, d, k) { return [a[0] + d[0] * k, a[1] + d[1] * k]; }
function p2_rot(d, a) { const c = Math.cos(a * D2R), s = Math.sin(a * D2R); return [d[0] * c - d[1] * s, d[0] * s + d[1] * c]; }
/* os long a→b : diaphyse w, épiphyses k·w */
function p2_bone(B, a, b, w, k) {
  const L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1, d = [(b[0] - a[0]) / L, (b[1] - a[1]) / L], n = [d[1], -d[0]];
  const h = w / 2, K = h * (k || 1.5), e = Math.min(L * 0.3, K * 1.6);
  const P = (o, dd, nn) => [o[0] + d[0] * dd + n[0] * nn, o[1] + d[1] * dd + n[1] * nn];
  return B.sm([P(a, -K * 0.55, 0), P(a, 0, K), P(a, e, h), P(b, -e, h), P(b, 0, K), P(b, K * 0.55, 0), P(b, 0, -K), P(b, -e, -h), P(a, e, -h), P(a, 0, -K)], true);
}
/* épine effilée : base b (largeur w) → pointe t, cambrure bend */
function p2_spk(B, b, t, w, bend) {
  const L = Math.hypot(t[0] - b[0], t[1] - b[1]) || 1, d = [(t[0] - b[0]) / L, (t[1] - b[1]) / L], n = [d[1], -d[0]];
  const m = p2_add([(b[0] + t[0]) / 2, (b[1] + t[1]) / 2], n, bend || 0);
  return B.M(p2_add(b, n, w / 2)).Q(p2_add(m, n, w * 0.3), t).Q(p2_add(m, n, -w * 0.3), p2_add(b, n, -w / 2)).Z();
}
/* côte en banane : tête b, contrôle c, pointe e ; demi-épaisseurs h0 (tête), hm (milieu), h1 (pointe) */
function p2_rib(B, b, c, e, h0, hm, h1) {
  const nr = (a, z) => { const l = Math.hypot(z[0] - a[0], z[1] - a[1]) || 1; return [(z[1] - a[1]) / l, -(z[0] - a[0]) / l]; };
  const n0 = nr(b, c), n1 = nr(c, e), nc = nr(b, e), k = 2 * hm - (h0 + h1) / 2;
  return B.M(p2_add(b, n0, h0)).Q(p2_add(c, nc, k), p2_add(e, n1, h1)).L(p2_add(e, n1, -h1)).Q(p2_add(c, nc, -k), p2_add(b, n0, -h0)).Z();
}
/* doigt : segments (métapode + phalanges) séparés d'un petit jour, en « gélules » */
function p2_digit(B, a, d, lens, gap) {
  let q = a;
  lens.forEach(l => { const e = p2_add(q, d, l); B.M(q).L(e); q = p2_add(e, d, gap); });
  return q;
}
/* os en gélule : même tracé en trait sombre large puis clair étroit */
function p2_caps(d, p, w, col) { return E.p(d, null, p.line, r1(w + 1.2)) + E.p(d, null, col || p.relief, w); }

/* ---------------- Mesosaurus tenuidens — Permien inférieur (formation d'Irati, Brésil) ----------------
   Fiche anatomique :
   ① crâne long et étroit (≈ 17 % du corps) : museau effilé (≈ 2/3 du crâne) garni de très nombreuses dents
      en aiguille, fines, obliques vers l'avant, qui se croisent entre les mâchoires ; grande orbite reculée,
      narine reculée près de l'œil ;
   ② colonne : 10 cervicales à courtes côtes, 20 dorsales, 2 sacrées, ~50 caudales de plus en plus petites ;
   ③ côtes pachyostotiques : épaisses, en banane, très serrées (presque jointives), courbées vers le bas et
      l'arrière — la signature du mésosaure ;
   ④ membres : antérieurs petits (humérus, radius/cubitus, main courte) ; postérieurs plus grands (fémur,
      tibia/fibula) avec un long pied palmé aux 5 doigts écartés ;
   ⑤ queue haute de nageur : épines neurales dessus, chevrons dessous, inclinés vers l'arrière, décroissants ;
   ⑥ ceintures : omoplate + coracoïde, ilion + plaque pubo-ischiatique ; gastralia fins sous le ventre.
   Construction : colonne = courbe en S (Catmull-Rom) parcourue en abscisse curviligne ; vertèbres, côtes,
   épines et membres placés dans le repère local (tangente / normale dorsale) ; crâne dans un repère rigide. */
function artMesosaurus(p) {
  const T = p2_trk(p2_cr([[72, 40], [92, 32], [114, 29], [142, 34], [170, 48], [194, 66], [220, 84], [248, 98], [276, 101], [297, 92], [311, 74]], 16)), L = T.L;
  /* longueurs relatives : 10 cervicales, 20 dorsales, 2 sacrées, 50 caudales */
  const rel = [];
  for (let i = 0; i < 82; i++) rel.push(i < 10 ? 0.74 : i < 30 ? 1 : i < 32 ? 0.95 : lerp(0.92, 0.36, (i - 32) / 49));
  const k = L / rel.reduce((a, b) => a + b, 0);
  let acc = 0;
  const V = rel.map(r => { const o = { s: acc + r * k / 2, l: r * k }; acc += r * k; return o; });
  const s0 = V[10].s - V[10].l / 2, s1 = V[29].s + V[29].l / 2, sS = V[31].s + V[31].l / 2;
  const Lr = t => lerp(19, 34, smooth(Math.min(1, t / 0.3))) - 17 * smooth(clamp((t - 0.45) / 0.55, 0, 1));
  const hsp = t => 8.5 * Math.pow(1 - t, 1.3) + 0.5, hch = t => 10 * Math.pow(1 - t, 1.3) + 0.5;
  let s = '';
  /* halo des tissus mous (empreinte) */
  const up = x => x < sS ? 5.5 : hsp((x - sS) / (L - sS)) + 2.2;
  const dn = x => x < s0 ? lerp(6, 16, smooth(x / s0)) : x < s1 ? Lr((x - s0) / (s1 - s0)) * 0.9 + 3 : x < sS + 6 ? 15 : hch((x - sS) / (L - sS)) + 2.4;
  const hu = [], hd = [];
  for (let i = 0; i <= 44; i++) { const x = L * i / 44; hu.push(T.P(x, 0, up(x))); hd.push(T.P(x, 0, -dn(x))); }
  s += E.p(p2_sm(hu.concat(hd.reverse()), true), p.film, null, 0, p2_fo(p, 0.42));
  /* membres : os longs (côté proche) ou gélules sombres (côté éloigné) */
  const lb = p2_B(), dg = p2_B(), fb = p2_B();
  const limb = (x, root, a1, l1, w1, a2, l2, w2, fan, spread, base, lens, far) => {
    const A = T.P(x, root[0], root[1]), K = p2_add(A, T.D(x, a1), l1), W = p2_add(K, T.D(x, a2), l2);
    const n = p2_rot(T.D(x, a2), 90), ds = [];
    if (far) fb.M(A).L(K).M(p2_add(K, n, 0.7)).L(p2_add(W, n, 0.7)).M(p2_add(K, n, -0.9)).L(p2_add(W, n, -0.9));
    else {
      p2_bone(lb, A, K, w1, 1.5);
      p2_bone(lb, p2_add(K, n, w2 * 0.45), p2_add(W, n, w2 * 0.4), w2 * 0.8, 1.35);
      p2_bone(lb, p2_add(K, n, -w2 * 0.45), p2_add(W, n, -w2 * 0.4), w2 * 0.62, 1.35);
    }
    lens.forEach((ls, j) => {
      const b = p2_add(W, p2_rot(T.D(x, fan), 90), (j - 2) * base);
      ds.push([b, p2_digit(far ? fb : dg, b, T.D(x, fan + (j - 2) * spread), ls, 0.7)]);
    });
    return { W, ds };
  };
  limb(s0 + 1, [0, -9], -100, 12, 0, -50, 8.5, 0, -14, 15, 1.2, [[3, 2, 1.5], [3.8, 2.3, 1.8], [4.2, 2.5, 2], [4, 2.3, 1.8], [3.2, 1.9]], true);
  limb(sS - 7, [0, -8], -98, 18, 0, -34, 13, 0, -10, 13, 1.8, [[6, 3.4, 2.6], [7.4, 4, 3], [8.4, 4.4, 3.4, 2.6], [8.6, 4.4, 3.4, 2.8], [7, 3.6, 2.8]], true);
  s += E.p(fb.d(), null, p.shade, 2.3, p2_op(p, 0.8));
  /* côtes pachyostotiques */
  const rb = p2_B();
  for (let i = 10; i < 30; i++) {
    const x = V[i].s, t = (i - 10) / 19, l = Lr(t), a = (18 + 10 * t) * D2R;
    p2_rib(rb, T.P(x, 0.4, 1.2), T.P(x, l * 0.42, -l * 0.46), T.P(x, l * Math.sin(a), -l * Math.cos(a)), 1.2, 0.47 * k, 0.7);
  }
  s += E.p(rb.d(), p.relief, p.line, 0.6);
  /* gastralia */
  let ga = '';
  for (let x = s0 + 6; x < s1 - 2; x += 2.6) { const l = Lr((x - s0) / (s1 - s0)) * 0.94 + 1.5; ga += 'M' + PS(T.P(x, -2, -l)) + 'L' + PS(T.P(x + 3.4, 1, -l - 2)); }
  s += E.p(ga, null, p.line, 0.55, p2_op(p, 0.8));
  /* épines neurales et chevrons */
  const sp = p2_B();
  V.forEach((v, i) => {
    const x = v.s;
    if (i < 32) return;
    const t = (i - 32) / 49, h = hsp(t), c = hch(t), w = lerp(2.4, 0.8, t);
    if (h > 0.9) p2_spk(sp, T.P(x, -0.3, 1.6), p2_add(T.P(x, 0, 1.6), T.D(x, 58), h), w, -0.4);
    if (i > 33 && c > 0.9) p2_spk(sp, T.P(x, -0.3, -1.6), p2_add(T.P(x, 0, -1.6), T.D(x, -52), c), w, 0.4);
  });
  s += E.p(sp.d(), p.body, p.line, 0.5);
  /* côtes cervicales, centres vertébraux */
  let cr = '';
  for (let i = 1; i < 10; i++) cr += 'M' + PS(T.P(V[i].s, -1, -2)) + 'L' + PS(T.P(V[i].s, 4.5, -4.6));
  s += p2_caps(cr, p, 1);
  const ce = p2_B();
  V.forEach((v, i) => {
    const x = v.s, a = v.l * 0.43, h = (i < 10 ? 2.4 : i < 32 ? 2.9 : lerp(2.8, 0.7, (i - 32) / 49));
    ce.pl([T.P(x, -a, h), T.P(x, a, h), T.P(x, a, -h), T.P(x, -a, -h)], true);
    if (i < 32) { const b = v.l * 0.34, t = i < 10 ? 4.6 : 5.6; ce.pl([T.P(x, -b, h), T.P(x, 1.3 - b, t), T.P(x, 1.3 + b, t), T.P(x, b, h)], true); }
  });
  s += E.p(ce.d(), p.relief, p.line, 0.5);
  /* ceintures : omoplate + coracoïde, ilion, plaque pubo-ischiatique */
  const gd = p2_B();
  gd.sm([T.P(s0 + 1, 0, 3.6), T.P(s0 + 5, 0, 4.4), T.P(s0 + 7, 0, 0), T.P(s0 + 5.5, 0, -8), T.P(s0 + 3, 0, -8.4), T.P(s0 + 1.5, 0, -1)], true);
  gd.sm([T.P(s0 + 1, 0, -8.6), T.P(s0 + 7, 0, -9), T.P(s0 + 8, 0, -13), T.P(s0 + 3, 0, -15.4), T.P(s0 - 1, 0, -12)], true);
  gd.sm([T.P(sS - 5, 0, -7), T.P(sS - 3, 0, 1.6), T.P(sS + 3, 0, 4.6), T.P(sS + 5, 0, 2.4), T.P(sS, 0, -1), T.P(sS - 1, 0, -7.6)], true);
  gd.sm([T.P(sS - 13, 0, -9.5), T.P(sS - 4, 0, -8), T.P(sS + 5, 0, -11), T.P(sS + 2, 0, -16), T.P(sS - 8, 0, -16), T.P(sS - 14, 0, -13)], true);
  s += E.p(gd.d(), p.relief, p.line, 0.7);
  /* membres du côté proche ; pied postérieur palmé */
  limb(s0 + 4, [2, -11], -112, 13, 3.4, -62, 9, 3, -30, 17, 1.4, [[3.2, 2, 1.6], [4, 2.4, 2, 1.6], [4.4, 2.6, 2.2, 1.8], [4.2, 2.4, 2, 1.7], [3.4, 2, 1.5]]);
  const hf = limb(sS - 3, [0, -9], -132, 20, 4.6, -62, 14, 4, -30, 17, 2.3, [[7, 4, 3], [8.6, 4.6, 3.6, 2.8], [9.6, 5, 4, 3.2, 2.6], [10, 5.2, 4, 3.2, 2.8], [8, 4.2, 3.2, 2.6]]);
  const web = [hf.W];
  hf.ds.forEach((d, j) => {
    web.push(lerpPt(d[0], d[1], 0.86));
    if (j < 4) { const e = hf.ds[j + 1]; web.push(lerpPt(lerpPt(d[0], e[0], 0.5), lerpPt(d[1], e[1], 0.5), 0.56)); }
  });
  s += E.p(p2_sm(web, true), p.shade, p.line, 0.5, p2_fo(p, 0.5));
  s += E.p(lb.d(), p.relief, p.line, 0.6) + p2_caps(dg.d(), p, 1.3);
  /* crâne (repère rigide : u vers l'avant, v vers le dos) ; les dents, dessinées derrière, débordent des mâchoires */
  const W = p2_frame([72, 40], 166);
  const RT = [[-2.5, 4], [1, 8.2], [6, 10.2], [12, 10.4], [18, 8.8], [26, 6.5], [36, 4.9], [46, 3.7], [53, 2.7], [57, 1.3], [58.4, 0]];
  const JB = [[-4, -8.4], [0, -10.2], [6, -9.8], [14, -8.6], [24, -7.3], [34, -6.3], [44, -5.4], [54, -4.4]];
  const g = u => 2.8 * clamp((u - 12) / 45, 0, 1), um = u => -0.4 + g(u) / 2, lm = u => -0.4 - g(u) / 2;
  const U = [56.5, 50, 44, 38, 32, 26, 20, 14];
  let th = '';
  for (let u = 14; u < 55.5; u += 1.45) {
    th += 'M' + PS(W(u, um(u) + 0.6)) + 'L' + PS(W(u + 3, u > 22 ? interpY(JB, u + 3) - 1.4 : lm(u) - 1));
    th += 'M' + PS(W(u + 0.7, lm(u) - 0.6)) + 'L' + PS(W(u + 3.7, u > 22 ? interpY(RT, u + 3.7) + 1.4 : um(u) + 1));
  }
  th += 'M' + PS(W(55, um(55))) + 'L' + PS(W(61, 0.5)) + 'M' + PS(W(55.5, lm(55.5))) + 'L' + PS(W(60.8, -2));
  s += E.p(th, null, p.line, 0.55);
  s += E.p(p2_sm(U.map(u => W(u, lm(u))).reverse().concat([W(57.8, -2.6)], JB.slice().reverse().map(q => W(q[0], q[1])), [W(-2.5, -6.4), W(4, -5.6)]), true), p.body, p.line, 0.9);
  s += E.p(p2_sm(RT.map(q => W(q[0], q[1])).concat(U.map(u => W(u, um(u))), [W(10, -2.4), W(5, -4.6), W(1.4, -7), W(-1.6, -5), W(-2.8, 0)]), true), p.relief, p.line, 1);
  s += E.p('M' + PS(W(5.4, 8.6)) + 'Q' + PS(W(3.2, 2)) + ' ' + PS(W(6.6, -3.4)) + 'M' + PS(W(6.4, -2.2)) + 'L' + PS(W(19, -0.9)) + 'M' + PS(W(23, 3.8)) + 'Q' + PS(W(40, 2.4)) + ' ' + PS(W(55, 0.9)), null, p.line, 0.55);
  s += E.c(...W(12.2, 3.8), 4.3, p.accent, p.line, 0.7) + E.el(...W(21.5, 5.4), 1.5, 0.8, 166, p.accent);
  s += E.p(p2_sm([W(2, 7.2), W(9, 8.8), W(18, 7.5), W(28, 5.2), W(40, 3.6)]), null, p.hi, 1.2, p2_op(p, 0.7));
  return s;
}

Object.assign(ART, {
  mesosaurus: { vb: [320, 144], fn: artMesosaurus, area: { cx: 166, cy: 70, rx: 150, ry: 42, rot: 0.12 } }
});
