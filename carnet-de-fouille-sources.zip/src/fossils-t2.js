/* ============ fossiles : Trias (Voltzia, Tanystropheus, Plateosaurus) ============ */

/* ---------- aides (préfixe t2_) ---------- */
function t2_fo(p, o) { return 'fill-opacity="' + (p.flat ? 1 : o) + '"'; }
function t2_op(p, o) { return 'opacity="' + (p.flat ? 1 : o) + '"'; }
function t2_ad(a, v, k) { return [a[0] + v[0] * k, a[1] + v[1] * k]; }
function t2_rot(v, a) { const c = Math.cos(a), s = Math.sin(a); return [v[0] * c - v[1] * s, v[0] * s + v[1] * c]; }
function t2_unit(a, b) { const x = b[0] - a[0], y = b[1] - a[1], l = Math.hypot(x, y) || 1; return [x / l, y / l]; }
function t2_dir(a) { return [Math.cos(a), Math.sin(a)]; }
function t2_n(v) { let s = String(Math.round(v * 10) / 10); if (s === '-0') s = '0'; return s.replace(/^(-?)0\./, '$1.'); }
/* chemin compact : commandes relatives au dixième ; on arrondit les points absolus, donc aucune dérive */
function t2_B() {
  let d = '', cx = 0, cy = 0, sx = 0, sy = 0, last = '';
  const R = v => Math.round(v * 10) / 10;
  const nums = a => a.map((v, i) => { const s = t2_n(v); return i && s[0] !== '-' ? ' ' + s : s; }).join('');
  const cmd = (c, a) => { const s = nums(a); d += c === last ? (s[0] === '-' ? '' : ' ') + s : c + s; last = c; };
  const P = {
    M(q) { const x = R(q[0]), y = R(q[1]); if (!d) { d = 'M' + nums([x, y]); last = 'M'; } else { d += 'm' + nums([x - cx, y - cy]); last = 'l'; } cx = sx = x; cy = sy = y; return P; },
    L(q) { const x = R(q[0]), y = R(q[1]); cmd('l', [x - cx, y - cy]); cx = x; cy = y; return P; },
    Q(c, q) { const x = R(q[0]), y = R(q[1]); cmd('q', [R(c[0]) - cx, R(c[1]) - cy, x - cx, y - cy]); cx = x; cy = y; return P; },
    C(c1, c2, q) { const x = R(q[0]), y = R(q[1]); cmd('c', [R(c1[0]) - cx, R(c1[1]) - cy, R(c2[0]) - cx, R(c2[1]) - cy, x - cx, y - cy]); cx = x; cy = y; return P; },
    Z() { d += 'z'; last = 'z'; cx = sx; cy = sy; return P; },
    pl(pts, close) { P.M(pts[0]); for (let i = 1; i < pts.length; i++) P.L(pts[i]); if (close) P.Z(); return P; },
    sm(pts, close) {
      const n = pts.length;
      if (n < 3) return P.pl(pts, close);
      const g = i => (close ? pts[(i + n) % n] : pts[clamp(i, 0, n - 1)]);
      P.M(pts[0]);
      for (let i = 0; i < (close ? n : n - 1); i++) {
        const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2);
        P.C([p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6], [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6], p2);
      }
      if (close) P.Z();
      return P;
    },
    d() { return d; }
  };
  return P;
}
function t2_sm(pts, close) { return t2_B().sm(pts, close).d(); }
function t2_taper(pts, w0, w1, prof) { return t2_sm(taperPts(pts, w0, w1, prof), true); }
/* point à la fraction f de la longueur d'une polyligne à pas régulier (sortie de resample) */
function t2_at(pts, f) { const x = clamp(f, 0, 1) * (pts.length - 1), i = Math.min(pts.length - 2, Math.floor(x)); return lerpPt(pts[i], pts[i + 1], x - i); }
function t2_tan(pts, f) { return tangentAt(pts, Math.round(clamp(f, 0, 1) * (pts.length - 1))); }
/* paquet de sous-chemins de même style, chacun dans son <path> (l'ordre de tracé gère les recouvrements) */
function t2_G(list, fill, stroke, sw, extra) { return E.g(list.map(d => '<path d="' + d + '"/>').join(''), 'fill="' + fill + '"' + (stroke ? ' stroke="' + stroke + '" stroke-width="' + sw + '"' : '') + (extra ? ' ' + extra : '')); }

/* ---------------- Voltzia heterophylla — le conifère du « grès à Voltzia » ----------------
   Fiche anatomique :
   ① pousse feuillée : axe principal un peu sinueux, épais à la base ; quatre rameaux seulement, irréguliers
      (hauteur d'insertion, angle, longueur et courbure tous différents) — rien de la plume régulière de Walchia ;
   ② hétérophyllie : a) écailles courtes, imbriquées, plaquées contre l'axe (bas de la pousse, base de chaque rameau) ;
      b) aiguilles longues (20–30 px), linéaires, falciformes, écartées à ~40° vers la pointe, des deux côtés,
         serrées, raccourcies vers les extrémités ;
   ③ cône femelle lâche au bout d'un rameau : axe visible entre des écailles séminifères plates en éventail
      (pédicelle étroit, bord à 3–5 lobes arrondis), en hélice (trois rangs visibles), plus petites aux deux bouts ;
   ④ film brun (aplat, sans relief) ; le cône, plus ligneux, un ton plus clair. */
/* aiguille falciforme : départ à a0 de l'axe t, pointe ramenée de ~11° vers l'avant */
function t2_needle(B, b, t, sd, L, a0, w) {
  const d0 = t2_rot(t, sd * a0), dm = t2_rot(t, sd * (a0 - 0.2));
  const e = t2_ad(b, dm, L), c = t2_ad(b, d0, L * 0.5), ch = t2_unit(b, e), n = [ch[1], -ch[0]], n0 = [d0[1], -d0[0]];
  return B.M(t2_ad(b, n0, w / 2)).Q(t2_ad(c, n, w * 0.85), e).Q(t2_ad(c, n, -w * 0.85), t2_ad(b, n0, -w / 2)).Z();
}
/* écaille plaquée : ovale pointu, plus large vers la base */
function t2_scaleLeaf(B, b, d, L, w) {
  const n = [d[1], -d[0]], m = t2_ad(b, d, L * 0.32);
  return B.M(t2_ad(b, n, w * 0.35)).Q(t2_ad(m, n, w * 1.15), t2_ad(b, d, L)).Q(t2_ad(m, n, -w * 1.15), t2_ad(b, n, -w * 0.35)).Z();
}
/* écaille séminifère en éventail : pédicelle en b, direction d, rayon R, demi-ouverture phi, nl lobes arrondis */
function t2_fan(B, b, d, R, phi, nl) {
  const nL = [d[1], -d[0]], P = (a, r) => t2_ad(b, t2_rot(d, a), r), st = 2 * phi / nl;
  B.M(t2_ad(b, nL, 1.2)).L(P(-phi, R * 0.74));
  for (let j = 0; j < nl; j++) B.Q(P(-phi + (j + 0.5) * st, R * 1.14), P(-phi + (j + 1) * st, j === nl - 1 ? R * 0.74 : R * 0.86));
  B.L(t2_ad(b, nL, -1.2)).Z();
  for (let j = 1; j < nl; j++) B.M(P((-phi + j * st) * 0.5, R * 0.4)).L(P(-phi + j * st, R * 0.8));
  return B;
}
/* une pousse : aiguilles alternes (un seul chemin, elles ne se croisent pas), tige, écailles imbriquées à la base */
function t2_shoot(pts, o, rnd) {
  const Lb = arcLen(pts), s0 = o.sc * Lb, nd = t2_B(), sc = [];
  const at = s => { const f = clamp(s / Lb, 0, 1); return [t2_at(pts, f), t2_tan(pts, f), lerp(o.w0, o.w1, f) / 2]; };
  for (let s = s0, k = 0; s < Lb - 1; s += o.step, k++) {
    const [q, t, hw] = at(s), sd = k % 2 ? 1 : -1, g = (s - s0) / (Lb - s0);
    const env = Math.min(1, 0.55 + g * 4) * (g > 0.5 ? 1 - (g - 0.5) * 1.1 : 1);
    t2_needle(nd, t2_ad(q, t2_rot(t, sd * Math.PI / 2), hw * 0.7), t, sd, o.Lmax * env * (0.9 + 0.2 * rnd()), (o.a0 - 10 * g) * D2R + (rnd() - 0.5) * 0.06, o.nw);
  }
  /* du haut vers la base : chaque écaille recouvre la base de la suivante */
  for (let s = s0 + 3, j = 0; s > 1; s -= o.ss, j++) {
    const [q, t, hw] = at(s), sd = [1, 0, -1][j % 3];
    const b = t2_ad(t2_ad(q, t2_rot(t, Math.PI / 2), sd * hw * 0.6), t, -1);
    sc.push(t2_scaleLeaf(t2_B(), b, t2_rot(t, sd * 0.3), o.sl, sd ? o.sw : o.sw * 1.25).d());
  }
  return { nd: nd.d(), stem: t2_taper(pts, o.w0, o.w1), sc };
}
function t2_cone(p, cb, cd) {
  const Lc = 54, T = t2_ad(cb, cd, Lc), N = 13, sc = [];
  for (let k = N - 1; k >= 0; k--) {
    const f = 0.03 + 0.92 * k / (N - 1), q = t2_ad(cb, cd, Lc * f), sd = (k % 3) - 1;
    const R = 7 + 12 * Math.sin(Math.PI * (0.14 + 0.78 * f));
    const d = t2_rot(cd, sd ? sd * (64 - 28 * f) * D2R : (k % 2 ? 0.14 : -0.14));
    sc.push(t2_fan(t2_B(), q, d, sd ? R : R * 0.8, 0.58, R > 16 ? 5 : R > 12.5 ? 4 : 3).d());
  }
  return E.p(t2_taper(linePts(cb, T, 8), 3.4, 1.4), p.shade, p.line, 0.6) + t2_G(sc, p.relief, p.line, 0.55);
}
function artVoltzia(p) {
  const rnd = mulberry32(hashStr('voltzia'));
  const A = resample(cubicPts([106, 273], [115, 196], [85, 122], [100, 16], 60), 130);
  const main = t2_shoot(A, { w0: 7.2, w1: 1.6, sc: 0.4, Lmax: 28, a0: 44, step: 3.3, nw: 2.4, ss: 2.6, sl: 8.5, sw: 1.9 }, rnd);
  /* rameaux : [u sur l'axe, angle (°, + = à droite), longueur, courbure (°), aiguille max] */
  const BR = [[0.12, 56, 92, -24, 23], [0.265, -60, 112, 28, 25], [0.47, 42, 68, -6, 21], [0.66, -38, 76, 16, 22]];
  let s = E.p(main.nd, p.body, p.line, 0.45), cone = '';
  BR.forEach((b, i) => {
    const S = t2_at(A, b[0]), d0 = t2_rot(t2_tan(A, b[0]), b[1] * D2R), C = t2_ad(S, d0, b[2] / 2), Eb = t2_ad(C, t2_rot(d0, b[3] * D2R), b[2] / 2);
    const sh = t2_shoot(resample(quadPts(S, C, Eb, 30), Math.round(b[2] / 2)), { w0: 3.4, w1: 1.3, sc: 0.2, Lmax: b[4], a0: 42, step: 3.2, nw: 2.2, ss: 2.5, sl: 7, sw: 1.5 }, rnd);
    s += E.p(sh.nd, p.body, p.line, 0.45) + E.p(sh.stem, p.shade, p.line, 0.6) + t2_G(sh.sc, p.relief, p.line, 0.45);
    if (i === 2) cone = t2_cone(p, Eb, t2_rot(t2_unit(C, Eb), -8 * D2R));
  });
  s += cone + E.p(main.stem, p.shade, p.line, 0.8) + t2_G(main.sc, p.relief, p.line, 0.45);
  /* reflet unique : flanc gauche de l'axe, en haut */
  s += E.p(t2_sm(A.slice(60, 112).map((q, i) => { const t = tangentAt(A, i + 60); return [q[0] + t[1] * 1.2, q[1] - t[0] * 1.2]; })), null, p.hi, 0.9, t2_op(p, 0.6));
  return s;
}

/* ---------------- registre ---------------- */
Object.assign(ART, {
  voltzia: { vb: [220, 280], fn: artVoltzia, area: { cx: 110, cy: 146, rx: 90, ry: 124 } }
});
