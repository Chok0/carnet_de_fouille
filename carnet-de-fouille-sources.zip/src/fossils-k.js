/* ============ fossiles : Crétacé (craie) ============ */

/* opacité : toujours 1 en mode silhouette */
function k_op(p, v) { return 'opacity="' + (p.flat ? 1 : v) + '"'; }
function k_fo(p, v) { return 'fill-opacity="' + (p.flat ? 1 : v) + '"'; }
/* point dans un polygone (lancer de rayon) */
function k_inPoly(pt, poly) {
  let c = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i], b = poly[j];
    if ((a[1] > pt[1]) !== (b[1] > pt[1]) && pt[0] < (b[0] - a[0]) * (pt[1] - a[1]) / (b[1] - a[1]) + a[0]) c = !c;
  }
  return c;
}
/* distance d'un point à un segment */
function k_dSeg(q, a, b) {
  const dx = b[0] - a[0], dy = b[1] - a[1], t = clamp(((q[0] - a[0]) * dx + (q[1] - a[1]) * dy) / (dx * dx + dy * dy || 1), 0, 1);
  return Math.hypot(q[0] - a[0] - dx * t, q[1] - a[1] - dy * t);
}
/* chemin compact : points (h0 = point rond) ou petits segments, en coordonnées relatives */
function k_dots(pts) {
  let d = '', lx = 0, ly = 0;
  pts.forEach((q, i) => {
    const x = r1(q[0]), y = r1(q[1]);
    d += (i ? 'm' + r1(x - lx) + ' ' + r1(y - ly) : 'M' + x + ' ' + y) + 'h0';
    lx = x; ly = y;
  });
  return d;
}
/* polygone rentré de d (vers l'intérieur), décalé de (dx, dy) */
function k_inset(pts, d, dx, dy) {
  const n = pts.length;
  let ar = 0;
  for (let i = 0; i < n; i++) { const a = pts[i], b = pts[(i + 1) % n]; ar += a[0] * b[1] - b[0] * a[1]; }
  const sg = ar > 0 ? 1 : -1;
  return pts.map((q, i) => {
    const a = pts[(i - 1 + n) % n], b = pts[(i + 1) % n];
    let tx = b[0] - a[0], ty = b[1] - a[1];
    const l = Math.hypot(tx, ty) || 1;
    tx /= l; ty /= l;
    return [q[0] - ty * d * sg + (dx || 0), q[1] + tx * d * sg + (dy || 0)];
  });
}
function k_segs(list) {
  let d = '';
  list.forEach(([a, b]) => { const x = r1(a[0]), y = r1(a[1]); d += 'M' + x + ' ' + y + 'l' + r1(b[0] - x) + ' ' + r1(b[1] - y); });
  return d;
}

/* ---------------- micraster — Micraster coranguinum, oursin cœur (vue de dessus, avant en haut) ----------------
   ① test en CŒUR : plus large à l'avant, encoche du sillon antérieur au milieu du bord avant, arrière arrondi
   ② disque apical compact un peu en avant du centre (4 pores génitaux)
   ③ 5 pétales : l'impair (III) droit dans le sillon jusqu'à l'encoche ; paire antérieure (II, IV) longue,
      paire postérieure (I, V) courte ; chaque pétale = feuille enfoncée bordée de deux rangées de pores
      conjugués (fentes transverses) de part et d'autre d'une zone interporifère étroite
   ④ fines granulations sur les interambulacres
   ⑤ petit périprocte ovale au bord postérieur
   Construction : ellipse déformée en œuf (plus large devant) + creux gaussien pour l'encoche ; pétales par
   rotation autour du disque apical ; ombrage de dôme par aplats décalés vers le haut-gauche. */
function artMicraster(p) {
  const cx = 110, cy = 114, a = 90, b = 96, ap = [cx, cy - 13];
  /* échantillonnage resserré vers l'avant (u → f = u − 0,6 sin u) pour dessiner l'encoche */
  const shape = (sc, dx, dy) => {
    const o = [];
    for (let i = 0; i < 56; i++) {
      const u = i / 56 * TAU, f = u - 0.6 * Math.sin(u), c = Math.cos(f), sn = Math.sin(f), w = ((f + Math.PI) % TAU) - Math.PI;
      const x = a * sn * (1 + 0.075 * c), y = -b * c + 14 * Math.exp(-((w / 0.19) ** 2)) * (c > 0 ? 1 : 0);
      o.push([cx + x * sc + dx, cy + y * sc + dy]);
    }
    return o;
  };
  const out = shape(1, 0, 0);
  const topY = out[0][1];
  let s = E.p(smoothD(out, true), p.shade, p.line, 1.5);
  s += E.p(smoothD(shape(0.94, -2.5, -3), true), p.body);
  /* calotte du dôme éclairée en haut à gauche */
  s += E.el(cx - 12, cy - 12, 66, 70, 0, p.relief, null, 0, k_fo(p, 0.45));
  s += E.el(cx - 20, cy - 22, 38, 40, 0, p.relief, null, 0, k_fo(p, 0.55));
  /* sillon antérieur : de l'apex à l'encoche */
  const sul = [[cx - 5, ap[1] - 6], [cx - 9, lerp(ap[1], topY, 0.5)], [cx - 17, topY + 2], [cx + 17, topY + 2], [cx + 9, lerp(ap[1], topY, 0.5)], [cx + 5, ap[1] - 6]];
  s += E.p(smoothD(sul, false) + 'Z', p.shade, null, 0, k_fo(p, 0.5));
  s += E.p(smoothD(sul.slice(0, 3), false), null, p.line, 0.6, k_op(p, 0.6));
  s += E.p(smoothD(sul.slice(3, 5).map(q => [q[0] - 1.5, q[1]]), false), null, p.hi, 0.9, k_op(p, 0.45));
  /* pétales */
  const petals = [[-90, 64, 8.5], [-146, 60, 17], [-34, 60, 17], [126, 46, 15], [54, 46, 15]];
  const axes = [];
  let leafF = '', mid = '', lit = '';
  const pores = [];
  petals.forEach(([deg, L, W]) => {
    const t0 = deg * D2R, d = [Math.cos(t0), Math.sin(t0)], n = [-d[1], d[0]];
    const S = [ap[0] + d[0] * 8, ap[1] + d[1] * 8];
    const h = t => W / 2 * Math.pow(Math.sin(Math.PI * Math.pow(t, 0.8)), 0.7);
    const at = (t, k) => [S[0] + d[0] * L * t + n[0] * k, S[1] + d[1] * L * t + n[1] * k];
    const Lf = [], Rt = [];
    for (let i = 0; i <= 8; i++) { const t = i / 8; Lf.push(at(t, h(t))); Rt.push(at(t, -h(t))); }
    leafF += smoothD(Lf.concat(Rt.reverse().slice(1, -1)), true);
    mid += 'M' + PS(at(0.12, 0)) + 'L' + PS(at(0.9, 0));
    const K = Math.round(L / 2.7);
    for (let k = 0; k < K; k++) {
      const t = (k + 0.7) / (K + 0.4), hh = h(t);
      if (hh < 1.2) continue;
      pores.push([at(t, hh * 0.36), at(t, hh * 0.9)], [at(t, -hh * 0.36), at(t, -hh * 0.9)]);
    }
    const sd = (n[0] * -0.7 + n[1] * -0.7) < 0 ? 1 : -1, lp = [];
    for (let i = 2; i <= 7; i++) { const t = i / 8; lp.push(at(t, sd * h(t) * 0.96)); }
    lit += smoothD(lp, false);
    axes.push([S, at(1, 0), W / 2]);
  });
  /* granulations (grille décalée, hors pétales, sillon et apex) */
  const rnd = mulberry32(hashStr('micraster')), inner = shape(0.93, -1, -1);
  const gr = [];
  for (let y = topY + 4; y < cy + b; y += 6.4) {
    for (let x = cx - a; x < cx + a; x += 6.8) {
      const q = [x + (Math.floor((y - topY) / 6.4) % 2 ? 3.4 : 0) + (rnd() - 0.5) * 2.4, y + (rnd() - 0.5) * 2.4];
      if (!k_inPoly(q, inner)) continue;
      if (Math.hypot(q[0] - ap[0], q[1] - ap[1]) < 13) continue;
      if (Math.abs(q[0] - cx) < 16 && q[1] < ap[1]) continue;
      if (axes.some(([A, B, hw]) => k_dSeg(q, A, B) < hw + 3)) continue;
      gr.push(q);
    }
  }
  s += E.p(k_dots(gr), null, p.shade, 1.5, k_op(p, 0.75));
  s += E.p(leafF, p.shade, p.line, 0.7);
  s += E.p(mid, null, p.body, 2.6);
  s += E.p(k_segs(pores), null, p.line, 0.75);
  s += E.p(lit, null, p.hi, 0.9, k_op(p, 0.6));
  /* disque apical */
  s += E.c(ap[0], ap[1], 7.5, p.relief, p.line, 0.9);
  let gp = '';
  [45, 135, 225, 315].forEach(g => { gp += 'M' + PS([ap[0] + Math.cos(g * D2R) * 4.2, ap[1] + Math.sin(g * D2R) * 4.2]) + 'h0'; });
  s += E.p(gp, null, p.accent, 1.8) + E.c(ap[0], ap[1], 1.4, p.shade);
  /* périprocte au bord arrière */
  const by = cy + b;
  s += E.el(cx, by - 6.5, 6, 7, 0, p.body, p.line, 0.8) + E.el(cx, by - 7, 3.4, 4.6, 0, p.accent);
  /* reflet */
  s += E.p(smoothD(shape(0.8, -4, -2).slice(39, 50), false), null, p.hi, 2.4, k_op(p, 0.7));
  return s;
}

Object.assign(ART, {
  micraster: { vb: [220, 220], fn: artMicraster, area: { cx: 110, cy: 116, rx: 84, ry: 86 } }
});
