/* ============ fossiles : Dévonien (grès rouge) et Carbonifère (schiste houiller) ============ */

/* ---- aides locales (préfixe dc_) ---- */
function dc_op(p, v) { return 'opacity="' + (p.flat ? 1 : v) + '"'; }            // opacité neutralisée en silhouette
function dc_fo(p, v) { return 'fill-opacity="' + (p.flat ? 1 : v) + '"'; }
function dc_dots(pts) { let d = ''; pts.forEach(q => { d += 'M' + PS(q) + 'h0'; }); return d; } // points : traits de longueur nulle, bouts ronds
function dc_mir(pts, cx) { return pts.map(q => [2 * cx - q[0], q[1]]); }
function dc_inPoly(q, poly) {
  let c = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i], b = poly[j];
    if ((a[1] > q[1]) !== (b[1] > q[1]) && q[0] < (b[0] - a[0]) * (q[1] - a[1]) / (b[1] - a[1]) + a[0]) c = !c;
  }
  return c;
}
function dc_inside(q, poly, m) { return dc_inPoly(q, poly) && dc_inPoly([q[0] - m, q[1]], poly) && dc_inPoly([q[0] + m, q[1]], poly) && dc_inPoly([q[0], q[1] - m], poly) && dc_inPoly([q[0], q[1] + m], poly); }
/* points d'une courbe de Catmull-Rom (même courbe que smoothD), n points par tronçon */
function dc_spline(pts, n, close) {
  const m = pts.length, g = i => (close ? pts[(i + m) % m] : pts[clamp(i, 0, m - 1)]);
  let out = [pts[0]];
  for (let i = 0; i < (close ? m : m - 1); i++) {
    const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2);
    out = out.concat(cubicPts(p1, [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6], [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6], p2, n).slice(1));
  }
  return out;
}
/* distance le long du rayon o + t·d jusqu'à la première rencontre d'une polyligne */
function dc_hit(o, d, poly) {
  let best = Infinity;
  for (let i = 0; i < poly.length - 1; i++) {
    const a = poly[i], b = poly[i + 1], ex = b[0] - a[0], ey = b[1] - a[1], den = d[0] * ey - d[1] * ex;
    if (Math.abs(den) < 1e-9) continue;
    const t = ((a[0] - o[0]) * ey - (a[1] - o[1]) * ex) / den, u = ((a[0] - o[0]) * d[1] - (a[1] - o[1]) * d[0]) / den;
    if (t > 1e-6 && u >= 0 && u <= 1 && t < best) best = t;
  }
  return best;
}
function dc_scale(pts, c, k) { return pts.map(q => [c[0] + (q[0] - c[0]) * k, c[1] + (q[1] - c[1]) * k]); }

/* phacops — Phacops rana (vue dorsale)
   ① céphalon semi-elliptique ; glabelle très bombée en poire renversée (étroite derrière, large devant), qui déborde sur le bord frontal, couverte de tubercules ;
   ② grands yeux schizochroaux réniformes de part et d'autre de la glabelle : lentilles rondes, séparées, en files dorso-ventrales (la signature) ;
   ③ angles génaux arrondis, sans pointe ; bourrelet marginal étroit ;
   ④ thorax de 11 segments : lobe axial fort (≈ 1/3 de la largeur), plèvres à sillon oblique, bout arrondi ;
   ⑤ petit pygidium semi-circulaire : rachis de 8 anneaux, 5 côtes pleurales, bordure lisse ;
   ⑥ anneau intercalaire et anneau occipital derrière la glabelle ; joues finement granuleuses. */
function artPhacops(p) {
  const cx = 100, rnd = mulberry32(hashStr('phacops'));
  const N = 11, y0 = 94, sh = 9.2;
  const ax = i => 21.5 - 6 * i / (N - 1), hw = i => 70 - 10 * Math.pow(i / (N - 1), 1.5);
  let s = '';
  /* ④ plèvres, de l'arrière vers l'avant (imbrication) */
  const pleurae = col => {
    let o = '', fur = '';
    for (let i = N - 1; i >= 0; i--) {
      const y = y0 + i * sh, h = hw(i), a = ax(i) - 2;
      o += E.p('M' + r1(cx - a) + ' ' + r1(y) + 'L' + r1(cx - h + 6) + ' ' + r1(y + 0.5) +
        'Q' + r1(cx - h - 1.4) + ' ' + r1(y + 1) + ' ' + r1(cx - h) + ' ' + r1(y + sh * 0.62) +
        'Q' + r1(cx - h + 0.8) + ' ' + r1(y + sh + 2.4) + ' ' + r1(cx - h + 7.5) + ' ' + r1(y + sh + 1.1) +
        'L' + r1(cx - a) + ' ' + r1(y + sh) + 'Z', col, p.line, 0.9);
      fur += 'M' + r1(cx - a - 3) + ' ' + r1(y + sh * 0.3) + 'Q' + r1(cx - (a + h) / 2) + ' ' + r1(y + sh * 0.34) + ' ' + r1(cx - h + 5) + ' ' + r1(y + sh * 0.8);
    }
    return o + E.p(fur, null, p.line, 0.75, dc_op(p, 0.8));
  };
  s += pleurae(p.body) + mirrorG(pleurae(p.body2), cx);
  /* ⑤ pygidium */
  const py = y0 + N * sh;
  const pygF = 'M' + cx + ' ' + r1(py - 1.5) + 'L' + (cx - 57) + ' ' + r1(py - 1.5) + 'C' + (cx - 59) + ' ' + r1(py + 22) + ' ' + (cx - 38) + ' ' + r1(py + 42) + ' ' + cx + ' ' + r1(py + 42) + 'Z';
  const pygO = 'M' + (cx - 57) + ' ' + r1(py - 1.5) + 'C' + (cx - 59) + ' ' + r1(py + 22) + ' ' + (cx - 38) + ' ' + r1(py + 42) + ' ' + cx + ' ' + r1(py + 42);
  const bord = cubicPts([cx - 50, py + 1], [cx - 51, py + 19], [cx - 33, py + 35.5], [cx, py + 35.5], 20);
  let pf = polyD(bord);
  for (let k = 0; k < 5; k++) {
    const ya = py + 3 + k * 6.2, xa = cx - lerp(15, 6, (ya - py) / 34) - 1, e = bord[3 + k * 3];
    pf += 'M' + r1(xa) + ' ' + r1(ya) + 'Q' + r1((xa + e[0]) / 2) + ' ' + r1(ya + 1) + ' ' + PS(e);
  }
  const pyg = col => E.p(pygF, col) + E.p(pf, null, p.line, 0.75, dc_op(p, 0.85)) + E.p(pygO, null, p.line, 1.1);
  s += pyg(p.body) + mirrorG(pyg(p.body2), cx);
  let pr = '';
  for (let k = 0; k < 8; k++) { const y = py + 3.6 + k * 3.9, w = lerp(14.5, 5, (y - py) / 34); pr += 'M' + r1(cx - w) + ' ' + r1(y) + 'Q' + cx + ' ' + r1(y - 1.6) + ' ' + r1(cx + w) + ' ' + r1(y); }
  s += E.p('M' + (cx - 15) + ' ' + r1(py - 1) + 'L' + (cx - 5) + ' ' + r1(py + 33) + 'Q' + cx + ' ' + r1(py + 37) + ' ' + (cx + 5) + ' ' + r1(py + 33) + 'L' + (cx + 15) + ' ' + r1(py - 1) + 'Z', p.relief, p.line, 0.9);
  s += E.p(pr, null, p.line, 0.7);
  /* ④ anneaux axiaux du thorax */
  let rings = '', rhi = '';
  for (let i = 0; i < N; i++) {
    const y = y0 + i * sh, a = ax(i);
    rings += 'M' + r1(cx - a) + ' ' + r1(y + 0.5) + 'Q' + cx + ' ' + r1(y - 3) + ' ' + r1(cx + a) + ' ' + r1(y + 0.5) + 'L' + r1(cx + a - 0.5) + ' ' + r1(y + sh) + 'Q' + cx + ' ' + r1(y + sh - 3) + ' ' + r1(cx - a + 0.5) + ' ' + r1(y + sh) + 'Z';
    rhi += 'M' + r1(cx - a + 3) + ' ' + r1(y + 3.6) + 'L' + r1(cx - a + 8) + ' ' + r1(y + 2.4);
  }
  s += E.p(rings, p.relief, p.line, 0.9) + E.p(rhi, null, p.hi, 1.1, dc_op(p, 0.55));
  /* ① ③ céphalon : bourrelet (relief) puis champ génal */
  const cephL = [[100, 12], [74, 16.4], [51, 29.5], [33.5, 50], [24.5, 74], [23.2, 88], [24.6, 95], [29.5, 98.6], [37.5, 99], [60, 96.4], [81, 94.4], [100, 94]];
  const cephF = smoothD(cephL, false) + 'Z', cephO = smoothD(cephL.slice(0, 11), false);
  const field = [];
  for (let a = 252; a >= 180; a -= 8) field.push([100 + 70.5 * Math.cos(a * D2R), 88 + 69 * Math.sin(a * D2R)]);
  field.push([30.6, 92], [35.5, 93.6], [58, 91.8], [82, 90], [84, 70], [77, 48], [74, 28]);
  const ceph = col => E.p(cephF, p.relief) + E.p(smoothD(field, true), col, p.line, 0.8) + E.p(cephO, null, p.line, 1.2);
  s += ceph(p.body) + mirrorG(ceph(p.body2), cx);
  /* granulation des joues */
  /* œil : demi-ellipse externe (surface visuelle) et interne (lobe palpébral), côté plat contre la glabelle */
  const eyeC = [71.5, 60], ERo = [21, 22.5], ERi = [9.5, 17], a0 = 98 * D2R, a1 = 262 * D2R;
  const eo = a => [eyeC[0] + ERo[0] * Math.cos(a), eyeC[1] + ERo[1] * Math.sin(a)], ei = a => [eyeC[0] + ERi[0] * Math.cos(a), eyeC[1] + ERi[1] * Math.sin(a)];
  const Ro = 24;
  let gran = [];
  for (let gy = 26; gy < 90; gy += 4.6) for (let gx = 28 + (Math.round(gy / 4.6) % 2) * 2.3; gx < 80; gx += 4.6) {
    const q = [gx + (rnd() - 0.5) * 2, gy + (rnd() - 0.5) * 2];
    if (!dc_inside(q, field, 2)) continue;
    if (Math.hypot(q[0] - eyeC[0], q[1] - eyeC[1]) < Ro + 3) continue;
    gran.push(q);
  }
  const granD = dc_dots(gran);
  s += E.p(granD, null, p.relief, 1.5) + mirrorG(E.p(granD, null, p.relief, 1.5), cx);
  /* ② œil schizochroal : surface visuelle en croissant, lobe palpébral, lentilles en files */
  const outer = [], inner = [];
  for (let k = 0; k <= 18; k++) { const a = lerp(a0, a1, k / 18); outer.push(eo(a)); inner.push(ei(a)); }
  const fl = [eyeC[0] + 1.5, eyeC[1]];                                   // sillon palpébral, légèrement bombé vers la glabelle
  let lens = [], glint = [];
  const nf = 13;
  for (let j = 0; j < nf; j++) {
    const a = lerp(a0, a1, (j + 0.5) / nf), A = eo(a), B = ei(a), L = Math.hypot(A[0] - B[0], A[1] - B[1]) - 2.2, n = Math.max(1, Math.round(L / 3.7));
    for (let k = 0; k < n; k++) {
      const t = (1.1 + L * (k + 0.5) / n) / (L + 2.2), q = lerpPt(A, B, t);
      lens.push(q); glint.push([q[0] - 0.5, q[1] - 0.5]);
    }
  }
  const eye = E.p(smoothD(outer, false) + 'Q' + PS(fl) + ' ' + PS(outer[0]) + 'Z', p.relief, p.line, 0.9) +
    E.p(smoothD(outer.concat(inner.slice().reverse()), true), p.accent, p.line, 0.9) +
    E.p(dc_dots(lens), null, p.relief, 2.9) + E.p(dc_dots(glint), null, p.hi, 1, dc_op(p, 0.75)) +
    E.p(polyD(inner.slice(5, 11).map(q => [q[0] + 2.2, q[1]])), null, p.hi, 1, dc_op(p, 0.5));
  s += eye + mirrorG(eye, cx);
  /* ⑥ anneau intercalaire, anneau occipital */
  s += E.p('M' + (cx - 21) + ' 81Q' + cx + ' 78 ' + (cx + 21) + ' 81L' + (cx + 21.5) + ' 94.4Q' + cx + ' 91.6 ' + (cx - 21.5) + ' 94.4Z', p.relief, p.line, 0.9);
  s += E.p('M' + (cx - 18) + ' 71.5Q' + cx + ' 69 ' + (cx + 18) + ' 71.5L' + (cx + 18.5) + ' 80Q' + cx + ' 77.5 ' + (cx - 18.5) + ' 80Z', p.relief, p.line, 0.9);
  s += E.p('M' + (cx - 15.5) + ' 75.6l4 -1.2M' + (cx + 15.5) + ' 75.6l-4 -1.2', null, p.line, 0.7);
  /* ① glabelle en poire renversée + tubercules */
  const glL = [[100, 12.2], [86, 13.4], [74, 19], [67.4, 29], [67.6, 41], [72.5, 53], [79.5, 64], [83.5, 71.5]];
  const glP = glL.slice().reverse().concat(dc_mir(glL, cx).slice(1));
  s += E.p(smoothD(glP, false) + 'Q' + cx + ' 74 ' + PS(glP[0]), p.relief, p.line, 1.1);
  const tb = [], tbh = [], tbs = [];
  for (let gy = 17; gy < 70; gy += 5.4) for (let gx = 66 + (Math.round(gy / 5.4) % 2) * 2.7; gx < 135; gx += 5.4) {
    const q = [gx + (rnd() - 0.5) * 1.8, gy + (rnd() - 0.5) * 1.8];
    if (!dc_inside(q, glP, 2.6)) continue;
    tb.push(q); tbs.push([q[0] + 0.6, q[1] + 0.7]); tbh.push([q[0] - 0.5, q[1] - 0.6]);
  }
  s += E.p(dc_dots(tbs), null, p.shade, 3.4, dc_op(p, 0.8)) + E.p(dc_dots(tb), null, p.relief, 2.7) + E.p(dc_dots(tbh), null, p.hi, 1, dc_op(p, 0.6));
  /* reflet unique */
  s += E.p('M71 44Q67 28 80 18.5', null, p.hi, 1.8, dc_op(p, 0.7));
  return s;
}

/* mucrospirifer — Mucrospirifer mucronatus, « hirondelle de pierre » (valve brachiale vue de dessus)
   ① charnière droite très longue, prolongée en ailes pointues (mucrons) : c'est la plus grande largeur ;
   ② contour : des pointes des ailes, bord légèrement concave puis épaule arrondie jusqu'au bord frontal arrondi (silhouette d'hirondelle) ;
   ③ pli médian lisse, du crochet au bord frontal, qui s'élargit vers l'avant (et avance un peu le bord : languette) ;
   ④ côtes simples rayonnantes (14 de chaque côté) en éventail depuis le crochet, les dernières presque parallèles à la charnière ;
   ⑤ lignes de croissance concentriques (homothéties du contour) qui recoupent les côtes, serrées vers le bord ;
   ⑥ crochet de la valve pédonculaire et interarea triangulaire basse au-dessus de la charnière, delthyrium sombre au milieu.
   Symétrie miroir exacte. */
function artMucrospirifer(p) {
  const cx = 150, U = [150, 42];
  const ctl = [[10, 42], [32, 46.5], [49, 53], [60, 62], [66, 76], [72, 100], [88, 127], [114, 145], [150, 152]];
  const full = ctl.concat(dc_mir(ctl, cx).reverse().slice(1)), fullP = dc_spline(full, 8);
  const outL = fullP.slice(0, 8 * 8 + 1), valve = outL.concat([U]);
  const dir = f => [-Math.sin(f * D2R), Math.cos(f * D2R)], at = (f, r) => [U[0] + dir(f)[0] * r, U[1] + dir(f)[1] * r];
  const R = f => dc_hit(U, dir(f), fullP);
  let s = '';
  /* ⑥ interarea, delthyrium, crochet */
  let ia = '';
  for (let k = 1; k <= 3; k++) ia += 'M12 42L' + cx + ' ' + r1(42 - 12 * k / 4) + 'L288 42';
  for (let x = 30; x < 140; x += 7) { const h = 12 * (x - 10) / 140; ia += 'M' + x + ' 42v' + r1(-h * 0.85) + 'M' + (300 - x) + ' 42v' + r1(-h * 0.85); }
  s += E.p('M10 42L' + cx + ' 29L290 42Z', p.shade, p.line, 0.9) + E.p(ia, null, p.line, 0.5, dc_op(p, 0.55));
  s += E.p('M' + cx + ' 27L141 42.5L159 42.5Z', p.accent, p.line, 0.8);
  s += E.p('M141.5 31Q143 18 150 16.5Q157 18 158.5 31Q150 26 141.5 31Z', p.relief, p.line, 1);
  s += E.p('M144.5 26Q146 20 150 19', null, p.hi, 1, dc_op(p, 0.6));
  /* ④ côtes : fond clair, sillons sombres en coins qui s'élargissent vers le bord */
  const NF = 15, f0 = 8.6, f1 = 86.5, dF = (f1 - f0) / (NF - 1);
  const half = (furrow) => {
    let o = E.p(polyD(valve, true), p.relief), fw = '';
    for (let j = 0; j < NF; j++) {
      const f = f0 + j * dF, h = (j === 0 ? 0.3 : 0.2) * dF, st = at(f, j === 0 ? 3 : 8);
      fw += 'M' + PS(st) + 'L' + PS(at(f - h, R(f - h) + 0.5)) + 'L' + PS(at(f + h, R(f + h) + 0.5)) + 'Z';
    }
    return o + E.p(fw, furrow);
  };
  function GS(k) { return 1 - 0.82 * Math.pow(1 - k / 13, 2); }
  s += half(p.body) + mirrorG(half(p.body2) + E.p(polyD(valve, true), p.shade, null, 0, dc_op(p, 0.12)), cx);
  /* ⑤ lignes de croissance : copies homothétiques du contour, resserrées vers le bord (sur toute la largeur) */
  let gl = '';
  for (let k = 3; k < 13; k++) gl += smoothD(dc_scale(full, U, GS(k)), false);
  s += E.p(gl, null, p.line, 0.5, dc_op(p, 0.6));
  /* ③ pli médian lisse (bombé : flanc droit un peu plus sombre) */
  const fr = R(0) + 2.5, fold = [U, at(7.2, R(7.2) + 0.6), [cx, U[1] + fr], at(-7.2, R(-7.2) + 0.6)];
  s += E.p('M' + PS(U) + 'L' + PS(fold[1]) + 'Q' + PS([cx, U[1] + fr + 1]) + ' ' + PS(fold[3]) + 'Z', p.relief, p.line, 0.8);
  s += E.p('M' + PS(U) + 'L' + PS([cx + 3, U[1] + fr]) + 'Q' + PS([cx + 9, U[1] + fr]) + ' ' + PS(fold[3]) + 'Z', p.shade, null, 0, dc_op(p, 0.12));
  let fg = '';
  for (let k = 3; k < 13; k++) {
    const sc = GS(k), a = at(7.2, R(7.2) * sc), b = at(-7.2, R(-7.2) * sc);
    fg += 'M' + PS(a) + 'Q' + PS([cx, U[1] + (fr + 3) * sc]) + ' ' + PS(b);
  }
  s += E.p(fg, null, p.line, 0.5, dc_op(p, 0.6));
  s += E.p(smoothD(full, false) + 'M10 42H290', null, p.line, 1.2);
  /* reflet unique */
  s += E.p('M' + PS(at(24, 40)) + 'Q' + PS(at(40, 62)) + ' ' + PS(at(58, 70)), null, p.hi, 1.8, dc_op(p, 0.65));
  return s;
}

/* manticoceras — Manticoceras sinuosum, goniatite (vue latérale, moule interne poli)
   ① enroulement involute : le dernier tour recouvre tous les autres, spirale logarithmique rapide (×1,8 par tour), ombilic étroit au centre ;
   ② coquille lisse, fines stries de croissance sinueuses (biconvexes, sinus ventral) ;
   ③ lignes de suture goniatitiques tous les 25° : chaque ligne traverse le tour de l'ombilic au bord ventral en zigzag
      (selles arrondies vers l'ouverture, lobes pointus en V vers l'apex), mise à l'échelle du tour — construction par rotation ;
   ④ chambre d'habitation sur le dernier quart de tour, sans sutures, terminée par l'ouverture (marche du contour) ;
   ⑤ aspect « coupe polie » : surface claire et lisse, sutures nettes, reflet unique en arc. */
function artManticoceras(p) {
  const W = 1.8, ue = 0.13, TE = -24 * D2R;
  const ro = th => Math.pow(W, th / TAU);                                   // th ≤ 0 ; 0 = ouverture
  let bb = [1e9, 1e9, -1e9, -1e9];
  for (let i = 0; i <= 240; i++) { const th = -TAU * i / 240, r = ro(th), x = r * Math.cos(th + TE), y = r * Math.sin(th + TE); bb = [Math.min(bb[0], x), Math.min(bb[1], y), Math.max(bb[2], x), Math.max(bb[3], y)]; }
  const R = 200 / Math.max(bb[2] - bb[0], bb[3] - bb[1]), C = [110 - (bb[0] + bb[2]) / 2 * R, 110 - (bb[1] + bb[3]) / 2 * R];
  const P = (rad, th) => [C[0] + rad * Math.cos(th + TE), C[1] + rad * Math.sin(th + TE)];
  const rO = th => R * ro(th), rU = th => ue * R * ro(th);
  /* point du tour : u ∈ [0,1] de l'ombilic au ventre, décalage tangentiel v en % de la largeur du flanc */
  const angOf = (th, u, v) => {                                           // angle réel du point (décalage tangentiel ∝ rayon local)
    let t2 = th;
    for (let k = 0; k < 3; k++) { const F = rO(t2) - rU(t2), rho = rU(t2) + F * u; t2 = th + v * F / 100 * (0.35 + 0.65 * rho / rO(t2)) / rho; }
    return t2;
  };
  const onWhorl = (th, u, v) => { const t2 = angOf(th, u, v); return P(rU(t2) + (rO(t2) - rU(t2)) * u, t2); };
  /* profil de suture : selles larges et arrondies (+), lobes étroits et pointus (−) */
  const SX = [[0, 0], [0.08, 2.5], [0.17, -4.5], [0.35, 8.5], [0.53, -17], [0.73, 9.5], [0.9, -12], [1, 0]];
  const sut = [];
  for (let i = 0; i < SX.length - 1; i++) {
    const a = SX[i], b = SX[i + 1];
    for (let j = 0; j < 7; j++) {
      const t = j / 7, u = lerp(a[0], b[0], t);
      sut.push([u, a[1] > b[1] ? a[1] + (b[1] - a[1]) * Math.pow(t, 3.2) : b[1] + (a[1] - b[1]) * Math.pow(1 - t, 3.2)]);
    }
  }
  sut.push(SX[SX.length - 1]);
  const grow = u => 3 * Math.sin(Math.PI * u * 1.2) - 3 * Math.sin(Math.PI * u * 2.4) - 5 * Math.pow(u, 4);   // strie biconvexe, sinus ventral
  const growPts = (th, u0) => { const o = []; for (let i = 0; i <= 10; i++) { const u = lerp(u0, 1, i / 10); o.push(onWhorl(th, u, grow(u))); } return o; };
  /* ① contour : spirale du dernier tour jusqu'au ventre de l'ouverture, puis l'ouverture jusqu'au tour précédent */
  const thV = angOf(0, 1, grow(1)), out = [];
  for (let i = 0; i <= 120; i++) { const th = lerp(-TAU, thV, i / 120); out.push(P(rO(th), th)); }
  const uStep = (R / W - rU(0)) / (R - rU(0));
  const apOut = growPts(0, uStep).reverse();
  let s = E.p(polyD(out.concat(apOut.slice(1)), true), p.relief, p.line, 1.5);
  /* ombre du ventre (bas-droite), éclairage haut-gauche */
  const band = (a1, a2) => {
    const o = [], iN = [];
    for (let i = 0; i <= 30; i++) { const th = lerp(a1, a2, i / 30); o.push(P(rO(th) - 0.8, th)); iN.push(P(lerp(rU(th), rO(th), 1 - 0.24 * Math.sin(Math.PI * i / 30)), th)); }
    return polyD(o.concat(iN.reverse()), true);
  };
  const shadeFrom = -TAU + ((0.2 - TE) % TAU + TAU) % TAU;
  s += E.p(band(shadeFrom, Math.min(-0.05, shadeFrom + 2.4)), p.shade, null, 0, dc_op(p, 0.25));
  /* ③ sutures, par rotation tous les 25° sur le phragmocône */
  let sd = '';
  for (let th = -93 * D2R; th > -TAU + 8 * D2R; th -= 25 * D2R) sd += polyD(sut.map(q => onWhorl(th, q[0], q[1])));
  s += E.p(sd, null, p.line, 1.1);
  /* ② ④ chambre d'habitation : stries de croissance sinueuses, ouverture */
  let gd = '';
  for (let th = -84 * D2R; th < -3 * D2R; th += 6 * D2R) gd += polyD(growPts(th, 0.22));
  s += E.p(gd, null, p.line, 0.5, dc_op(p, 0.45));
  s += E.p(polyD(growPts(0, 0)), null, p.line, 1.4);
  /* ① ombilic étroit */
  const um = [];
  for (let i = 0; i <= 40; i++) { const th = -TAU + TAU * i / 40; um.push(P(rU(th), th)); }
  s += E.p(polyD(um, true), p.accent, p.line, 0.9);
  let inner = '';
  for (let i = 0; i <= 30; i++) { const th = -TAU * 2 + TAU * i / 30; inner += (i ? 'L' : 'M') + PS(P(rU(th) * 1.1, th)); }
  s += E.p(inner, null, p.shade, 1.1);
  /* reflet unique */
  let hl = '';
  const hl0 = -TAU + ((3.3 - TE) % TAU + TAU) % TAU;
  for (let th = hl0; th <= Math.min(-0.1, hl0 + 1.25); th += 0.05) hl += (hl ? 'L' : 'M') + PS(P(lerp(rU(th), rO(th), 0.86), th));
  s += E.p(hl, null, p.hi, 2.2, dc_op(p, 0.7));
  return s;
}

/* ============ registre ============ */
Object.assign(ART, {
  phacops: { vb: [200, 250], fn: artPhacops, area: { cx: 100, cy: 125, rx: 72, ry: 110 } },
  mucrospirifer: { vb: [300, 170], fn: artMucrospirifer, area: { cx: 150, cy: 86, rx: 116, ry: 62 } },
  manticoceras: { vb: [220, 220], fn: artManticoceras, area: { cx: 110, cy: 110, rx: 92, ry: 92 } }
});
