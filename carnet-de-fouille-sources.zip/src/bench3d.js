/* ============ l'établi en 3D : une pierre à l'encre qu'on tourne, qu'on tapote et qu'on fend ============
   Plusieurs fils par pierre (feuillets parallèles, parfois un joint oblique ; les roches massives n'ont que des joints).
   Chaque fil cache un contenu décidé par le jeu (os, veine, géode, rien) ; on l'entend en tapotant.
   Une seule ouverture : le jeu dit ce qui sort (onSplit), l'établi dessine la face ouverte et joue la cassure.
   Tout reste dans cette fermeture (le jeu est concaténé dans un seul script). */
const Bench3D = (function () {
  const T3 = () => window.THREE;
  /* ---------- bruit 3D ---------- */
  function h3(x, y, z, s) { return hash2(x + Math.imul(z | 0, 7919), y - Math.imul(z | 0, 104729), s); }
  function noise3(x, y, z, s) {
    const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z), xf = x - xi, yf = y - yi, zf = z - zi;
    const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf), w = zf * zf * (3 - 2 * zf), L = (a, b, t) => a + (b - a) * t;
    const c = (i, j, k) => h3(xi + i, yi + j, zi + k, s);
    return L(L(L(c(0, 0, 0), c(1, 0, 0), u), L(c(0, 1, 0), c(1, 1, 0), u), v), L(L(c(0, 0, 1), c(1, 0, 1), u), L(c(0, 1, 1), c(1, 1, 1), u), v), w);
  }
  const easeOutCubic = k => 1 - Math.pow(1 - k, 3);
  const easeOutBack = k => { const c1 = 1.9, c3 = c1 + 1; return 1 + c3 * Math.pow(k - 1, 3) + c1 * Math.pow(k - 1, 2); };

  /* ---------- shaders : trois aplats lissés, litage, fils usés, taches, faces de cassure ---------- */
  const VERT = `
    varying vec3 vLocal; varying vec3 vNormalV;
    #include <clipping_planes_pars_vertex>
    void main(){
      vLocal = position;
      vNormalV = normalize(normalMatrix * normal);
      vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
      gl_Position = projectionMatrix * mvPosition;
      #include <clipping_planes_vertex>
    }`;
  const FRAG = `
    uniform vec3 uBase, uLight, uShade, uInk, uTex, uFace, uFaceShade, uLightDir, uBed;
    uniform float uSeed, uBedOn, uVis;
    uniform vec4 uPl[4]; uniform float uPlK[4];
    uniform vec4 uSpots[8]; uniform float uSpotType[8];
    uniform vec4 uReveal[32];
    uniform float uGlow[4]; uniform float uTime; uniform vec4 uMarks[6];
    varying vec3 vLocal; varying vec3 vNormalV;
    #include <clipping_planes_pars_fragment>
    float h3(vec3 p){ p = fract(p * 0.3183099 + vec3(0.71, 0.113, 0.419)); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
    float n3(vec3 x){ vec3 i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f);
      return mix(mix(mix(h3(i), h3(i + vec3(1,0,0)), f.x), mix(h3(i + vec3(0,1,0)), h3(i + vec3(1,1,0)), f.x), f.y),
                 mix(mix(h3(i + vec3(0,0,1)), h3(i + vec3(1,0,1)), f.x), mix(h3(i + vec3(0,1,1)), h3(i + vec3(1,1,1)), f.x), f.y), f.z); }
    float aa(float e, float x){ float w = fwidth(x) * 0.85 + 1e-5; return smoothstep(e - w, e + w, x); }
    void main(){
      #include <clipping_planes_fragment>
      if (!gl_FrontFacing) {
        float g = n3(vLocal * 18.0 + uSeed) * 0.5 + n3(vLocal * 40.0) * 0.5;
        gl_FragColor = vec4(mix(uFaceShade, uFace, smoothstep(0.25, 0.75, g) * 0.6 + 0.4), 1.0);
        return;
      }
      vec3 nv = normalize(vNormalV);
      float l = dot(nv, normalize(uLightDir));
      vec3 c = mix(uShade, uBase, aa(0.05, l));
      c = mix(c, uLight, aa(0.55, l));
      float sb = dot(vLocal, uBed);
      float band = sin(sb * 70.0 + n3(vLocal * 3.0 + uSeed) * 6.0);
      float brk = smoothstep(0.4, 0.52, n3(vLocal * 6.0 + uSeed * 1.7));
      c = mix(c, uTex, 0.15 * uBedOn * smoothstep(0.78, 0.97, band) * brk);
      c = mix(c, uTex, 0.13 * aa(0.82, n3(vLocal * 36.0 + uSeed)));
      c = mix(c, uLight, 0.10 * aa(0.88, n3(vLocal * 31.0 + 7.0)));
      for (int i = 0; i < 8; i++) {
        vec4 sp = uSpots[i]; if (sp.w <= 0.0) continue;
        float d = distance(vLocal, sp.xyz) / sp.w;
        float edge = 1.0 + (n3(vLocal * 14.0 + float(i) * 3.1) - 0.5) * 0.6;
        if (uSpotType[i] < 0.5) { c = mix(c, vec3(0.20, 0.14, 0.09), 0.5 * (1.0 - smoothstep(0.5 * edge, 1.0 * edge, d))); }
        else if (uSpotType[i] < 1.5) { float m = n3(vLocal * 22.0 + float(i)); c = mix(c, mix(vec3(0.62, 0.30, 0.10), vec3(0.78, 0.48, 0.18), m), 0.65 * (1.0 - smoothstep(0.35 * edge, 1.0 * edge, d))); }
        else { float dots = aa(0.55, n3(vLocal * 26.0 + float(i))); c = mix(c, vec3(0.78, 0.80, 0.64), 0.85 * dots * (1.0 - smoothstep(0.6 * edge, 1.0 * edge, d))); }
      }
      float rv = 0.0;
      for (int i = 0; i < 32; i++) { vec4 r = uReveal[i]; if (r.w <= 0.0) continue; rv = max(rv, 1.0 - smoothstep(r.w * 0.45, r.w, distance(vLocal, r.xyz))); }
      for (int i = 0; i < 4; i++) {
        if (uPlK[i] < 0.5) continue;
        float s = dot(vLocal, uPl[i].xyz) - uPl[i].w;
        float joint = step(1.5, uPlK[i]);
        float th = mix(0.57, 0.52, joint) - uVis;
        float vis = smoothstep(th, th + 0.1, n3(vLocal * 2.4 + uSeed * 0.37 + float(i) * 5.3));
        vis = max(vis, rv);
        float wob = (n3(vLocal * 22.0 + float(i) * 2.0) - 0.5) * 0.006;
        float fw = fwidth(s);
        float lw = mix(0.0045, 0.0065, joint);
        /* tutoriel : le fil à écouter s'éclaire d'un halo doré qui pulse */
        if (uGlow[i] > 0.0) { vis = 1.0; float pulse = 0.6 + 0.4 * sin(uTime * 4.0), ds = abs(s + wob); c = mix(c, vec3(1.0, 0.86, 0.42), uGlow[i] * pulse * 0.55 * (1.0 - smoothstep(0.02, 0.05 + fw * 2.0, ds))); c = mix(c, vec3(1.0, 0.72, 0.12), uGlow[i] * (0.7 + 0.3 * pulse) * (1.0 - smoothstep(0.008, 0.02 + fw * 1.5, ds))); }
        c = mix(c, uLight, 0.7 * vis * (1.0 - smoothstep(0.003, 0.003 + fw * 1.4 + 0.002, abs(s + 0.013 + wob))));
        c = mix(c, uInk, 0.95 * vis * (1.0 - smoothstep(lw - fw * 0.7, lw + fw * 0.9, abs(s + wob))));
      }
      /* tutoriel : des marques dorées le long du fil mènent au cœur */
      for (int i = 0; i < 6; i++) {
        vec4 m = uMarks[i]; if (m.w <= 0.0) continue;
        float d = distance(vLocal, m.xyz), fwd = fwidth(d) * 1.5 + 0.003;
        float ring = 1.0 - smoothstep(m.w * 0.16, m.w * 0.16 + fwd, abs(d - m.w * 0.72));
        float dotm = 1.0 - smoothstep(m.w * 0.3, m.w * 0.3 + fwd, d);
        float pulse = 0.6 + 0.4 * sin(uTime * 5.0 - float(i) * 0.9);
        c = mix(c, vec3(0.16, 0.1, 0.04), 0.5 * ring);
        c = mix(c, vec3(1.0, 0.8, 0.26), clamp(ring * 0.9 + dotm * 0.8, 0.0, 1.0) * pulse);
      }
      gl_FragColor = vec4(c, 1.0);
    }`;
  const HULL_V = `
    #include <clipping_planes_pars_vertex>
    void main(){ vec3 p = position + normal * 0.022; vec4 mvPosition = modelViewMatrix * vec4(p, 1.0); gl_Position = projectionMatrix * mvPosition;
    #include <clipping_planes_vertex>
    }`;
  const HULL_F = `
    uniform vec3 uInk;
    #include <clipping_planes_pars_fragment>
    void main(){
    #include <clipping_planes_fragment>
    gl_FragColor = vec4(uInk, 1.0); }`;

  /* ---------- géométrie ---------- */
  function mergeVerts(geo) {
    const THREE = T3(), pos = geo.attributes.position, map = new Map(), verts = [], idx = [];
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i), k = Math.round(x * 1e4) + ',' + Math.round(y * 1e4) + ',' + Math.round(z * 1e4);
      let j = map.get(k);
      if (j === undefined) { j = verts.length / 3; map.set(k, j); verts.push(x, y, z); }
      idx.push(j);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    g.setIndex(idx);
    return g;
  }
  function basis(N) {
    const THREE = T3(), ref = Math.abs(N.x) < 0.9 ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(0, 0, 1);
    const U = ref.projectOnPlane(N).normalize(), W = new THREE.Vector3().crossVectors(N, U);
    return { U, W };
  }
  /* coupe plan / maillage : le contour fermé de la face qui apparaîtra à l'ouverture */
  function sliceContour(geo, N, D, U, W) {
    const THREE = T3(), pos = geo.attributes.position.array, ix = geo.index.array, n = pos.length / 3;
    const sd = new Float64Array(n);
    for (let i = 0; i < n; i++) { let s = pos[i * 3] * N.x + pos[i * 3 + 1] * N.y + pos[i * 3 + 2] * N.z - D; if (s === 0) s = 1e-9; sd[i] = s; }
    const pt = new Map(), adj = new Map();
    const ek = (a, b) => (a < b ? a * n + b : b * n + a);
    const cross = (a, b) => {
      const k = ek(a, b);
      if (!pt.has(k)) { const t = sd[a] / (sd[a] - sd[b]); pt.set(k, new THREE.Vector3(pos[a * 3] + (pos[b * 3] - pos[a * 3]) * t, pos[a * 3 + 1] + (pos[b * 3 + 1] - pos[a * 3 + 1]) * t, pos[a * 3 + 2] + (pos[b * 3 + 2] - pos[a * 3 + 2]) * t)); }
      return k;
    };
    const link = (a, b) => { (adj.get(a) || adj.set(a, []).get(a)).push(b); (adj.get(b) || adj.set(b, []).get(b)).push(a); };
    for (let t = 0; t < ix.length; t += 3) {
      const a = ix[t], b = ix[t + 1], c = ix[t + 2], ks = [];
      if (sd[a] * sd[b] < 0) ks.push(cross(a, b));
      if (sd[b] * sd[c] < 0) ks.push(cross(b, c));
      if (sd[c] * sd[a] < 0) ks.push(cross(c, a));
      if (ks.length === 2) link(ks[0], ks[1]);
    }
    const seen = new Set(); let best = [];
    for (const start of adj.keys()) {
      if (seen.has(start)) continue;
      const loop = []; let prev = -1, cur = start;
      while (cur !== undefined && !seen.has(cur)) { seen.add(cur); loop.push(cur); const nb = adj.get(cur); const nx = nb.find(x => x !== prev && !seen.has(x)); prev = cur; cur = nx; }
      if (loop.length > best.length) best = loop;
    }
    const pts = best.map(k => { const p = pt.get(k); return p.sub(N.clone().multiplyScalar(p.dot(N) - D)); });
    const uw = pts.map(p => [p.dot(U), p.dot(W)]);
    let u0 = 1e9, u1 = -1e9, w0 = 1e9, w1 = -1e9;
    for (const [u, w] of uw) { u0 = Math.min(u0, u); u1 = Math.max(u1, u); w0 = Math.min(w0, w); w1 = Math.max(w1, w); }
    return { pts, uw, bb: [u0, u1, w0, w1] };
  }
  function inPoly(u, w, poly) { let ins = false; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) { const [ui, wi] = poly[i], [uj, wj] = poly[j]; if ((wi > w) !== (wj > w) && u < (uj - ui) * (w - wi) / (wj - wi) + ui) ins = !ins; } return ins; }
  function segDist(u, w, a0, b0, a1, b1) { const du = a1 - a0, dw = b1 - b0, L = du * du + dw * dw || 1e-9; const t = clamp(((u - a0) * du + (w - b0) * dw) / L, 0, 1); return Math.hypot(u - a0 - du * t, w - b0 - dw * t); }
  function edgeDist(u, w, poly) { let m = 1e9; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) m = Math.min(m, segDist(u, w, poly[j][0], poly[j][1], poly[i][0], poly[i][1])); return m; }
  const RADIUS = { os: [0.42, 0.55], unique: [0.5, 0.62], geode: [0.45, 0.56] };
  /* le tak hors fil : le son seul (pari du lot 1, moins de bruit visuel) ; true pour revoir l'onomatopée */
  const SHOW_TAK = true;
  /* la fatigue de la pierre rogne la qualité de tout ce qu'on ouvre : qualité = proximité × (1 − FATK × fatigue) */
  const FATK = 0.5;
  /* où repose le contenu d'un fil, dans sa face */
  function placeContent(pl, rnd) {
    const C = pl.C, poly = pl.contour.uw, [u0, u1, w0, w1] = pl.contour.bb;
    if (C.type === 'geode') {
      let su = 0, sw = 0; poly.forEach(([u, w]) => { su += u; sw += w; }); C.u = su / poly.length; C.w = sw / poly.length;
      C.r = 0.7 * Math.min(u1 - u0, w1 - w0) / 2; C.ang = rnd() * TAU; C.cut = rnd() * TAU; C.dmin = edgeDist(C.u, C.w, poly);
    } else if (RADIUS[C.type]) {
      let r = RADIUS[C.type][0] + rnd() * (RADIUS[C.type][1] - RADIUS[C.type][0]), pick = null;
      for (let tries = 0; tries < 6 && !pick; tries++) {
        const ok = [];
        for (let i = 0; i < 80; i++) { const u = u0 + rnd() * (u1 - u0), w = w0 + rnd() * (w1 - w0); if (inPoly(u, w, poly) && edgeDist(u, w, poly) >= r * 0.95) ok.push([u, w]); }
        if (ok.length) pick = ok[Math.floor(rnd() * ok.length)]; else r *= 0.85;
      }
      if (!pick) pick = [(u0 + u1) / 2, (w0 + w1) / 2];
      C.u = pick[0]; C.w = pick[1]; C.r = r; C.ang = rnd() * TAU; C.cut = rnd() * TAU;
      /* le point de la surface le plus proche de l'os : c'est là que le POK est le plus gros, et là qu'il faut frapper */
      C.dmin = edgeDist(C.u, C.w, poly);
    } else if (C.type === 'veine') {
      const ia = Math.floor(rnd() * poly.length), [ua, wa] = poly[ia];
      const cu = (u0 + u1) / 2, cw = (w0 + w1) / 2, a = Math.atan2(cw - wa, cu - ua) + (rnd() - 0.5) * 0.9, len = 0.5 + rnd() * 0.5;
      C.ia = ia; C.ua = ua; C.wa = wa; C.ub = ua + Math.cos(a) * len; C.wb = wa + Math.sin(a) * len; C.wid = 0.05 + rnd() * 0.035;
    }
  }
  function makeStone(spec) {
    const THREE = T3(), rnd = mulberry32(spec.seed), S = new THREE.Vector3(1.32 + rnd() * 0.18, 0.66 + rnd() * 0.14, 0.95 + rnd() * 0.15);
    const ns = spec.seed % 997, shape = spec.shape || 'round';
    if (shape === 'nodule') S.set(1.02 + rnd() * 0.08, 0.86 + rnd() * 0.06, 0.94 + rnd() * 0.06);
    const geo = mergeVerts(new THREE.IcosahedronGeometry(1, 5));
    const p = geo.attributes.position, v = new THREE.Vector3();
    const rough = shape === 'angular' ? 0.44 : shape === 'nodule' ? 0.12 : 0.32, flat = shape === 'slab' ? 1.18 : 1;
    for (let i = 0; i < p.count; i++) {
      v.fromBufferAttribute(p, i).normalize();
      let r = 1 + (noise3(v.x * 1.6 + 3, v.y * 1.6 + 5, v.z * 1.6 + 7, ns) - 0.5) * rough + (noise3(v.x * 4.5, v.y * 4.5, v.z * 4.5, ns + 9) - 0.5) * (shape === 'nodule' ? 0.16 : 0.08);
      r *= 1 - 0.06 * Math.pow(Math.abs(v.y), 6);
      p.setXYZ(i, v.x * r * S.x, v.y * r * S.y / flat, v.z * r * S.z);
    }
    geo.computeVertexNormals();
    S.y /= flat;
    const N = new THREE.Vector3((rnd() - 0.5) * 0.5, 1, (rnd() - 0.5) * 0.5).normalize();
    const contents = spec.contents, planes = [];
    /* feuillets : un écart minimal garanti (les gros doigts doivent savoir quel fil ils frappent), mais des places tirées au hasard,
       et chaque feuillet légèrement de biais : pas de fils au gabarit */
    const nBed = spec.bedded ? contents.filter(c => !c.joint).length : 0, lim = (0.42 + rnd() * 0.12) * S.y, ds = [];
    const minGap = Math.min(0.2, lim * 2 / Math.max(1, nBed) * 0.72);
    for (let t = 0; ds.length < nBed && t < 600; t++) { const d = (rnd() * 2 - 1) * lim; if (ds.every(x => Math.abs(x - d) >= minGap)) ds.push(d); }
    if (ds.length < nBed) { ds.length = 0; const gap = lim * 2 / nBed; for (let i = 0; i < nBed; i++) ds.push(-lim + (i + 0.5) * gap + (rnd() - 0.5) * gap * 0.25); }
    const tilt = () => { const b = basis(N), a = rnd() * TAU, s = (rnd() - 0.5) * 0.07; return N.clone().addScaledVector(b.U, Math.cos(a) * s).addScaledVector(b.W, Math.sin(a) * s).normalize(); };
    ds.sort((a, b) => b - a);
    let bi = 0;
    contents.forEach(C => {
      if (spec.bedded && !C.joint && bi < ds.length) { planes.push({ N: tilt(), d: ds[bi++], kind: 'feuillet', C: Object.assign({}, C) }); return; }
      /* un joint : oblique aux feuillets (les roches massives n'ont que ça) */
      const b = basis(N), phi = rnd() * TAU, a = (spec.bedded ? 50 + rnd() * 30 : 25 + rnd() * 65) * Math.PI / 180;
      const t = b.U.clone().multiplyScalar(Math.cos(phi)).addScaledVector(b.W, Math.sin(phi));
      planes.push({ N: N.clone().multiplyScalar(Math.cos(a)).addScaledVector(t, Math.sin(a)).normalize(), d: (rnd() - 0.5) * (C.type === 'geode' ? 0.08 : 0.3), kind: 'joint', C: Object.assign({}, C) });
    });
    for (const pl of planes) { Object.assign(pl, basis(pl.N)); pl.contour = sliceContour(geo, pl.N, pl.d, pl.U, pl.W); placeContent(pl, rnd); }
    if (spec.tuto) for (const pl of planes) if (pl.C.type === 'os' && pl.contour.uw.length > 2) {
      let su = 0, sw = 0; pl.contour.uw.forEach(([u, w]) => { su += u; sw += w; });
      pl.C.u = su / pl.contour.uw.length; pl.C.w = sw / pl.contour.uw.length; pl.C.ang = 0; pl.C.dmin = edgeDist(pl.C.u, pl.C.w, pl.contour.uw);
    }
    /* un autre fil ne doit pas passer pile sur le point chaud d'un contenu (là où le POK est le plus gros) : on l'écarte */
    for (const pl of planes) {
      if (pl.C.dmin == null || !pl.contour.pts || !pl.contour.pts.length) continue;
      let hot = null, hd = 1e9;
      pl.contour.pts.forEach(P => { const u = P.dot(pl.U), w = P.dot(pl.W), dd = Math.hypot(u - pl.C.u, w - pl.C.w); if (dd < hd) { hd = dd; hot = P; } });
      for (const q of planes) {
        if (q === pl) continue;
        const s = hot.dot(q.N) - q.d;
        if (Math.abs(s) < 0.16) { q.d += (s >= 0 ? -1 : 1) * (0.16 - Math.abs(s)); q.contour = sliceContour(geo, q.N, q.d, q.U, q.W); if (q.contour.uw.length > 2) placeContent(q, rnd); }
      }
    }
    return { geo, S, N, planes, seed: spec.seed };
  }

  /* ---------- son : des chocs de pierre (bruit qui fait sonner quelques modes), rien qui bipe ---------- */
  let NOISE = null, actx = null;
  function noiseBuf(c) { if (!NOISE || NOISE.sampleRate !== c.sampleRate) { NOISE = c.createBuffer(1, c.sampleRate * 2, c.sampleRate); const d = NOISE.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; } return NOISE; }
  function knock(o) {
    const c = O.audio && O.audio(); if (!c) return;
    try {
      const t = c.currentTime + (o.delay || 0), exc = o.exc || 0.006;
      const src = c.createBufferSource(); src.buffer = noiseBuf(c);
      const env = c.createGain();
      env.gain.setValueAtTime(0.0001, t); env.gain.exponentialRampToValueAtTime(1, t + 0.0008); env.gain.exponentialRampToValueAtTime(0.0005, t + 0.0008 + exc);
      src.connect(env);
      const out = c.createGain(); out.gain.value = (o.vol || 0.6); out.connect(c.destination);
      let end = exc + 0.05;
      for (const [f, Q, g, dec] of (o.modes || [])) {
        /* la résonance tient le temps voulu : Q = π f τ, τ = dec / 4,6 */
        const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = f * (1 + (Math.random() - 0.5) * 0.04);
        const Qr = Math.max(Q, Math.PI * f * dec / 4.6); bp.Q.value = Qr;
        /* une bouffée de bruit si courte n'a pas toujours d'énergie à la fréquence du mode : certains coups sortaient 3× plus faibles.
           Le bruit garde le grain de la pierre (30 % du niveau), une résonance à niveau fixe garantit le reste. */
        const ge = c.createGain(), g0 = g * Math.sqrt(Qr) * 2.2 * 0.3;
        ge.gain.setValueAtTime(g0, t); ge.gain.setValueAtTime(g0, t + dec * 0.5); ge.gain.exponentialRampToValueAtTime(0.0005, t + dec * 1.5);
        env.connect(bp).connect(ge).connect(out); end = Math.max(end, dec * 1.5);
        const A = 0.0098 * g * bp.frequency.value * Math.sqrt(exc) / Math.sqrt(Qr), tau = Qr / (Math.PI * bp.frequency.value);
        const os = c.createOscillator(), og = c.createGain(), att = Math.min(0.003, tau * 0.5);
        os.frequency.value = bp.frequency.value;
        og.gain.setValueAtTime(0.0001, t); og.gain.exponentialRampToValueAtTime(A, t + att);
        const mid = Math.max(A * Math.exp(-dec * 0.5 / tau), 0.0002);
        og.gain.exponentialRampToValueAtTime(mid, t + att + dec * 0.5); og.gain.exponentialRampToValueAtTime(0.0001, t + dec * 1.5 + 0.01);
        os.connect(og).connect(out); os.start(t); os.stop(t + dec * 1.5 + 0.05);
      }
      if (o.click) { const [type, f, Q, g] = o.click; const fl = c.createBiquadFilter(); fl.type = type; fl.frequency.value = f; fl.Q.value = Q; const ge = c.createGain(); ge.gain.value = g; env.connect(fl).connect(ge).connect(out); }
      src.start(t, Math.random() * 1.5); src.stop(t + end + 0.1);
    } catch (e) { /* audio indisponible */ }
  }
  function crackle(n, span, vol, delay) { for (let i = 0; i < n; i++) knock({ delay: (delay || 0) + Math.pow(Math.random(), 1.6) * span, exc: 0.002, vol: vol * (0.4 + Math.random() * 0.6), click: ['highpass', 2500 + Math.random() * 2500, 0.7, 1], modes: [[1800 + Math.random() * 2400, 6, 0.6, 0.02]] }); }
  const SND = {
    plein() { knock({ exc: 0.004, vol: 0.5, click: ['highpass', 2600, 0.7, 0.45], modes: [[2050 + Math.random() * 150, 14, 1.0, 0.045], [3250, 16, 0.8, 0.035], [4700, 12, 0.6, 0.025]] }); },
    creux(q, deep) { const f = (520 - 190 * q) * (deep ? 0.82 : 1); knock({ exc: 0.008, vol: 1.5, click: ['lowpass', 300, 0.7, 0.9 + 0.6 * q], modes: [[f, 7, 1.3, 0.09 + 0.1 * q + (deep ? 0.06 : 0)], [f * 1.68, 8, 0.8, 0.07 + 0.05 * q], [f * 2.9, 7, 0.4, 0.045]] }); },
    frag(q) { const f = 560 - 120 * q; knock({ exc: 0.007, vol: 1.2, click: ['lowpass', 380, 0.7, 0.8], modes: [[f, 6, 1.2, 0.06 + 0.04 * q], [f * 1.8, 7, 0.7, 0.05]] }); [0.032, 0.05, 0.066, 0.079, 0.09].forEach((d, i) => knock({ delay: d, exc: 0.002, vol: 0.3 * (1 - i * 0.12), click: ['bandpass', 1400, 1.2, 1.2], modes: [[1100 + i * 90, 5, 0.6, 0.015]] })); },
    bong(q) { knock({ exc: 0.01, vol: 1.3, click: ['lowpass', 500, 0.7, 0.7], modes: [[170, 30, 1.2, 0.5 + 0.4 * q], [262, 40, 0.8, 0.4 + 0.3 * q], [415, 50, 0.5, 0.3], [1250, 60, 0.25, 0.25]] }); },
    ting(q) { knock({ exc: 0.003, vol: 0.55, click: ['highpass', 2600, 0.7, 0.4], modes: [[2210, 70, 0.9, 0.35 + 0.35 * q], [3470, 90, 0.6, 0.28 + 0.25 * q], [5240, 100, 0.45, 0.2 + 0.15 * q], [2050, 14, 0.8, 0.04]] }); },
    sourd() { knock({ exc: 0.012, vol: 0.75, click: ['lowpass', 420, 0.7, 1.1], modes: [[190, 3, 1.2, 0.07], [330, 4, 0.6, 0.05]] }); },
    marteau(f) { knock({ exc: 0.02, vol: 0.85 + 0.15 * f, click: ['lowpass', 1600, 0.7, 1.4], modes: [[140, 4, 1.5, 0.18], [310, 5, 0.9, 0.12], [880, 6, 0.6, 0.07], [2300, 10, 0.4, 0.04]] }); },
    fissure() { crackle(9, 0.22, 0.5, 0.03); },
    eclat() { crackle(16, 0.3, 0.7, 0); knock({ delay: 0.05, exc: 0.03, vol: 0.8, click: ['lowpass', 700, 0.7, 1.2], modes: [[110, 3, 1.4, 0.25], [260, 4, 0.8, 0.15]] }); },
    snap() { crackle(10, 0.08, 0.6, 0); },
    clac() { knock({ exc: 0.015, vol: 1, click: ['bandpass', 2100, 0.6, 1.6], modes: [[720, 3, 1.2, 0.08], [1650, 4, 0.8, 0.06], [3100, 6, 0.5, 0.04]] }); },
    thud() { knock({ exc: 0.03, vol: 1.6, click: ['lowpass', 280, 0.7, 1.8], modes: [[85, 2.5, 1.6, 0.22], [170, 3, 0.8, 0.12], [520, 5, 0.3, 0.05]] }); }
  };

  /* ---------- état ---------- */
  let O = {}, renderer = null, scene = null, camera = null, world = null, cv = null, ray = null, LIGHT = null;
  let ST = null, rock = null, spec = null, running = false, active = false, sayT = 0;
  let down = null, vel = { x: 0, y: 0 }, shakeAmt = 0, last = 0, lensCtx = null, lensEl = null;
  const dusts = [];
  const $e = sel => O.host.querySelector(sel);
  /* grammaire des mots qui jaillissent de la pierre : le mot dit ce qu'on touche, sa taille dit la proximité du cœur.
     pic (petit) : un fil, rien dessous · tak : la chair de la pierre, hors des fils · pok, de plus en plus gros : un os tout près ·
     ting, doré : une veine · et pour les coups forts : TAK, CLAC, CRAC */
  function pop(text, size, color, P, cls, delay) {
    if (!rock || (O.words && !O.words())) return;
    size *= 1.7;
    const THREE = T3(), hr = O.host.getBoundingClientRect(), cr = cv.getBoundingClientRect();
    const toScr = v => { const w = v.project(camera); return [cr.left - hr.left + (w.x + 1) / 2 * cr.width, cr.top - hr.top + (1 - w.y) / 2 * cr.height]; };
    const [x, y] = toScr(rock.mesh.localToWorld(P.clone())), [cx, cy] = toScr(rock.mesh.localToWorld(new THREE.Vector3()));
    let dx = x - cx, dy = y - cy, L = Math.hypot(dx, dy) || 1; dx /= L; dy = dy / L - 0.9; L = Math.hypot(dx, dy) || 1; dx /= L; dy /= L;
    const a = (Math.random() - 0.5) * 0.7, ca = Math.cos(a), sa = Math.sin(a), ux = dx * ca - dy * sa, uy = dx * sa + dy * ca;
    const dist = 30 + size * 0.75, rot = (Math.random() - 0.5) * 26;
    const el = document.createElement('span');
    el.className = 'b3-pop' + (cls ? ' ' + cls : ''); el.textContent = text;
    el.style.cssText = 'left:' + x + 'px;top:' + y + 'px;font-size:' + Math.round(size) + 'px;color:' + color;
    const at = (k, sc, r) => 'translate(calc(-50% + ' + (ux * dist * k).toFixed(1) + 'px),calc(-50% + ' + (uy * dist * k).toFixed(1) + 'px)) scale(' + sc + ') rotate(' + r.toFixed(1) + 'deg)';
    const go = () => {
      O.host.appendChild(el);
      try {
        el.animate([
          { transform: at(0, 0.2, rot * 0.3), opacity: 0 },
          { transform: at(0.5, 1.25, rot), opacity: 1, offset: 0.18 },
          { transform: at(0.85, 1, rot * 1.15), opacity: 1, offset: 0.62 },
          { transform: at(1.05, 0.92, rot * 1.3), opacity: 0 }
        ], { duration: 650 + size * 9, easing: 'cubic-bezier(.2,.8,.3,1)' }).onfinish = () => el.remove();
      } catch (e) { setTimeout(() => el.remove(), 800); }
    };
    if (delay) setTimeout(go, delay); else go();
  }
  const mixHex = (a, b, t) => { const A = hex2rgb(a), B = hex2rgb(b); return 'rgb(' + A.map((v, i) => Math.round(v + (B[i] - v) * t)).join(',') + ')'; };
  function shout(t) { const s = $e('.b3-say'); s.textContent = t; s.classList.add('on'); clearTimeout(sayT); sayT = setTimeout(() => s.classList.remove('on'), 1200); }

  function init(opts) {
    O = opts;
    const THREE = T3();
    if (!THREE) return false;
    const host = O.host;
    host.insertAdjacentHTML('beforeend', '<canvas class="b3-gl" aria-label="Pierre à fendre : glissez pour la tourner, touchez pour la tapoter, maintenez pour frapper fort"></canvas><i class="b3-ring" aria-hidden="true"></i><div class="b3-say" aria-live="polite"></div>');
    cv = $e('.b3-gl');
    /* la bulle de visée vit au-dessus de tout l'écran : elle suit le pouce sans sauter aux bords de l'établi */
    lensEl = document.createElement('canvas'); lensEl.className = 'b3-lens'; lensEl.setAttribute('aria-hidden', 'true'); document.body.appendChild(lensEl);
    lensCtx = lensEl.getContext('2d');
    try { renderer = new THREE.WebGLRenderer({ canvas: cv, antialias: true, alpha: true }); } catch (e) { renderer = null; return false; }
    renderer.setPixelRatio(Math.min((window.devicePixelRatio || 1) * 1.25, 2.5));
    renderer.localClippingEnabled = true;
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(32, 1, 0.1, 60);
    world = new THREE.Group(); scene.add(world);
    ray = new THREE.Raycaster();
    LIGHT = new THREE.Vector3(-0.55, 0.7, 0.55).normalize();
    bindPointer();
    window.addEventListener('resize', () => { if (active) resize(); });
    /* la zone de l'établi peut changer de taille sans que la fenêtre bouge (panneau du bas, barre de l'app) */
    if (window.ResizeObserver) new ResizeObserver(() => { if (active) resize(); }).observe(O.host);
    return true;
  }
  const ok = () => !!renderer;

  function uniformsFor(st, pal) {
    const THREE = T3(), col = h => new THREE.Color(h), spots = [], types = [], pl = [], plk = [], rev = [];
    for (let i = 0; i < 8; i++) { spots.push(new THREE.Vector4(0, 0, 0, 0)); types.push(0); }
    for (let i = 0; i < 32; i++) rev.push(new THREE.Vector4(0, 0, 0, 0));
    for (let i = 0; i < 4; i++) { const P = st.planes[i]; pl.push(P ? new THREE.Vector4(P.N.x, P.N.y, P.N.z, P.d) : new THREE.Vector4()); plk.push(P ? (P.kind === 'joint' ? 2 : 1) : 0); }
    return {
      uBase: { value: col(pal.base) }, uLight: { value: col(pal.light) }, uShade: { value: col(pal.shade) }, uInk: { value: col(pal.ink) }, uTex: { value: col(pal.tex) },
      uFace: { value: col(pal.face) }, uFaceShade: { value: col(pal.faceShade) }, uBed: { value: st.N }, uBedOn: { value: spec.bedded ? 1 : 0.35 },
      uSeed: { value: (st.seed % 97) * 0.37 }, uLightDir: { value: LIGHT }, uVis: { value: 0.035 * (spec.loupe || 0) },
      uPl: { value: pl }, uPlK: { value: plk }, uSpots: { value: spots }, uSpotType: { value: types }, uReveal: { value: rev },
      uGlow: { value: [0, 0, 0, 0] }, uTime: { value: 0 }, uMarks: { value: [0, 1, 2, 3, 4, 5].map(() => new THREE.Vector4(0, 0, 0, 0)) }
    };
  }
  function surfacePoint(dirLocal, from) {
    const THREE = T3(), o = (from || new THREE.Vector3()).clone().addScaledVector(dirLocal.clone().normalize(), 4);
    const wo = rock.mesh.localToWorld(o.clone()), wt = rock.mesh.localToWorld((from || new THREE.Vector3()).clone());
    ray.set(wo, wt.sub(wo).normalize());
    const hit = ray.intersectObject(rock.mesh, false)[0];
    return hit ? rock.mesh.worldToLocal(hit.point.clone()) : null;
  }
  function alongContour(pl, i0, dist, rnd) {
    const pts = pl.contour.pts, n = pts.length, dir = rnd() < 0.5 ? 1 : -1;
    let acc = 0, i = i0;
    while (acc < dist) { const j = (i + dir + n) % n; acc += pts[i].distanceTo(pts[j]); i = j; if (i === i0) break; }
    return pts[i];
  }
  /* taches : elles orientent sans rien promettre */
  function placeSpots(rnd) {
    const THREE = T3(), u = rock.u; let k = 0;
    const put = (P, r, t) => { if (!P || k >= 8) return; u.uSpots.value[k].set(P.x, P.y, P.z, r); u.uSpotType.value[k] = t; k++; };
    const near = (P, pl, off) => surfacePoint(P.clone().addScaledVector(pl.N, off)) || P;
    for (const pl of ST.planes) {
      const C = pl.C, pts = pl.contour.pts;
      if (!pts.length) continue;
      if (C.type === 'os' || C.type === 'unique') {
        if (rnd() < 0.5) {
          let bi = 0, bd = 1e9; pl.contour.uw.forEach(([uu, ww], i) => { const d = Math.hypot(uu - C.u, ww - C.w); if (d < bd) { bd = d; bi = i; } });
          put(near(alongContour(pl, bi, 0.18 + rnd() * 0.22, rnd), pl, (rnd() - 0.5) * 0.09), 0.1 + rnd() * 0.05, 0);
        }
      } else if (C.type === 'veine' && rnd() < 0.7) put(near(pts[C.ia], pl, (rnd() - 0.5) * 0.08), 0.11 + rnd() * 0.07, 1);
    }
    const rv = () => new THREE.Vector3(rnd() - 0.5, rnd() - 0.5, rnd() - 0.5);
    const fakes = 1 + Math.floor(rnd() * 2);
    for (let i = 0; i < fakes; i++) put(surfacePoint(rv()), 0.09 + rnd() * 0.08, rnd() < 0.55 ? 0 : 1);
    const lich = Math.floor(rnd() * 3);
    for (let i = 0; i < lich; i++) put(surfacePoint(rv()), 0.12 + rnd() * 0.1, 2);
  }
  function dispose() {
    if (!rock) return;
    world.remove(rock.spin);
    rock.spin.traverse(o => { if (o.geometry && o.geometry !== ST.geo) o.geometry.dispose(); if (o.material) { if (o.material.map) o.material.map.dispose(); } });
    ST.geo.dispose();
    rock = null; ST = null;
  }
  /* une nouvelle pierre sur l'établi */
  function load(s) {
    if (!ok()) return false;
    const THREE = T3();
    dispose();
    spec = s;
    ST = makeStone(s);
    const u = uniformsFor(ST, s.pal);
    const mat = new THREE.ShaderMaterial({ uniforms: u, vertexShader: VERT, fragmentShader: FRAG, side: THREE.DoubleSide, clipping: true, extensions: { derivatives: true } });
    const hullMat = new THREE.ShaderMaterial({ uniforms: { uInk: u.uInk }, vertexShader: HULL_V, fragmentShader: HULL_F, side: THREE.BackSide, clipping: true });
    const mesh = new THREE.Mesh(ST.geo, mat), hull = new THREE.Mesh(ST.geo, hullMat);
    const group = new THREE.Group(); group.add(mesh); group.add(hull);
    const spin = new THREE.Group(); spin.add(group); world.add(spin);
    rock = { spin, group, mesh, hull, mat, hullMat, u, rev: 0, cracks: new THREE.Group(), fatigue: 0, coups: 0, offFil: 0, done: false, top: null };
    group.add(rock.cracks);
    const r0 = mulberry32(s.seed ^ 0x51);
    spin.quaternion.setFromEuler(new THREE.Euler(0.35 + r0() * 0.5, r0() * TAU, 0));
    spin.updateMatrixWorld(true);
    placeSpots(mulberry32(s.seed ^ 0xabc));
    world.position.set(0, 0, 0);
    active = true; resize(); fatigue();
    if (!running) { running = true; last = performance.now(); requestAnimationFrame(frame); }
    return true;
  }
  function clear() { dispose(); active = false; spec = null; lensEl.style.display = 'none'; }
  function pause() { active = false; }
  function resume() { if (!ok() || !rock) return; active = true; resize(); if (!running) { running = true; last = performance.now(); requestAnimationFrame(frame); } }
  function fatigue() { if (O.onFatigue && rock) O.onFatigue(rock.fatigue, rock.coups); }

  /* ---------- gestes ---------- */
  function pick(clientX, clientY) {
    const THREE = T3(), r = cv.getBoundingClientRect(), m = new THREE.Vector2(((clientX - r.left) / r.width) * 2 - 1, -((clientY - r.top) / r.height) * 2 + 1);
    ray.setFromCamera(m, camera);
    const hit = ray.intersectObject(rock.mesh, false)[0];
    return hit ? rock.mesh.worldToLocal(hit.point.clone()) : null;
  }
  function local(e) { const r = O.host.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
  /* la charge : sur le fil d'une géode, elle va et vient pour laisser une chance de lâcher au bon moment */
  const isGeo = P => { if (!P) return false; const pl = onPlane(P, Math.max(0.055, pxUnits(11))); return !!(pl && pl.C.type === 'geode'); };
  function chargeF(d, now) { const p = (now - d.t - 260) / (d.geo ? 800 : 650); if (!d.geo) return clamp(p, 0, 1); if (p <= 0) return 0; const m = p % 2; return m <= 1 ? m : 2 - m; }
  function ringK(d, now) { const held = now - d.t; return held < 260 ? clamp((held - 120) / 140, 0, 1) * 0.15 : 0.15 + 0.85 * chargeF(d, now); }
  function bindPointer() {
    const ring = $e('.b3-ring');
    cv.addEventListener('pointerdown', e => {
      if (!rock || rock.done || (O.blocked && O.blocked())) return;
      if (O.onTouch) O.onTouch();
      try { cv.setPointerCapture(e.pointerId); } catch (x) { }
      const P = pick(e.clientX, e.clientY), [lx, ly] = local(e);
      down = { x: e.clientX, y: e.clientY, cx: lx, cy: ly, t: performance.now(), lx: e.clientX, ly: e.clientY, moved: false, aim: false, P, P0: P, fx: e.clientX, fy: e.clientY, charging: !!P, touch: e.pointerType !== 'mouse', geo: isGeo(P) };
      vel = { x: 0, y: 0 };
      ring.style.left = lx + 'px'; ring.style.top = ly + 'px';
    });
    cv.addEventListener('pointermove', e => {
      if (!down) return;
      const dx = e.clientX - down.lx, dy = e.clientY - down.ly, held = performance.now() - down.t;
      if (down.charging && !down.moved && (down.aim || held > 220)) {
        /* en charge depuis un moment : le doigt vise au lieu de tourner */
        down.aim = true; down.fx = e.clientX; down.fy = e.clientY;
        if (down.touch) aimFromFinger();
        else {
          /* à la souris, la bulle suit le pointeur ; hors de la pierre, le coup ne part pas */
          const P = pick(e.clientX, e.clientY), [lx, ly] = local(e); down.P = P; down.cx = lx; down.cy = ly; ring.style.left = lx + 'px'; ring.style.top = ly + 'px';
          ring.classList.toggle('off', !P);
        }
        if (down.P && !down.geo && isGeo(down.P)) down.geo = true;
      } else if (!down.moved && Math.hypot(e.clientX - down.x, e.clientY - down.y) > 8) { down.moved = true; down.charging = false; ring.style.opacity = 0; cv.classList.remove('charging'); }
      if (down.moved) { rotateBy(dx, dy); vel = { x: dx, y: dy }; }
      down.lx = e.clientX; down.ly = e.clientY;
    });
    const end = () => {
      if (!down) return;
      const d = down; down = null;
      ring.style.opacity = 0; lensEl.style.display = 'none'; cv.classList.remove('charging');
      $e('.b3-ring').classList.remove('off');
      if (d.moved || !(d.P || d.P0) || !d.charging || !rock || rock.done) return;
      const held = performance.now() - d.t;
      if (held < 260) { const tp = d.touch ? d.P0 : d.P; if (tp) tap(tp); } else if (d.P) strike(d.P, chargeF(d, performance.now()));
    };
    cv.addEventListener('pointerup', end);
    cv.addEventListener('pointercancel', () => { down = null; ring.style.opacity = 0; lensEl.style.display = 'none'; });
    /* un appui long (frapper) n'ouvre pas le menu contextuel du système */
    cv.addEventListener('contextmenu', e => e.preventDefault());
  }
  function rotateBy(dx, dy) {
    const THREE = T3();
    rock.spin.quaternion.premultiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), dx * 0.008)).premultiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), dy * 0.008));
  }
  /* tolérance au doigt : quelques pixels d'écran, convertis en distance dans la pierre */
  function pxUnits(px) { const h = cv.clientHeight || 500; return px * 2 * camera.position.z * Math.tan(camera.fov * Math.PI / 360) / h; }
  function onPlane(P, tol) {
    let best = null, bd = tol;
    ST.planes.forEach(pl => { const s = Math.abs(P.dot(pl.N) - pl.d); if (s < bd) { bd = s; best = pl; } });
    return best;
  }
  function distToContent(pl, P) {
    const u = P.dot(pl.U), w = P.dot(pl.W), C = pl.C;
    if (C.r) return Math.hypot(u - C.u, w - C.w);
    if (C.type === 'veine') return segDist(u, w, C.ua, C.wa, C.ub, C.wb);
    return 1e9;
  }
  /* tapoter : écouter */
  function tap(P) {
    rock.coups++;
    /* le fil dégagé reste dégagé : un tapotement tout près rafraîchit le même endroit au lieu d'en effacer un ancien */
    const RV = rock.u.uReveal.value, near = RV.find(r => r.w > 0 && Math.hypot(r.x - P.x, r.y - P.y, r.z - P.z) < 0.12);
    if (near) near.set(P.x, P.y, P.z, near.w); else { RV[rock.rev % RV.length].set(P.x, P.y, P.z, 0.3 + 0.04 * (spec.loupe || 0)); rock.rev++; }
    const pl = onPlane(P, Math.max(0.07, pxUnits(16)));
    const FM = 1.35 - 0.12 * (spec.marteau || 0);
    if (!pl) { if (!spec.tuto || spec.tutoFat) rock.fatigue += 0.04 * FM; rock.offFil++; SND.sourd(); if (SHOW_TAK) pop('tak', 19, '#d8c9ad', P, 'dull'); if (O.onTap) O.onTap('sourd', rock.offFil); }
    else {
      if (!spec.tuto || spec.tutoFat) rock.fatigue += 0.022 * FM;
      /* on retient le fil qu'on vient d'écouter : la frappe qui suit, au même endroit, ira sur ce fil-là */
      rock.lastPl = pl; rock.lastTapP = P.clone();
      const C = pl.C, d = distToContent(pl, P);
      let k = 'plein', heardQ = 0;
      const dm = C.dmin != null ? C.dmin : C.r;
      if (C.r && d < dm + 0.42) {
        /* le POK le plus gros sonne au point de la surface le plus proche de ce que cache le fil */
        const q = heardQ = clamp(1 - (d - dm - 0.03) / 0.39, 0, 1);
        if (C.type === 'geode') { SND.bong(q); k = 'bong'; pop(q > 0.72 ? 'BONG' : 'bong', 18 + 26 * q, mixHex('#efe4ff', '#b48ae8', q), P, 'ting'); }
        else { SND.creux(q, C.type === 'unique'); k = 'creux'; if (q > 0.8) rock.coreTaps = (rock.coreTaps || 0) + 1; const big = 18 + 30 * q + (C.type === 'unique' ? 6 : 0); pop(q > 0.72 ? 'POK' : 'pok', big, mixHex('#fff1cc', '#ff9d3a', q), P, q > 0.72 ? 'heavy' : ''); }
      } else if (C.type === 'veine' && d < 0.42) { const q = heardQ = clamp(1 - d / 0.42, 0, 1); SND.ting(q); k = 'ting'; pop('ting', 15 + 22 * q, '#ffe27a', P, 'ting'); }
      else { SND.plein(); pop('pic', 14, '#fff6dd', P, 'thin'); }
      if (O.onTap) O.onTap(k, 0, heardQ, ST.planes.indexOf(pl), P);
    }
    /* au tutoriel, la jauge monte pour de vrai mais la pierre n'éclate jamais */
    if (spec.tuto) rock.fatigue = Math.min(rock.fatigue, 0.92);
    dust(P, 5); shake(0.01); fatigue();
    if (rock.fatigue >= 1) shatter(P);
  }
  /* proximité du cœur (gros POK, ting le plus clair) : 1 au cœur, 0 à la lisière */
  function proxOf(pl, P) {
    const C = pl.C, d = distToContent(pl, P);
    if (C.r) { const dm = C.dmin != null ? C.dmin : C.r; return 1 - clamp((d - dm - 0.04) / 0.42, 0, 1); }
    if (C.type === 'veine') return 1 - clamp((d - 0.03) / 0.39, 0, 1);
    return 0;
  }
  /* ---------- tutoriel : guider l'œil ---------- */
  /* le point chaud d'un fil : là où le POK est le plus gros, où le ting est le plus clair */
  function hotIndex(pl) {
    const C = pl.C, pts = pl.contour.pts; let bi = 0, bd = 1e9;
    const tu = C.type === 'veine' ? C.ua : C.u, tw = C.type === 'veine' ? C.wa : C.w;
    pts.forEach((P, i) => { const dd = Math.hypot(P.dot(pl.U) - tu, P.dot(pl.W) - tw); if (dd < bd) { bd = dd; bi = i; } });
    return bi;
  }
  /* glow : intensité par fil (0 à 1) ; trail : { idx, from } des marques le long du fil, du point écouté jusqu'au cœur */
  /* tutoriel : la pierre se tourne d'elle-même pour présenter un point (la main du professeur) */
  function present(P) {
    const THREE = T3(), d = P.clone().normalize(), view = new THREE.Vector3(0, 0.35, 1).normalize();
    const now0 = rock.spin.quaternion.clone(), seen = d.clone().applyQuaternion(now0);
    if (seen.dot(view) > 0.8) return;
    /* le plus petit tour qui amène le point face à nous, en gardant l'orientation actuelle */
    const q = new THREE.Quaternion().setFromUnitVectors(seen, view).multiply(now0);
    rock.focus = { q0: now0, q1: q, t0: performance.now(), dur: 700 };
  }
  function guide(o) {
    if (!rock) return;
    const u = rock.u;
    if (o && o.present != null && ST.planes[o.present]) {
      const pl = ST.planes[o.present], pts = pl.contour.pts;
      if (pts.length) {
        let P = pts[hotIndex(pl)];
        if (pl.C.type === 'rien') { let best = -2; pts.forEach(X => { const z = X.clone().normalize().applyQuaternion(rock.spin.quaternion).z; if (z > best) { best = z; P = X; } }); }
        present(P);
      }
    }
    for (let i = 0; i < 4; i++) u.uGlow.value[i] = o && o.glow ? o.glow[i] || 0 : 0;
    u.uMarks.value.forEach(m => m.set(0, 0, 0, 0));
    if (!o || !o.trail) return;
    const pl = ST.planes[o.trail.idx]; if (!pl || !pl.contour.pts.length) return;
    const pts = pl.contour.pts, n = pts.length, ih = hotIndex(pl);
    let i0 = (ih + Math.floor(n / 2)) % n;
    if (o.trail.from) { let bd = 1e9; pts.forEach((P, i) => { const dd = P.distanceTo(o.trail.from); if (dd < bd) { bd = dd; i0 = i; } }); }
    const fwd = (ih - i0 + n) % n, back = n - fwd, dir = fwd <= back ? 1 : -1, len = Math.min(fwd, back);
    const steps = len < 4 ? [1] : [0.3, 0.55, 0.78, 1];
    steps.forEach((t, k) => { const i = ((i0 + dir * Math.round(len * t)) % n + n) % n, P = pts[i].clone().multiplyScalar(1.004); u.uMarks.value[k].set(P.x, P.y, P.z, t === 1 ? 0.12 : 0.07); });
  }
  /* frapper : sur un fil, la pierre s'ouvre selon ce fil ; ailleurs, elle se fatigue */
  function strike(P, f) {
    const THREE = T3();
    rock.coups++;
    const force = 0.55 + 0.45 * f, M = spec.marteau || 0;
    SND.marteau(f);
    shake(0.03 * force); dust(P, 14);
    rock.lastP = P;
    const rnd = mulberry32((spec.seed + rock.coups * 31) >>> 0);
    const tolS = Math.max(0.055, pxUnits(11)) + 0.01 * M;
    let pl = onPlane(P, tolS);
    /* deux fils qui se croisent : si l'on frappe là où l'on vient d'écouter, c'est le fil écouté qui s'ouvre */
    if (rock.lastPl && rock.lastTapP && P.distanceTo(rock.lastTapP) < 0.3 && Math.abs(P.dot(rock.lastPl.N) - rock.lastPl.d) < tolS * 1.8) pl = rock.lastPl;
    if (spec.tuto && O.gate) {
      const g = O.gate({ idx: pl ? ST.planes.indexOf(pl) : -1, type: pl ? pl.C.type : null, f, soft: !!pl && force <= 0.6, prox: pl ? proxOf(pl, P) : 0 });
      if (g !== true) { shout(g || 'Hors du fil'); pop(pl ? 'tok' : 'tak', 20, '#f3e2bd', P, 'heavy'); return; }
    }
    if (pl && force > 0.6) {
      const C = pl.C, d = distToContent(pl, P);
      /* le choc se propage dans le plan : trop près de ce qu'il cache, il l'abîme */
      /* la qualité du coup : le point parfait est au plus gros POK, au plus près de ce que cache le fil ;
         le marteau élargit la tolérance, une pierre fatiguée abîme davantage */
      /* la qualité du coup = proximité du cœur (gros POK, ting le plus clair, 1) ou de la lisière (0), rognée par la fatigue.
         le marteau élargit la tolérance. Ouvrir le bon fil rend toujours quelque chose : le plancher est géré par les étoiles. */
      let score = 1, aim = null;
      const tol = 1 + 0.12 * M;
      if (C.type === 'geode') {
        /* une géode s'ouvre d'un coup dosé : ni trop doux, ni trop fort */
        score = f >= 0.3 && f <= 0.65 ? 1 : f < 0.3 ? 0.5 + f / 0.3 * 0.25 : f <= 0.82 ? 0.6 : 0.3;
      } else if (C.r) {
        const dm = C.dmin != null ? C.dmin : C.r;
        score = aim = 1 - clamp((d - dm - 0.04) / (0.42 * tol), 0, 1);
      } else if (C.type === 'veine') {
        score = aim = 1 - clamp((d - 0.03) / (0.39 * tol), 0, 1);
      }
      score *= 1 - FATK * clamp(rock.fatigue, 0, 1);
      const quality = score >= 0.55 ? 'intact' : 'abime';
      open(pl, { kind: 'fil', plane: ST.planes.indexOf(pl), type: C.type, quality, score, aim, force: f, fatigue: rock.fatigue, coreTaps: rock.coreTaps || 0, coups: rock.coups }, P);
      return;
    }
    rock.fatigue += (0.2 + 0.25 * force) * (1.3 - 0.12 * M) + (pl ? -0.12 : 0);
    crackFrom(P, 0.5 + force * 0.6, rnd);
    fatigue();
    shout(pl ? 'Trop doux : maintenez plus longtemps' : rock.fatigue > 0.7 ? 'Ça craque…' : 'Hors du fil');
    SND.fissure();
    pop(pl ? 'tok' : 'TAK !', pl ? 20 : 28 + 8 * f, pl ? '#f3e2bd' : '#e8b48a', P, 'heavy');
    pop('crr', 15, '#d8c9ad', P, 'thin', 160);
    if (O.onMiss) O.onMiss(!!pl);
    if (rock.fatigue >= 1 || (rock.fatigue > 0.55 && rnd() < (rock.fatigue - 0.5) * force)) shatter(P);
    void THREE;
  }
  function shatter(P) {
    const THREE = T3(), rr = mulberry32((spec.seed ^ 0x77) + rock.coups);
    const n = P.clone().normalize().cross(new THREE.Vector3(rr() - 0.5, rr() - 0.5, rr() - 0.5)).normalize();
    const pl = { N: n, d: P.dot(n), kind: 'cassure' };
    Object.assign(pl, basis(n));
    pl.contour = sliceContour(ST.geo, n, pl.d, pl.U, pl.W);
    let hit = null;
    for (const q of ST.planes) {
      if (!q.C.r) continue;
      const c = q.N.clone().multiplyScalar(q.d).addScaledVector(q.U, q.C.u).addScaledVector(q.W, q.C.w);
      if (Math.abs(c.dot(n) - pl.d) < q.C.r * 0.9) { hit = q; const cp = c.clone().addScaledVector(n, pl.d - c.dot(n)); pl.C = { type: 'casse', u: cp.dot(pl.U), w: cp.dot(pl.W), r: q.C.r * 0.8, ang: q.C.ang, cut: q.C.cut }; break; }
    }
    if (!pl.C) pl.C = { type: 'rien' };
    SND.eclat();
    pop('CRAC', 44, '#ff8a5c', P, 'heavy');
    open(pl, { kind: 'cassure', plane: hit ? ST.planes.indexOf(hit) : -1, type: hit ? hit.C.type : 'rien', quality: hit ? 'casse' : 'eclatee', coups: rock.coups }, P);
  }
  function crackFrom(P, len, rnd) {
    const THREE = T3(), n = P.clone().normalize(), branches = 2 + Math.floor(len * 3);
    const mat = new THREE.MeshBasicMaterial({ color: spec.pal.ink });
    for (let b = 0; b < branches; b++) {
      let dir = new THREE.Vector3(rnd() - 0.5, rnd() - 0.5, rnd() - 0.5).projectOnPlane(n).normalize(), q = P.clone();
      const pts = [q.clone()], steps = 3 + Math.floor(len * 7 * (0.6 + rnd() * 0.6));
      for (let i = 0; i < steps; i++) {
        dir.add(new THREE.Vector3(rnd() - 0.5, rnd() - 0.5, rnd() - 0.5).multiplyScalar(0.7)).normalize();
        const sp = surfacePoint(q.clone().addScaledVector(dir, 0.055)); if (!sp) break;
        q = sp.clone().multiplyScalar(1.004); pts.push(q.clone());
        dir = q.clone().sub(pts[pts.length - 2]).normalize();
      }
      if (pts.length < 2) continue;
      rock.cracks.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), pts.length * 3, 0.0085 * (1 - b * 0.12), 4, false), mat));
    }
  }

  /* ---------- la face ouverte : un vrai plan de coupe, texturé avec ce que le jeu a décidé ---------- */
  const imgCache = new Map();
  function svgImage(svg) {
    let im = imgCache.get(svg);
    if (!im) { im = new Image(); im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg); imgCache.set(svg, im); if (imgCache.size > 40) imgCache.delete(imgCache.keys().next().value); }
    return im;
  }
  function capTexture(pl, variant, cap, P) {
    const THREE = T3(), pal = spec.pal, SZ = 1024, cvs = document.createElement('canvas'); cvs.width = cvs.height = SZ;
    const ctx = cvs.getContext('2d'), tex = new THREE.CanvasTexture(cvs);
    const [u0, u1, w0, w1] = pl.contour.bb, cu = (u0 + u1) / 2, cw = (w0 + w1) / 2, ext = Math.max(u1 - u0, w1 - w0) * 1.04;
    const X = u => (u - cu) / ext * SZ + SZ / 2, Y = w => (w - cw) / ext * SZ + SZ / 2, K = SZ / ext;
    pl.uvMap = (u, w) => [(u - cu) / ext + 0.5, 0.5 - (w - cw) / ext];
    const ink = variant === 'ink', C = pl.C, img = cap && cap.svg ? svgImage(ink ? cap.svgInk : cap.svg) : null;
    const draw = () => {
      ctx.clearRect(0, 0, SZ, SZ);
      ctx.save();
      ctx.beginPath(); pl.contour.uw.forEach(([u, w], i) => (i ? ctx.lineTo(X(u), Y(w)) : ctx.moveTo(X(u), Y(w)))); ctx.closePath();
      ctx.fillStyle = ink ? pal.faceShade : pal.face; ctx.fill();
      ctx.clip();
      const g = mulberry32(spec.seed + 11);
      for (let i = 0; i < 1400; i++) { ctx.fillStyle = g() < 0.6 ? pal.faceShade : (pal.faceTex || pal.tex); ctx.globalAlpha = 0.16 + g() * 0.24; ctx.fillRect(g() * SZ, g() * SZ, 2 + g() * 4, 2 + g() * 3); }
      ctx.globalAlpha = 0.22; ctx.strokeStyle = pal.faceShade; ctx.lineWidth = 3;
      for (let i = 0; i < 5; i++) { ctx.beginPath(); let x = 0, y = g() * SZ; ctx.moveTo(x, y); while (x < SZ) { x += 40; y += (g() - 0.5) * 18; ctx.lineTo(x, y); } ctx.stroke(); }
      ctx.globalAlpha = 1;
      const k = cap ? cap.k : 'rien';
      if ((k === 'piece' || k === 'whole') && C.r) {
        /* le bloc (ou la pièce entière) repose dans la face, à sa place */
        const size = C.r * 2.5 * K * (k === 'whole' ? 1.05 : 1) * Math.min(1.5, cap.scale || 1), a = cap.aspect || 1, w = a >= 1 ? size : size * a, h = a >= 1 ? size / a : size;
        ctx.save(); ctx.translate(X(C.u), Y(C.w)); ctx.rotate(C.ang * 0.25);
        if (C.type === 'casse') {
          const r = mulberry32(spec.seed + 5); ctx.save(); ctx.rotate(C.cut); ctx.beginPath(); ctx.moveTo(-size, -size); ctx.lineTo(size, -size);
          let yy = -size * 0.05; for (let xx = size; xx >= -size; xx -= size / 9) { ctx.lineTo(xx, yy); yy += (r() - 0.5) * size * 0.16; } ctx.closePath(); ctx.restore(); ctx.clip();
        }
        if (ink) ctx.globalAlpha = 0.3;
        if (img && img.complete && img.naturalWidth) ctx.drawImage(img, -w / 2, -h / 2, w, h);
        ctx.restore();
        const nCr = cap.cracks != null ? cap.cracks : cap.damaged ? 1 : 0;
        if (!ink && nCr > 0 && P) for (let ci = 0; ci < nCr; ci++) {
          /* la conservation se voit : un éclat sauté et des fêlures par étoile perdue, le premier du côté de l'impact */
          const pu = P.dot(pl.U), pw = P.dot(pl.W), an = Math.atan2(pw - C.w, pu - C.u) + ci * 2.1, r = mulberry32(spec.seed + 9 + ci * 13);
          const cx = X(C.u) + Math.cos(an) * C.r * 0.62 * K, cy = Y(C.w) + Math.sin(an) * C.r * 0.62 * K, rr = C.r * 0.42 * K;
          ctx.beginPath(); for (let i = 0; i < 10; i++) { const b = i / 10 * TAU, q = rr * (0.6 + r() * 0.5); ctx.lineTo(cx + Math.cos(b) * q, cy + Math.sin(b) * q); } ctx.closePath();
          ctx.fillStyle = pal.faceShade; ctx.fill(); ctx.strokeStyle = pal.ink; ctx.globalAlpha = 0.6; ctx.lineWidth = 3; ctx.stroke(); ctx.globalAlpha = 1;
          ctx.strokeStyle = 'rgba(40,25,10,.5)'; ctx.lineWidth = 2.5;
          for (let i = 0; i < 4; i++) { const b = an + Math.PI + (r() - 0.5) * 1.6; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(b) * rr * (1.4 + r()), cy + Math.sin(b) * rr * (1.4 + r())); ctx.stroke(); }
        }
      } else if (k === 'geode') {
        /* la géode, c'est la pierre entière : une croûte, des bandes, puis la cavité hérissée de cristaux qui remplit toute la coupe */
        const oc = cap.colors || {}, r = mulberry32(spec.seed + 61), nCr = cap.cracks || 0;
        const pts = pl.contour.uw.map(([u, w]) => [X(u), Y(w)]);
        let cx = 0, cy = 0; pts.forEach(p => { cx += p[0]; cy += p[1]; }); cx /= pts.length; cy /= pts.length;
        const ph = r() * TAU, wob = (a, kk) => 1 + 0.035 * Math.sin(a * 3 + ph + kk * 9) + 0.025 * Math.sin(a * 7 - ph * 2 + kk * 5);
        const at = (i, kk) => { const [x, y] = pts[i], a = Math.atan2(y - cy, x - cx), f = kk * wob(a, kk); return [cx + (x - cx) * f, cy + (y - cy) * f]; };
        const ring = kk => { ctx.beginPath(); pts.forEach((_, i) => { const q = at(i, kk); i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); }); ctx.closePath(); };
        const bands = oc.band || ['#ddd', '#bbb', '#eee'];
        ring(0.94); ctx.fillStyle = ink ? 'rgba(40,30,20,.18)' : '#efe8da'; ctx.fill();
        [0.9, 0.86, 0.82, 0.785, 0.75].forEach((kk, i) => { ring(kk); ctx.fillStyle = ink ? 'rgba(40,30,20,' + (0.1 + i * 0.03) + ')' : bands[i % bands.length]; ctx.fill(); });
        const CAV = 0.72;
        ring(CAV); ctx.fillStyle = ink ? 'rgba(30,20,10,.35)' : oc.dark || '#555'; ctx.fill();
        ring(CAV * 0.45); ctx.fillStyle = ink ? 'rgba(20,12,6,.4)' : 'rgba(20,10,25,.45)'; ctx.fill();
        /* les cristaux poussent du bord de la cavité vers le cœur */
        const n = 90;
        for (let i = 0; i < n; i++) {
          const idx = Math.floor((i + r() * 0.6) / n * pts.length) % pts.length, [bx, by] = at(idx, CAV * 1.01);
          const dx = cx - bx, dy = cy - by, D = Math.hypot(dx, dy) || 1, ux = dx / D, uy = dy / D;
          const len = D * (0.3 + r() * 0.38), w = D * (0.045 + r() * 0.05), sk = (r() - 0.5) * 0.5;
          const vx = ux * Math.cos(sk) - uy * Math.sin(sk), vy = ux * Math.sin(sk) + uy * Math.cos(sk);
          const broken = !ink && nCr > 0 && r() < nCr * 0.22, L2 = broken ? len * 0.5 : len;
          const tx = bx + vx * L2, ty = by + vy * L2, px = -vy * w, py = vx * w;
          ctx.beginPath(); ctx.moveTo(bx + px, by + py); ctx.lineTo(bx + px * 0.6 + vx * L2 * 0.82, by + py * 0.6 + vy * L2 * 0.82); ctx.lineTo(tx, ty); ctx.lineTo(bx - px * 0.6 + vx * L2 * 0.82, by - py * 0.6 + vy * L2 * 0.82); ctx.lineTo(bx - px, by - py); ctx.closePath();
          ctx.fillStyle = ink ? 'rgba(30,20,10,.22)' : broken ? (oc.dark || '#555') : (r() < 0.5 ? oc.col : oc.hi) || '#ccc';
          ctx.fill(); ctx.strokeStyle = 'rgba(40,25,50,.45)'; ctx.lineWidth = 1.4; ctx.stroke();
          if (!ink && !broken) { ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(bx + px * 0.3, by + py * 0.3); ctx.lineTo(tx, ty); ctx.stroke(); }
        }
        if (!ink) { ctx.fillStyle = 'rgba(255,255,255,.7)'; for (let i = 0; i < 40; i++) { const idx = Math.floor(r() * pts.length), [x, y] = at(idx, CAV * (0.35 + r() * 0.6)); ctx.fillRect(x, y, 3, 3); } }
        if (!ink && nCr > 0) {
          ctx.strokeStyle = 'rgba(30,18,10,.65)'; ctx.lineWidth = 3;
          for (let i = 0; i < nCr * 2; i++) { const idx = Math.floor(r() * pts.length), [x0, y0] = at(idx, 0.97), [x1, y1] = at((idx + Math.floor(pts.length * 0.06)) % pts.length, CAV * 0.5); ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo((x0 + x1) / 2 + (r() - 0.5) * 30, (y0 + y1) / 2 + (r() - 0.5) * 30); ctx.lineTo(x1, y1); ctx.stroke(); }
        }
      } else if (k === 'ore' && C.type === 'veine') {
        /* une veine de minerai : elle se partage entre les deux moitiés */
        const r = mulberry32(spec.seed + 21), pts = [], oc = cap.colors || {};
        for (let i = 0; i <= 14; i++) { const t = i / 14; pts.push([X(C.ua + (C.ub - C.ua) * t) + (r() - 0.5) * 12, Y(C.wa + (C.wb - C.wa) * t) + (r() - 0.5) * 12, (1 - Math.pow(t, 3)) * C.wid * K]); }
        const path = wk => {
          ctx.beginPath();
          const side = (i, sg) => { const [x, y, wd] = pts[i], j = i < pts.length - 1 ? i + 1 : i - 1, s2 = i < pts.length - 1 ? 1 : -1, nx = (pts[j][0] - x) * s2, ny = (pts[j][1] - y) * s2, L = Math.hypot(nx, ny) || 1; return [x - ny / L * wd * wk * sg, y + nx / L * wd * wk * sg]; };
          pts.forEach((_, i) => { const q = side(i, 1); i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); });
          for (let i = pts.length - 1; i >= 0; i--) { const q = side(i, -1); ctx.lineTo(q[0], q[1]); }
          ctx.closePath();
        };
        path(1.0); ctx.fillStyle = '#efe9dc'; ctx.fill(); ctx.strokeStyle = pal.ink; ctx.lineWidth = 2.5; ctx.globalAlpha = 0.5; ctx.stroke(); ctx.globalAlpha = 1;
        path(0.55); ctx.fillStyle = ink ? (oc.dark || '#8a6a20') : (oc.color || '#c9a640'); ctx.fill();
        for (let i = 0; i < 26; i++) {
          const j = Math.floor(r() * (pts.length - 2)), [x, y, wd] = pts[j]; if (wd < 4) continue;
          const s = 5 + r() * wd * 0.35; ctx.save(); ctx.translate(x + (r() - 0.5) * wd * 0.8, y + (r() - 0.5) * wd * 0.8); ctx.rotate(r() * TAU);
          ctx.fillStyle = r() < 0.5 ? (oc.hi || '#e8cf6a') : (oc.color || '#9a7e2a'); ctx.fillRect(-s / 2, -s / 2, s, s); ctx.strokeStyle = oc.dark || '#5b4a18'; ctx.lineWidth = 1.5; ctx.strokeRect(-s / 2, -s / 2, s, s);
          ctx.fillStyle = 'rgba(255,250,220,.8)'; ctx.fillRect(-s / 2, -s / 2, s * 0.35, s * 0.2); ctx.restore();
        }
      } else if (pl.kind !== 'cassure' && mulberry32(spec.seed + 41)() < 0.5) {
        /* rien… sinon des dendrites de manganèse : de faux fossiles */
        const r = mulberry32(spec.seed + 31);
        ctx.strokeStyle = ink ? 'rgba(30,20,10,.25)' : 'rgba(30,20,10,.55)'; ctx.lineCap = 'round';
        const branch = (x, y, a, len, wd, depth) => { if (depth > 5 || len < 6) return; const x2 = x + Math.cos(a) * len, y2 = y + Math.sin(a) * len; ctx.lineWidth = wd; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x2, y2); ctx.stroke(); const n = 2 + (r() < 0.4 ? 1 : 0); for (let i = 0; i < n; i++) branch(x2, y2, a + (r() - 0.5) * 1.3, len * (0.55 + r() * 0.2), wd * 0.7, depth + 1); };
        const [ua, wa] = pl.contour.uw[Math.floor(r() * pl.contour.uw.length)];
        const a0 = Math.atan2(Y(cw) - Y(wa), X(cu) - X(ua));
        for (let i = 0; i < 3; i++) branch(X(ua), Y(wa), a0 + (r() - 0.5) * 0.8, 60 + r() * 50, 4, 0);
      }
      ctx.restore();
      ctx.beginPath(); pl.contour.uw.forEach(([u, w], i) => (i ? ctx.lineTo(X(u), Y(w)) : ctx.moveTo(X(u), Y(w)))); ctx.closePath();
      ctx.strokeStyle = pal.ink; ctx.lineWidth = 7; ctx.stroke();
      tex.needsUpdate = true;
    };
    draw();
    if (img && !img.complete) img.addEventListener('load', draw, { once: true });
    tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
    return tex;
  }
  function capMesh(pl, tex, sign) {
    const THREE = T3(), uw = pl.contour.uw, tris = THREE.ShapeUtils.triangulateShape(uw.map(([u, w]) => new THREE.Vector2(u, w)), []);
    const pos = [], uv = [], off = pl.N.clone().multiplyScalar(pl.d + sign * 0.0015);
    for (const [u, w] of uw) { const p = off.clone().addScaledVector(pl.U, u).addScaledVector(pl.W, w); pos.push(p.x, p.y, p.z); uv.push(...pl.uvMap(u, w)); }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    g.setIndex(tris.flat());
    const m = new THREE.Mesh(g, new THREE.MeshBasicMaterial({ map: tex, side: THREE.DoubleSide }));
    m.renderOrder = 1;
    return m;
  }

  /* ---------- l'ouverture : craque, claque, bascule, retombe ---------- */
  function open(pl, outcome, P) {
    const THREE = T3();
    rock.done = true;
    /* le jeu décide de ce qui sort ; on dessine la face en conséquence */
    const cap = O.onSplit ? O.onSplit(outcome) : null;
    const N = pl.N.clone(), D = pl.d;
    const planeA = new THREE.Plane(), planeB = new THREE.Plane();
    rock.mat.clippingPlanes = [planeA]; rock.hullMat.clippingPlanes = [planeA];
    const matB = rock.mat.clone(); matB.uniforms = rock.u; matB.clippingPlanes = [planeB];
    const hullB = rock.hullMat.clone(); hullB.uniforms = rock.hullMat.uniforms; hullB.clippingPlanes = [planeB];
    const top = new THREE.Group(); top.add(new THREE.Mesh(ST.geo, matB)); top.add(new THREE.Mesh(ST.geo, hullB));
    rock.cracks.children.slice().forEach(c => { const c2 = c.clone(); c2.material = c.material.clone(); c2.material.clippingPlanes = [planeB]; top.add(c2); c.material = c.material.clone(); c.material.clippingPlanes = [planeA]; });
    rock.spin.add(top);
    const texA = capTexture(pl, 'full', cap, P), texB = capTexture(pl, 'ink', cap, P);
    rock.group.add(capMesh(pl, texA, 1)); top.add(capMesh(pl, texB, -1));
    const loop = pl.contour.pts.filter((_, i) => i % 2 === 0).map(p => p.clone().multiplyScalar(1.01));
    const climax = cap && cap.climax ? cap.climax : 0, curve = new THREE.CatmullRomCurve3(loop, true);
    const flash = new THREE.Mesh(new THREE.TubeGeometry(curve, loop.length * 2, climax ? 0.018 : 0.014, 4, true), new THREE.MeshBasicMaterial({ color: climax ? '#ffd257' : spec.pal.ink }));
    rock.group.add(flash);
    /* une grande trouvaille : la lumière fuit par la fissure, la pierre tremble, puis cède */
    let glow = null;
    if (climax) { glow = new THREE.Mesh(new THREE.TubeGeometry(curve, loop.length * 2, 0.06, 6, true), new THREE.MeshBasicMaterial({ color: '#ffcf5a', transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending })); rock.group.add(glow); }
    /* cadrage final : la face ouverte vient vers nous ; les deux moitiés côte à côte, jamais l'une sur l'autre */
    const r = O.host.getBoundingClientRect(), portrait = r.width < r.height * 1.05;
    const q1 = new THREE.Quaternion().setFromUnitVectors(N.clone(), new THREE.Vector3(0, 0.4, 0.92).normalize());
    const away = (portrait ? new THREE.Vector3(0, 1, 0) : new THREE.Vector3(1, 0, 0)).applyQuaternion(q1.clone().invert()).projectOnPlane(N).normalize();
    const hingeAx = new THREE.Vector3().crossVectors(N, away).normalize();
    const pa = ST.geo.attributes.position, v = new THREE.Vector3(); let maxA = -1e9, minA = 1e9, minH = 1e9, maxH = -1e9;
    for (let i = 0; i < pa.count; i++) { v.fromBufferAttribute(pa, i); const a = v.dot(away), h = v.dot(hingeAx); maxA = Math.max(maxA, a); minA = Math.min(minA, a); minH = Math.min(minH, h); maxH = Math.max(maxH, h); }
    const e = maxA + 0.07, H = N.clone().multiplyScalar(D).addScaledVector(away, e);
    const tn = Math.tan(camera.fov * Math.PI / 360), asp = camera.aspect, room = O.room || 0.62;
    const along = 2 * (e - minA) * 1.08, across = (maxH - minH) * 1.12;
    const zA = (portrait ? along : across) / (2 * tn * room), zB = (portrait ? across : along) / (2 * tn * asp * 0.92);
    const z1 = Math.max(zA, zB, camera.position.z * 0.9);
    const pre = climax === 2 ? 1500 : climax ? 950 : 0;
    rock.top = { kind: outcome.kind, climax, pre, glow, P, group: top, planeA, planeB, N, D, t0: performance.now() + pre, q0: rock.spin.quaternion.clone(), q1, hingeAx, H, z0: camera.position.z, z1, y1: 2 * z1 * tn * (0.5 - room / 2), flash, ev: {} };
    SND.snap();
    dust(P, 10);
    const slow = cap && cap.slow ? cap.slow : 0;
    rock.top.slow = slow;
    setTimeout(() => { if (O.onOpened) O.onOpened(outcome, cap); }, 950 + slow + pre);
  }
  function updateOpening(now) {
    const THREE = T3(), Tp = rock && rock.top; if (!Tp) return;
    const t = (now - Tp.t0) / (1 + (Tp.slow || 0) / 900);
    const kr = easeOutCubic(clamp(t / 520, 0, 1));
    rock.spin.quaternion.copy(Tp.q0).slerp(Tp.q1, kr);
    rock.spin.position.copy(Tp.H).applyQuaternion(rock.spin.quaternion).multiplyScalar(-kr);
    world.position.y = Tp.y1 * kr;
    camera.position.z = Tp.z0 + (Tp.z1 - Tp.z0) * kr;
    let ang = 0, lift = 0, hop = 0;
    if (t >= 90 && t < 270) { const k = (t - 90) / 180, e2 = easeOutBack(k); lift = 0.2 * e2; ang = 0.55 * e2; hop = 0.06 * Math.sin(Math.PI * k); }
    else if (t >= 270 && t < 600) { const k = (t - 270) / 330; lift = 0.2 * (1 - k * k); ang = 0.55 + (Math.PI - 0.55) * k * k; }
    else if (t >= 600) { const k = (t - 600) / 300; ang = Math.PI - 0.13 * Math.abs(Math.sin(k * Math.PI * 2.2)) * Math.exp(-4.5 * k); hop = 0.025 * Math.abs(Math.sin(k * Math.PI * 2.2)) * Math.exp(-6 * k); }
    if (t >= 90 && !Tp.ev.clac) { Tp.ev.clac = 1; SND.clac(); if (Tp.glow) { rock.group.remove(Tp.glow); Tp.glow.geometry.dispose(); Tp.glow = null; dust(Tp.P, Tp.climax === 2 ? 40 : 26, '#ffd257'); shake(0.09); } if (Tp.kind === 'fil' && rock.lastP) pop('CLAC', 42, '#fff1cc', rock.lastP, 'heavy'); shake(0.05); rock.group.remove(Tp.flash); Tp.flash.geometry.dispose(); if (O.buzz) O.buzz(18); }
    if (t >= 600 && !Tp.ev.thud) { Tp.ev.thud = 1; SND.thud(); shake(0.035); if (O.buzz) O.buzz(10); }
    if (t < 0) {
      /* la montée : tremblement croissant, lueur qui pulse, crépitements */
      const kp = clamp(1 + (now - Tp.t0) / Tp.pre, 0, 1), j = 0.01 + 0.035 * kp * kp;
      rock.spin.position.x += (Math.random() - 0.5) * j; rock.spin.position.y += (Math.random() - 0.5) * j;
      Tp.flash.visible = true;
      if (Tp.glow) Tp.glow.material.opacity = (0.2 + 0.65 * kp) * (0.65 + 0.35 * Math.sin(now / 40));
      if (!Tp.ev.rumble) { Tp.ev.rumble = 1; knock({ exc: 0.05, vol: 0.9, click: ['lowpass', 180, 0.7, 1.2], modes: [[60, 2, 1.4, 0.6], [95, 3, 0.8, 0.4]] }); }
      if (Math.random() < 0.06 + 0.25 * kp) crackle(1, 0.01, 0.35 + 0.4 * kp);
      if (Math.random() < 0.02 + 0.05 * kp) pop('crr', 13 + 6 * kp, '#ffe6a0', Tp.P, 'thin');
    } else if (t < 90) Tp.flash.visible = (Math.floor(t / 30) % 2) === 0;
    const q = new THREE.Quaternion().setFromAxisAngle(Tp.hingeAx, ang);
    Tp.group.quaternion.copy(q);
    Tp.group.position.copy(Tp.H).sub(Tp.H.clone().applyQuaternion(q)).addScaledVector(Tp.N, lift);
    rock.group.position.copy(Tp.N).multiplyScalar(hop);
    rock.spin.updateMatrixWorld(true);
    const toWorld = (obj, sign) => { const pl = new THREE.Plane(Tp.N.clone().multiplyScalar(sign), -Tp.D * sign); pl.applyMatrix4(obj.matrixWorld); return pl; };
    Tp.planeA.copy(toWorld(rock.group, -1));
    Tp.planeB.copy(toWorld(Tp.group, 1));
  }
  /* position écran (dans l'établi) du centre de la face ouverte : d'où s'envolent les blocs */
  function capScreen() {
    if (!rock || !rock.top) return null;
    const THREE = T3(), r = cv.getBoundingClientRect();
    const p = rock.group.localToWorld(rock.top.N.clone().multiplyScalar(rock.top.D)).project(camera);
    const q = rock.group.localToWorld(rock.top.N.clone().multiplyScalar(rock.top.D).add(new THREE.Vector3(0.5, 0, 0))).project(camera);
    return { x: r.left + (p.x + 1) / 2 * r.width, y: r.top + (1 - p.y) / 2 * r.height, k: Math.abs(q.x - p.x) / 2 * r.width * 2 };
  }

  /* ---------- petits effets et boucle ---------- */
  function shake(a) { shakeAmt = Math.max(shakeAmt, a); }
  function dust(P, n, color) {
    const THREE = T3(), w = rock.mesh.localToWorld(P.clone());
    for (let i = 0; i < n; i++) {
      const m = new THREE.Mesh(new THREE.TetrahedronGeometry(0.018 + Math.random() * 0.025), new THREE.MeshBasicMaterial({ color: color || (Math.random() < 0.5 ? spec.pal.light : spec.pal.base) }));
      m.position.copy(w); scene.add(m);
      dusts.push({ m, v: new THREE.Vector3((Math.random() - 0.5) * 1.6, Math.random() * 1.4 + 0.3, (Math.random() - 0.2) * 1.2), t: 0 });
    }
  }
  /* où se place la loupe (coordonnées écran) : juste au-dessus du doigt ; plus près s'il manque de place en haut ; à côté tout en haut */
  const LENS = 132;
  function lensPos(fx, fy) {
    const L = LENS, W = window.innerWidth;
    let lx = fx - L / 2, ly = fy - L / 2 - 92;
    if (ly < 8) ly = fy - L / 2 - 72;
    if (ly < 8) { ly = Math.max(8, fy - L / 2); lx = fx + (fx > W / 2 ? -L - 56 : 56); }
    lx = clamp(lx, 8, W - L - 8);
    return { lx, ly, ax: lx + L / 2, ay: ly + L / 2 };
  }
  /* au doigt : la frappe part sous le doigt, la loupe au-dessus le montre en grand */
  function aimFromFinger() {
    /* la loupe montre ce qu'il y a sous le doigt ; sa croix, c'est l'endroit où la frappe va tomber */
    const hr = O.host.getBoundingClientRect();
    down.P = pick(down.fx, down.fy); down.cx = down.fx - hr.left; down.cy = down.fy - hr.top;
    $e('.b3-ring').classList.toggle('off', !down.P);
  }
  function drawLens() {
    const lens = lensEl;
    if (!down || !down.charging || !down.touch) { lens.style.display = 'none'; return; }
    const held = performance.now() - down.t;
    if (held < 120) return;
    const L = LENS, dpr = Math.min(window.devicePixelRatio || 1, 2), hr = O.host.getBoundingClientRect();
    if (lens.width !== L * dpr) lens.width = lens.height = L * dpr;
    if (!down.moved) { down.aim = true; aimFromFinger(); }
    const { lx, ly } = lensPos(down.fx, down.fy);
    lens.style.left = Math.round(lx) + 'px'; lens.style.top = Math.round(ly) + 'px'; lens.style.display = 'block';
    /* échelles séparées en x et en y : si la hauteur de l'écran a bougé (barre du navigateur), l'image n'est plus carrée */
    const half = L / 3, gkx = cv.width / cv.clientWidth, gky = cv.height / cv.clientHeight, bg = O.background && O.background();
    lensCtx.save(); lensCtx.setTransform(dpr, 0, 0, dpr, 0, 0); lensCtx.clearRect(0, 0, L, L);
    lensCtx.fillStyle = '#6e4a2b'; lensCtx.fillRect(0, 0, L, L);
    if (bg) { const br = bg.getBoundingClientRect(), bkx = bg.width / br.width, bky = bg.height / br.height; lensCtx.drawImage(bg, (hr.left - br.left + down.cx - half) * bkx, (hr.top - br.top + down.cy - half) * bky, half * 2 * bkx, half * 2 * bky, 0, 0, L, L); }
    lensCtx.drawImage(cv, (down.cx - half) * gkx, (down.cy - half) * gky, half * 2 * gkx, half * 2 * gky, 0, 0, L, L);
    const k = ringK(down, performance.now()), s = 10 + k * 26;
    if (down.geo) {
      /* la bonne dose : une bande violette entre deux cercles */
      const a = 10 + (0.15 + 0.85 * 0.3) * 26, b = 10 + (0.15 + 0.85 * 0.65) * 26;
      lensCtx.fillStyle = 'rgba(180,138,232,.35)'; lensCtx.beginPath(); lensCtx.arc(L / 2, L / 2, b, 0, TAU); lensCtx.arc(L / 2, L / 2, a, 0, TAU, true); lensCtx.fill();
      lensCtx.strokeStyle = 'rgba(220,200,255,.7)'; lensCtx.lineWidth = 1; lensCtx.beginPath(); lensCtx.arc(L / 2, L / 2, a, 0, TAU); lensCtx.stroke(); lensCtx.beginPath(); lensCtx.arc(L / 2, L / 2, b, 0, TAU); lensCtx.stroke();
    }
    const inBand = down.geo && k >= 0.15 + 0.85 * 0.3 && k <= 0.15 + 0.85 * 0.65;
    lensCtx.strokeStyle = inBand ? '#e7d4ff' : !down.P ? 'rgba(247,236,212,.35)' : held > 260 ? '#ffcb5c' : '#f7ecd4'; lensCtx.lineWidth = 2.5; lensCtx.beginPath(); lensCtx.arc(L / 2, L / 2, s, 0, TAU); lensCtx.stroke();
    lensCtx.strokeStyle = 'rgba(30,15,5,.8)'; lensCtx.lineWidth = 1.5; lensCtx.beginPath(); lensCtx.moveTo(L / 2 - 8, L / 2); lensCtx.lineTo(L / 2 + 8, L / 2); lensCtx.moveTo(L / 2, L / 2 - 8); lensCtx.lineTo(L / 2, L / 2 + 8); lensCtx.stroke();
    lensCtx.restore();
  }
  function baseZ() { const r = O.host.getBoundingClientRect(), a = r.width / Math.max(1, r.height); return (a < 0.75 ? 7.2 / Math.max(0.55, a / 0.75) : 6.4) * 1.12 / (spec && spec.scale || 1); }
  function resize() {
    if (!ok()) return;
    const r = O.host.getBoundingClientRect(); if (!r.width || !r.height) return;
    renderer.setSize(r.width, r.height, false);
    camera.aspect = r.width / r.height;
    if (!rock || !rock.top) camera.position.z = baseZ();
    camera.updateProjectionMatrix();
  }
  function frame(now) {
    if (!active) { running = false; return; }
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    if (rock) {
      if (!down && !rock.done && (Math.abs(vel.x) + Math.abs(vel.y) > 0.2)) { rotateBy(vel.x, vel.y); vel.x *= 0.9; vel.y *= 0.9; }
      if (rock.focus) { const F = rock.focus, k = clamp((now - F.t0) / F.dur, 0, 1); if (down || rock.done) rock.focus = null; else { rock.spin.quaternion.copy(F.q0).slerp(F.q1, easeOutCubic(k)); if (k >= 1) rock.focus = null; } }
      if (down && down.charging) {
        const ring = $e('.b3-ring'), held = now - down.t, k = ringK(down, now), s = 20 + k * 52;
        ring.style.opacity = held > 120 && !down.touch ? 1 : 0; ring.style.width = ring.style.height = s + 'px'; ring.style.margin = (-s / 2) + 'px 0 0 ' + (-s / 2) + 'px';
        ring.classList.toggle('hard', held > 260); ring.classList.toggle('geo', !!down.geo); cv.classList.add('charging');
      }
      rock.u.uTime.value = now / 1000;
      updateOpening(now);
      world.position.x = (Math.random() - 0.5) * shakeAmt; if (!rock.top) world.position.y = (Math.random() - 0.5) * shakeAmt; shakeAmt *= 0.8;
    }
    for (let i = dusts.length - 1; i >= 0; i--) { const d = dusts[i]; d.t += dt; d.v.y -= 4 * dt; d.m.position.addScaledVector(d.v, dt); d.m.rotation.x += dt * 6; if (d.t > 1) { scene.remove(d.m); d.m.geometry.dispose(); dusts.splice(i, 1); } }
    renderer.render(scene, camera);
    drawLens();
    requestAnimationFrame(frame);
  }
  /* pour les tests */
  const debug = () => ({ ST, rock, tap, strike, onPlane, distToContent, surfacePoint, proxOf, hotIndex });
  return { init, ok, load, clear, pause, resume, resize, capScreen, debug, guide, get busy() { return !!(rock && rock.done); } };
})();
