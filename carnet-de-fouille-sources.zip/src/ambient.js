/* ---------- musique d'ambiance : « Matin de fouille » ----------
   Ré majeur, chaleureux et posé : Ré maj9 · Sol maj7 · Si m7 · La sus4, un accord toutes les 6,4 s (75 bpm).
   Une nappe claire, une basse douce, et le handpan d'Adrien (vrais enregistrements, HANDPAN_SAMPLES) qui égrène
   les notes de l'accord en croches, avec le ding grave de temps en temps. Une petite salle de réverbération donne de l'air.
   Sur la carte seulement : des feuilles qui bruissent, un oiseau qui chante. Plus discrète à l'établi. */
const AMB = { carte: 0.34, musee: 0.3, etabli: 0.15 };   /* volume général de l'ambiance selon l'écran */
const HP_VOL = 1.25;                                      /* volume du handpan par rapport à la nappe */
const Ambient = {
  on: false, g: null, envG: null, verb: null, padBus: null, timers: [], step: 0, buf: null, idx: 0, mode: 'calme',
  BLOCK: 6.4,
  PROG: [
    { name: 'Ré maj9', bass: 146.83, pad: [185, 220, 277.18, 329.63], arp: ['D4', 'E4', 'Fs4', 'A4', 'Cs5'] },
    { name: 'Sol maj7', bass: 98, pad: [196, 246.94, 293.66, 369.99], arp: ['D4', 'Fs4', 'G4', 'B4', 'A4'] },
    { name: 'Si m7', bass: 123.47, pad: [185, 220, 246.94, 293.66], arp: ['B3', 'D4', 'Fs4', 'A4', 'B4'] },
    { name: 'La sus4', bass: 110, pad: [164.81, 220, 293.66, 329.63], arp: ['A3', 'D4', 'E4', 'A4', 'E4'] }
  ],
  /* l'accueil, l'introduction et le tutoriel : un petit thème enjoué et chaloupé à 112 bpm, qui revient en boucle.
     Ré · Si m · Sol · La, une mesure par accord ; croches swinguées ; basse qui rebondit (fondamentale, quinte) ; taks sur 2 et 4.
     Le thème : 8 croches par mesure (null = silence), deux fins de phrase qui alternent. */
  JOY_BLOCK: 60 / 112 * 4,
  JOY: [
    { bass: [146.83, 220], hp: ['D4', null, 'Fs4', 'A4', null, 'A4', 'Fs4', null] },
    { bass: [123.47, 185], hp: ['B3', null, 'D4', 'Fs4', null, 'Fs4', 'E4', 'D4'] },
    { bass: [98, 146.83], hp: ['B3', null, 'D4', 'G4', null, 'B4', 'A4', 'G4'] },
    { bass: [110, 164.81], hp: ['A3', 'Cs4', 'E4', 'A4', null, 'Cs5', null, 'A4'], alt: ['E4', null, 'Cs4', null, 'A3', null, null, null] }
  ],
  TRIM: { G4: 1.4 },   /* le sol 4 a été enregistré 3 dB plus bas */
  level() { return AMB[SCREEN] || AMB.carte; },
  wild() { return SCREEN === 'carte' && !G.voyage && this.mode !== 'joyeux'; },
  /* calme (le jeu) ou joyeux (accueil, introduction, tutoriel) : le changement se fait à l'accord suivant, en repartant de ré */
  setMode(m) { if (this.mode === m) return; this.mode = m; this.step = 0; this.screen(); },
  start() {
    if (this.on || !G.set.son || G.set.amb === false) return;
    const c = Sound.ensure(); if (!c) return;
    try {
      this.on = true;
      /* sortie : un limiteur doux, pour ne jamais saturer avec les bruitages */
      const lim = c.createDynamicsCompressor(); lim.threshold.value = -12; lim.knee.value = 6; lim.ratio.value = 10; lim.attack.value = 0.003; lim.release.value = 0.25; lim.connect(c.destination);
      const g = this.g = c.createGain(); g.gain.value = 0.0001; g.connect(lim);
      /* l'air : un écho léger à deux têtes, adouci, qui se répète en s'éteignant (bien moins coûteux qu'une réverbération à convolution) */
      const v = this.verb = c.createGain(), wet = c.createGain(); wet.gain.value = 0.28;
      [[0.137, 0.42], [0.211, 0.38]].forEach(([d, fb]) => { const dl = c.createDelay(1), lp = c.createBiquadFilter(), f = c.createGain(); dl.delayTime.value = d; lp.type = 'lowpass'; lp.frequency.value = 2400; f.gain.value = fb; v.connect(dl); dl.connect(lp).connect(f).connect(dl); lp.connect(wet); });
      wet.connect(g);
      /* la nappe : un seul filtre pour toutes les voix */
      this.padBus = c.createBiquadFilter(); this.padBus.type = 'lowpass'; this.padBus.frequency.value = 2800; this.padBus.Q.value = 0.4;
      this.padBus.connect(g); const ps = c.createGain(); ps.gain.value = 0.6; this.padBus.connect(ps).connect(v);
      this.envG = c.createGain(); this.envG.gain.value = this.wild() ? 1 : 0.0001; this.envG.connect(g);
      g.gain.exponentialRampToValueAtTime(this.level(), c.currentTime + 3);
      this.load();
      this.step = 0; this.chord();
      this.later(() => this.leaves(), 4000); this.later(() => this.bird(), 9000);
    } catch (e) { this.on = false; }
  },
  /* les échantillons du handpan : décodés une fois, au premier lancement */
  load() {
    if (this.buf || typeof HANDPAN_SAMPLES === 'undefined') return;
    this.buf = {};
    const c = Sound.ctx;
    Object.keys(HANDPAN_SAMPLES).forEach(k => {
      try {
        const bin = atob(HANDPAN_SAMPLES[k]), u = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
        c.decodeAudioData(u.buffer, b => { this.buf[k] = b; }, () => { });
      } catch (e) { }
    });
  },
  later(fn, ms) { const id = setTimeout(() => { this.timers = this.timers.filter(x => x !== id); if (this.on) fn(); }, ms); this.timers.push(id); },
  send(node, wet) { node.connect(this.g); if (wet) { const s = Sound.ctx.createGain(); s.gain.value = wet; node.connect(s).connect(this.verb); } },
  /* une voix de nappe : attaque et extinction lentes ; la voix du haut est doublée, à peine désaccordée */
  pad(f, t, dur, amp, o) {
    o = o || {};
    const c = Sound.ctx, vg = c.createGain(), at = o.attack || dur * 0.3;
    vg.gain.setValueAtTime(0.0001, t); vg.gain.exponentialRampToValueAtTime(amp, t + at); vg.gain.setValueAtTime(amp, t + dur * 0.62); vg.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    vg.connect(o.bus || this.padBus);
    (o.det || [0]).forEach(det => { const x = c.createOscillator(); x.type = o.type || 'triangle'; x.frequency.value = f; x.detune.value = det; x.connect(vg); x.start(t); x.stop(t + dur + 0.1); });
  },
  /* une basse pincée, courte (mode joyeux) */
  pluck(f, t, amp) {
    const c = Sound.ctx, x = c.createOscillator(), e = c.createGain();
    x.type = 'sine'; x.frequency.value = f; e.gain.setValueAtTime(0.0001, t); e.gain.exponentialRampToValueAtTime(amp, t + 0.01); e.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
    x.connect(e).connect(this.g); x.start(t); x.stop(t + 0.55);
  },
  /* une note du handpan */
  hp(note, t, amp) {
    const b = this.buf && this.buf[note]; if (!b) return;
    const c = Sound.ctx, s = c.createBufferSource(), g = c.createGain(), w = c.createGain();
    s.buffer = b; g.gain.value = amp * HP_VOL * (this.TRIM[note] || 1) * (0.85 + Math.random() * 0.25);
    w.gain.value = 0.45; s.connect(g); g.connect(this.g); g.connect(w).connect(this.verb); s.start(t);
  },
  chord() {
    if (!this.on) return;
    const joy = this.mode === 'joyeux', t = Sound.ctx.currentTime + 0.08;
    if (!document.hidden) { if (joy) this.joyBar(t); else this.calmBar(t); }
    this.step++;
    this.later(() => this.chord(), (joy ? this.JOY_BLOCK : this.BLOCK) * 1000);
  },
  calmBar(t) {
    const C = this.PROG[this.step % this.PROG.length], len = this.BLOCK * 1.35;
    this.pad(C.bass, t, len, 0.16, { type: 'sine', bus: this.g });
    C.pad.forEach((f, k) => this.pad(f, t + k * 0.12, len, 0.04, { attack: 1.4, det: k === C.pad.length - 1 ? [-5, 5] : [0] }));
    /* le ding grave sur le premier temps, un accord sur deux */
    if (this.step % 2 === 0) this.hp('D3', t, 0.34);
    /* 16 croches de 0,4 s : environ six notes, qui montent puis redescendent dans l'accord */
    const e = this.BLOCK / 16;
    for (let s = 0; s < 16; s++) {
      if (Math.random() < (s % 4 === 0 ? 0.7 : 0.28)) {
        this.idx = Math.max(0, Math.min(C.arp.length - 1, this.idx + (Math.random() < 0.6 ? 1 : -1) * (s > 8 ? -1 : 1)));
        this.hp(C.arp[this.idx], t + s * e + (Math.random() - 0.5) * 0.02, s % 4 === 0 ? 0.3 : 0.22);
      }
    }
  },
  /* un tak : la paume sur la tôle, un souffle court et sec */
  tak(t, amp) {
    const c = Sound.ctx, n = c.createBufferSource(), f = c.createBiquadFilter(), e = c.createGain();
    n.buffer = Sound.noise(); f.type = 'bandpass'; f.frequency.value = 1700; f.Q.value = 1.3;
    e.gain.setValueAtTime(0.0001, t); e.gain.exponentialRampToValueAtTime(amp, t + 0.004); e.gain.exponentialRampToValueAtTime(0.0001, t + 0.07);
    n.connect(f).connect(e).connect(this.g); n.start(t); n.stop(t + 0.1);
  },
  /* une mesure du thème : croches swinguées, basse qui rebondit, taks sur 2 et 4, un ding tous les deux tours */
  joyBar(t) {
    const C = this.JOY[this.step % this.JOY.length], beat = this.JOY_BLOCK / 4, cycle = Math.floor(this.step / this.JOY.length);
    const line = C.alt && cycle % 2 === 1 ? C.alt : C.hp;
    this.pluck(C.bass[0], t, 0.22); this.pluck(C.bass[1], t + beat, 0.12); this.pluck(C.bass[0], t + beat * 2, 0.17); this.pluck(C.bass[1], t + beat * 3, 0.12);
    this.tak(t + beat, 0.09); this.tak(t + beat * 3, 0.09);
    if (Math.random() < 0.5) this.tak(t + beat * 3.66, 0.04);
    if (this.step % 8 === 0) this.hp('D3', t, 0.4);
    line.forEach((n, i) => {
      if (!n) return;
      /* la croche du temps tombe pile, celle d'après un peu en retard : le swing */
      const at = t + Math.floor(i / 2) * beat + (i % 2 ? beat * 0.62 : 0);
      this.hp(n, at, i % 2 ? 0.24 : 0.32);
    });
  },
  /* des feuilles qui bruissent : un souffle aigu qui enfle et retombe, avec de petits froissements */
  leaves() {
    const c = Sound.ctx;
    if (this.wild() && !document.hidden) {
      const t = c.currentTime + 0.05, dur = 1.8 + Math.random() * 2, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
      s.buffer = Sound.noise(); s.loop = true; f.type = 'bandpass'; f.frequency.value = 3200 + Math.random() * 1800; f.Q.value = 0.8;
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.06, t + dur * 0.45); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      s.connect(f).connect(g).connect(this.envG); s.start(t); s.stop(t + dur + 0.1);
      for (let i = 0; i < 7; i++) { const tt = t + Math.random() * dur * 0.9, b = c.createBufferSource(), bf = c.createBiquadFilter(), bg = c.createGain(); b.buffer = Sound.noise(); bf.type = 'highpass'; bf.frequency.value = 4500; bg.gain.setValueAtTime(0.0001, tt); bg.gain.exponentialRampToValueAtTime(0.035, tt + 0.006); bg.gain.exponentialRampToValueAtTime(0.0001, tt + 0.05); b.connect(bf).connect(bg).connect(this.envG); b.start(tt); b.stop(tt + 0.08); }
    }
    this.later(() => this.leaves(), 7000 + Math.random() * 12000);
  },
  /* un oiseau : trois chants possibles, une courte phrase, puis le silence */
  bird() {
    const c = Sound.ctx;
    if (this.wild() && !document.hidden) {
      let t = c.currentTime + 0.05;
      const kind = Math.floor(Math.random() * 3), base = 2600 + Math.random() * 900, notes = kind === 0 ? 3 + Math.floor(Math.random() * 3) : kind === 1 ? 2 : 5;
      for (let i = 0; i < notes; i++) {
        const o = c.createOscillator(), g = c.createGain(), d = kind === 2 ? 0.05 : 0.11 + Math.random() * 0.06;
        const f0 = kind === 1 ? base * (i ? 0.84 : 1.12) : base * (0.95 + Math.random() * 0.15), f1 = kind === 0 ? f0 * 1.25 : kind === 1 ? f0 * 0.9 : f0 * 1.08;
        o.type = 'sine'; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + d);
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.035, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
        o.connect(g).connect(this.envG); o.start(t); o.stop(t + d + 0.05);
        t += d + (kind === 2 ? 0.035 : 0.07 + Math.random() * 0.08);
      }
    }
    this.later(() => this.bird(), 14000 + Math.random() * 22000);
  },
  /* l'écran change : plus discrète à l'établi ; la nature ne s'entend que sur la carte */
  screen() {
    if (!this.on || !Sound.ctx) return;
    const t = Sound.ctx.currentTime;
    this.g.gain.cancelScheduledValues(t); this.g.gain.setTargetAtTime(this.level(), t, 0.7);
    this.envG.gain.cancelScheduledValues(t); this.envG.gain.setTargetAtTime(this.wild() ? 1 : 0.0001, t, 0.6);
  },
  stop() {
    if (!this.on) return; this.on = false;
    this.timers.forEach(clearTimeout); this.timers = [];
    const c = Sound.ctx, g = this.g;
    try { g.gain.setTargetAtTime(0.0001, c.currentTime, 0.4); } catch (e) { }
    setTimeout(() => { try { g.disconnect(); } catch (e) { } }, 2500);
  },
  sync() { if (G.set.son && G.set.amb !== false) this.start(); else this.stop(); }
};
