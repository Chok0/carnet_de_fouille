/* ============ fossiles : Quaternaire ============ */
/* aides préfixées q_ (seuls noms de haut niveau avec les art<Id>) */
function q_op(p, o) { return 'opacity="' + (p.flat ? 1 : o) + '"'; }
/* points (pores) : segments nuls à bouts ronds, tous dans un seul d */
function q_dots(pts, col, w, extra) {
  let d = '';
  for (let i = 0; i < pts.length; i++) d += 'M' + PS(pts[i]) + 'h0';
  return pts.length ? E.p(d, null, col, w, 'stroke-linecap="round"' + (extra ? ' ' + extra : '')) : '';
}
function q_inPoly(q, poly) {
  let c = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i], b = poly[j];
    if ((a[1] > q[1]) !== (b[1] > q[1]) && q[0] < (b[0] - a[0]) * (q[1] - a[1]) / (b[1] - a[1]) + a[0]) c = !c;
  }
  return c;
}
/* semis reproductible de points dans un polygone (os poreux) */
function q_stipple(poly, n, seed, pad) {
  const rnd = mulberry32(seed), out = [];
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  poly.forEach(q => { x0 = Math.min(x0, q[0]); y0 = Math.min(y0, q[1]); x1 = Math.max(x1, q[0]); y1 = Math.max(y1, q[1]); });
  for (let k = 0; k < n * 10 && out.length < n; k++) {
    const q = [lerp(x0, x1, rnd()), lerp(y0, y1, rnd())];
    if (!q_inPoly(q, poly)) continue;
    if (pad && poly.some(v => Math.hypot(v[0] - q[0], v[1] - q[1]) < pad)) continue;
    if (out.some(v => Math.hypot(v[0] - q[0], v[1] - q[1]) < 2.2)) continue;
    out.push(q);
  }
  return out;
}
/* décalage d'une polyligne le long de sa normale (distance fixe ou fonction de t) ; > 0 = à droite du sens de parcours */
function q_offset(pts, dist) {
  return pts.map((q, i) => { const t = tangentAt(pts, i), k = typeof dist === 'function' ? dist(i / (pts.length - 1)) : dist; return [q[0] - t[1] * k, q[1] + t[0] * k]; });
}
/* bande entre deux décalages d'une polyligne */
function q_band(pts, d0, d1) { return polyD(q_offset(pts, d0).concat(q_offset(pts, d1).reverse()), true); }
/* suture dentelée : zigzag irrégulier (reproductible) le long de pts */
function q_zig(pts, amp, step, seed) {
  const rnd = mulberry32(seed || 7), n = Math.max(3, Math.round(arcLen(pts) / step)), P = resample(pts, n + 1);
  let d = 'M' + PS(P[0]);
  for (let i = 1; i < P.length; i++) {
    const t = tangentAt(P, i), k = i === P.length - 1 ? 0 : (i % 2 ? 1 : -1) * amp * (0.55 + 0.9 * rnd());
    d += 'L' + PS([P[i][0] - t[1] * k, P[i][1] + t[0] * k]);
  }
  return d;
}
/* dent conique : base b0-b1, pointe tip, renflement k */
function q_toothD(b0, b1, tip, k) {
  const m0 = [lerp(b0[0], tip[0], 0.55), lerp(b0[1], tip[1], 0.55)], m1 = [lerp(b1[0], tip[0], 0.55), lerp(b1[1], tip[1], 0.55)];
  const n0 = [b0[0] - b1[0], b0[1] - b1[1]], L = Math.hypot(n0[0], n0[1]) || 1;
  const c0 = [m0[0] + n0[0] / L * k, m0[1] + n0[1] / L * k], c1 = [m1[0] - n0[0] / L * k, m1[1] - n0[1] / L * k];
  return 'M' + PS(b0) + 'Q' + PS(c0) + ' ' + PS(tip) + 'Q' + PS(c1) + ' ' + PS(b1) + 'Z';
}
/* incisive en palette (bord libre arrondi) : collet x0-x1 en y0, bord libre en y1 */
function q_incD(x0, x1, y0, y1) {
  const dir = Math.sign(y1 - y0), m = (x0 + x1) / 2;
  return 'M' + r1(x0) + ' ' + y0 + 'L' + r1(x0 - 0.4) + ' ' + r1(y1 - dir * 2.5) + 'Q' + r1(x0 - 0.2) + ' ' + r1(y1 + dir * 0.6) + ' ' + r1(m) + ' ' + r1(y1 + dir * 0.6) + 'Q' + r1(x1 + 0.2) + ' ' + r1(y1 + dir * 0.6) + ' ' + r1(x1 + 0.4) + ' ' + r1(y1 - dir * 2.5) + 'L' + r1(x1) + ' ' + y0 + 'Z';
}
/* couronnes de jugales vues de profil : collet en y0, surface d'occlusion en y1 ; segs = [[x0, x1, nCuspides, h (nombre ou tableau par cuspide)]]
   renvoie { d : couronnes à cuspides arrondies, l : sillons entre cuspides, c : ligne du collet } */
function q_crownD(segs, y0, y1) {
  const dir = Math.sign(y1 - y0);
  let d = '', l = '', c = '';
  segs.forEach(([x0, x1, n, h]) => {
    const w = (x1 - x0) / n, ym = y1 - dir * 0.7;
    d += 'M' + r1(x0 + 1.2) + ' ' + y0 + 'Q' + r1(x0 - 0.6) + ' ' + r1(lerp(y0, y1, 0.6)) + ' ' + r1(x0) + ' ' + r1(ym);
    for (let k = 0; k < n; k++) {
      const a = x0 + w * k, b = a + w;
      const hk = Array.isArray(h) ? h[k] : h;
      d += 'Q' + r1((a + b) / 2) + ' ' + r1(y1 + dir * hk * 2) + ' ' + r1(b) + ' ' + r1(ym);
      if (k) l += 'M' + r1(a) + ' ' + r1(ym) + 'L' + r1(a + 0.3) + ' ' + r1(lerp(y1, y0, 0.55));
    }
    d += 'Q' + r1(x1 + 0.6) + ' ' + r1(lerp(y0, y1, 0.6)) + ' ' + r1(x1 - 1.2) + ' ' + y0 + 'Z';
    c += 'M' + r1(x0 + 1) + ' ' + r1(y0 + dir * 1.8) + 'Q' + r1((x0 + x1) / 2) + ' ' + r1(y0 + dir * 3) + ' ' + r1(x1 - 1) + ' ' + r1(y0 + dir * 1.8);
  });
  return { d: d, l: l, c: c };
}

/* ---------------- ursus — Ursus spelaeus, ours des cavernes : crâne et mandibule de profil (museau à gauche) ----------------
   ① crâne long au FRONT BOMBÉ : nasaux presque horizontaux puis « stop » abrupt vers le front gonflé par les sinus frontaux ;
      point culminant au-dessus des orbites, longue crête sagittale qui redescend jusqu'à l'inion, en surplomb de l'occiput ;
   ② dentition : incisives serrées, grosses canines (la supérieure en dehors de la mandibule, l'inférieure juste devant elle),
      long diastème sans dents (P1–P3 perdues), petite P4 puis grosses molaires broyeuses bunodontes (M2 très longue) ;
   ③ petite orbite ouverte en arrière (apophyses postorbitaires qui ne se touchent pas), arcade zygomatique large et profonde ;
   ④ mandibule profonde, apophyse coronoïde très haute qui monte dans la fosse temporale au-dessus de l'arcade, condyle, angle ;
   ⑤ ouverture nasale à l'avant (bord du prémaxillaire), trou sous-orbitaire, bosse de la racine de la canine ;
   ⑥ os : sutures dentelées (prémaxillo-maxillaire, nasale, fronto-nasale, coronale, écailleuse), os poreux, trous mentonniers.
   Repères : longueur L ≈ 256 (x 14 → 270), hauteur du crâne 0,36 L, rangée P4–M2 sous l'orbite, glène à 0,75 L. */
function artUrsus(p) {
  const cran = [[17, 109], [13.5, 100], [15, 90], [20, 84], [26, 80], [27, 71], [25, 63], [33, 58.5], [50, 55.5], [68, 53], [84, 50], [91, 47], [97, 41], [103, 32.5], [111, 25], [124, 19.5], [144, 17.5], [166, 19.5], [190, 23.5], [214, 28], [236, 32.5], [254, 36.5], [266, 40], [270, 46], [265, 57], [259, 70], [255, 84], [258, 94], [262, 102], [257, 108.5], [248, 106.5], [243, 110.5], [237, 107], [226, 105], [215, 109], [205, 107.5], [186, 106.5], [168, 106.5], [160, 111], [120, 110.5], [80, 110.5], [40, 110.5]];
  let s = E.p(smoothD(cran, true), p.body, p.line, 1.3);
  /* dos éclairé du crâne (nasaux → front → crête) */
  s += E.p(q_band(cran.slice(6, 23), 0.6, 7.5), p.relief, null, 0, q_op(p, 0.6));
  /* rostre : bosse de la racine de la canine, ouverture nasale, sutures, trou sous-orbitaire */
  s += E.p('M40 110Q39 92 47 83Q55 77 61 86Q64 98 61 110Z', p.relief, null, 0, q_op(p, 0.5)) + E.p('M47 83Q55 77 61 86Q64 98 61 110', null, p.line, 0.6, 'opacity=".55"');
  s += E.p('M25 63Q35 63.5 37 72Q37.5 81 22 84.5Q28 80 27.5 72Q27 66 25 63Z', p.accent, p.line, 0.7);
  s += E.p('M26.5 63.8Q35 64.5 36.2 72Q36.6 80 23.5 84', null, p.relief, 1.8) + E.p('M27 64.2Q35.4 65 36.8 72Q37.3 81 23 84.8', null, p.line, 0.6);
  let sut = q_zig([[38, 77], [40.5, 92], [41.5, 108]], 0.85, 2.6, 11) + q_zig([[30, 62.5], [50, 59], [70, 56.5], [87, 53]], 0.7, 2.6, 12) + q_zig([[89, 49], [96, 55], [106, 57]], 0.85, 2.6, 13);
  s += E.el(98, 86, 3.2, 2.1, -20, p.accent);
  s += q_dots(q_stipple([[40, 66], [84, 57], [99, 66], [96, 100], [66, 106], [44, 102]], 30, hashStr('urs-r'), 3), p.shade, 1.1, q_op(p, 0.85));
  s += q_dots(q_stipple([[106, 36], [150, 23], [152, 32], [134, 48], [110, 48]], 12, hashStr('urs-f'), 2), p.shade, 1, q_op(p, 0.7));
  /* fosse temporale sous la crête sagittale + paroi bombée du neurocrâne */
  s += E.p(smoothD([[134, 52], [142, 40], [156, 31], [180, 27.5], [210, 31.5], [236, 36.5], [252, 42], [259, 50], [254, 64], [248, 78], [238, 88], [220, 90], [200, 89], [178, 87], [158, 83], [146, 77], [138, 66]], true), p.shade, p.line, 0.6);
  s += E.p(smoothD([[160, 44], [194, 36.5], [228, 40.5], [247, 51], [243, 67], [222, 75], [192, 73], [168, 63]], true), p.body, null, 0, q_op(p, 0.5));
  sut += q_zig([[160, 19.5], [157, 32], [150, 48]], 0.85, 2.6, 14) + q_zig([[178, 86], [192, 71], [214, 64], [236, 71], [244, 84]], 0.85, 2.8, 15);
  s += E.p(sut, null, p.line, 0.5, 'opacity=".6"');
  /* occiput : crête nucale, condyle, mastoïde, méat auditif */
  s += E.p('M263 45Q258 64 251 84', null, p.line, 0.6, 'opacity=".6"');
  s += E.el(257.5, 101, 5.2, 7, -10, p.relief, p.line, 0.9) + E.p('M237 104Q244 103 244.5 109Q240 111.5 237 108Z', p.relief, p.line, 0.6) + E.el(229, 98, 3.4, 2.8, 0, p.accent);
  /* mandibule : branche horizontale profonde, coronoïde très haute, condyle, angle */
  const mand = [[21, 126], [18, 133], [20, 142], [27, 151], [40, 157.5], [62, 161], [96, 162], [128, 160.5], [156, 156], [180, 150], [198, 145], [211, 141], [216, 136], [213, 127], [210, 119], [207, 112], [200, 104], [196, 90], [193, 72], [190, 60], [185, 55.5], [179, 58], [173, 70], [167, 90], [161, 110], [155, 126.5], [120, 127], [80, 127], [46, 127]];
  s += E.p(smoothD(mand, true), p.body2, p.line, 1.2);
  s += E.p(smoothD([[164, 118], [170, 104], [178, 100], [200, 106], [207, 118], [206, 132], [194, 140], [176, 142], [164, 134]], true), p.shade, null, 0, q_op(p, 0.6));
  s += E.p(smoothD([[177, 88], [181, 68], [186, 60.5], [190, 68], [192, 88]], true), p.shade, null, 0, q_op(p, 0.5));
  s += E.p(q_band(mand.slice(2, 11), -0.6, t => -1 - 5.5 * Math.sin(Math.PI * t)), p.shade, null, 0, q_op(p, 0.55));
  s += q_dots(q_stipple([[48, 131], [150, 131], [154, 146], [100, 155], [52, 151]], 26, hashStr('urs-m'), 3), p.shade, 1.1, q_op(p, 0.8));
  s += q_dots([[62, 141], [86, 139]], p.accent, 2.6);
  s += E.el(207, 110, 7, 5, 12, p.relief, p.line, 0.9);
  /* dents inférieures : incisives, canine, p4 + trois molaires */
  s += E.p(q_incD(19.5, 24, 127, 117.5) + q_incD(24.2, 28.7, 127, 117) + q_incD(28.9, 33.6, 127, 116.5), p.relief, p.line, 0.7);
  s += E.p(q_toothD([33.5, 127], [47, 127], [41.5, 96], 2.8), p.relief, p.line, 0.9) + E.p('M37 123Q37.5 108 41 99', null, p.hi, 1, 'opacity=".7"') + E.p('M41 125Q42 110 41.5 100', null, p.line, 0.5, 'opacity=".5"');
  const lo = q_crownD([[89, 98.5, 1, 1.9], [99, 117, 4, [1.4, 1.2, 1, 1]], [117.5, 133, 3, 1.1], [133.5, 148, 3, [1, 0.9, 0.7]]], 127.5, 118.5);
  /* arcade zygomatique */
  const zyU = [[96, 90], [104, 82], [114, 77.8], [126, 77.2], [136, 73], [141, 68], [146, 75], [162, 83], [186, 87.5], [206, 88], [222, 86], [233, 88.5]], zyL = [[233, 94], [222, 101], [210, 104.5], [194, 104.5], [172, 103], [150, 104], [130, 105.5], [113, 103.5], [101, 99]];
  s += E.p(smoothD(zyU.concat(zyL), true), p.relief) + E.p(smoothD(zyU) + smoothD(zyL), null, p.line, 1);
  s += E.p('M112 100Q160 97 214 100', null, p.line, 0.5, 'opacity=".5"') + E.p(q_zig([[180, 88], [173, 104]], 0.9, 2.6, 16), null, p.line, 0.5, 'opacity=".6"');
  /* orbite ouverte vers l'arrière + apophyse postorbitaire du frontal */
  const oc = [122, 65], oR = 10.5, oP = a => PS([oc[0] + Math.cos(a * D2R) * oR, oc[1] + Math.sin(a * D2R) * oR]);
  s += E.c(oc[0], oc[1], oR, p.accent) + E.p('M' + oP(-60) + 'A' + oR + ' ' + oR + ' 0 0 0 ' + oP(160) + 'A7.5 7.5 0 0 1 ' + oP(-60) + 'Z', p.shade, null, 0, q_op(p, 0.8));
  s += E.p('M' + oP(-45) + 'A' + oR + ' ' + oR + ' 0 1 0 ' + oP(50), null, p.relief, 3) + E.p('M' + oP(-45) + 'A' + oR + ' ' + oR + ' 0 1 0 ' + oP(50), null, p.line, 0.8);
  s += E.p('M128.5 56Q137.5 57 140.5 63.5Q134.5 62 128.5 60.5Z', p.relief, p.line, 0.7);
  /* dents supérieures : incisives, P4 + M1 + longue M2 */
  const up = q_crownD([[96, 107, 2, [1.7, 1]], [107.5, 124, 3, [1.6, 1.5, 1.3]], [124.5, 151, 5, [1.5, 1.5, 1.3, 1, 0.7]]], 110, 119);
  s += E.p(lo.d + up.d, p.relief, p.line, 0.8) + E.p(lo.l + up.l, null, p.line, 0.5, 'opacity=".65"') + E.p(lo.c + up.c, null, p.shade, 0.7, 'opacity=".7"');
  s += E.p(q_incD(15.8, 21, 109.8, 119) + q_incD(21.2, 26.8, 110.2, 119.8) + q_toothD([27.5, 110.5], [37.5, 110.5], [31.5, 125], 1.6), p.relief, p.line, 0.7);
  /* canine supérieure, en dehors de la mandibule */
  s += E.p(q_toothD([42, 110.5], [58, 110.5], [48.5, 138], 3), p.relief, p.line, 1);
  s += E.p('M51 113Q52 126 49 134', null, p.line, 0.5, 'opacity=".5"') + E.p('M45 114Q44.5 126 47 133', null, p.hi, 1.3, 'opacity=".7"');
  /* bords alvéolaires */
  s += E.p('M16 110L60 110.5Q80 110.8 96 110.3L152 110.5M20 127L48 127Q70 127.4 89 127.3L154 127', null, p.line, 1);
  /* reflet unique : front bombé */
  s += E.p(polyD(q_offset(cran.slice(9, 18), 3.6)), null, p.hi, 1.8, 'opacity=".65"');
  return s;
}

/* ---------------- bison — Bison priscus, bison des steppes : crâne vu de face avec ses chevilles osseuses ----------------
   ① front très large et plat (frontaux), bord nucal presque droit entre les cornes ; la face se rétrécit en dessous
      en un museau long et étroit (nasaux, maxillaires, prémaxillaires sans incisives) ;
   ② chevilles osseuses des cornes aux coins du front : grosses à la base (un « col » sous le frontal), elles partent
      sur les côtés en descendant un peu puis s'incurvent vers le haut, effilées ; rainures vasculaires longitudinales ;
      chacune ≈ la largeur du crâne ;
   ③ orbites tubulaires, saillantes sur les côtés sous la base des cornes ;
   ④ os poreux (pores en semis), trous et gouttières supra-orbitaires, tubérosité faciale ;
   ⑤ nasaux étroits, ouverture nasale entre les prémaxillaires, suture médiane dentelée. Symétrie bilatérale.
   Repères : largeur aux orbites 146, bord nucal y 49, orbites y 90, museau y 195 ; envergure des cornes 268. */
function artBison(p) {
  const cx = 150, ax = cubicPts([117, 55], [76, 72], [22, 74], [17, 14], 40);
  const hw = t => 15.2 * Math.pow(1 - t, 0.92) + 0.7, at = f => q_offset(ax, t => f * hw(t));
  const up = at(1), dn = at(-1);
  const sk = [[150.5, 49], [134, 49.3], [120, 49.8], [110, 53], [103.5, 60], [100, 70], [97.5, 80], [97, 96], [99.5, 106], [104, 116], [107.5, 126], [112, 140], [117, 155], [121, 169], [125, 181], [131, 189.5], [140, 194], [150.5, 195]];
  const half = col => {
    /* cheville osseuse : cône courbé, face supérieure éclairée, dessous ombré, rainures longitudinales, pores */
    let o = E.p(smoothD(up.concat(dn.slice().reverse()), true), col, p.line, 1.2);
    o += E.p(polyD(at(0.92).slice(0, 26).concat(at(0.3).slice(0, 26).reverse()), true), p.relief, null, 0, q_op(p, 0.55));
    o += E.p(polyD(at(-0.94).slice(0, 30).concat(at(-0.42).slice(0, 30).reverse()), true), p.shade, null, 0, q_op(p, 0.5));
    let g = '';
    [-0.66, -0.34, -0.02, 0.32, 0.66].forEach((f, k) => { g += polyD(at(f).slice(2 + k % 2 * 2, 35 - k)); });
    o += E.p(g, null, p.line, 0.5, 'opacity=".55"');
    o += q_dots(q_stipple(up.slice(0, 20).concat(dn.slice(0, 20).reverse()), 18, hashStr('bis-h'), 2), p.shade, 1, q_op(p, 0.8));
    /* frontal et face (moitié gauche) : remplissage fermé sur l'axe, contour ouvert */
    o += E.p(smoothD(sk) + 'Z', col) + E.p(smoothD(sk), null, p.line, 1.3);
    o += E.p(q_band(sk.slice(0, 6), -0.6, -6.5), p.relief, null, 0, q_op(p, 0.6));
    o += E.p(q_band(sk.slice(8, 16), -0.6, -5), p.shade, null, 0, q_op(p, 0.5));
    o += q_dots(q_stipple([[146, 57], [118, 57], [106, 67], [102, 84], [106, 104], [122, 110], [146, 110]], 30, hashStr('bis-f'), 2.5), p.shade, 1.1, q_op(p, 0.8));
    o += q_dots(q_stipple([[106, 112], [136, 118], [134, 158], [124, 176], [116, 150], [108, 128]], 16, hashStr('bis-m'), 2.5), p.shade, 1, q_op(p, 0.8));
    /* trou et gouttière supra-orbitaires */
    o += E.p('M125 92Q127 103 131 116', null, p.shade, 2.2, q_op(p, 0.8)) + E.p('M126.2 92Q128.2 103 132.2 116', null, p.line, 0.5, 'opacity=".6"') + E.c(125, 90.5, 2.3, p.accent);
    /* orbite tubulaire saillante */
    o += E.p(smoothD([[101, 72], [90, 72.5], [81.5, 78], [77.5, 89], [80, 101], [88, 107.5], [101, 108]]), col, p.line, 1.1);
    o += E.p('M98 75Q88 76 83 82', null, p.relief, 2.4, q_op(p, 0.7));
    o += E.el(86, 90, 8.5, 13.5, 10, p.relief, p.line, 1) + E.el(85.2, 90.6, 5, 10, 10, p.accent);
    /* nasal, suture naso-maxillaire, ouverture nasale, prémaxillaire, tubérosité faciale, trou sous-orbitaire */
    o += E.p(smoothD([[150.5, 113], [141, 113.5], [138, 126], [139, 142], [142, 156], [146.5, 164], [150.5, 166]]) + 'Z', p.relief, null, 0, q_op(p, 0.75));
    o += E.p(q_zig([[141, 114], [138.3, 128], [139.4, 144], [143, 158], [147, 164.5]], 0.8, 2.5, 21) + q_zig([[127, 110], [139, 112.4], [150, 113.6]], 0.9, 2.5, 22), null, p.line, 0.55, 'opacity=".7"');
    o += E.p(smoothD([[150.5, 167], [146, 164.5], [141, 160.5], [137, 166], [135.5, 177], [139, 186], [145, 189.5], [150.5, 189]]) + 'Z', p.accent);
    o += E.p(taperD([[134, 157], [132.5, 171], [136, 184.5], [143, 191.5], [148.5, 193]], 5.5, 3.2), p.relief, p.line, 0.6);
    o += E.el(108.5, 128, 3.2, 5.5, -10, p.relief, p.line, 0.6) + E.el(118, 146, 1.8, 2.8, 0, p.accent);
    return o;
  };
  let s = half(p.body) + mirrorG(half(p.body2), cx);
  /* axe : suture interfrontale dentelée, suture internasale, fente entre les prémaxillaires */
  s += E.p(q_zig([[150, 51], [150, 112]], 1, 2.6, 23), null, p.line, 0.55, 'opacity=".7"') + E.p('M150 114L150 166', null, p.line, 0.6);
  s += E.p('M147.6 195.2Q150 190 152.4 195.2Z', p.accent);
  /* reflet unique : dessus de la corne gauche */
  s += E.p(polyD(at(0.62).slice(3, 21)), null, p.hi, 1.7, 'opacity=".65"');
  return s;
}

Object.assign(ART, {
  ursus: { vb: [280, 180], fn: artUrsus, area: { cx: 142, cy: 94, rx: 126, ry: 62, rot: -0.1 } },
  bison: { vb: [300, 200], fn: artBison, area: { cx: 150, cy: 88, rx: 128, ry: 70 } }
});
