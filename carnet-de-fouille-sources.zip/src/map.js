/* ============ carte du gisement : génération + rendu encre et lavis ============ */
const MAPPX = 560, CELL = MAPPX / GRID;

/* distance entre deux zones, en cases (les diagonales comptent pour une) */
const zcheb = (a, b) => Math.max(Math.abs(a % GRID - b % GRID), Math.abs(Math.floor(a / GRID) - Math.floor(b / GRID)));
function weightedIdx(rnd, w) {
  let r = rnd() * w.reduce((a, b) => a + b, 0);
  for (let i = 0; i < w.length; i++) { r -= w[i]; if (r <= 0 && w[i] > 0) return i; }
  for (let i = w.length - 1; i >= 0; i--) if (w[i] > 0) return i;
  return 0;
}
/* Un gisement : une large bande de roche propice (les couches fossilifères qui affleurent, un peu ondulées),
   bordée de roche pauvre, le reste stérile. Les squelettes dorment dans des poches, dans la bande :
   la roche dit « c'est possible ici », jamais « c'est ici ». poches : [{ z }] déjà placées (partie en cours), sinon on les place. */
function generateSite(seed, epochId, num, poches) {
  const rng = mulberry32(seed), ep = EPOCHS[epochId], SG = SITEGEN;
  const nseed = randInt(rng, 1, 999999);
  const ang = rng() * Math.PI, ca = Math.cos(ang), sa = Math.sin(ang);
  const c = [(GRID - 1) / 2 + (rng() - 0.5) * 2.2, (GRID - 1) / 2 + (rng() - 0.5) * 2.2];
  const bend = (rng() - 0.5) * 1.8, ph = rng() * TAU;
  let hw = SG.band[0] + rng() * (SG.band[1] - SG.band[0]);
  const dist = [];
  for (let y = 0; y < GRID; y++) for (let x = 0; x < GRID; x++) {
    const dx = x - c[0], dy = y - c[1], u = dx * ca + dy * sa, v = -dx * sa + dy * ca;
    dist.push(Math.abs(v - bend * Math.sin(u * 0.6 + ph)) + (vnoise(x * 0.9 + 0.3, y * 0.9 + 0.7, nseed) - 0.5) * 0.7);
  }
  /* une bande ni trop maigre ni trop large : entre 11 et 21 zones */
  for (let k = 0; k < 12 && dist.filter(d => d < hw).length < 11; k++) hw += 0.15;
  for (let k = 0; k < 12 && dist.filter(d => d < hw).length > 21; k++) hw -= 0.1;
  const rockIds = [ep.rocks.propice, ep.rocks.peu, ep.rocks.sterile];
  const zones = [];
  for (let y = 0; y < GRID; y++) for (let x = 0; x < GRID; x++) {
    const i = y * GRID + x, d = dist[i], band = d < hw ? 'propice' : d < hw + SG.peu ? 'peu' : 'sterile';
    const r = rng(), st = SG.stock[band];
    zones.push({
      i, x, y, d, band, rock: ep.rocks[band], vis: ep.rocks[band], s0: randInt(rng, st[0], st[1]), c0: 0, dug: 0,
      variant: randInt(rng, 0, 3), cover: r < 0.28 ? 'herbe' : r < 0.4 ? 'mousse' : r < 0.49 ? 'sable' : r < 0.57 ? 'eboulis' : null,
      coverAmt: 0.35 + rng() * 0.5, mask: null, revealed: false, patch: false
    });
  }
  /* faux affleurement : un îlot de bonne roche loin de la bande, sans aucun squelette */
  if (rng() < SG.patch) {
    const far = zones.filter(z => z.d > hw + 1.3);
    if (far.length) {
      const a = pick(rng, far), nb = far.filter(z => z !== a && zcheb(z.i, a.i) === 1);
      [a].concat(nb.length ? [pick(rng, nb)] : []).forEach(z => { z.band = 'propice'; z.rock = z.vis = ep.rocks.propice; z.patch = true; z.s0 = randInt(rng, SG.stock.propice[0], SG.stock.propice[1]); });
    }
  }
  /* zones masquées (bois, éboulis) : la moitié sur la bande, pour qu'on ne la voie jamais en entier */
  const nMask = randInt(rng, SG.masks[0], SG.masks[1]), onBand = shuffle(rng, zones.filter(z => z.band === 'propice')), off = shuffle(rng, zones.filter(z => z.band !== 'propice'));
  onBand.slice(0, Math.ceil(nMask / 2)).concat(off.slice(0, Math.floor(nMask / 2))).forEach(z => {
    if (rng() < 0.5) { z.mask = 'foret'; z.vis = null; }
    else { z.mask = 'eboulis'; z.vis = pick(rng, rockIds.filter(id => id !== z.rock)); }
  });
  /* poches : dans la bande, plutôt au cœur, jamais collées l'une à l'autre (tirage à part, pour que la roche reste la même) */
  const rngP = mulberry32((seed ^ 0x9e3779b1) >>> 0);
  if (!poches) {
    poches = [];
    const cnt = SG.poches[weightedIdx(rngP, SG.poches.map(p => p[1]))][0];
    const core = zones.filter(z => z.band === 'propice' && !z.patch), edge = zones.filter(z => z.band === 'peu' && z.d < hw + 0.9);
    for (let k = 0; k < cnt; k++) {
      const from = rngP() < SG.horsBande && edge.length ? edge : core;
      const pool = from.filter(z => poches.every(p => zcheb(p.z, z.i) >= 2));
      if (!pool.length) break;
      poches.push({ z: pool[weightedIdx(rngP, pool.map(z => 1 / (0.35 + Math.max(0, z.d))))].i });
    }
  }
  const coreZ = zones.filter(z => z.band === 'propice' && !z.patch), uniZone = (coreZ.length ? pick(rngP, coreZ) : zones[24]).i;
  /* le cœur d'une poche et ses abords donnent plus de cailloux ; la chaleur (richesse de départ) suit les poches */
  poches.forEach(p => zones.forEach(z => {
    const d = zcheb(p.z, z.i);
    if (d === 0) z.s0 += SG.bonus[0]; else if (d === 1) z.s0 += SG.bonus[1];
    z.c0 = Math.max(z.c0, [1, 0.52, 0.2][d] || 0);
  }));
  zones.forEach(z => { z.stock = z.s0; });
  const oreSets = [['cuivre', 'argent'], ['cuivre', 'or'], ['cuivre', 'argent', 'or'], ['argent', 'or'], ['cuivre', 'argent']];
  /* les feuillets des roches suivent la direction de la bande */
  const dip = ((ang / D2R + 90) % 180) - 90;
  return {
    seed, num, epoch: epochId, zones, poches, uniZone, hw,
    relief: pick(rng, ['riviere', 'falaise', 'carriere']), dip: Math.round(dip), dipVal: randInt(rng, 12, 58),
    light: pick(rng, ['chaude', 'froide', 'neutre']), ores: pick(rng, oreSets),
    hseed: randInt(rng, 1, 999999), dseed: randInt(rng, 1, 999999)
  };
}
function applySiteState(site, saved) {
  if (!saved) return;
  site.zones.forEach((z, i) => {
    if (saved.stock && saved.stock[i] !== undefined) z.stock = saved.stock[i];
    if (saved.dug && saved.dug[i] !== undefined) z.dug = saved.dug[i];
    if (saved.rev && saved.rev[i]) { z.revealed = true; z.vis = z.rock; }
  });
}
const RELIEF_NAMES = { riviere: 'Lit de rivière', falaise: 'Pied de falaise', carriere: 'Ancienne carrière' };

/* ---------- textures de roche (coordonnées carte) ---------- */
function texFoliation(ctx, rock, rnd, W, H, dip) {
  const ink = ROCKS[rock].ink;
  ctx.save(); ctx.translate(W / 2, H / 2); ctx.rotate(dip * D2R);
  const ext = Math.max(W, H) * 0.75;
  ctx.strokeStyle = rgba(ink, 0.5); ctx.lineWidth = 0.8;
  ctx.beginPath();
  for (let y = -ext; y < ext; y += 5.2) {
    let x = -ext;
    while (x < ext) {
      const L = 18 + rnd() * 70;
      for (let xx = x, f = true; xx <= x + L; xx += 6, f = false) {
        const yy = y + Math.sin(xx * 0.035 + y * 0.7) * 1.3 + (vnoise(xx * 0.03, y * 0.11, 7) - 0.5) * 2.6;
        f ? ctx.moveTo(xx, yy) : ctx.lineTo(xx, yy);
      }
      x += L + 2 + rnd() * 8;
    }
  }
  ctx.stroke();
  ctx.strokeStyle = rgba(ink, 0.35); ctx.lineWidth = 0.7; ctx.beginPath();
  for (let k = 0; k < W * H / 1400; k++) { const x = (rnd() - 0.5) * 2 * ext, y = (rnd() - 0.5) * 2 * ext; ctx.moveTo(x, y); ctx.lineTo(x + 2, y + 6); }
  ctx.stroke();
  ctx.restore();
}
function texGrain(ctx, rock, rnd, W, H, dip) {
  const c = hex2rgb(ROCKS[rock].ink);
  ctx.fillStyle = 'rgba(' + c + ',0.42)';
  for (let i = 0, n = W * H / 12; i < n; i++) { const s = 0.5 + rnd() * 0.8; ctx.fillRect(rnd() * W, rnd() * H, s, s); }
  ctx.fillStyle = 'rgba(255,248,230,0.4)';
  for (let i = 0, n = W * H / 36; i < n; i++) { const s = 0.6 + rnd() * 0.9; ctx.fillRect(rnd() * W, rnd() * H, s, s); }
  ctx.strokeStyle = 'rgba(' + c + ',0.3)'; ctx.lineWidth = 0.8;
  for (let k = 0, n = W * H / 8000; k < n; k++) {
    const x = rnd() * W, y = rnd() * H, L = 16 + rnd() * 24, a = (dip + (rnd() - 0.5) * 40) * D2R, ca = Math.cos(a), sa = Math.sin(a);
    for (let j = 0; j < 4; j++) {
      const ox = -sa * j * 3.2, oy = ca * j * 3.2;
      ctx.beginPath(); ctx.moveTo(x + ox, y + oy); ctx.quadraticCurveTo(x + ox + ca * L * 0.5 - sa * 4, y + oy + sa * L * 0.5 + ca * 4, x + ox + ca * L, y + oy + sa * L); ctx.stroke();
    }
  }
}
function texFracture(ctx, rock, rnd, W, H) {
  const ink = ROCKS[rock].ink, sp = 24, nx = Math.ceil(W / sp) + 3, ny = Math.ceil(H / sp) + 3, P = [];
  for (let j = 0; j < ny; j++) { P.push([]); for (let i = 0; i < nx; i++) P[j].push([(i - 1) * sp + (rnd() - 0.5) * sp * 0.75, (j - 1) * sp + (rnd() - 0.5) * sp * 0.75]); }
  for (let j = 0; j < ny - 1; j++) for (let i = 0; i < nx - 1; i++) {
    const r = rnd();
    if (r < 0.3) { ctx.fillStyle = r < 0.15 ? 'rgba(255,255,255,0.22)' : 'rgba(90,92,86,0.1)'; ctx.beginPath(); ctx.moveTo(...P[j][i]); ctx.lineTo(...P[j][i + 1]); ctx.lineTo(...P[j + 1][i + 1]); ctx.lineTo(...P[j + 1][i]); ctx.closePath(); ctx.fill(); }
  }
  ctx.strokeStyle = rgba(ink, 0.55); ctx.lineWidth = 0.9; ctx.beginPath();
  for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
    if (i < nx - 1 && rnd() < 0.86) { ctx.moveTo(...P[j][i]); ctx.lineTo(...P[j][i + 1]); }
    if (j < ny - 1 && rnd() < 0.86) { ctx.moveTo(...P[j][i]); ctx.lineTo(...P[j + 1][i]); }
    if (i < nx - 1 && j < ny - 1 && rnd() < 0.18) { ctx.moveTo(...P[j][i]); ctx.lineTo(...P[j + 1][i + 1]); }
  }
  ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = 1.1; ctx.beginPath();
  for (let k = 0, n = W * H / 2500; k < n; k++) { const x = rnd() * W, y = rnd() * H; ctx.moveTo(x - 2, y); ctx.lineTo(x + 2, y); ctx.moveTo(x, y - 2); ctx.lineTo(x, y + 2); }
  ctx.stroke();
}
function texBlocks(ctx, rock, rnd, W, H, dip) {
  const ink = ROCKS[rock].ink;
  ctx.save(); ctx.translate(W / 2, H / 2); ctx.rotate(dip * 0.5 * D2R);
  const ext = Math.max(W, H) * 0.75;
  ctx.strokeStyle = rgba(ink, 0.5); ctx.lineWidth = 0.9; ctx.beginPath();
  for (let y = -ext; y < ext; y += 11) {
    for (let x = -ext; x < ext; x += 8) { const yy = y + (vnoise(x * 0.04, y * 0.2, 3) - 0.5) * 2.2; x === -ext ? ctx.moveTo(x, yy) : ctx.lineTo(x, yy); }
    let x = -ext + rnd() * 20;
    while (x < ext) { ctx.moveTo(x, y + 0.5); ctx.lineTo(x + (rnd() - 0.5) * 2, y + 10.5); x += 14 + rnd() * 16; }
  }
  ctx.stroke();
  ctx.fillStyle = rgba(ink, 0.12);
  for (let k = 0, n = W * H / 900; k < n; k++) { const x = (rnd() - 0.5) * 2 * ext, y = Math.floor((rnd() - 0.5) * 2 * ext / 11) * 11; ctx.fillRect(x, y + 1, 10 + rnd() * 14, 9); }
  ctx.strokeStyle = rgba(ink, 0.4); ctx.lineWidth = 0.7; ctx.beginPath();
  for (let k = 0, n = W * H / 1800; k < n; k++) { const x = (rnd() - 0.5) * 2 * ext, y = (rnd() - 0.5) * 2 * ext; ctx.moveTo(x, y); ctx.quadraticCurveTo(x + 2, y - 2.4, x + 4, y); }
  ctx.stroke();
  ctx.restore();
}
function texSpeckle(ctx, rock, rnd, W, H) {
  const ink = ROCKS[rock].ink;
  ctx.fillStyle = 'rgba(200,142,128,0.5)';
  for (let i = 0, n = W * H / 160; i < n; i++) { const s = 1.4 + rnd() * 1.2; ctx.fillRect(rnd() * W, rnd() * H, s, s * 0.8); }
  ctx.fillStyle = 'rgba(38,33,31,0.72)';
  for (let i = 0, n = W * H / 40; i < n; i++) { const s = 0.8 + rnd() * 0.9; ctx.fillRect(rnd() * W, rnd() * H, s, s); }
  ctx.fillStyle = 'rgba(252,250,246,0.8)';
  for (let i = 0, n = W * H / 70; i < n; i++) { const s = 0.8 + rnd() * 0.9; ctx.fillRect(rnd() * W, rnd() * H, s, s); }
  ctx.strokeStyle = rgba(ink, 0.3); ctx.lineWidth = 0.9;
  for (let k = 0, n = W * H / 9000; k < n; k++) { const x = rnd() * W, y = rnd() * H, r = 20 + rnd() * 40; ctx.beginPath(); ctx.arc(x, y, r, rnd() * TAU, rnd() * TAU + 1.2); ctx.stroke(); }
}
/* calcaire récifal : amas de coraux en anneaux, débris */
function texReef(ctx, rock, rnd, W, H) {
  const ink = ROCKS[rock].ink;
  ctx.fillStyle = rgba(ink, 0.2);
  for (let i = 0, n = W * H / 60; i < n; i++) ctx.fillRect(rnd() * W, rnd() * H, 1.1, 1.1);
  ctx.strokeStyle = rgba(ink, 0.55); ctx.lineWidth = 0.8;
  for (let k = 0, n = W * H / 2600; k < n; k++) {
    const cx = rnd() * W, cy = rnd() * H, m = 4 + Math.floor(rnd() * 6);
    for (let i = 0; i < m; i++) { const a = rnd() * TAU, d = rnd() * 9, r = 1.5 + rnd() * 1.8; ctx.beginPath(); ctx.arc(cx + Math.cos(a) * d, cy + Math.sin(a) * d * 0.8, r, 0, TAU); ctx.stroke(); }
  }
  ctx.strokeStyle = rgba(ink, 0.3); ctx.lineWidth = 0.7; ctx.beginPath();
  for (let k = 0, n = W * H / 3000; k < n; k++) { const x = rnd() * W, y = rnd() * H, a = rnd() * Math.PI; ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(a) * 5, y + Math.sin(a) * 5); }
  ctx.stroke();
}
/* schiste houiller : feuillets sombres, filets de charbon luisants */
function texCoal(ctx, rock, rnd, W, H, dip) {
  const ink = ROCKS[rock].ink;
  ctx.save(); ctx.translate(W / 2, H / 2); ctx.rotate(dip * D2R);
  const ext = Math.max(W, H) * 0.75;
  ctx.strokeStyle = rgba(ink, 0.6); ctx.lineWidth = 0.9; ctx.beginPath();
  for (let y = -ext; y < ext; y += 6) {
    let x = -ext;
    while (x < ext) { const L = 20 + rnd() * 80; ctx.moveTo(x, y + (vnoise(x * 0.02, y * 0.1, 5) - 0.5) * 2); ctx.lineTo(x + L, y + (vnoise((x + L) * 0.02, y * 0.1, 5) - 0.5) * 2); x += L + 3 + rnd() * 10; }
  }
  ctx.stroke();
  ctx.strokeStyle = 'rgba(214,214,206,0.55)'; ctx.lineWidth = 1.1; ctx.beginPath();
  for (let k = 0, n = W * H / 1300; k < n; k++) { const x = (rnd() - 0.5) * 2 * ext, y = Math.round((rnd() - 0.5) * 2 * ext / 6) * 6 - 1.5, L = 6 + rnd() * 16; ctx.moveTo(x, y); ctx.lineTo(x + L, y); }
  ctx.stroke();
  ctx.restore();
}
/* craie : pâte blanche, rangées de rognons de silex noirs le long des bancs */
function texChalk(ctx, rock, rnd, W, H, dip) {
  const ink = ROCKS[rock].ink;
  ctx.save(); ctx.translate(W / 2, H / 2); ctx.rotate(dip * 0.5 * D2R);
  const ext = Math.max(W, H) * 0.75;
  ctx.strokeStyle = rgba(ink, 0.25); ctx.lineWidth = 0.7; ctx.beginPath();
  for (let y = -ext; y < ext; y += 26) { for (let x = -ext; x < ext; x += 10) { const yy = y + (vnoise(x * 0.03, y * 0.1, 8) - 0.5) * 3; x === -ext ? ctx.moveTo(x, yy) : ctx.lineTo(x, yy); } }
  ctx.stroke();
  for (let y = -ext + 13; y < ext; y += 26) {
    let x = -ext + rnd() * 20;
    while (x < ext) {
      const r = 2.2 + rnd() * 2.6, yy = y + (rnd() - 0.5) * 4;
      ctx.beginPath(); for (let a = 0; a < 8; a++) { const t = a / 8 * TAU, rr = r * (0.7 + rnd() * 0.5); a ? ctx.lineTo(x + Math.cos(t) * rr * 1.4, yy + Math.sin(t) * rr) : ctx.moveTo(x + rr * 1.4, yy); }
      ctx.closePath(); ctx.fillStyle = 'rgba(70,70,74,0.8)'; ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 0.8; ctx.stroke();
      x += 12 + rnd() * 26;
    }
  }
  ctx.restore();
}
/* falun : sable coquillier */
function texShells(ctx, rock, rnd, W, H) {
  const ink = ROCKS[rock].ink;
  ctx.fillStyle = rgba(ink, 0.3);
  for (let i = 0, n = W * H / 20; i < n; i++) ctx.fillRect(rnd() * W, rnd() * H, 0.8, 0.8);
  ctx.lineWidth = 1;
  for (let k = 0, n = W * H / 340; k < n; k++) {
    const x = rnd() * W, y = rnd() * H, r = 2 + rnd() * 3.5, a = rnd() * TAU;
    ctx.strokeStyle = 'rgba(255,248,226,0.8)'; ctx.beginPath(); ctx.arc(x, y + 0.8, r, a, a + 2.4); ctx.stroke();
    ctx.strokeStyle = rgba(ink, 0.6); ctx.beginPath(); ctx.arc(x, y, r, a, a + 2.4); ctx.stroke();
  }
}
/* basalte : prismes (joints hexagonaux) et petites bulles */
function texVesicle(ctx, rock, rnd, W, H) {
  const ink = ROCKS[rock].ink, s = 22, h = s * Math.sqrt(3) / 2;
  ctx.strokeStyle = rgba(ink, 0.5); ctx.lineWidth = 0.9; ctx.beginPath();
  for (let row = -1; row * h < H + h; row++) for (let col = -1; col * s * 1.5 < W + s; col++) {
    const cx = col * s * 1.5, cy = row * h * 2 + (col % 2 ? h : 0);
    for (let k = 0; k < 3; k++) { if (rnd() < 0.2) continue; const a = (k * 60) * D2R, b = (k * 60 + 60) * D2R, j = () => (rnd() - 0.5) * 3; ctx.moveTo(cx + Math.cos(a) * s + j(), cy + Math.sin(a) * s + j()); ctx.lineTo(cx + Math.cos(b) * s + j(), cy + Math.sin(b) * s + j()); }
  }
  ctx.stroke();
  for (let i = 0, n = W * H / 90; i < n; i++) {
    const x = rnd() * W, y = rnd() * H, r = 0.7 + rnd() * 1.3;
    ctx.fillStyle = rgba(ink, 0.75); ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    ctx.strokeStyle = 'rgba(200,196,190,0.5)'; ctx.lineWidth = 0.6; ctx.beginPath(); ctx.arc(x + 0.3, y + 0.4, r + 0.4, 0.2, 2.2); ctx.stroke();
  }
}
const TEX = { foliation: texFoliation, grain: texGrain, fracture: texFracture, blocks: texBlocks, speckle: texSpeckle, reef: texReef, coal: texCoal, chalk: texChalk, shells: texShells, vesicle: texVesicle };

/* ---------- vignette de roche (miniature de tuile) ---------- */
const swatchCache = {};
function rockSwatch(rock, size) {
  const key = rock + size;
  if (swatchCache[key]) return swatchCache[key];
  const cv = document.createElement('canvas'), dpr = 2, S = size * dpr;
  cv.width = S; cv.height = S;
  const ctx = cv.getContext('2d'), c = hex2rgb(ROCKS[rock].wash[0]), paper = [240, 232, 213];
  const img = ctx.createImageData(S, S);
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    const i = (y * S + x) * 4, a = 0.8 + (fbm(x * 0.03, y * 0.03, 5, 2) - 0.5) * 0.3, g = 1 - hash2(x, y, 3) * 0.08;
    for (let ch = 0; ch < 3; ch++) img.data[i + ch] = (paper[ch] * (1 - a) + c[ch] * a) * g;
    img.data[i + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  ctx.scale(dpr * 0.9, dpr * 0.9);
  TEX[ROCKS[rock].tex](ctx, rock, mulberry32(11), size * 1.2, size * 1.2, 18);
  return (swatchCache[key] = cv.toDataURL());
}

/* ---------- rendu complet de la carte ---------- */
const MapView = {
  site: null, zm: null, dpr: 1, boxes: null, masks: {},
  init(els) { Object.assign(this, els); },
  zoneKey(z) { return z.vis || 'sol'; },
  buildZmap(site) {
    const N = MAPPX, zm = new Uint8Array(N * N), js = site.seed % 9973, amp = CELL * 0.8;
    const boxes = site.zones.map(() => [1e9, 1e9, -1, -1]);
    for (let py = 0; py < N; py++) for (let px = 0; px < N; px++) {
      const jx = (fbm(px * 0.011, py * 0.011, js + 5, 2) - 0.5) * amp, jy = (fbm(px * 0.011, py * 0.011, js + 6, 2) - 0.5) * amp;
      const zx = clamp(Math.floor((px + 0.5 + jx) / CELL), 0, GRID - 1), zy = clamp(Math.floor((py + 0.5 + jy) / CELL), 0, GRID - 1);
      const z = zy * GRID + zx; zm[py * N + px] = z;
      const b = boxes[z]; if (px < b[0]) b[0] = px; if (py < b[1]) b[1] = py; if (px > b[2]) b[2] = px; if (py > b[3]) b[3] = py;
    }
    this.zm = zm; this.boxes = boxes; this.masks = {};
  },
  maskFor(pred) {
    const N = MAPPX, cv = document.createElement('canvas'); cv.width = N; cv.height = N;
    const ctx = cv.getContext('2d'), img = ctx.createImageData(N, N), D = img.data, zs = this.site.zones;
    for (let i = 0; i < N * N; i++) if (pred(zs[this.zm[i]])) { D[i * 4 + 3] = 255; }
    ctx.putImageData(img, 0, 0);
    return cv;
  },
  paintBase(ctx) {
    const site = this.site, zm = this.zm, N = MAPPX, img = ctx.createImageData(N, N), D = img.data, js = site.seed % 9973;
    const paper = [240, 232, 213];
    const tint = site.light === 'chaude' ? [1.03, 1, 0.94] : site.light === 'froide' ? [0.96, 0.99, 1.04] : [1, 1, 1];
    const zc = site.zones.map((z, i) => {
      const c = hex2rgb(z.vis ? ROCKS[z.vis].wash[z.variant] : '#8f7b5b'), r = mulberry32(site.seed + i * 31), k = 1 + (r() - 0.5) * 0.07;
      return [c[0] * k, c[1] * k, c[2] * k];
    });
    const key = site.zones.map(z => this.zoneKey(z));
    for (let py = 0; py < N; py++) {
      for (let px = 0; px < N; px++) {
        const i = py * N + px, z = zm[i], c = zc[z], k0 = key[z];
        let e = 0;
        if (px > 3 && key[zm[i - 3]] !== k0) e++;
        if (px < N - 4 && key[zm[i + 3]] !== k0) e++;
        if (py > 3 && key[zm[i - 3 * N]] !== k0) e++;
        if (py < N - 4 && key[zm[i + 3 * N]] !== k0) e++;
        if (px > 1 && key[zm[i - 1]] !== k0) e += 1.5;
        if (py > 1 && key[zm[i - N]] !== k0) e += 1.5;
        const lf = fbm(px * 0.016, py * 0.016, js + 11, 3);
        let a = clamp(0.78 + (lf - 0.5) * 0.42 + e * 0.025, 0.5, 1);
        const g = (1 - hash2(px, py, js) * 0.08) * (1 - Math.min(e, 5) * 0.04);
        const o = i * 4;
        D[o] = (paper[0] * (1 - a) + c[0] * a) * g * tint[0];
        D[o + 1] = (paper[1] * (1 - a) + c[1] * a) * g * tint[1];
        D[o + 2] = (paper[2] * (1 - a) + c[2] * a) * g * tint[2];
        D[o + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
  },
  riverPts() {
    const rnd = mulberry32(this.site.dseed), N = MAPPX, vert = rnd() < 0.5;
    const a = 0.2 + rnd() * 0.6, b = 0.2 + rnd() * 0.6;
    const P0 = vert ? [N * a, -12] : [-12, N * a], P3 = vert ? [N * b, N + 12] : [N + 12, N * b];
    const off = () => (rnd() - 0.5) * 300;
    const P1 = vert ? [lerp(P0[0], P3[0], 0.33) + off(), N * 0.33] : [N * 0.33, lerp(P0[1], P3[1], 0.33) + off()];
    const P2 = vert ? [lerp(P0[0], P3[0], 0.66) + off(), N * 0.66] : [N * 0.66, lerp(P0[1], P3[1], 0.66) + off()];
    const base = cubicPts(P0, P1, P2, P3, 180), ph = rnd() * 6;
    return base.map((q, i) => { const t = tangentAt(base, i), m = Math.sin(i / 180 * Math.PI * 7 + ph) * 9 + (vnoise(i * 0.08, 3, 9) - 0.5) * 10; return [q[0] - t[1] * m, q[1] + t[0] * m]; });
  },
  heightField(river) {
    const site = this.site, st = 8, n = MAPPX / st + 1, H = [];
    for (let j = 0; j < n; j++) {
      H.push([]);
      for (let i = 0; i < n; i++) {
        const x = i * st, y = j * st;
        let h = fbm(x * 0.0055, y * 0.0055, site.hseed, 3);
        if (river) { let d = 1e9; for (let k = 0; k < river.length; k += 3) { const dd = (river[k][0] - x) ** 2 + (river[k][1] - y) ** 2; if (dd < d) d = dd; } h = h * 0.55 + 0.45 * clamp(Math.sqrt(d) / 190, 0, 1); }
        H[j].push(h);
      }
    }
    return { H, st, n };
  },
  isoSegments(F, L) {
    const { H, st, n } = F, segs = [];
    const ip = (a, b, va, vb) => { const t = (L - va) / (vb - va); return [lerp(a[0], b[0], t), lerp(a[1], b[1], t)]; };
    for (let j = 0; j < n - 1; j++) for (let i = 0; i < n - 1; i++) {
      const p = [[i * st, j * st], [(i + 1) * st, j * st], [(i + 1) * st, (j + 1) * st], [i * st, (j + 1) * st]];
      const v = [H[j][i], H[j][i + 1], H[j + 1][i + 1], H[j + 1][i]];
      const e = [];
      for (let k = 0; k < 4; k++) { const k2 = (k + 1) % 4; if ((v[k] < L) !== (v[k2] < L)) e.push(ip(p[k], p[k2], v[k], v[k2])); }
      if (e.length === 2) segs.push(e); else if (e.length === 4) { segs.push([e[0], e[1]]); segs.push([e[2], e[3]]); }
    }
    return segs;
  },
  render(site) {
    this.site = site;
    const N = MAPPX, dpr = this.dpr = Math.min(window.devicePixelRatio || 1, 2), S = Math.round(N * dpr);
    this.buildZmap(site);
    const base = document.createElement('canvas'); base.width = N; base.height = N;
    this.paintBase(base.getContext('2d'));
    const cv = this.terrain; cv.width = S; cv.height = S;
    const ctx = cv.getContext('2d');
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(base, 0, 0, S, S);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    /* textures, masquées par roche visible */
    const present = [...new Set(site.zones.map(z => z.vis).filter(Boolean))];
    present.forEach((rock, k) => {
      const T = document.createElement('canvas'); T.width = S; T.height = S;
      const t = T.getContext('2d'); t.setTransform(dpr, 0, 0, dpr, 0, 0); t.lineCap = 'round'; t.lineJoin = 'round';
      TEX[ROCKS[rock].tex](t, rock, mulberry32(site.seed + k * 101), N, N, site.dip);
      t.setTransform(1, 0, 0, 1, 0, 0); t.globalCompositeOperation = 'destination-in'; t.imageSmoothingEnabled = true;
      t.drawImage(this.maskFor(z => z.vis === rock), 0, 0, S, S);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(T, 0, 0); ctx.restore();
    });
    /* relief */
    const river = site.relief === 'riviere' ? this.riverPts() : null;
    const F = this.heightField(river);
    const rnd = mulberry32(site.dseed + 3);
    let li = 0;
    for (let L = 0.14; L < 0.96; L += 0.045, li++) {
      const segs = this.isoSegments(F, L), major = li % 5 === 0;
      ctx.strokeStyle = major ? 'rgba(112,78,40,0.42)' : 'rgba(112,78,40,0.26)'; ctx.lineWidth = major ? 1.1 : 0.7;
      ctx.beginPath(); segs.forEach(s => { ctx.moveTo(s[0][0], s[0][1]); ctx.lineTo(s[1][0], s[1][1]); }); ctx.stroke();
    }
    if (river) this.drawRiver(ctx, river, rnd);
    if (site.relief === 'falaise') this.drawCliff(ctx, F, rnd);
    if (site.relief === 'carriere') this.drawQuarry(ctx, rnd);
    /* couvertures */
    site.zones.forEach(z => this.drawCover(ctx, z));
    /* pendages sur les roches litées */
    const sr = mulberry32(site.seed + 77);
    ctx.font = '8px "Special Elite", "Courier New", monospace'; ctx.textBaseline = 'middle';
    site.zones.forEach(z => {
      if (z.mask && !z.revealed) return;
      if (!z.vis || !ROCKS[z.vis].bedded || sr() > 0.22) return;
      const p = this.pointIn(z, sr, 18); if (!p) return;
      const a = site.dip * (ROCKS[z.vis].tex === 'blocks' ? 0.5 : 1) * D2R, ca = Math.cos(a), sa = Math.sin(a);
      ctx.strokeStyle = 'rgba(33,26,18,0.9)'; ctx.lineWidth = 1.3; ctx.beginPath();
      ctx.moveTo(p[0] - ca * 8, p[1] - sa * 8); ctx.lineTo(p[0] + ca * 8, p[1] + sa * 8);
      ctx.moveTo(p[0], p[1]); ctx.lineTo(p[0] - sa * 4.5, p[1] + ca * 4.5); ctx.stroke();
      ctx.fillStyle = 'rgba(33,26,18,0.9)'; ctx.fillText(String(site.dipVal + ((z.i * 7) % 9) - 4), p[0] + 3, p[1] + ca * 7 + 3);
    });
  },
  pointIn(z, rnd, spread) {
    const cx = (z.x + 0.5) * CELL, cy = (z.y + 0.5) * CELL;
    for (let k = 0; k < 14; k++) {
      const x = cx + (rnd() - 0.5) * 2 * spread, y = cy + (rnd() - 0.5) * 2 * spread;
      const xi = clamp(Math.round(x), 0, MAPPX - 1), yi = clamp(Math.round(y), 0, MAPPX - 1);
      if (this.zm[yi * MAPPX + xi] === z.i) return [x, y];
    }
    return null;
  },
  drawRiver(ctx, P, rnd) {
    const path = () => { ctx.beginPath(); P.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); };
    ctx.strokeStyle = 'rgba(96,86,64,0.22)'; ctx.lineWidth = 16; path(); ctx.stroke();
    ctx.strokeStyle = 'rgba(122,160,176,0.85)'; ctx.lineWidth = 9; path(); ctx.stroke();
    ctx.strokeStyle = 'rgba(160,196,206,0.9)'; ctx.lineWidth = 4; path(); ctx.stroke();
    [-1, 1].forEach(sd => {
      ctx.beginPath();
      P.forEach((q, i) => { const t = tangentAt(P, i), w = 4.6 + Math.sin(i * 0.21) * 0.8; const x = q[0] - t[1] * w * sd, y = q[1] + t[0] * w * sd; i ? ctx.lineTo(x, y) : ctx.moveTo(x, y); });
      ctx.strokeStyle = 'rgba(38,52,60,0.85)'; ctx.lineWidth = 0.9; ctx.stroke();
    });
    ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 0.8; ctx.beginPath();
    for (let i = 6; i < P.length - 6; i += 7) { const t = tangentAt(P, i), q = P[i], o = (rnd() - 0.5) * 3; ctx.moveTo(q[0] - t[1] * o - t[0] * 2.5, q[1] + t[0] * o - t[1] * 2.5); ctx.lineTo(q[0] - t[1] * o + t[0] * 2.5, q[1] + t[0] * o + t[1] * 2.5); }
    ctx.stroke();
    ctx.fillStyle = 'rgba(110,98,80,0.6)';
    for (let i = 4; i < P.length - 4; i += 2) { if (rnd() < 0.55) continue; const t = tangentAt(P, i), sd = rnd() < 0.5 ? -1 : 1, w = 7 + rnd() * 4; ctx.fillRect(P[i][0] - t[1] * w * sd, P[i][1] + t[0] * w * sd, 1.4, 1.4); }
  },
  drawCliff(ctx, F, rnd) {
    const L = 0.5, segs = this.isoSegments(F, L), cs = this.site.hseed;
    const hAt = (x, y) => fbm(x * 0.0055, y * 0.0055, this.site.hseed, 3);
    ctx.strokeStyle = 'rgba(33,26,18,0.85)'; ctx.lineWidth = 1.5; ctx.beginPath();
    const keep = segs.filter(s => vnoise(s[0][0] * 0.006, s[0][1] * 0.006, cs + 3) > 0.42);
    keep.forEach(s => { ctx.moveTo(s[0][0], s[0][1]); ctx.lineTo(s[1][0], s[1][1]); });
    ctx.stroke();
    ctx.lineWidth = 0.8; ctx.beginPath();
    keep.forEach(s => {
      const m = [(s[0][0] + s[1][0]) / 2, (s[0][1] + s[1][1]) / 2];
      let gx = hAt(m[0] + 2, m[1]) - hAt(m[0] - 2, m[1]), gy = hAt(m[0], m[1] + 2) - hAt(m[0], m[1] - 2);
      const gl = Math.hypot(gx, gy) || 1; gx /= gl; gy /= gl;
      ctx.moveTo(m[0], m[1]); ctx.lineTo(m[0] - gx * 6, m[1] - gy * 6);
    });
    ctx.stroke();
  },
  drawQuarry(ctx, rnd) {
    const N = MAPPX, qx = 110 + rnd() * (N - 220), qy = 110 + rnd() * (N - 220), w = 96 + rnd() * 30, h = 68 + rnd() * 20;
    const rr = (x, y, ww, hh, r) => { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + ww, y, x + ww, y + hh, r); ctx.arcTo(x + ww, y + hh, x, y + hh, r); ctx.arcTo(x, y + hh, x, y, r); ctx.arcTo(x, y, x + ww, y, r); ctx.closePath(); };
    rr(qx - w / 2, qy - h / 2, w, h, 16); ctx.fillStyle = 'rgba(248,242,226,0.38)'; ctx.fill();
    for (let k = 0; k < 3; k++) {
      const ww = w - k * 20, hh = h - k * 16, x = qx - ww / 2, y = qy - hh / 2;
      rr(x, y, ww, hh, 14 - k * 3); ctx.strokeStyle = 'rgba(33,26,18,0.8)'; ctx.lineWidth = 1.1; ctx.stroke();
      ctx.lineWidth = 0.7; ctx.beginPath();
      const per = 2 * (ww + hh);
      for (let d = 0; d < per; d += 5) {
        let x0, y0, nx, ny;
        if (d < ww) { x0 = x + d; y0 = y; nx = 0; ny = 1; } else if (d < ww + hh) { x0 = x + ww; y0 = y + d - ww; nx = -1; ny = 0; }
        else if (d < 2 * ww + hh) { x0 = x + ww - (d - ww - hh); y0 = y + hh; nx = 0; ny = -1; } else { x0 = x; y0 = y + hh - (d - 2 * ww - hh); nx = 1; ny = 0; }
        ctx.moveTo(x0, y0); ctx.lineTo(x0 + nx * 4, y0 + ny * 4);
      }
      ctx.stroke();
    }
    const edge = [[qx, 0], [N, qy], [qx, N], [0, qy]].sort((a, b) => Math.hypot(a[0] - qx, a[1] - qy) - Math.hypot(b[0] - qx, b[1] - qy))[0];
    ctx.setLineDash([5, 4]); ctx.strokeStyle = 'rgba(33,26,18,0.7)'; ctx.lineWidth = 0.9;
    [-3, 3].forEach(o => {
      const vx = edge[0] - qx, vy = edge[1] - qy, l = Math.hypot(vx, vy), nx = -vy / l * o, ny = vx / l * o;
      ctx.beginPath(); ctx.moveTo(qx + vx * 0.25 + nx, qy + vy * 0.25 + ny);
      ctx.quadraticCurveTo(qx + vx * 0.6 + nx + vy / l * 20, qy + vy * 0.6 + ny - vx / l * 20, edge[0] + nx, edge[1] + ny); ctx.stroke();
    });
    ctx.setLineDash([]);
  },
  drawCover(ctx, z) {
    const rnd = mulberry32(this.site.seed * 3 + z.i * 977);
    const type = z.mask || z.cover;
    if (!type) return;
    const thin = z.mask && z.revealed ? 0.3 : 1;
    if (type === 'herbe') {
      const n = Math.round(3 + z.coverAmt * 7);
      for (let k = 0; k < n; k++) {
        const p = this.pointIn(z, rnd, 30); if (!p) continue;
        ctx.fillStyle = 'rgba(120,146,74,0.35)'; ctx.beginPath(); ctx.ellipse(p[0], p[1] + 1, 6, 3, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(46,64,30,0.9)'; ctx.lineWidth = 0.9; ctx.beginPath();
        for (let b = 0; b < 5; b++) { const a = (-90 + (b - 2) * 18 + (rnd() - 0.5) * 10) * D2R, L = 4 + rnd() * 3.5; ctx.moveTo(p[0] + (b - 2) * 1.2, p[1] + 1); ctx.lineTo(p[0] + (b - 2) * 1.2 + Math.cos(a) * L, p[1] + 1 + Math.sin(a) * L); }
        ctx.stroke();
      }
    } else if (type === 'mousse') {
      const n = Math.round(2 + z.coverAmt * 4);
      for (let k = 0; k < n; k++) {
        const p = this.pointIn(z, rnd, 28); if (!p) continue;
        const r = 5 + rnd() * 5;
        ctx.beginPath(); for (let a = 0; a <= 12; a++) { const t = a / 12 * TAU, rr = r * (0.8 + rnd() * 0.35); a ? ctx.lineTo(p[0] + Math.cos(t) * rr, p[1] + Math.sin(t) * rr * 0.8) : ctx.moveTo(p[0] + rr, p[1]); }
        ctx.closePath(); ctx.fillStyle = 'rgba(112,134,58,0.45)'; ctx.fill();
        ctx.setLineDash([1, 2]); ctx.strokeStyle = 'rgba(52,66,28,0.8)'; ctx.lineWidth = 0.8; ctx.stroke(); ctx.setLineDash([]);
      }
    } else if (type === 'sable') {
      const p = this.pointIn(z, rnd, 20); if (!p) return;
      ctx.fillStyle = 'rgba(240,226,190,0.6)'; ctx.beginPath(); ctx.ellipse(p[0], p[1], 14 + rnd() * 8, 8 + rnd() * 5, rnd(), 0, TAU); ctx.fill();
      ctx.strokeStyle = 'rgba(140,112,70,0.55)'; ctx.lineWidth = 0.7; ctx.beginPath();
      for (let k = -2; k <= 2; k++) { ctx.moveTo(p[0] - 9, p[1] + k * 3); ctx.quadraticCurveTo(p[0], p[1] + k * 3 - 2, p[0] + 9, p[1] + k * 3); }
      ctx.stroke();
    } else if (type === 'eboulis') {
      const S = ROCKS[z.vis || z.rock].stone, n = Math.round((z.mask ? 34 : 5 + z.coverAmt * 8) * thin);
      if (z.mask && !z.revealed) { const m = this.boxes[z.i]; ctx.fillStyle = rgba(S.light, 0.25); ctx.fillRect(m[0] + 8, m[1] + 8, m[2] - m[0] - 16, m[3] - m[1] - 16); }
      for (let k = 0; k < n; k++) {
        const p = this.pointIn(z, rnd, z.mask ? 34 : 28); if (!p) continue;
        const r = 2 + rnd() * (z.mask ? 4.5 : 3), m = 5 + Math.floor(rnd() * 2);
        ctx.beginPath(); for (let a = 0; a < m; a++) { const t = a / m * TAU + rnd() * 0.4, rr = r * (0.7 + rnd() * 0.5); a ? ctx.lineTo(p[0] + Math.cos(t) * rr, p[1] + Math.sin(t) * rr) : ctx.moveTo(p[0] + Math.cos(t) * rr, p[1] + Math.sin(t) * rr); }
        ctx.closePath(); ctx.fillStyle = rnd() < 0.5 ? S.light : S.base; ctx.fill(); ctx.strokeStyle = rgba(S.ink, 0.85); ctx.lineWidth = 0.7; ctx.stroke();
      }
    } else if (type === 'foret') {
      const n = Math.round(16 * thin), greens = ['#6f8b4a', '#5f7c3f', '#7d9a55', '#688446'];
      for (let k = 0; k < n; k++) {
        const p = this.pointIn(z, rnd, 36); if (!p) continue;
        const r = 7 + rnd() * 5;
        ctx.fillStyle = 'rgba(40,34,20,0.18)'; ctx.beginPath(); ctx.arc(p[0] + 2, p[1] + 2.5, r, 0, TAU); ctx.fill();
        ctx.beginPath();
        for (let a = 0; a <= 9; a++) { const t = a / 9 * TAU, rr = r * (a % 2 ? 0.86 : 1); a ? ctx.lineTo(p[0] + Math.cos(t) * rr, p[1] + Math.sin(t) * rr) : ctx.moveTo(p[0] + rr, p[1]); }
        ctx.closePath(); ctx.fillStyle = greens[k % 4]; ctx.fill(); ctx.strokeStyle = 'rgba(34,46,22,0.9)'; ctx.lineWidth = 0.9; ctx.stroke();
        ctx.strokeStyle = 'rgba(210,226,160,0.55)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(p[0] - r * 0.25, p[1] - r * 0.25, r * 0.45, Math.PI * 1.05, Math.PI * 1.6); ctx.stroke();
      }
    }
  },
  /* calques dynamiques */
  /* trous de la pelle, épingles des squelettes en cours, poches vidées (carnet de relevés), voile du soir */
  drawOverlay(opts) {
    const site = this.site, N = MAPPX, dpr = this.dpr, S = Math.round(N * dpr);
    const cv = this.overlay; cv.width = S; cv.height = S;
    const ctx = cv.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.lineCap = 'round';
    if (this.exhaust.width !== 1) { this.exhaust.width = 1; this.exhaust.height = 1; }
    (opts.spent || []).forEach(p => {
      ctx.save(); ctx.setLineDash([4, 3]); ctx.strokeStyle = 'rgba(33,26,18,0.7)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.arc(p.x, p.y, CELL * 0.42, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
      ctx.beginPath(); ctx.moveTo(p.x - 9, p.y - 9); ctx.lineTo(p.x + 9, p.y + 9); ctx.moveTo(p.x + 9, p.y - 9); ctx.lineTo(p.x - 9, p.y + 9); ctx.stroke();
      ctx.restore();
    });
    (opts.holes || []).forEach((h, k) => {
      const z = site.zones[h.z] || site.zones[0], S2 = ROCKS[z.rock].stone, rnd = mulberry32(site.seed * 7 + k * 131);
      ctx.fillStyle = 'rgba(62,44,28,0.6)'; ctx.beginPath(); ctx.ellipse(h.x, h.y, 6.5, 4.4, 0, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(28,18,10,0.7)'; ctx.beginPath(); ctx.ellipse(h.x + 0.8, h.y + 0.7, 4, 2.5, 0, 0, TAU); ctx.fill();
      ctx.strokeStyle = 'rgba(30,22,14,0.9)'; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.ellipse(h.x, h.y, 6.5, 4.4, 0, 0, TAU); ctx.stroke();
      ctx.strokeStyle = 'rgba(246,238,218,0.55)'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.ellipse(h.x, h.y, 8.6, 6.2, 0, 0, TAU); ctx.stroke();
      for (let j = 0; j < 3; j++) {
        const a = rnd() * TAU, d = 8 + rnd() * 3, x = h.x + Math.cos(a) * d, y = h.y + Math.sin(a) * d * 0.7, r = 1.1 + rnd() * 1.1;
        ctx.beginPath(); ctx.ellipse(x, y, r * 1.3, r, a, 0, TAU); ctx.fillStyle = 'rgba(120,88,52,0.85)'; ctx.fill();
      }
      if (h.k === 'pierre') {
        ctx.beginPath(); ctx.ellipse(h.x + 9, h.y - 5, 4.6, 3.3, -0.3, 0, TAU); ctx.fillStyle = S2.light; ctx.fill(); ctx.strokeStyle = rgba(S2.ink, 0.95); ctx.lineWidth = 0.9; ctx.stroke();
        if (h.t >= 2) { ctx.save(); ctx.translate(h.x + 9, h.y - 13); ctx.fillStyle = h.t >= 3 ? '#c9962c' : 'rgba(33,26,18,0.92)'; ctx.fillRect(-3, -0.9, 6, 1.8); [[-3.2, -1.2], [-3.2, 1.2], [3.2, -1.2], [3.2, 1.2]].forEach(q => { ctx.beginPath(); ctx.arc(q[0], q[1], 1.35, 0, TAU); ctx.fill(); }); ctx.restore(); }
        else if (h.t === 1) { ctx.beginPath(); ctx.arc(h.x + 9, h.y - 12, 2.2, 0, TAU); ctx.fillStyle = '#d8a621'; ctx.fill(); ctx.strokeStyle = 'rgba(33,26,18,0.9)'; ctx.lineWidth = 0.8; ctx.stroke(); }
      }
    });
    /* squelettes en cours : une épingle avec la part du squelette déjà dégagée */
    (opts.pins || []).forEach(pin => {
      const x = pin.x + 16, y = pin.y - 16, f = pin.f, R = 13;
      ctx.fillStyle = 'rgba(33,26,18,0.25)'; ctx.beginPath(); ctx.arc(x + 1.4, y + 1.8, R, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(250,245,232,0.97)'; ctx.beginPath(); ctx.arc(x, y, R, 0, TAU); ctx.fill();
      ctx.lineWidth = 1.2; ctx.strokeStyle = 'rgba(33,26,18,0.95)'; ctx.stroke();
      ctx.lineWidth = 3.6; ctx.strokeStyle = opts.color; ctx.beginPath(); ctx.arc(x, y, R - 3.4, -Math.PI / 2, -Math.PI / 2 + TAU * Math.max(0.08, f)); ctx.stroke();
      ctx.save(); ctx.translate(x, y); ctx.rotate(-0.6);
      ctx.fillStyle = 'rgba(33,26,18,0.95)'; ctx.fillRect(-3.6, -1, 7.2, 2);
      [[-3.8, -1.4], [-3.8, 1.4], [3.8, -1.4], [3.8, 1.4]].forEach(q => { ctx.beginPath(); ctx.arc(q[0], q[1], 1.6, 0, TAU); ctx.fill(); });
      ctx.restore();
    });
    /* le soir tombe : un voile bleu qui monte avec la fin du jour */
    if (opts.dusk > 0) { ctx.fillStyle = 'rgba(28,38,78,' + (0.42 * opts.dusk).toFixed(3) + ')'; ctx.fillRect(0, 0, N, N); }
  },
  /* les lunettes du professeur : la chaleur du sous-sol, lisible seulement autour des trous */
  heatKey: null, heatImg: null,
  buildHeat(sources) {
    const key = JSON.stringify(sources);
    if (key === this.heatKey) return this.heatImg;
    const HR = 4, HN = MAPPX / HR, c = document.createElement('canvas'); c.width = c.height = HN;
    const ctx = c.getContext('2d'), img = ctx.createImageData(HN, HN), D = img.data;
    const LV = [0.07, 0.16, 0.3, 0.48, 0.68, 0.88], HC = ['#2c4566', '#36637e', '#4f8c8a', '#a9ad5a', '#e0a33e', '#d9642e', '#b5301e'].map(hex2rgb);
    for (let j = 0; j < HN; j++) for (let i = 0; i < HN; i++) {
      const x = (i + 0.5) * HR, y = (j + 0.5) * HR;
      let f = (hash2(i, j, 5) - 0.5) * 0.03;
      sources.forEach(s => { const d2 = ((s.x - x) ** 2 + (s.y - y) ** 2) / (CELL * CELL); f += s.w * Math.exp(-d2 / s.s); });
      let l = 0; while (l < LV.length && f > LV[l]) l++;
      const o = (j * HN + i) * 4, col = HC[l]; D[o] = col[0]; D[o + 1] = col[1]; D[o + 2] = col[2]; D[o + 3] = 255;
    }
    ctx.putImageData(img, 0, 0);
    this.heatKey = key; this.heatImg = c;
    return c;
  },
  drawGlasses(o) {
    const cv = this.heat, N = MAPPX, dpr = this.dpr, W = Math.round(N * dpr);
    cv.width = W; cv.height = W;
    if (!o.on && !o.all) return;
    const ctx = cv.getContext('2d'), k = W / N;
    ctx.fillStyle = 'rgba(16,30,48,.42)'; ctx.fillRect(0, 0, W, W);
    const t = document.createElement('canvas'); t.width = t.height = W;
    const tc = t.getContext('2d'); tc.imageSmoothingEnabled = true; tc.imageSmoothingQuality = 'high';
    tc.drawImage(this.buildHeat(o.sources), 0, 0, W, W);
    tc.fillStyle = 'rgba(0,0,0,.12)'; for (let y = 0; y < W; y += 3 * k) tc.fillRect(0, y, W, 1.2 * k);
    if (!o.all) {
      const m = document.createElement('canvas'); m.width = m.height = W;
      const mc = m.getContext('2d');
      o.holes.forEach(h => { const R = o.reach * k, g = mc.createRadialGradient(h.x * k, h.y * k, R * 0.55, h.x * k, h.y * k, R); g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)'); mc.fillStyle = g; mc.beginPath(); mc.arc(h.x * k, h.y * k, R, 0, TAU); mc.fill(); });
      tc.globalCompositeOperation = 'destination-in'; tc.drawImage(m, 0, 0); tc.globalCompositeOperation = 'source-over';
    }
    ctx.globalAlpha = 0.82; ctx.drawImage(t, 0, 0); ctx.globalAlpha = 1;
    if (!o.holes.length && !o.all) { ctx.fillStyle = 'rgba(233,243,255,.92)'; ctx.font = (22 * k) + 'px "Caveat", cursive'; ctx.textAlign = 'center'; ctx.fillText('Les lunettes ne voient rien : creusez d’abord.', W / 2, W / 2); }
  },
  /* la pelle survole la carte (souris) */
  drawHover(pt, dark) {
    const cv = this.hover, N = MAPPX;
    if (cv.width !== N) { cv.width = N; cv.height = N; }
    const ctx = cv.getContext('2d'); ctx.clearRect(0, 0, N, N);
    if (!pt) return;
    ctx.setLineDash([4, 3]); ctx.strokeStyle = dark ? '#e9f3ff' : 'rgba(33,26,18,0.9)'; ctx.lineWidth = 1.8;
    ctx.beginPath(); ctx.ellipse(pt.x, pt.y, 10, 6.8, 0, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
    ctx.beginPath(); ctx.moveTo(pt.x, pt.y); ctx.lineTo(pt.x, pt.y - 22); ctx.stroke();
    ctx.fillStyle = '#9b3b25'; ctx.beginPath(); ctx.moveTo(pt.x, pt.y - 22); ctx.lineTo(pt.x + 11, pt.y - 18.5); ctx.lineTo(pt.x, pt.y - 15); ctx.fill();
  },
  zoneAt(x, y) { return this.zm[clamp(Math.floor(y), 0, MAPPX - 1) * MAPPX + clamp(Math.floor(x), 0, MAPPX - 1)]; },
  pointAtClient(el, cx, cy) {
    const r = el.getBoundingClientRect(), x = (cx - r.left) / r.width * MAPPX, y = (cy - r.top) / r.height * MAPPX;
    if (x < 0 || y < 0 || x >= MAPPX || y >= MAPPX) return null;
    return { x: clamp(x, 6, MAPPX - 6), y: clamp(y, 6, MAPPX - 6) };
  },
  zoneAtClient(el, cx, cy) {
    const r = el.getBoundingClientRect(), x = Math.floor((cx - r.left) / r.width * MAPPX), y = Math.floor((cy - r.top) / r.height * MAPPX);
    if (x < 0 || y < 0 || x >= MAPPX || y >= MAPPX) return null;
    return this.zm[y * MAPPX + x];
  }
};
