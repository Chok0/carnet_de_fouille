/* ---------- journal de playtest ----------
   Chaque partie note ce qui s'y passe (fouilles, pierres, frappes, achats, tutoriel…) dans le navigateur du joueur,
   sans rien envoyer nulle part. Le testeur l'exporte depuis les Réglages (« Journal de partie ») avec ses réponses
   aux trois questions, et le transmet au développeur. t : secondes depuis le tout premier lancement. */
const LOG_KEY = 'carnet-de-fouille-journal', LOG_MAX = 8000;
const Log = {
  data: null, st: 0, seen: null,
  load() {
    if (this.data) return this.data;
    try { this.data = JSON.parse(localStorage.getItem(LOG_KEY)); } catch (e) { this.data = null; }
    if (!this.data || this.data.v !== 1 || !Array.isArray(this.data.ev)) this.data = { v: 1, id: Math.random().toString(36).slice(2, 8), debut: Date.now(), jeu: 0, ev: [], reponses: {} };
    return this.data;
  },
  ev(type, d) {
    const D = this.load(), e = { t: Math.round((Date.now() - D.debut) / 1000), e: type };
    if (d) Object.assign(e, d);
    D.ev.push(e);
    if (D.ev.length > LOG_MAX) D.ev.splice(0, D.ev.length - LOG_MAX);
    this.saveSoon();
  },
  /* le temps de jeu réel : seulement quand la page est visible */
  tick() { if (this.seen != null) this.load().jeu += Math.round((Date.now() - this.seen) / 1000); this.seen = document.hidden ? null : Date.now(); this.saveSoon(); },
  saveSoon() { clearTimeout(this.st); this.st = setTimeout(() => this.save(), 600); },
  save() { try { localStorage.setItem(LOG_KEY, JSON.stringify(this.data)); } catch (e) { } },
  /* une nouvelle partie ne vide pas le journal : on veut voir les recommencements */
  reset() { this.ev('effacement_partie'); },
  wipe() { const id = this.load().id; this.data = null; try { localStorage.removeItem(LOG_KEY); } catch (e) { } this.load().id = id; this.save(); },
  /* le résumé lisible qui accompagne l'export */
  summary() {
    const D = this.load(), ev = D.ev, n = t => ev.filter(e => e.e === t), P = n('pierre');
    const cnt = (arr, k) => arr.reduce((o, e) => { o[e[k]] = (o[e[k]] || 0) + 1; return o; }, {});
    const tutoFin = n('tuto_fin').pop();
    return {
      testeur: D.id, premier_lancement: new Date(D.debut).toISOString(), temps_de_jeu_min: Math.round(this.tickNow() / 6) / 10,
      lancements: n('ouverture').length, tutoriel: tutoFin ? (tutoFin.passe ? 'passé à la pierre ' + (tutoFin.pierre + 1) : 'terminé en ' + tutoFin.duree + ' s') : 'jamais terminé',
      coups_de_pelle: n('pelle').length, pierres: P.length, resultats: cnt(P, 'res'), etoiles_os: cnt(P.filter(p => p.res === 'fragment' || p.res === 'doublon'), 'etoiles'),
      pierres_eclatees: P.filter(p => p.qualite === 'eclatee').length, frappes_ratees: P.reduce((a, p) => a + (p.rates || 0), 0),
      fatigue_moyenne_a_la_frappe: P.length ? Math.round(P.reduce((a, p) => a + (p.fatigue || 0), 0) / P.length * 100) / 100 : 0,
      tapotements_moyens: P.length ? Math.round(P.reduce((a, p) => a + (p.taps || 0), 0) / P.length * 10) / 10 : 0,
      gisements_finis: n('fin_gisement').length, achats: n('achat').map(e => e.id + ' ' + e.niveau), lunettes: n('lunettes').length,
      especes_identifiees: n('identification').map(e => e.fid), argent_final: (n('pierre').pop() || {}).argent
    };
  },
  tickNow() { const D = this.load(); return D.jeu + (this.seen != null ? Math.round((Date.now() - this.seen) / 1000) : 0); },
  file() { const D = this.load(); return { jeu: 'Carnet de Fouille', version: GAME_VERSION, exporte: new Date().toISOString(), resume: this.summary(), reponses: D.reponses, evenements: D.ev }; }
};
