/* ============ données de jeu ============ */
const GRID = 7;
const COLS = 'ABCDEFG';

/* roches : msg selon la bande (propice / peu) quand une roche change de rôle d'une époque à l'autre */
const ROCKS = {
  schiste: {
    name: 'Schiste argileux', msg: { propice: 'Un feuilletage prometteur.', peu: 'Un schiste plus pauvre : quelques fossiles, pas davantage.' }, look: 'roche feuilletée gris-vert',
    wash: ['#7c8871', '#748070', '#848879', '#6c7865'], ink: '#27311f', tex: 'foliation', bedded: true,
    stone: { shape: 'slab', base: '#7b8670', light: '#a0a992', shade: '#5a644f', ink: '#20271b', side: '#566050', tex: '#2f3828', face: '#b2b9a2', faceShade: '#8e977f', faceTex: '#5f6a55' }
  },
  gresfin: {
    name: 'Grès fin', msg: 'Un grain plus pauvre. On peut y trouver quelque chose.', look: 'grain ocre fin',
    wash: ['#c9a66c', '#c19c62', '#d0ae78', '#bd9c6a'], ink: '#6e4f28', tex: 'grain', bedded: true,
    stone: { shape: 'round', base: '#c7a168', light: '#e2c692', shade: '#9b7947', ink: '#47321a', tex: '#6d5029', face: '#e6d0a3', faceShade: '#c8ab78', faceTex: '#9b7d4d' }
  },
  quartzite: {
    name: 'Quartzite', msg: 'Le grain ne trompe pas : zone trop éloignée du gisement.', look: 'blocs pâles anguleux',
    wash: ['#d0d1c9', '#d6cec5', '#c9ccc6', '#d3d1c3'], ink: '#62625b', tex: 'fracture', bedded: false,
    stone: { shape: 'angular', base: '#cfd0c9', light: '#f0f0ec', shade: '#9fa099', ink: '#3f403b', tex: '#8c8d86', face: '#f2f1ec', faceShade: '#d2d1ca', faceTex: '#b3b2aa' }
  },
  calcaire: {
    name: 'Calcaire marneux', msg: { propice: 'Des bancs tendres, pleins de promesses.', peu: 'Un calcaire bien plus ancien : quelques os se glissent dans ses fissures.' }, look: 'bancs clairs en dalles',
    wash: ['#ddd1ae', '#d5cba9', '#e2d5b1', '#d3c69f'], ink: '#76694a', tex: 'blocks', bedded: true,
    stone: { shape: 'block', base: '#d8cba6', light: '#f0e6ca', shade: '#aa9c78', ink: '#4c412d', tex: '#8f8160', face: '#f1e9d3', faceShade: '#d6caa7', faceTex: '#b3a47f' }
  },
  gres: {
    name: 'Grès', msg: 'Un grès grossier : peu de chances, mais pas aucune.', look: 'grain roux',
    wash: ['#c98e5c', '#c08556', '#cf9a69', '#bb8a5e'], ink: '#633a1c', tex: 'grain', bedded: true,
    stone: { shape: 'round', base: '#c48a58', light: '#dea878', shade: '#96633a', ink: '#432511', tex: '#6b3f1f', face: '#e5bb8f', faceShade: '#c89a6b', faceTex: '#9c6c45' }
  },
  granite: {
    name: 'Granite', msg: 'Du granite : né de la fonte des roches, il ne garde aucun fossile.', look: 'gris moucheté',
    wash: ['#b4aca6', '#aba6a2', '#bab0a8', '#a8a39c'], ink: '#3a3533', tex: 'speckle', bedded: false,
    stone: { shape: 'boulder', base: '#b1a9a3', light: '#d2cbc4', shade: '#837c76', ink: '#332e2b', tex: '#2c2826', face: '#dbd4cd', faceShade: '#bfb7af', faceTex: '#7a726c' }
  },
  ardoise: {
    name: 'Schiste ardoisier', msg: 'Des feuillets serrés, parfaits pour garder les empreintes.', look: 'feuillets gris ardoise',
    wash: ['#747c86', '#6c747e', '#7b838c', '#687079'], ink: '#1d232a', tex: 'foliation', bedded: true,
    stone: { shape: 'slab', base: '#6d757e', light: '#939ba3', shade: '#4c535b', ink: '#1a1f24', side: '#4a5159', tex: '#262c33', face: '#aab1b7', faceShade: '#8b939a', faceTex: '#5b636b' }
  },
  calcrecif: {
    name: 'Calcaire récifal', msg: { propice: 'Un ancien récif : la vie y grouillait.', peu: 'Un récif battu par les vagues : peu de fossiles entiers.' }, look: 'calcaire pâle semé de coraux',
    wash: ['#d9d3c2', '#d1cbba', '#ded8c8', '#cec7b4'], ink: '#6a6250', tex: 'reef', bedded: true,
    stone: { shape: 'block', base: '#d3ccb9', light: '#ece6d6', shade: '#a79f8b', ink: '#4a4436', tex: '#8a8270', face: '#efe9da', faceShade: '#d3cbb8', faceTex: '#aea58f' }
  },
  gresrouge: {
    name: 'Grès rouge', msg: { propice: 'Un grès rouge déposé par d’anciennes rivières : prometteur.', peu: 'Un grès rouge de désert : les fossiles y sont rares.' }, look: 'grès rouge à grain fin',
    wash: ['#b96a4d', '#af6247', '#c17555', '#aa5f47'], ink: '#4f2215', tex: 'grain', bedded: true,
    stone: { shape: 'round', base: '#b5654a', light: '#d58a6c', shade: '#8a4632', ink: '#3c1a0f', tex: '#62291a', face: '#e0a78b', faceShade: '#c4876c', faceTex: '#955a42' }
  },
  houiller: {
    name: 'Schiste houiller', msg: 'Le schiste qui accompagne le charbon : des forêts entières y ont laissé leur empreinte.', look: 'schiste noir veiné de charbon',
    wash: ['#57544f', '#504d49', '#5e5b55', '#4c4945'], ink: '#131210', tex: 'coal', bedded: true,
    stone: { shape: 'slab', base: '#4d4b47', light: '#77746d', shade: '#34322f', ink: '#0f0e0c', side: '#3a3835', tex: '#1c1b19', face: '#aaa79f', faceShade: '#8a877f', faceTex: '#5c5953' }
  },
  marne: {
    name: 'Marne', msg: 'Une marne tendre : quelques fossiles, dispersés.', look: 'argile grise et tendre',
    wash: ['#aaaea5', '#a3a79f', '#b1b4ab', '#9fa49c'], ink: '#474c45', tex: 'blocks', bedded: true,
    stone: { shape: 'block', base: '#a4a89f', light: '#c6c9c0', shade: '#7d8179', ink: '#3a3e37', tex: '#61665e', face: '#d4d6cd', faceShade: '#b8bbb1', faceTex: '#8f948a' }
  },
  craie: {
    name: 'Craie à silex', msg: 'Une craie tendre : chaque bloc peut cacher un trésor.', look: 'craie blanche à silex',
    wash: ['#ece8dc', '#e5e1d4', '#f0ece1', '#e2ddcf'], ink: '#6f6a5c', tex: 'chalk', bedded: true,
    stone: { shape: 'block', base: '#e4dfd1', light: '#faf8f1', shade: '#bdb6a4', ink: '#5a5446', tex: '#8f8878', face: '#f7f4ec', faceShade: '#dcd7c9', faceTex: '#b9b3a4' }
  },
  schistebit: {
    name: 'Schiste bitumineux', msg: 'Un schiste brun et gras : il conserve les moindres détails.', look: 'feuillets bruns et gras',
    wash: ['#716050', '#6a5a4a', '#786756', '#655546'], ink: '#231a11', tex: 'foliation', bedded: true,
    stone: { shape: 'plate', base: '#6a5946', light: '#8f7d67', shade: '#4b3e30', ink: '#1e160e', side: '#4a3d2f', tex: '#2b2117', face: '#b9a78c', faceShade: '#9b8970', faceTex: '#6b5a45' }
  },
  falun: {
    name: 'Falun', msg: 'Un sable pétri de coquilles : le gisement est tout proche.', look: 'sable jaune pétri de coquilles',
    wash: ['#dcc38c', '#d4bb84', '#e2ca94', '#d1b87f'], ink: '#6e5327', tex: 'shells', bedded: true,
    stone: { shape: 'round', base: '#d8bd86', light: '#efdcaf', shade: '#aa8f5a', ink: '#4d3a1b', tex: '#7c6232', face: '#f1e2bd', faceShade: '#d7c395', faceTex: '#a98f5c' }
  },
  loess: {
    name: 'Loess', msg: 'Un limon fin, apporté par le vent : les os y reposent intacts.', look: 'limon jaune très fin',
    wash: ['#ddd0a7', '#d6c9a0', '#e2d6af', '#d3c59b'], ink: '#75653d', tex: 'grain', bedded: true,
    stone: { shape: 'round', base: '#d8ca9f', light: '#efe5c6', shade: '#ad9f74', ink: '#4f4424', tex: '#857548', face: '#f0e7c9', faceShade: '#d9cda6', faceTex: '#b0a175' }
  },
  basalte: {
    name: 'Basalte', msg: 'Du basalte : une lave refroidie. Aucun être vivant n’y a laissé de trace.', look: 'roche noire et bulleuse',
    wash: ['#6d6a67', '#666361', '#74716e', '#615e5b'], ink: '#1c1a19', tex: 'vesicle', bedded: false,
    stone: { shape: 'boulder', base: '#5f5c5a', light: '#86827e', shade: '#403e3c', ink: '#151413', tex: '#232120', face: '#8f8b86', faceShade: '#76726d', faceTex: '#4a4744' }
  }
};
const rockMsg = (id, band) => { const m = ROCKS[id].msg; return typeof m === 'string' ? m : m[band] || m.propice || m.peu; };

/* les douze périodes : couleurs de la Commission de la carte géologique du monde.
   deep : lisible sur le papier ; head : fond des en-têtes de colonne, lisible avec l'encre ; du : « du Cambrien », « de l’Ordovicien » */
const EPOCHS = {
  cambrien: { name: 'Cambrien', du: 'du Cambrien', code: 'Cm', age: '538,8 – 485,4 Ma', color: '#7FA056', deep: '#4b6a2e', head: '#a2b77d', wash: '#e1e8d0',
    rocks: { propice: 'schiste', peu: 'gresfin', sterile: 'quartzite' }, fossils: ['trilobite', 'marrella', 'hallucigenia', 'opabinia', 'anomalocaris'] },
  ordovicien: { name: 'Ordovicien', du: 'de l’Ordovicien', code: 'O', age: '485,4 – 443,8 Ma', color: '#009270', deep: '#096d54', head: '#75bda2', wash: '#c7e7e0',
    rocks: { propice: 'ardoise', peu: 'gresfin', sterile: 'quartzite' }, fossils: ['graptolite', 'echinosphaerites', 'asaphus', 'endoceras', 'isotelus'] },
  silurien: { name: 'Silurien', du: 'du Silurien', code: 'S', age: '443,8 – 419,2 Ma', color: '#B3E1B6', deep: '#4f6849', head: '#b3e1b6', wash: '#eef8ef',
    rocks: { propice: 'calcrecif', peu: 'schiste', sterile: 'granite' }, fossils: ['calymene', 'halysites', 'cooksonia', 'eurypterus', 'guiyu'] },
  devonien: { name: 'Dévonien', du: 'du Dévonien', code: 'D', age: '419,2 – 358,9 Ma', color: '#CB8C37', deep: '#7e5927', head: '#d6a764', wash: '#f4e6d3',
    rocks: { propice: 'gresrouge', peu: 'calcrecif', sterile: 'basalte' }, fossils: ['phacops', 'mucrospirifer', 'manticoceras', 'eusthenopteron', 'dunkleosteus'] },
  carbonifere: { name: 'Carbonifère', du: 'du Carbonifère', code: 'C', age: '358,9 – 298,9 Ma', color: '#67A599', deep: '#46675e', head: '#8eb9ab', wash: '#deebe9',
    rocks: { propice: 'houiller', peu: 'gres', sterile: 'granite' }, fossils: ['neuropteris', 'lepidodendron', 'annularia', 'meganeura', 'arthropleura'] },
  permien: { name: 'Permien', du: 'du Permien', code: 'P', age: '298,9 – 251,9 Ma', color: '#F04028', deep: '#b13421', head: '#f29984', wash: '#fcd5d0',
    rocks: { propice: 'gresrouge', peu: 'marne', sterile: 'basalte' }, fossils: ['glossopteris', 'walchia', 'mesosaurus', 'helicoprion', 'dimetrodon'] },
  trias: { name: 'Trias', du: 'du Trias', code: 'T', age: '251,9 – 201,4 Ma', color: '#812B92', deep: '#812b92', head: '#cba7bf', wash: '#e3d0e7',
    rocks: { propice: 'calcaire', peu: 'gresrouge', sterile: 'granite' }, fossils: ['ceratites', 'voltzia', 'nothosaurus', 'tanystropheus', 'plateosaurus'] },
  jurassique: { name: 'Jurassique', du: 'du Jurassique', code: 'J', age: '201,4 – 145 Ma', color: '#34B2C9', deep: '#1c6878', head: '#57bccc', wash: '#d4ebef',
    rocks: { propice: 'calcaire', peu: 'gres', sterile: 'granite' }, fossils: ['ammonite', 'leptolepides', 'pentacrinites', 'ichthyosaure', 'archaeopteryx'] },
  cretace: { name: 'Crétacé', du: 'du Crétacé', code: 'K', age: '145 – 66 Ma', color: '#7FC64E', deep: '#4a672e', head: '#7fc64e', wash: '#e3f2d8',
    rocks: { propice: 'craie', peu: 'marne', sterile: 'basalte' }, fossils: ['micraster', 'cretolamna', 'turrilites', 'iguanodon', 'mosasaurus'] },
  paleogene: { name: 'Paléogène', du: 'du Paléogène', code: 'Pg', age: '66 – 23 Ma', color: '#FD9A52', deep: '#84532f', head: '#fd9a52', wash: '#ffe9d9',
    rocks: { propice: 'schistebit', peu: 'marne', sterile: 'basalte' }, fossils: ['nummulites', 'knightia', 'heliobatis', 'eurohippus', 'gastornis'] },
  neogene: { name: 'Néogène', du: 'du Néogène', code: 'N', age: '23 – 2,6 Ma', color: '#FFE619', deep: '#6e6215', head: '#ffe619', wash: '#fffacc',
    rocks: { propice: 'falun', peu: 'marne', sterile: 'granite' }, fossils: ['pecten', 'clypeaster', 'megalodon', 'machairodus', 'deinotherium'] },
  quaternaire: { name: 'Quaternaire', du: 'du Quaternaire', code: 'Q', age: '2,6 Ma – aujourd’hui', color: '#F9F97F', deep: '#635f35', head: '#f9f97f', wash: '#fefee3',
    rocks: { propice: 'loess', peu: 'calcaire', sterile: 'granite' }, fossils: ['ursus', 'bison', 'megaloceros', 'coelodonta', 'mammouth'] }
};
const EPOCH_IDS = Object.keys(EPOCHS);
const ERAS = [['Paléozoïque', 6, '538,8'], ['Mésozoïque', 3, '251,9'], ['Cénozoïque', 3, '66']];

/* primes d'identification ; doublons : bloc déjà dégagé, revendu aux collectionneurs */
const RARITY = { commun: { weight: 3, bonus: 120, dup: 12, bloc: 12 }, 'peu commun': { weight: 2, bonus: 240, dup: 18, bloc: 18 }, rare: { weight: 1, bonus: 480, dup: 30, bloc: 25 },
  /* les grandes bêtes de chaque époque (anciennes « pièces uniques ») : un squelette en 15 blocs, rare, très bien payé */
  exceptionnel: { weight: 0.6, bonus: 900, dup: 45, bloc: 35 } };
const COLUMN_BONUS = 600;

/* ---------- fragments : squelettes et doublons ----------
   Chaque squelette repose dans une poche de la roche (une zone du gisement) : ses os sortent surtout de la poche,
   parfois des zones voisines. doublon : chance de retomber sur un bloc déjà dégagé = doublon × (blocs dégagés / blocs du fossile) */
const FRAG = { doublon: 0.3 };
/* ---------- gisements ----------
   La roche propice forme une large bande (les couches qui affleurent) ; les squelettes se cachent dans des poches, dans la bande.
   band : demi-largeur de la bande, en zones ; peu : largeur des bandes de roche pauvre de part et d'autre ;
   patch : chance d'un faux affleurement (un îlot de roche propice sans squelette) ; masks : zones cachées (bois, éboulis) ;
   stock : cailloux par zone selon la roche ; bonus : cailloux en plus au cœur d'une poche et autour ;
   poches : nombre de squelettes [n, poids] ; horsBande : chance qu'une poche déborde dans la roche pauvre ;
   frag : chance qu'un caillou porte un os d'une poche située à 0, 1 ou 2 zones ;
   uniq : chance que le gisement cache la pièce unique ; uniqP : chance par caillou, à 0 ou 1 zone de sa cachette ;
   vide : part des cailloux sans fossile qui ne contiennent rien du tout (le reste porte du minerai) */
const SITEGEN = {
  band: [1.0, 1.4], peu: 1.6, patch: 0.5, masks: [6, 9],
  stock: { propice: [3, 5], peu: [1, 3], sterile: [0, 0] }, bonus: [7, 2],
  poches: [[2, 0.3], [3, 0.5], [4, 0.2]], horsBande: 0.15,
  frag: [0.55, 0.18, 0.04], uniq: 0.33, uniqP: [0.18, 0.03],
  vide: { propice: 0.3, peu: 0.45, sterile: 1 }
};
/* ---------- prélèvement : on sort plusieurs cailloux, on n'en fend que quelques-uns, le reste part au déblai ----------
   [cailloux fendus, cailloux sortis] selon le niveau du Sac ; sur le tout premier gisement, un caillou de moins à choisir */
const PRELEV = [[1, 3], [2, 4], [3, 5]];
/* ---------- indices à la surface des pierres ----------
   affleure : un morceau du fossile affleure (affleureU pour la pièce unique) ; marque : une bosse ou une tache ;
   minerai : une veine ou des reflets ; bruit : faux indices, sur n'importe quel caillou, dont les pseudo-fossiles
   (dendrites de manganèse, concrétions) et la pyrite, l'or des fous ; surFil : part des indices posés le long du fil ;
   loupe : effacement des faux indices par niveau de loupe ; max : indices au plus par caillou */
const TELLS = {
  affleure: 0.1, affleureU: 0.35, marque: 0.4, minerai: 0.55,
  bruit: { bosse: 0.13, tache: 0.12, dendrite: 0.07, concretion: 0.06, pyrite: 0.06 },
  surFil: { vrai: 0.65, faux: 0.45 }, loupe: 0.22, max: 3
};
/* ---------- aspect du fil selon l'expérience de lecture (xp, comme les fausses fissures) ----------
   net : franc ; discret : fin et pâle ; discontinu : des tronçons à relier ; voile : en partie sous le lichen ou la terre.
   Proportions atteintes à xp = to (au-delà de from, on passe progressivement du tout-net à ce mélange) */
const FILVIS = { from: 8, to: 150, end: { net: 0.3, discret: 0.24, discontinu: 0.28, voile: 0.18 } };

const FOSSILS = {
  /* ---- Cambrien ---- */
  trilobite: { epoch: 'cambrien', kind: 'frag', blocks: 6, rarity: 'commun', name: 'Trilobite', latin: 'Elrathia kingii', ref: 'Schistes de Wheeler, Utah · ~505 Ma',
    note: 'Le trilobite le plus récolté au monde : les schistes de Wheeler, dans l’Utah, en livrent des milliers. Comme tous les trilobites, il voyait à travers des lentilles de calcite, un minéral.' },
  marrella: { epoch: 'cambrien', kind: 'frag', blocks: 7, rarity: 'commun', name: 'Marrella', latin: 'Marrella splendens', ref: 'Schistes de Burgess, Canada · ~508 Ma',
    note: 'L’animal le plus abondant des schistes de Burgess, avec des dizaines de milliers de spécimens. Charles Walcott, qui l’a découvert en 1909, le surnommait le « crabe dentelle ».' },
  hallucigenia: { epoch: 'cambrien', kind: 'frag', blocks: 10, rarity: 'peu commun', name: 'Hallucigénie', latin: 'Hallucigenia sparsa', ref: 'Schistes de Burgess, Canada · ~508 Ma',
    note: 'On l’a d’abord reconstitué à l’envers, marchant sur ses épines, la tête à la place de la queue. Sa vraie tête, avec des yeux et une bouche garnie de dents, n’a été identifiée qu’en 2015.' },
  opabinia: { epoch: 'cambrien', kind: 'frag', blocks: 12, rarity: 'rare', name: 'Opabinia', latin: 'Opabinia regalis', ref: 'Schistes de Burgess, Canada · ~508 Ma',
    note: 'Cinq yeux pédonculés et une longue trompe terminée par une pince. Quand Harry Whittington a présenté sa reconstitution en 1972, la salle a éclaté de rire.' },
  anomalocaris: { epoch: 'cambrien', kind: 'frag', blocks: 15, rarity: 'exceptionnel', name: 'Anomalocaris', latin: 'Anomalocaris canadensis', ref: 'Schistes de Burgess, Canada · ~508 Ma',
    note: 'Le grand prédateur du Cambrien. Ses morceaux, trouvés séparément, avaient d’abord été décrits comme trois animaux différents : une crevette, une méduse et un concombre de mer.' },
  /* ---- Ordovicien ---- */
  graptolite: { epoch: 'ordovicien', kind: 'frag', blocks: 6, rarity: 'commun', name: 'Graptolite', latin: 'Didymograptus murchisoni', ref: 'Abereiddi, pays de Galles · ~465 Ma',
    note: 'Leur nom veut dire « écrit sur la pierre » : on les prenait pour des dessins. Ces colonies flottantes ont changé de forme si vite que les géologues s’en servent comme d’une horloge pour dater les roches.' },
  echinosphaerites: { epoch: 'ordovicien', kind: 'frag', blocks: 7, rarity: 'commun', name: 'Échinosphérite', latin: 'Echinosphaerites aurantium', ref: 'Région de Saint-Pétersbourg, Russie · ~460 Ma',
    note: 'Une boule de calcite fixée au fond de la mer, percée de pores pour respirer. Son nom, aurantium, veut dire « orange » : certains bancs en sont si pleins qu’on dirait des cageots de fruits.' },
  asaphus: { epoch: 'ordovicien', kind: 'frag', blocks: 10, rarity: 'peu commun', name: 'Asaphus', latin: 'Asaphus kowalewskii', ref: 'Région de Saint-Pétersbourg, Russie · ~465 Ma',
    note: 'Ses yeux se dressent au bout de longues tiges, comme des périscopes. Enfoui dans la vase, ce trilobite pouvait guetter ses ennemis sans se montrer.' },
  endoceras: { epoch: 'ordovicien', kind: 'frag', blocks: 13, rarity: 'rare', name: 'Endocéras', latin: 'Endoceras giganteum', ref: 'Calcaires de Trenton, New York · ~450 Ma',
    note: 'Un cousin des nautiles, à la coquille droite comme une corne. Le plus grand spécimen conservé mesure 3 mètres, et la coquille entière devait approcher les 6 mètres : le géant des mers de l’Ordovicien.' },
  isotelus: { epoch: 'ordovicien', kind: 'frag', blocks: 15, rarity: 'exceptionnel', name: 'Isotelus géant', latin: 'Isotelus rex', ref: 'Churchill, Manitoba, Canada · ~445 Ma',
    note: 'Le plus grand trilobite complet jamais trouvé : 72 centimètres de long. Il a été découvert en 1999 au bord de la baie d’Hudson, et baptisé rex, le « roi ».' },
  /* ---- Silurien ---- */
  calymene: { epoch: 'silurien', kind: 'frag', blocks: 7, rarity: 'commun', name: 'Trilobite de Dudley', latin: 'Calymene blumenbachii', ref: 'Calcaire de Wenlock, Dudley, Angleterre · ~428 Ma',
    note: 'Si abondant dans les carrières de Dudley qu’on l’y surnommait le « criquet », et qu’il figure sur les armoiries de la ville. On le trouve souvent roulé en boule, comme un cloporte.' },
  halysites: { epoch: 'silurien', kind: 'frag', blocks: 6, rarity: 'commun', name: 'Corail chaînette', latin: 'Halysites catenularia', ref: 'Île de Gotland, Suède · ~425 Ma',
    note: 'Ses petits tubes se soudent en file, comme les maillons d’une chaîne : vue de dessus, la colonie dessine un filet de dentelle. Toute sa famille, celle des coraux tabulés, a disparu il y a 252 millions d’années.' },
  cooksonia: { epoch: 'silurien', kind: 'frag', blocks: 9, rarity: 'peu commun', name: 'Cooksonia', latin: 'Cooksonia pertoni', ref: 'Marches galloises, Angleterre · ~420 Ma',
    note: 'L’une des toutes premières plantes terrestres : quelques centimètres de haut, ni feuilles ni racines, juste des tiges fourchues coiffées de capsules à spores. Avec elle, la vie a commencé à conquérir la terre ferme.' },
  eurypterus: { epoch: 'silurien', kind: 'frag', blocks: 12, rarity: 'rare', name: 'Scorpion de mer', latin: 'Eurypterus remipes', ref: 'Dolomie de Bertie, New York · ~420 Ma',
    note: 'Ce « scorpion de mer » long comme une main nageait à l’aide de sa dernière paire de pattes, aplaties en rames. Il est le fossile officiel de l’État de New York.' },
  guiyu: { epoch: 'silurien', kind: 'frag', blocks: 15, rarity: 'exceptionnel', name: 'Guiyu', latin: 'Guiyu oneiros', ref: 'Formation de Kuanti, Yunnan, Chine · ~423 Ma',
    note: 'Le plus ancien poisson osseux connu entier, décrit en 2009. Son nom veut dire « poisson fantôme du rêve » : il réunit des traits qu’on croyait apparus bien plus tard.' },
  /* ---- Dévonien ---- */
  phacops: { epoch: 'devonien', kind: 'frag', blocks: 7, rarity: 'commun', name: 'Phacops', latin: 'Phacops rana', ref: 'Schistes de Silica, Ohio · ~385 Ma',
    note: 'Ses gros yeux sont faits de lentilles de calcite bien séparées, comme des grains de caviar. On le trouve souvent roulé en boule ; la Pennsylvanie en a fait son fossile officiel.' },
  mucrospirifer: { epoch: 'devonien', kind: 'frag', blocks: 6, rarity: 'commun', name: 'Hirondelle de pierre', latin: 'Mucrospirifer mucronatus', ref: 'Schistes de Hamilton, New York · ~385 Ma',
    note: 'En Chine, on appelait ces coquillages « hirondelles de pierre » : leurs deux valves déployées ressemblent à des ailes. On racontait qu’ils s’envolaient pendant les orages.' },
  manticoceras: { epoch: 'devonien', kind: 'frag', blocks: 10, rarity: 'peu commun', name: 'Goniatite', latin: 'Manticoceras sinuosum', ref: 'Carrière de Coumiac, Hérault · ~372 Ma',
    note: 'Un ancêtre des ammonites. Son nom de famille vient du grec gônia, « angle » : les cloisons de sa coquille dessinent des zigzags anguleux, bien visibles quand la pierre est polie.' },
  eusthenopteron: { epoch: 'devonien', kind: 'frag', blocks: 13, rarity: 'rare', name: 'Eusthénoptéron', latin: 'Eusthenopteron foordi', ref: 'Miguasha, Québec · ~380 Ma',
    note: 'Le « prince de Miguasha ». Dans ses nageoires, on reconnaît déjà les os de nos bras : humérus, radius et cubitus. Il appartient à la lignée des poissons qui ont conduit les vertébrés hors de l’eau.' },
  dunkleosteus: { epoch: 'devonien', kind: 'frag', blocks: 15, rarity: 'exceptionnel', name: 'Dunkleosteus', latin: 'Dunkleosteus terrelli', ref: 'Schistes de Cleveland, Ohio · ~365 Ma',
    note: 'Un poisson cuirassé, la tête blindée de plaques d’os. Il n’avait pas de dents : ses mâchoires se terminaient par des lames osseuses qui s’aiguisaient en frottant l’une contre l’autre.' },
  /* ---- Carbonifère ---- */
  neuropteris: { epoch: 'carbonifere', kind: 'frag', blocks: 6, rarity: 'commun', name: 'Fougère à graines', latin: 'Neuropteris heterophylla', ref: 'Bassin houiller de Saint-Étienne · ~305 Ma',
    note: 'On dirait une fougère, mais elle portait des graines : c’est l’une des premières plantes à en produire. Ses feuilles tapissent les schistes des mines de charbon.' },
  lepidodendron: { epoch: 'carbonifere', kind: 'frag', blocks: 7, rarity: 'commun', name: 'Arbre à écailles', latin: 'Lepidodendron aculeatum', ref: 'Bassin houiller du Nord · ~310 Ma',
    note: 'Un arbre de 30 mètres dont l’écorce, couverte de losanges, ressemble à une peau de serpent. Ses forêts sont devenues le charbon qui a fait tourner les machines de la révolution industrielle.' },
  annularia: { epoch: 'carbonifere', kind: 'frag', blocks: 9, rarity: 'peu commun', name: 'Annularia', latin: 'Annularia stellata', ref: 'Bassin houiller de la Sarre · ~305 Ma',
    note: 'Les feuilles des calamites, des prêles géantes aussi hautes qu’une maison. Groupées en étoiles le long des rameaux, elles ont laissé sur la roche de petites fleurs de pierre.' },
  meganeura: { epoch: 'carbonifere', kind: 'frag', blocks: 13, rarity: 'rare', name: 'Libellule géante', latin: 'Meganeura monyi', ref: 'Commentry, Allier · ~300 Ma',
    note: 'Près de 70 centimètres d’envergure : l’un des plus grands insectes qui aient jamais volé. Elle a été découverte en 1880 dans les mines de charbon de Commentry, dans l’Allier.' },
  arthropleura: { epoch: 'carbonifere', kind: 'frag', blocks: 15, rarity: 'exceptionnel', name: 'Arthropleura', latin: 'Arthropleura sp.', ref: 'Howick Bay, Northumberland · ~326 Ma',
    note: 'Un mille-pattes de 2,70 mètres, le plus grand arthropode connu. Il a été découvert en 2018 dans un bloc de grès tombé d’une falaise, qui s’était fendu en deux sur la plage !' },
  /* ---- Permien ---- */
  glossopteris: { epoch: 'permien', kind: 'frag', blocks: 6, rarity: 'commun', name: 'Glossoptéris', latin: 'Glossopteris indica', ref: 'Bassin du Damodar, Inde · ~260 Ma',
    note: 'Ses feuilles en forme de langue se retrouvent en Inde, en Afrique, en Amérique du Sud, en Australie et en Antarctique : la preuve que ces continents étaient soudés. L’expédition Scott en rapportait encore dans ses traîneaux en 1912.' },
  walchia: { epoch: 'permien', kind: 'frag', blocks: 7, rarity: 'commun', name: 'Walchia', latin: 'Walchia piniformis', ref: 'Bassin d’Autun, Saône-et-Loire · ~295 Ma',
    note: 'L’un des premiers conifères. Ses rameaux en forme de plume rappellent ceux de l’araucaria, le « désespoir des singes » de nos jardins.' },
  mesosaurus: { epoch: 'permien', kind: 'frag', blocks: 10, rarity: 'peu commun', name: 'Mésosaure', latin: 'Mesosaurus tenuidens', ref: 'Formation d’Irati, Brésil · ~280 Ma',
    note: 'Ce petit reptile d’eau douce se retrouve à la fois au Brésil et en Afrique du Sud. Incapable de traverser un océan, il a aidé Alfred Wegener à défendre l’idée que les continents se déplacent.' },
  helicoprion: { epoch: 'permien', kind: 'frag', blocks: 12, rarity: 'rare', name: 'Hélicoprion', latin: 'Helicoprion bessonowi', ref: 'Monts Oural, Russie · ~275 Ma',
    note: 'Une spirale de dents, comme une scie circulaire. Pendant un siècle, on l’a placée au bout du museau, ou même sur le dos ! En 2013, des images au scanner ont montré qu’elle garnissait la mâchoire inférieure.' },
  dimetrodon: { epoch: 'permien', kind: 'frag', blocks: 15, rarity: 'exceptionnel', name: 'Dimétrodon', latin: 'Dimetrodon grandis', ref: 'Red Beds du Texas · ~285 Ma',
    note: 'Malgré sa voile, ce n’était pas un dinosaure : il a vécu plus de 40 millions d’années avant eux. C’était un synapside, plus proche des mammifères, et donc de nous, que des reptiles.' },
  /* ---- Trias ---- */
  ceratites: { epoch: 'trias', kind: 'frag', blocks: 6, rarity: 'commun', name: 'Cératite', latin: 'Ceratites nodosus', ref: 'Muschelkalk de Lorraine · ~240 Ma',
    note: 'L’ammonite du Trias. Ses cloisons dessinent une ligne en dents de scie si typique qu’elle a donné son nom à tout un type de suture : la suture cératitique.' },
  voltzia: { epoch: 'trias', kind: 'frag', blocks: 7, rarity: 'commun', name: 'Voltzia', latin: 'Voltzia heterophylla', ref: 'Grès à Voltzia, Vosges · ~245 Ma',
    note: 'Un conifère si courant dans les grès des Vosges qu’il a donné son nom à toute une couche de roche, le « grès à Voltzia ». Cette couche conserve aussi des insectes et des scorpions d’une finesse rare.' },
  nothosaurus: { epoch: 'trias', kind: 'frag', blocks: 10, rarity: 'peu commun', name: 'Nothosaure', latin: 'Nothosaurus mirabilis', ref: 'Muschelkalk de Bayreuth, Allemagne · ~240 Ma',
    note: 'Un reptile marin qui vivait un peu comme un phoque, entre la mer et le rivage. Ses longues dents pointues s’emboîtaient comme les barreaux d’une nasse pour piéger les poissons.' },
  tanystropheus: { epoch: 'trias', kind: 'frag', blocks: 13, rarity: 'rare', name: 'Tanystrophée', latin: 'Tanystropheus longobardicus', ref: 'Monte San Giorgio, Suisse · ~242 Ma',
    note: 'Son cou de près de trois mètres ne comptait que 13 vertèbres, chacune démesurément allongée. Le Monte San Giorgio, où on le trouve, est inscrit au patrimoine mondial de l’Unesco.' },
  plateosaurus: { epoch: 'trias', kind: 'frag', blocks: 15, rarity: 'exceptionnel', name: 'Plateosaurus', latin: 'Plateosaurus trossingensis', ref: 'Trossingen, Allemagne · ~210 Ma',
    note: 'L’un des premiers grands dinosaures, un herbivore de 8 mètres. À Trossingen, des dizaines de squelettes reposent ensemble : ces animaux s’étaient enlisés dans la boue sans pouvoir en sortir.' },
  /* ---- Jurassique ---- */
  ammonite: { epoch: 'jurassique', kind: 'frag', blocks: 6, rarity: 'commun', name: 'Ammonite', latin: 'Dactylioceras commune', ref: 'Falaises de Whitby, Yorkshire · ~180 Ma',
    note: 'Si commune à Whitby qu’on y sculptait autrefois une tête de serpent sur les spécimens, vendus comme des serpents changés en pierre par sainte Hilda.' },
  leptolepides: { epoch: 'jurassique', kind: 'frag', blocks: 7, rarity: 'commun', name: 'Leptolépide', latin: 'Leptolepides sprattiformis', ref: 'Calcaires de Solnhofen, Bavière · ~150 Ma',
    note: 'Ce petit poisson, à peine plus long qu’un doigt, est le fossile le plus courant de Solnhofen. Des bancs entiers sont morts d’un coup, piégés dans des lagunes trop salées.' },
  pentacrinites: { epoch: 'jurassique', kind: 'frag', blocks: 10, rarity: 'peu commun', name: 'Lys de mer', latin: 'Pentacrinites fossilis', ref: 'Falaises de Lyme Regis, Dorset · ~195 Ma',
    note: 'Malgré son nom, c’est un animal, cousin des étoiles de mer. Ces crinoïdes vivaient accrochés à des bois flottants, en colonies qui dérivaient au large.' },
  ichthyosaure: { epoch: 'jurassique', kind: 'frag', blocks: 13, rarity: 'rare', name: 'Ichthyosaure', latin: 'Stenopterygius quadriscissus', ref: 'Schistes de Holzmaden, Allemagne · ~182 Ma',
    note: 'Reptile marin à silhouette de dauphin, il ne pondait pas : il mettait ses petits au monde dans l’eau. À Holzmaden, des femelles ont été fossilisées en pleine mise bas.' },
  archaeopteryx: { epoch: 'jurassique', kind: 'frag', blocks: 15, rarity: 'exceptionnel', name: 'Archéoptéryx', latin: 'Archaeopteryx lithographica', ref: 'Calcaires de Solnhofen, Bavière · ~150 Ma',
    note: 'Plumes et ailes d’oiseau, mais aussi dents, doigts griffus et longue queue osseuse. Découvert en 1861, deux ans après L’Origine des espèces, il est devenu l’icône de l’évolution.' },
  /* ---- Crétacé ---- */
  micraster: { epoch: 'cretace', kind: 'frag', blocks: 6, rarity: 'commun', name: 'Oursin cœur', latin: 'Micraster coranguinum', ref: 'Falaises d’Étretat, Normandie · ~88 Ma',
    note: 'Cet oursin en forme de cœur vivait enfoui dans la boue crayeuse. Sa forme a changé très lentement, couche après couche : il est devenu un exemple célèbre pour étudier l’évolution.' },
  cretolamna: { epoch: 'cretace', kind: 'frag', blocks: 7, rarity: 'commun', name: 'Dent de requin', latin: 'Cretolamna appendiculata', ref: 'Craie du Kent, Angleterre · ~85 Ma',
    note: 'Pendant des siècles, on a pris ces dents pour des langues de serpent pétrifiées, les « glossopètres ». En 1667, le savant danois Nicolas Sténon a montré que c’étaient des dents de requin.' },
  turrilites: { epoch: 'cretace', kind: 'frag', blocks: 10, rarity: 'peu commun', name: 'Turrilite', latin: 'Turrilites costatus', ref: 'Craie de Rouen, Normandie · ~95 Ma',
    note: 'Une ammonite qui a enroulé sa coquille en tire-bouchon, comme un escargot. On ignore encore comment elle se tenait dans l’eau : peut-être flottait-elle la pointe en l’air.' },
  iguanodon: { epoch: 'cretace', kind: 'frag', blocks: 14, rarity: 'rare', name: 'Iguanodon', latin: 'Iguanodon bernissartensis', ref: 'Mine de Bernissart, Belgique · ~125 Ma',
    note: 'En 1878, des mineurs belges ont trouvé une trentaine de squelettes au fond d’une mine de charbon, à plus de 300 mètres sous terre. Son pouce en pointe avait d’abord été placé sur son nez, comme une corne !' },
  mosasaurus: { epoch: 'cretace', kind: 'frag', blocks: 15, rarity: 'exceptionnel', name: 'Mosasaure', latin: 'Mosasaurus hoffmannii', ref: 'Montagne Saint-Pierre, Maastricht · ~68 Ma',
    note: 'Son crâne, découvert près de Maastricht vers 1780, fut emporté par l’armée française en 1795 : la légende dit qu’on avait promis 600 bouteilles de vin à qui le trouverait. Il est toujours exposé à Paris.' },
  /* ---- Paléogène ---- */
  nummulites: { epoch: 'paleogene', kind: 'frag', blocks: 6, rarity: 'commun', name: 'Nummulite', latin: 'Nummulites gizehensis', ref: 'Plateau de Gizeh, Égypte · ~45 Ma',
    note: 'Un être d’une seule cellule, grand comme une pièce de monnaie. Les pyramides de Gizeh en sont bâties : le géographe grec Strabon y voyait des lentilles pétrifiées, restes des repas des ouvriers.' },
  knightia: { epoch: 'paleogene', kind: 'frag', blocks: 7, rarity: 'commun', name: 'Knightia', latin: 'Knightia eocaena', ref: 'Formation de Green River, Wyoming · ~50 Ma',
    note: 'Un petit hareng d’eau douce, si abondant dans les anciens lacs du Wyoming qu’il est devenu le fossile officiel de l’État. Certaines dalles en portent des dizaines, morts ensemble.' },
  heliobatis: { epoch: 'paleogene', kind: 'frag', blocks: 10, rarity: 'peu commun', name: 'Raie d’eau douce', latin: 'Heliobatis radians', ref: 'Formation de Green River, Wyoming · ~50 Ma',
    note: 'Une raie qui vivait dans un lac, loin de la mer. Son nom veut dire « raie soleil » : sur les fossiles, les rayons de son disque s’étalent comme ceux d’un soleil.' },
  eurohippus: { epoch: 'paleogene', kind: 'frag', blocks: 12, rarity: 'rare', name: 'Cheval de Messel', latin: 'Eurohippus messelensis', ref: 'Fosse de Messel, Allemagne · ~48 Ma',
    note: 'Un ancêtre du cheval pas plus grand qu’un fox-terrier, avec quatre doigts aux pattes avant. À Messel, une jument a même été fossilisée avec son poulain encore dans le ventre.' },
  gastornis: { epoch: 'paleogene', kind: 'frag', blocks: 15, rarity: 'exceptionnel', name: 'Gastornis', latin: 'Gastornis parisiensis', ref: 'Meudon, Hauts-de-Seine · ~55 Ma',
    note: 'Un oiseau géant de deux mètres, incapable de voler, au bec massif. Son premier os fut trouvé à Meudon en 1855 par Gaston Planté, futur inventeur de la batterie au plomb : l’animal porte son prénom.' },
  /* ---- Néogène ---- */
  pecten: { epoch: 'neogene', kind: 'frag', blocks: 6, rarity: 'commun', name: 'Coquille Saint-Jacques', latin: 'Pecten jacobaeus', ref: 'Pliocène d’Asti, Italie · ~4 Ma',
    note: 'L’emblème des pèlerins de Compostelle vit toujours en Méditerranée. Ses fossiles du Pliocène italien sont presque identiques aux coquilles d’aujourd’hui.' },
  clypeaster: { epoch: 'neogene', kind: 'frag', blocks: 7, rarity: 'commun', name: 'Clypéastre', latin: 'Clypeaster altus', ref: 'Calcaires de Bonifacio, Corse · ~18 Ma',
    note: 'Un oursin massif, grand comme la main. Sur son dos, cinq pétales dessinent une fleur : leurs rangées de trous laissaient passer de petits pieds qui lui servaient à respirer.' },
  megalodon: { epoch: 'neogene', kind: 'frag', blocks: 10, rarity: 'peu commun', name: 'Dent de mégalodon', latin: 'Otodus megalodon', ref: 'Calvert Cliffs, Maryland · ~15 Ma',
    note: 'Une dent grande comme une main, d’un requin qui dépassait sans doute 15 mètres. Ce géant a disparu il y a environ 3,6 millions d’années, peut-être concurrencé par le grand requin blanc.' },
  machairodus: { epoch: 'neogene', kind: 'frag', blocks: 13, rarity: 'rare', name: 'Machairodus', latin: 'Machairodus aphanistus', ref: 'Cerro de los Batallones, Madrid · ~9 Ma',
    note: 'Un grand félin à dents de sabre. Près de Madrid, des cavités naturelles ont servi de pièges : attirés par les animaux tombés au fond, les prédateurs y tombaient à leur tour.' },
  deinotherium: { epoch: 'neogene', kind: 'frag', blocks: 15, rarity: 'exceptionnel', name: 'Deinotherium', latin: 'Deinotherium giganteum', ref: 'Eppelsheim, Allemagne · ~10 Ma',
    note: 'Un cousin des éléphants, plus grand qu’eux, dont les défenses sortaient de la mâchoire inférieure et se recourbaient vers le bas. On ignore encore à quoi elles servaient : arracher l’écorce, peut-être.' },
  /* ---- Quaternaire ---- */
  ursus: { epoch: 'quaternaire', kind: 'frag', blocks: 6, rarity: 'commun', name: 'Ours des cavernes', latin: 'Ursus spelaeus', ref: 'Drachenhöhle, Autriche · ~40 000 ans',
    note: 'Malgré sa taille, il se nourrissait surtout de plantes. Il hibernait dans les grottes, où ses os se sont accumulés par milliers : au Moyen Âge, on les prenait pour des os de dragons.' },
  bison: { epoch: 'quaternaire', kind: 'frag', blocks: 7, rarity: 'commun', name: 'Bison des steppes', latin: 'Bison priscus', ref: 'Steppe à mammouths, Europe · ~50 000 ans',
    note: 'Plus grand que le bison d’aujourd’hui, avec des cornes d’un mètre d’envergure. Les artistes de Lascaux et de Chauvet l’ont peint sur les parois de leurs grottes.' },
  megaloceros: { epoch: 'quaternaire', kind: 'frag', blocks: 10, rarity: 'peu commun', name: 'Cerf géant', latin: 'Megaloceros giganteus', ref: 'Tourbières d’Irlande · ~12 000 ans',
    note: 'Ses bois pouvaient dépasser 3,5 mètres d’envergure. On l’appelle aussi « élan d’Irlande », mais ce n’était pas un élan, et il vivait dans toute l’Europe.' },
  coelodonta: { epoch: 'quaternaire', kind: 'frag', blocks: 12, rarity: 'rare', name: 'Rhinocéros laineux', latin: 'Coelodonta antiquitatis', ref: 'Permafrost de Iakoutie, Sibérie · ~30 000 ans',
    note: 'Sa grande corne avant, aplatie et usée, lui servait sans doute à balayer la neige pour atteindre l’herbe. Les hommes préhistoriques l’ont dessiné sur les parois de la grotte Chauvet.' },
  mammouth: { epoch: 'quaternaire', kind: 'frag', blocks: 15, rarity: 'exceptionnel', name: 'Mammouth laineux', latin: 'Mammuthus primigenius', ref: 'Île Wrangel, Sibérie · ~4 000 ans',
    note: 'Sur l’île Wrangel, au nord de la Sibérie, les derniers mammouths vivaient encore il y a 4 000 ans, quand les pyramides d’Égypte étaient déjà bâties. Leurs défenses pouvaient dépasser 4 mètres.' }
};
/* nombre de blocs avant la v12 (migration des anciennes parties) */
const OLD_BLOCKS = { trilobite: 4, marrella: 4, hallucigenia: 6, opabinia: 8, ammonite: 4, leptolepides: 4, pentacrinites: 6, ichthyosaure: 10 };

const ORES = {
  cuivre: { name: 'cuivre', value: 12, color: '#c26d38', hi: '#f2a56c', dark: '#6b3419' },
  argent: { name: 'argent', value: 20, color: '#aeb8bf', hi: '#ffffff', dark: '#5d666c' },
  or: { name: 'or', value: 36, color: '#d8a621', hi: '#fde58a', dark: '#7a5a0e' }
};

const HAMMERS = ['Marteau de carrier', 'Manche gainé de cuir', 'Tête en acier forgé', 'Acier trempé', 'Pointe carbure', 'Carbure de tungstène'];

/* ---------- terrain : la pelle, les lunettes, le budget de fouille ----------
   digs : coups de pelle par expédition (selon la Pelle) ; glassT : durée d'un coup d'œil des lunettes ;
   glass : usages des lunettes par expédition avant qu'elles cassent, reach : leur portée autour d'un trou, en zones (selon les Lunettes) ;
   pocheR / bordR : distance (en zones) au cœur d'une poche pour sortir une pierre à coup sûr / parfois (bordP, selon la Pelle) ;
   veinR : près d'une veine ; uniR : près de la cachette de la pièce unique ; stray : pierre sans os, ailleurs dans la bonne roche ;
   extra : pierres qu'une poche donne encore une fois son squelette entier (doublons) */
const DIG = {
  digs: [8, 11, 14], glass: [3, 4, 5, 6], glassT: [1.5, 2, 2.5, 3], reach: 1.5, bordP: 0.5,
  pocheR: 0.7, bordR: 1.2, veinR: 0.55, uniR: 0.55, stray: { propice: 0.2, peu: 0.12, sterile: 0.04 }, extra: 4,
  bordOs: 0.55,  // au bord d'une poche : chance que le fil principal soit un os (sinon une veine)
  repli: 0.85    // pierre à os : chance d'avoir au moins une veine de repli
};
/* qualité du coup → étoiles : score = proximité du cœur × (1 − fatigue/2) ; sous STAR_AT[0] : 1★, au-dessus de STAR_AT[1] : 3★ */
const STAR_AT = [0.4, 0.7];
/* minerai : multiplicateur de la valeur selon les étoiles (index 1 à 3) */
const ORE_MULT = [0, 0.6, 1, 1.4];
const PELLES = ['Pelle de jardin', 'Bêche affûtée', 'Pelle de terrassier'];
const UPGRADES = [
  { id: 'marteau', tab: 'outils', name: 'Marteau', icon: 'hammer', max: 5, cost: [150, 280, 450, 700, 1000],
    now: l => HAMMERS[l], next: l => HAMMERS[l + 1] + ' : coups plus tolérants, la pierre se fatigue moins vite' },
  { id: 'quantite', tab: 'outils', name: 'Pelle', icon: 'shovel', max: 2, cost: [400, 1100],
    now: l => PELLES[l] + ' : ' + DIG.digs[l] + ' coups de pelle par expédition', next: l => PELLES[l + 1] + ' : ' + DIG.digs[l + 1] + ' coups de pelle par expédition' },
  { id: 'chaleur', tab: 'outils', name: 'Lunettes du professeur', icon: 'glasses', max: 3, cost: [300, 700, 1300],
    now: l => DIG.glass[l] + ' coups d’œil de ' + String(DIG.glassT[l]).replace('.', ',') + ' s par expédition', next: l => DIG.glass[l + 1] + ' coups d’œil de ' + String(DIG.glassT[l + 1]).replace('.', ',') + ' s : on lit le sous-sol plus souvent, plus longtemps' },
  { id: 'jauge', tab: 'indices', name: 'Carnet de relevés', icon: 'gauge', max: 1, cost: [200],
    now: l => (l ? 'Squelettes enfouis comptés, poches vidées barrées' : 'Non acquis'), next: () => 'Compte les squelettes encore enfouis et barre sur la carte les poches vidées' },
  { id: 'loupe', tab: 'indices', name: 'Loupe de terrain', icon: 'loupe', max: 3, cost: [250, 650, 1300],
    now: l => ['Non acquise', 'Grossissement ×5', 'Grossissement ×10', 'Grossissement ×20'][l],
    next: l => ['Les fils usés de la pierre se devinent mieux', 'Chaque tapotement dégage le fil plus largement', 'Le moindre fil se lit au premier coup d’œil'][l] }
];
/* ---------- géodes : des pierres creuses tapissées de cristaux, loin des fossiles ----------
   val : prix de revente pour 2 étoiles (×0,5 + 0,25 par étoile) ; w : fréquence ; on les ouvre d'un coup dosé */
/* la croûte d'une géode : un nodule rond, bosselé, qui sort entier de la roche */
const NODULE = { shape: 'nodule', base: '#a8977e', light: '#cdbfa6', shade: '#7c6c56', ink: '#3a2e22', side: '#7c6c56', tex: '#6b5c48', face: '#cbbd9f', faceShade: '#a99a7e', faceTex: '#86775f' };
const GEODES = {
  quartz: { name: 'géode de quartz', de: 'de quartz', val: 45, w: 0.5, col: '#e9e5f2', hi: '#ffffff', dark: '#8d86a6', band: ['#d8d2e4', '#b9b1cc', '#efeaf6'] },
  agate: { name: 'géode d’agate', de: 'd’agate', val: 60, w: 0.3, col: '#c98a5a', hi: '#f4d7b6', dark: '#6e3f22', band: ['#e3b48c', '#a4643a', '#f0d5b8'] },
  amethyste: { name: 'géode d’améthyste', de: 'd’améthyste', val: 85, w: 0.2, col: '#9468c2', hi: '#dcc6f4', dark: '#4b2c6c', band: ['#c7b1e0', '#7d58a8', '#e6daf4'] }
};
/* ---------- destinations proposées à l'escale ----------
   trois gisements : modeste, prometteur, riche (poches, chance d'une pièce unique) ; le prix monte avec la richesse,
   la nouveauté (espèces encore absentes du musée) et la distance (numéro du gisement). Le musée avance toujours le plus modeste. */
const DESTS = {
  tiers: [{ name: 'Gisement modeste', poches: 2 }, { name: 'Gisement prometteur', poches: 3 }, { name: 'Gisement riche', poches: 4 }],
  base: 20, perPoche: 35, uni: 70, perNew: 6, perNum: 5, perGeode: 12, perVein: 4,
  /* pas de géode avant ce gisement : le geste dosé s'apprend une fois l'écoute acquise */
  geodeFrom: 3,
  profils: { fossiles: { name: 'riche en fossiles', veins: 4, geodes: 1 }, mineral: { name: 'très minéral', veins: 9, geodes: 1 }, gemmes: { name: 'riche en géodes', veins: 5, geodes: 4 }, mixte: { name: 'un peu de tout', veins: 6, geodes: 2 } }
};
const TABS = [['outils', 'Outils'], ['indices', 'Indices']];

/* ---------- fissures multiples (prototype) ----------
   xp = pierres litées fendues à la visée. Lisibilité : 1 = fausses fissures béantes et rouillées,
   0 = même trait que le fil (seules la direction et la fin en pointe les trahissent). */
const CRACK = {
  tuto: 4,          // pierres avec le fil seul avant les premières fausses fissures
  two: 30,          // à partir de là, parfois deux fausses fissures
  p2: 0.55,         // probabilité d'en avoir deux
  p0: 0.12,         // probabilité qu'une pierre n'en ait aucune
  fadeFrom: 10, fadeTo: 240, fade: 0.9,   // la lisibilité baisse de 1 à 0,1 entre ces deux xp
  loupe: 0.3,       // lisibilité rendue par niveau de loupe
  blurNote: 0.62    // seuil de la note qui suggère la loupe
};
/* gains selon la fissure frappée : blocs de fossile en plus, multiplicateur du minerai */
const CUTS = { fil: { blocs: 1, ore: 2 }, veine: { blocs: 0, ore: 3 }, fausse: { blocs: 0, ore: 1 }, aucune: { blocs: 0, ore: 1 } };

/* ---------- narration : le professeur Kayou ----------
   Directeur du nouveau musée ; le joueur est son assistant de terrain. Textes de premier jet, à réécrire librement.
   expr : content, encourage, conseil, surpris, soucieux. {x} : valeurs insérées par le jeu. */
const KAYOU = { name: 'Professeur Kayou', role: 'directeur du nouveau musée' };
const INTRO = [
  { expr: 'content', text: 'Ah, vous voilà ! Je suis le professeur Kayou, directeur du nouveau musée d’histoire naturelle. Bienvenue !' },
  { expr: 'soucieux', text: 'Comme vous le voyez, nos vitrines sont vides… et nos caisses aussi. Sans pièces à montrer, pas de visiteurs. Et sans visiteurs, pas de musée.' },
  { expr: 'surpris', text: 'Mais j’ai un grand projet : reconstituer toute l’histoire du vivant, des premiers trilobites jusqu’au mammouth laineux. Douze époques, soixante espèces, chacune à sa place sur la grande frise du musée. Il nous les faut toutes !' },
  { expr: 'conseil', text: 'Vous serez mon assistant de terrain : fouillez les gisements, ramenez-moi les fossiles qui manquent… et un peu de minerai pour faire tourner la maison.' },
  { expr: 'encourage', text: 'Chaque voyage vers un gisement coûte de l’argent. Ce qu’il reste, nous l’investirons dans votre équipement, à la boutique du musée.' },
  { expr: 'content', text: 'Votre premier gisement vous attend. Mais avant de partir, passons à mon établi : je vais vous apprendre à écouter une pierre.' }
];
/* notes d'apprentissage, aux premières fois */
const NOTES = {
  trou: { expr: 'conseil',
    text: 'Chaque coup de pelle sort une pierre, mais les os dorment dans des poches. Touchez mes lunettes : un instant, elles lisent la chaleur du sous-sol autour de vos trous. Plus c’est chaud, plus un squelette est proche. Mais elles sont fragiles : quelques coups d’œil, et elles cassent.' },
  pierre: { expr: 'content',
    text: 'Une pierre ! Elle a plusieurs fils, de fines lignes que l’usure efface par endroits. Tournez-la, tapotez ces lignes et écoutez : pic, rien dessous ; pok, un os tout près. Plus le mot jaillit gros, plus vous approchez du cœur.' },
  creux: { expr: 'surpris',
    text: 'Ce pok creux, c’est un os ! Le pok grossit quand on s’en approche. Pour frapper, maintenez : une loupe montre en grand ce qu’il y a sous votre doigt, et sa croix marque où tombera le coup. Placez-la là où le POK sonne le plus gros, puis lâchez : plus vous êtes près du cœur, plus l’os sort beau. Mais chaque tapotement fatigue la pierre, et une pierre fatiguée abîme ce qu’elle cache : à vous de choisir quand frapper.' },
  geode: { expr: 'surpris',
    text: 'Ce bong qui résonne, c’est une géode : une pierre toute ronde et creuse, tapissée de cristaux ! Maintenez sur son fil : la jauge monte et redescend. Lâchez quand elle est au milieu ! Trop doux, la croûte résiste ; trop fort, les cristaux se brisent.' },
  ting: { expr: 'content',
    text: 'Ce ting cristallin, c’est une veine de minerai ! Plus le ting sonne clair, plus vous êtes près du cœur de la veine : frappez là. Pas d’os en vue ? Une veine, c’est un gain assuré.' },
  sourd: { expr: 'conseil',
    text: 'Tak, tak : vous tapez dans la chair de la pierre, sur aucun fil. Cherchez les lignes fines, elles font le tour de la pierre. Les taches aident à deviner où elles passent.' },
  massive: { expr: 'conseil',
    text: 'Une roche massive : pas de feuillets, seulement des joints, en biais. Ils cachent surtout du minerai.' },
  poche: { expr: 'content', sketch: 'individus',
    text: 'Un fragment ! Les os d’un animal reposent ensemble, dans une poche de la roche. L’épingle sur la carte marque l’endroit : creusez autour pour dégager la suite.' },
  individu: { expr: 'surpris', sketch: 'individus',
    text: 'Tiens, ce fragment n’appartient pas au même animal : c’est un autre individu, dans une autre poche ! Chacun a son épingle sur la carte.' },
  doublon: { expr: 'content',
    text: 'Un doublon : ce morceau, notre spécimen l’a déjà. Ne le jetez pas ! Les collectionneurs se l’arrachent, et c’est autant pour les finances du musée.' }
};
const GAME_VERSION = 'v46';
/* journal de playtest : les trois questions posées au testeur (modifiables librement).
   PLAYTEST_ASK = false : les questions ne s'affichent pas (le questionnaire se fait de vive voix). */
const PLAYTEST_ASK = false;
const PLAYTEST_Q = [
  'Qu’est-ce qui t’a donné envie de continuer… ou d’arrêter ?',
  'À quel moment t’es-tu senti perdu, bloqué ou frustré ?',
  'Sans regarder : que veulent dire pic, pok, ting et bong ? Et la fatigue de la pierre ?'
];
/* écran d'accueil */
const TITLE_TXT = {
  start: 'Démarrer la partie', cont: 'Reprendre la fouille', fresh: 'Nouvelle partie', sure: 'Tout effacer ? Touchez encore',
  cover: 'Musée d’histoire naturelle · Pr Kayou', hint: 'Touchez le carnet pour l’ouvrir',
  page: 'Carnet de fouille', pageSub: 'Assistant de terrain du professeur Kayou',
  save: '{n} espèce{s} au musée · gisement n°{g}'
};
/* tutoriel à l'établi du professeur : deux pierres, un geste chacune (la géode s'apprend sur le terrain) */
const TUTO_TXT = {
  skip: 'Passer', skipSure: 'Passer le tutoriel ?', next: 'Pierre suivante', go: 'En route !',
  tak: 'Tak : là, c’est la pierre pleine, hors des fils. Visez la ligne dorée.',
  takFat: 'Tak ! Hors des fils : regardez la jauge, la fatigue monte deux fois plus vite.',
  fatHigh: 'La jauge monte : une pierre fatiguée abîme ce qu’elle cache. Ne traînez pas !',
  listenFirst: 'Écoutez d’abord : un simple toucher, sans appuyer.',
  soft: 'Trop doux : maintenez plus longtemps avant de lâcher.',
  along: 'Pic ici : c’est le bon fil, mais plus loin. Suivez les marques en tapotant.',
  listenLine: 'Commencez par la ligne dorée.',
  geode: {
    rock: 'un nodule tout rond',
    listen: 'Voici une géode : une pierre ronde et creuse. Glissez le doigt pour la tourner, puis touchez une fois la ligne dorée pour l’écouter.',
    strike: 'Bong ! Ça sonne creux : des cristaux dorment dedans. Maintenant, maintenez le doigt sur la ligne : la jauge monte et redescend. Lâchez quand elle est au milieu.',
    soft: 'Trop doux : attendez que la jauge monte.', hard: 'Trop fort : lâchez quand la jauge est au milieu.', off: 'Hors du fil : visez la ligne dorée.',
    done: 'Magnifique ! Retenez : bong, c’est une géode. Pierre suivante !',
    title: 'Géode de quartz', sub: 'Bong : une géode. Un coup dosé, des cristaux intacts.'
  },
  veine: {
    rock: 'roche massive : des joints, pas de feuillets',
    listen: 'Une quartzite : pas de feuillets, seulement des joints, ces lignes en biais. Glissez le doigt pour la tourner, puis touchez les fils dorés, sans appuyer, et écoutez : l’un d’eux cache une veine.',
    pic: 'Pic : un son plein, ce fil est vide. Essayez l’autre.',
    strike: 'Ting ! Une veine de minerai. Plus le ting sonne clair, plus vous êtes près du cœur : maintenez le doigt sur la grosse marque, puis lâchez.',
    closer: 'Plus près de la grosse marque : le ting y est plus clair.', wrong: 'Pas ce fil-là : il sonne pic, il est vide.', off: 'Hors du fil : visez la ligne.',
    done: 'Voilà ! Le ting, c’est votre filet de sécurité : quand aucun os ne répond, une veine rapporte toujours quelque chose. Dernière pierre, la plus précieuse.',
    title: 'Veine de cuivre', sub: 'Ting : du minerai. Un gain sûr.'
  },
  os: {
    rock: 'roche litée : c’est là que dorment les fossiles',
    pic: 'Un schiste, en feuillets : c’est là que dorment les fossiles. Voyez la jauge en haut : chaque tapotement fatigue la pierre, et un tak hors des fils encore plus. Touchez d’abord la ligne dorée.',
    pok: 'Pic : un son plein, rien dessous. Essayez maintenant l’autre fil.',
    follow: 'Pok ! Un os, tout près. Tapotez le long des marques : le pok grossit à mesure que vous approchez du cœur.',
    strike: 'Le gros POK : c’est ici ! Maintenez le doigt dessus, puis lâchez pour frapper.',
    closer: 'Un peu plus près du gros POK, sur la grosse marque.', wrong: 'Pas ce fil-là : lui sonne pic.', off: 'Hors du fil : visez la ligne.',
    done: 'Un trilobite ! Vous avez l’oreille. Pic : rien. Pok : un os, et plus il est gros, plus vous êtes près. Ting : du minerai. Sur le terrain, chaque tapotement fatigue la pierre : écoutez, puis décidez-vous.',
    title: 'Trilobite', sub: '★★★ · frappé au gros POK : l’os sort intact.'
  }
};
/* fin d'expédition et lunettes */
const FIN = {
  fouilles: 'Nos crédits de fouille sont épuisés ! Regardez ce que cachait le sous-sol, puis rentrons au musée.',
  casse: 'Crac… mes lunettes ont rendu l’âme. Le musée les fera réparer à l’escale.'
};
/* arrivée sur un gisement */
const ARRIVEE = {
  premier: 'Vous voilà sur le site de fouilles ! Touchez la carte pour creuser : chaque coup de pelle sort une pierre. Mes lunettes montrent où dorment les os.',
  suivant: 'Nous voici au gisement n°{n}, en plein {epoque}.',
  relief: { riviere: 'Un lit de rivière : les crues ont dégagé bien des roches pour nous.', falaise: 'Au pied de la falaise, les éboulis cachent parfois des merveilles.', carriere: 'Une ancienne carrière : les carriers n’ont sûrement pas tout emporté.' },
  roche: 'Cherchez {propices} : quelque part dedans, des squelettes dorment, chacun dans sa poche.',
  avance: 'Le musée a avancé les frais du voyage. Il va falloir remplir les caisses !',
  equipe: 'Ne cherchez pas que les os : une veine bien ouverte, un doublon, et voilà de quoi payer un meilleur marteau ou une pelle plus solide. Avec de bons outils, les fossiles viendront plus vite.',
  reserve: 'Nos spécimens inachevés sont rangés en réserve. Ici, chaque squelette est à reprendre de zéro.'
};
/* après une longue série de pierres sans fossile */
const COURAGE = {
  patience: { expr: 'encourage', text: 'Ne vous découragez pas : il y a forcément des fossiles dans ce secteur !' },
  pauvre: { expr: 'conseil', text: '{Roche} est pauvre en fossiles. Cherchez plutôt {propices} sur la carte : c’est là que dorment les fossiles.' },
  sterile: { expr: 'conseil', text: '{Roche} ne garde aucun fossile : rien à espérer ici. Rapprochez-vous du cœur du gisement.' },
  tari: { expr: 'soucieux', text: 'On dirait que ce gisement a livré tous ses squelettes. Il reste du minerai, mais pour les fossiles, il faudra repartir ailleurs.' },
  chercher: { expr: 'conseil', text: '{Propices}, c’est la bonne roche, mais les squelettes s’y cachent dans des poches. Creusez à plusieurs endroits et regardez avec mes lunettes : là où ça chauffe, creusez autour.' },
  epoque: { expr: 'content', text: 'Tous les fossiles {du} sont déjà au musée ! Il ne reste ici que du minerai : une autre époque nous attend.' }
};
/* après plusieurs ouvertures malheureuses */
const ASTUCES = {
  ecoute: { expr: 'conseil', text: 'Avant de frapper, faites le tour des fils en tapotant. Frappez là où le POK est le plus gros : plus vous êtes près du cœur, mieux l’os est conservé.' },
  fatigue: { expr: 'soucieux', text: 'Chaque tapotement fatigue la pierre, et les coups hors des fils encore plus. Fatiguée, elle abîme ce qu’elle cache ; à bout, elle éclate. Écoutez, puis décidez-vous : ne frappez fort que sur un fil.' }
};
/* voyage et escale au musée */
const VOYAGE = { base: 50, step: 10, max: 120 };   // prix du voyage vers le gisement n : base + step × (n − 2), plafonné
const ESCALE = {
  bienvenue: { expr: 'content', text: 'Belle campagne ! Choisissez notre prochaine destination : plus un gisement est riche et neuf pour nos vitrines, plus le voyage coûte. La boutique ouvrira ensuite avec ce qui reste en caisse.' },
  fauche: { expr: 'soucieux', text: 'Les caisses sont presque vides… Heureusement, un musée voisin propose une mission à l’atelier : un bloc à nettoyer. De quoi payer au moins un voyage modeste !' },
  boutique: { expr: 'content', text: 'Cap sur {dest} ! Avant de partir, passez par la boutique : un bon outil fait une bonne fouille.' },
  fermee: { expr: 'conseil', text: 'La boutique n’ouvre qu’aux escales, quand les crédits de fouille sont épuisés. Gardez de quoi choisir une belle destination !' },
    equipe: { expr: 'content', text: 'Vous avez de quoi vous équiper ! La boutique ouvrira à l’escale, quand nos crédits de fouille seront épuisés.' },
  dernier: { expr: 'conseil', text: 'Plus que trois fouilles sur ce gisement. Choisissez-les bien !' }
};
/* mots pour les phrases : la roche avec son article, les roches propices au pluriel */
const ROCK_WORDS = {
  schiste: ['le schiste', 'les schistes'], gresfin: ['le grès fin', 'le grès fin'], quartzite: ['le quartzite', 'le quartzite'], calcaire: ['le calcaire', 'les calcaires'],
  gres: ['le grès', 'le grès'], granite: ['le granite', 'le granite'], ardoise: ['le schiste ardoisier', 'les schistes ardoisiers'], calcrecif: ['le calcaire récifal', 'les calcaires récifaux'],
  gresrouge: ['le grès rouge', 'les grès rouges'], houiller: ['le schiste houiller', 'les schistes houillers'], marne: ['la marne', 'les marnes'], craie: ['la craie', 'la craie'],
  schistebit: ['le schiste bitumineux', 'les schistes bitumineux'], falun: ['le falun', 'les faluns'], loess: ['le loess', 'le loess'], basalte: ['le basalte', 'le basalte']
};
const cap1 = s => s.charAt(0).toUpperCase() + s.slice(1);
