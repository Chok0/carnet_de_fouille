/* ============ fossiles : Trias (fin), Crétacé ============ */

/* plateosaurus — Plateosaurus trossingensis, pièce unique, squelette en marche bipède (tête à gauche).
   ① petit crâne allongé ; ② long cou en S ; ③ tronc profond, bassin ; ④ grands membres postérieurs à 4 orteils,
   bras courts à grosse griffe de pouce ; ⑤ longue queue horizontale */
function artPlateosaurus(p) {
  const neck = resample(sk_spline([[58, 72], [74, 86], [92, 98], [112, 104]], 6), 10);
  const back = resample(sk_spline([[112, 104], [140, 98], [168, 96], [198, 104]], 6), 14);
  const tail = resample(sk_spline([[198, 104], [232, 108], [270, 114], [306, 118], [336, 120]], 6), 34);
  let s = sk_film([[60, 64], [100, 90], [140, 82], [200, 88], [250, 100], [336, 116], [300, 128], [240, 132], [214, 150], [180, 162], [140, 158], [110, 132], [80, 104], [56, 84]], p, 0.28);
  const leg = (hip, knee, ank, toe, w, col) => sk_bone(hip, knee, w, p, w * 1.7, col) + sk_bone(knee, ank, w * 0.85, p, w * 1.4, col) + sk_bone(ank, toe, w * 0.6, p, w * 1.1, col);
  /* membres éloignés */
  s += leg([204, 116], [214, 158], [210, 196], [222, 214], 3.2, p.shade) + sk_digits([222, 214], 10, 40, [12, 15, 16, 12], 1.5, p, 2.5);
  s += sk_bone([128, 114], [138, 142], 2.4, p, 3.6, p.shade) + sk_bone([138, 142], [132, 164], 2, p, 3, p.shade) + sk_digits([132, 164], 110, 50, [8, 9, 9], 1.2, p, 2);
  /* côtes, colonne */
  s += sk_ribs(back, 1, 13, p, { len: t => 44 - 14 * Math.abs(t - 0.45), back: 0.12, bend: 0.22, w: 1.6 });
  s += sk_column(neck, p, { h: () => 5.6, spine: () => 4, lean: 0.4 }) + sk_column(back, p, { h: () => 7.4, spine: () => 12, lean: 0.25 }) + sk_column(tail, p, { h: t => 7 - 5.2 * t, spine: t => 12 * (1 - t), chev: t => 13 * (1 - t) * (t > 0.04 ? 1 : 0), lean: 0.45 });
  /* bassin */
  s += E.p('M184 98Q204 88 222 100L216 116Q200 122 188 114Z', p.relief, p.line, 0.9) + E.p('M194 116L184 156L192 157L204 118Z', p.relief, p.line, 0.8) + E.p('M210 116L228 152L220 154L204 118Z', p.relief, p.line, 0.8);
  /* membres proches */
  s += leg([200, 118], [188, 160], [202, 198], [190, 218], 3.4, p.relief) + sk_digits([190, 218], 172, 44, [12, 15, 16, 12], 1.6, p, 2.8);
  s += E.p('M116 104Q124 100 130 108L126 124Z', p.relief, p.line, 0.8);
  s += sk_bone([124, 116], [132, 144], 2.5, p, 3.8) + sk_bone([132, 144], [122, 166], 2.1, p, 3.2) + sk_digits([122, 166], 120, 40, [7, 8, 8], 1.3, p, 2) + E.p('M118 166Q108 170 104 178Q112 176 121 170Z', p.hi, p.line, 0.8);
  /* crâne */
  s += E.p('M14 66Q18 56 34 52Q50 50 60 58L62 70Q50 76 34 76Q20 76 14 70Z', p.relief, p.line, 1) + E.el(47, 60, 4.5, 4, 0, p.accent, p.line, 0.6) + E.el(32, 62, 5, 3, -8, p.accent, null) + E.p('M16 69Q38 70 60 66', null, p.line, 0.7);
  s += sk_teeth(linePts([18, 69], [50, 68], 8), 2.2, 1, p, 0.9) + E.p('M20 78Q40 82 60 74L62 70Q40 74 18 72Z', p.relief, p.line, 0.8);
  s += E.p('M20 58Q36 50 52 52', null, p.hi, 1.6, 'opacity=".7"') + E.p('M140 92Q170 88 196 96', null, p.hi, 1.6, 'opacity=".5"');
  return s;
}

/* cretolamna — Cretolamna appendiculata, dent de requin.
   ① cuspide triangulaire lisse, un peu inclinée ; ② deux petites cuspides latérales ; ③ racine bilobée ; ④ limite émail/racine ; ⑤ reflet */
function artCretolamna(p) {
  const rnd = mulberry32(hashStr('cretolamna'));
  let s = '';
  /* racine bilobée */
  const ROOT = [[46, 140], [154, 140], [162, 160], [164, 184], [156, 200], [140, 198], [124, 180], [108, 166], [100, 164], [92, 166], [76, 180], [60, 198], [44, 198], [36, 184], [38, 160]];
  s += E.p(smoothD(ROOT, true), p.relief, p.line, 1.2) + sk_dots(rnd, ROOT, 60, 0.9, p.shade, 0.55) + E.p('M100 146L100 162', null, p.line, 0.8);
  /* cuspides latérales */
  s += E.p('M40 142Q42 128 50 112Q56 126 64 138Z', p.body, p.line, 1) + E.p('M160 142Q158 128 150 114Q144 128 136 138Z', p.body2, p.line, 1);
  /* cuspide principale : deux faces */
  s += E.p('M54 142Q70 96 88 52Q98 26 108 14Q108 80 104 142Z', p.body, p.line, 1.2) + E.p('M104 142Q108 80 108 14Q116 30 124 58Q138 100 146 142Z', p.body2, p.line, 1.2);
  s += E.p('M50 142Q100 150 150 142', null, p.line, 1.2) + E.p('M52 140Q100 147 148 140', null, p.shade, 2.2, 'opacity=".6"');
  /* reflet */
  s += E.p('M80 122Q86 80 102 32', null, p.hi, 2.6, 'opacity=".75"') + E.p('M112 60Q118 90 122 124', null, p.hi, 1.2, 'opacity=".35"');
  return s;
}

/* turrilites — Turrilites costatus, ammonite en tire-bouchon, vue de côté.
   ① spire haute, pointe en haut ; ② tours inclinés (hélice) ; ③ fortes côtes obliques et rangées de tubercules ;
   ④ sutures profondes entre les tours ; ⑤ ouverture sur le côté du dernier tour ; ombrage cylindrique */
function artTurrilites(p) {
  const cx = 95, N = 6;
  const H = [], W = [], Y = [];
  let y = 30;
  for (let i = 0; i < N; i++) { H.push(19 * Math.pow(1.21, i)); W.push(15 * Math.pow(1.3, i)); Y.push(y); y += H[i]; }
  let s = '';
  /* pointe */
  s += E.p('M' + cx + ' 10Q' + (cx - 10) + ' 20 ' + (cx - W[0] * 0.9) + ' ' + r1(Y[0] + 6) + 'L' + (cx + W[0] * 0.9) + ' ' + r1(Y[0] - 2) + 'Q' + (cx + 8) + ' 18 ' + cx + ' 10Z', p.body, p.line, 1);
  for (let i = N - 1; i >= 0; i--) {
    const h = H[i], w = W[i], y0 = Y[i], tilt = h * 0.3;
    const tl = [cx - w * 0.94, y0 + tilt], tr = [cx + w * 0.94, y0 - tilt], bl = [cx - w * 0.94, y0 + h + tilt], br = [cx + w * 0.94, y0 + h - tilt];
    const band = [tl, [cx, y0 - 1], tr, [cx + w * 1.1, y0 + h * 0.5 - tilt], br, [cx, y0 + h + 1], bl, [cx - w * 1.1, y0 + h * 0.5 + tilt]];
    s += E.p(smoothD(band, true), p.body, p.line, 1.2);
    /* ombrage cylindrique : bande sombre à droite, claire à gauche */
    s += E.p(smoothD([[cx + w * 0.45, y0 - tilt * 0.4], tr, [cx + w * 1.04, y0 + h * 0.5 - tilt], br, [cx + w * 0.45, y0 + h - tilt * 0.4]], true), p.shade, null, 0, 'opacity="' + (p.flat ? 1 : 0.45) + '"');
    /* côtes obliques + tubercules */
    let ribs = '', tub = '';
    const nr = 11;
    for (let k = 0; k < nr; k++) {
      const u = (k + 0.5) / nr, x = cx + (u * 2 - 1) * w * 0.9, sl = h * 0.28, t0 = [x, y0 + tilt * (1 - 2 * u) + 2.5], t1 = [x + sl, y0 + h + tilt * (1 - 2 * u) - 2.5];
      ribs += 'M' + PS(t0) + 'L' + PS(t1);
      [0.3, 0.62].forEach(f => { const q = lerpPt(t0, t1, f); tub += 'M' + PS(q) + 'h.1'; });
    }
    s += sk_str(ribs, Math.max(1.4, w / 12), p) + E.p(tub, null, p.line, Math.max(2.4, w / 10) + 1.3) + E.p(tub, null, p.relief, Math.max(1.6, w / 11));
    s += E.p('M' + PS(bl) + 'Q' + cx + ' ' + r1(y0 + h + 2.5) + ' ' + PS(br), null, p.line, 1.6);
  }
  /* ouverture du dernier tour */
  const i = N - 1;
  s += E.el(cx + W[i] * 0.78, Y[i] + H[i] * 0.5, W[i] * 0.2, H[i] * 0.32, -14, p.relief, p.line, 1.1) + E.el(cx + W[i] * 0.8, Y[i] + H[i] * 0.5, W[i] * 0.12, H[i] * 0.22, -14, p.accent, null);
  s += E.p('M' + (cx - W[3] * 0.6) + ' ' + r1(Y[3] + 6) + 'Q' + (cx - W[4] * 0.9) + ' ' + r1(Y[4] + H[4] * 0.5) + ' ' + (cx - W[5] * 0.7) + ' ' + r1(Y[5] + H[5] * 0.7), null, p.hi, 2, 'opacity=".6"');
  return s;
}

/* iguanodon — Iguanodon bernissartensis, squelette de profil (tête à gauche), dos horizontal.
   ① crâne long et haut à bec ; ② cou en S ; ③ tendons ossifiés en treillis le long du dos et de la queue ;
   ④ éperon de pouce conique ; ⑤ grands membres postérieurs à 3 orteils, bassin à tige prépubienne ; ⑥ queue à chevrons */
function artIguanodon(p) {
  const neck = resample(sk_spline([[76, 82], [92, 90], [108, 96], [122, 98]], 6), 8);
  const back = resample(sk_spline([[122, 98], [150, 92], [182, 90], [214, 96]], 6), 15);
  const tail = resample(sk_spline([[214, 96], [252, 102], [292, 112], [334, 126]], 6), 30);
  let s = sk_film([[70, 70], [120, 86], [180, 80], [230, 88], [334, 124], [290, 124], [236, 128], [218, 150], [180, 158], [140, 150], [112, 122], [80, 100], [66, 88]], p, 0.26);
  const leg = (hip, knee, ank, toe, w, col) => sk_bone(hip, knee, w, p, w * 1.7, col) + sk_bone(knee, ank, w * 0.85, p, w * 1.4, col) + sk_bone(ank, toe, w * 0.7, p, w * 1.1, col) + sk_digits(toe, 176, 34, [11, 14, 12], w * 0.5, p, 2.4);
  s += leg([220, 108], [228, 150], [222, 188], [232, 204], 4, p.shade);
  s += sk_bone([134, 110], [144, 140], 3, p, 4.4, p.shade) + sk_bone([144, 140], [138, 166], 2.6, p, 3.6, p.shade);
  s += sk_ribs(back, 1, 13, p, { len: t => 50 - 16 * Math.abs(t - 0.45), back: 0.1, bend: 0.2, w: 1.7 });
  s += sk_column(neck, p, { h: () => 7, spine: () => 5, lean: 0.4 }) + sk_column(back, p, { h: () => 8, spine: () => 17, lean: 0.2 }) + sk_column(tail, p, { h: t => 7.6 - 5.8 * t, spine: t => 16 * (1 - t), chev: t => 16 * (1 - t) * (t > 0.05 ? 1 : 0), lean: 0.45 });
  /* tendons ossifiés : deux familles de fines lignes croisées au-dessus des vertèbres */
  let tn = '';
  const top = back.concat(tail.slice(1, 20));
  for (let i = 3; i < top.length - 3; i++) { const a = top[i], b = top[i + 3]; tn += 'M' + r1(a[0]) + ' ' + r1(a[1] - 7) + 'L' + r1(b[0]) + ' ' + r1(b[1] - 14) + 'M' + r1(a[0]) + ' ' + r1(a[1] - 14) + 'L' + r1(b[0]) + ' ' + r1(b[1] - 7); }
  s += E.p(tn, null, p.line, 0.6, 'opacity=".65"');
  /* bassin : ilion, tige prépubienne, ischion */
  s += E.p('M192 90Q214 82 240 92L236 106Q214 112 196 104Z', p.relief, p.line, 0.9) + sk_str('M208 110L176 124', 2.6, p) + sk_str('M222 110L240 148', 2.8, p);
  /* membres proches, éperon de pouce */
  s += leg([214, 110], [204, 152], [218, 190], [206, 208], 4.2, p.relief);
  s += E.p('M126 100Q136 96 140 106L134 124Z', p.relief, p.line, 0.8) + sk_bone([132, 112], [140, 142], 3.2, p, 4.6) + sk_bone([140, 142], [132, 168], 2.7, p, 3.8) + sk_digits([132, 168], 112, 26, [11, 13, 12], 1.8, p, 0);
  s += E.p('M130 164L110 156L112 162Z', p.hi, p.line, 1) + E.p('M129 163Q116 156 110 156', null, p.line, 0.6);
  /* crâne à bec */
  s += E.p('M14 90Q16 74 34 68Q58 62 76 70L80 84Q70 96 50 100Q28 102 16 98Z', p.relief, p.line, 1.1);
  s += E.el(58, 76, 6, 5.4, 0, p.accent, p.line, 0.8) + E.p('M22 76Q30 72 38 76L34 82Q26 82 22 76Z', p.accent, null) + E.p('M14 92Q24 96 34 94', null, p.line, 0.9);
  s += E.p('M36 94L72 88M36 98L70 92', null, p.line, 0.6, 'opacity=".7"') + E.p('M16 100Q40 110 74 96L78 88Q50 102 18 98Z', p.relief, p.line, 0.9);
  s += E.p('M22 74Q40 64 60 66', null, p.hi, 1.8, 'opacity=".7"') + E.p('M150 84Q184 80 212 88', null, p.hi, 1.6, 'opacity=".5"');
  return s;
}

/* mosasaurus — Mosasaurus hoffmannii, pièce unique, crâne de profil (museau à gauche).
   ① crâne long et bas, rostre mousse ; ② grandes dents coniques recourbées + dents ptérygoïdiennes ;
   ③ grande orbite à anneau sclérotique ; ④ mandibule articulée au milieu, os carré courbe ; ⑤ sutures ; bouche entrouverte */
function artMosasaurus(p) {
  let s = '';
  /* bouche : ombre entre les mâchoires */
  s += E.p('M22 104L220 106L286 110L292 118L200 124L40 122Z', p.accent, null, 0, 'opacity="' + (p.flat ? 1 : 0.75) + '"');
  /* dents ptérygoïdiennes (palais) */
  s += sk_teeth(linePts([170, 104], [236, 106], 7), 5, 1, p, 1.6, -0.25);
  /* mandibule */
  const JAW = [[20, 120], [60, 118], [150, 122], [240, 124], [262, 112], [274, 116], [296, 120], [298, 132], [250, 142], [150, 140], [60, 134], [26, 130]];
  s += E.p(smoothD(JAW, true), p.body2, p.line, 1.2);
  s += E.p('M148 122L144 128L152 132L148 140', null, p.line, 1.1) + E.p('M60 130Q150 134 250 134', null, p.line, 0.6, 'opacity=".6"') + E.p('M230 125Q246 110 262 112', null, p.line, 0.8);
  s += sk_teeth(resample(sk_spline([[28, 120], [100, 120], [214, 124]], 6), 14), t => 16 - 6 * t, -1, p, 3.2, -0.28);
  /* crâne */
  const SK = [[12, 94], [18, 84], [60, 76], [120, 68], [170, 58], [206, 50], [250, 52], [276, 60], [292, 74], [298, 96], [286, 106], [240, 104], [180, 104], [100, 102], [30, 104], [14, 102]];
  s += E.p(smoothD(SK, true), p.body, p.line, 1.3);
  s += sk_teeth(resample(sk_spline([[24, 104], [110, 103], [214, 105]], 6), 13), t => 17 - 7 * t, 1, p, 3.4, -0.28);
  /* os carré */
  s += E.p('M278 70Q300 78 302 98Q300 116 286 120Q292 100 280 84Z', p.relief, p.line, 1);
  /* narine, fenêtre temporale, sutures */
  s += E.p('M74 80Q104 70 136 68Q112 78 76 84Z', p.accent, p.line, 0.8) + E.el(250, 72, 14, 9, -8, p.accent, p.line, 0.9);
  s += E.p('M40 92Q90 88 150 90Q190 92 230 92M150 66Q156 80 150 102M100 72Q104 86 100 102M226 56Q232 78 228 102', null, p.line, 0.7, 'opacity=".7"');
  /* orbite et anneau sclérotique */
  s += E.c(204, 74, 17, p.relief, p.line, 1);
  let ring = '';
  for (let k = 0; k < 14; k++) { const a = k / 14 * TAU; ring += 'M' + r1(204 + Math.cos(a) * 11) + ' ' + r1(74 + Math.sin(a) * 11) + 'L' + r1(204 + Math.cos(a) * 16.5) + ' ' + r1(74 + Math.sin(a) * 16.5); }
  s += E.p(ring, null, p.line, 0.7) + E.c(204, 74, 11, p.accent, p.line, 0.9) + E.c(200, 70, 3, p.hi, null, 0, 'opacity=".7"');
  s += E.p('M22 86Q80 70 160 60', null, p.hi, 2.2, 'opacity=".7"');
  return s;
}

Object.assign(ART, {
  plateosaurus: { vb: [340, 232], fn: artPlateosaurus, area: { cx: 172, cy: 130, rx: 160, ry: 90 } },
  cretolamna: { vb: [200, 214], fn: artCretolamna, area: { cx: 100, cy: 110, rx: 70, ry: 94 } },
  turrilites: { vb: [190, 290], fn: artTurrilites, area: { cx: 95, cy: 150, rx: 76, ry: 132 } },
  iguanodon: { vb: [340, 220], fn: artIguanodon, area: { cx: 172, cy: 124, rx: 160, ry: 84 } },
  mosasaurus: { vb: [320, 170], fn: artMosasaurus, area: { cx: 158, cy: 98, rx: 146, ry: 56 } }
});
