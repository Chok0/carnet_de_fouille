/* ============ fossiles : Paléogène (fin), Quaternaire ============ */

/* eurohippus — Eurohippus messelensis, squelette couché sur le flanc, silhouette conservée (Messel).
   ① contour du corps en film sombre ; ② crâne allongé, dents ; ③ dos arqué, côtes ;
   ④ pattes fines : 4 doigts devant, 3 derrière ; ⑤ queue courte ; ⑥ fœtus recroquevillé dans le ventre */
function artEurohippus(p) {
  const neck = resample(sk_spline([[76, 74], [90, 78], [106, 84]], 5), 7), back = resample(sk_spline([[106, 84], [140, 80], [176, 78], [212, 86]], 6), 16), tail = resample(sk_spline([[212, 86], [236, 94], [262, 112]], 5), 11);
  let s = sk_film([[14, 96], [22, 70], [60, 56], [84, 62], [104, 74], [150, 64], [196, 66], [230, 78], [266, 108], [252, 114], [232, 104], [236, 130], [224, 176], [214, 188], [206, 150], [186, 134], [150, 138], [140, 180], [130, 188], [120, 150], [104, 118], [86, 100], [58, 104], [26, 106]], p, 0.72);
  const leg = (a, b, c, d, w, dig, col) => sk_bone(a, b, w, p, w * 1.6, col) + sk_bone(b, c, w * 0.8, p, w * 1.3, col) + sk_bone(c, d, w * 0.6, p, w * 1.1, col) + sk_digits(d, 100, 30, dig, 1, p, 0) + E.p(dig.map((L, i) => { const a2 = (100 + (dig.length > 1 ? (i / (dig.length - 1) - 0.5) * 30 : 0)) * D2R; const e = [d[0] + Math.cos(a2) * L, d[1] + Math.sin(a2) * L]; return 'M' + r1(e[0] - 2) + ' ' + r1(e[1]) + 'L' + r1(e[0] + 2.4) + ' ' + r1(e[1]) + 'L' + r1(e[0]) + ' ' + r1(e[1] + 3.4) + 'Z'; }).join(''), p.shade, p.line, 0.5);
  s += leg([128, 108], [140, 134], [136, 162], [132, 178], 2.4, [5, 6, 6, 5], p.shade) + leg([214, 98], [206, 128], [226, 156], [220, 176], 2.8, [6, 7, 6], p.shade);
  s += sk_ribs(back, 1, 13, p, { len: t => 42 - 12 * Math.abs(t - 0.45), back: 0.12, bend: 0.25, w: 1.3 });
  /* fœtus */
  const fe = []; for (let i = 0; i <= 10; i++) { const a = (-40 + i * 25) * D2R; fe.push([170 + Math.cos(a) * 12, 114 + Math.sin(a) * 10]); }
  s += E.p(polyD(fe), null, p.relief, 2.2) + E.el(156, 104, 6, 4, -30, p.relief, p.line, 0.6) + E.p('M168 124l-4 8M176 122l3 8', null, p.relief, 1.2);
  s += sk_column(neck, p, { h: () => 5.4, spine: () => 3, lean: 0.4 }) + sk_column(back, p, { h: () => 6, spine: t => 9 - 4 * t, lean: 0.35 }) + sk_column(tail, p, { h: t => 5 - 3.4 * t, lean: 0.4 });
  s += E.p('M200 82Q214 76 226 86L220 100Q210 104 202 96Z', p.relief, p.line, 0.8) + E.p('M118 84Q128 80 134 90L130 108Z', p.relief, p.line, 0.8);
  s += leg([126, 106], [124, 136], [132, 164], [134, 182], 2.6, [5, 6, 6, 5], p.relief) + leg([212, 100], [196, 130], [214, 158], [206, 180], 3, [6, 7, 6], p.relief);
  /* crâne */
  s += E.p('M16 92Q18 80 30 76Q50 66 72 64Q80 68 80 78L76 86Q54 90 32 96Z', p.relief, p.line, 1) + E.p('M20 96Q46 100 74 88L78 84Q50 98 18 94Z', p.relief, p.line, 0.8);
  s += E.el(64, 72, 5, 4.6, 0, p.accent, p.line, 0.6) + E.p('M34 90L66 84', null, p.line, 1.4, 'stroke-dasharray="2.4 1.4"') + E.p('M22 80Q40 70 62 66', null, p.hi, 1.4, 'opacity=".6"');
  return s;
}

/* gastornis — Gastornis parisiensis, pièce unique, oiseau géant debout (bec à gauche).
   ① crâne énorme au bec très haut ; ② cou épais en S ; ③ cage thoracique ronde, ailes minuscules ;
   ④ pattes massives à 3 gros orteils griffus ; ⑤ grand bassin, queue courte */
function artGastornis(p) {
  const neck = resample(sk_spline([[104, 72], [118, 96], [118, 120], [128, 144]], 6), 12), back = resample(sk_spline([[128, 144], [160, 150], [196, 164], [222, 178]], 6), 12);
  let s = sk_film([[20, 76], [60, 26], [100, 38], [122, 90], [130, 134], [176, 136], [226, 160], [236, 190], [214, 214], [196, 226], [150, 222], [124, 196], [112, 150], [100, 100], [92, 104], [30, 98]], p, 0.3);
  const leg = (h, k, a, t, w, col) => sk_bone(h, k, w, p, w * 1.5, col) + sk_bone(k, a, w * 0.85, p, w * 1.3, col) + sk_bone(a, t, w * 0.8, p, w * 1.25, col);
  s += leg([204, 194], [212, 232], [206, 282], [218, 302], 5, p.shade) + sk_digits([218, 302], 175, 40, [18, 22, 16], 3.2, p, 5);
  s += sk_ribs(back, 1, 10, p, { len: t => 52 - 16 * t, back: 0.05, bend: 0.28, w: 2 });
  s += sk_column(neck, p, { h: () => 9.5, spine: () => 4, lean: 0.4 }) + sk_column(back, p, { h: () => 8, spine: () => 7, lean: 0.3 });
  /* bassin, queue, aile vestigiale */
  s += E.p('M188 164Q216 156 236 176L232 196Q210 202 192 190Z', p.relief, p.line, 1) + sk_str('M214 196L234 222', 3.4, p) + E.el(238, 178, 5, 7, 20, p.relief, p.line, 0.8);
  s += sk_bone([150, 160], [168, 172], 2.4, p, 3.4) + sk_bone([168, 172], [176, 186], 1.8, p, 2.6);
  s += E.p('M130 208Q160 222 190 214', null, p.line, 1.2) + E.p('M130 208Q160 218 190 210', null, p.relief, 2.4, 'opacity=".7"');
  /* patte proche */
  s += leg([198, 196], [182, 234], [196, 284], [186, 306], 5.6, p.relief) + sk_digits([186, 306], 178, 44, [20, 26, 18], 3.6, p, 5.6);
  /* crâne : bec énorme */
  s += E.p('M92 44Q106 46 110 62L106 88Q98 100 90 100L88 70Z', p.relief, p.line, 1);
  s += E.p('M20 76Q22 52 44 36Q62 26 82 30Q96 34 98 52L92 88L22 80Z', p.body, p.line, 1.3);
  s += E.p('M22 82L92 90L94 104Q60 106 30 96Q22 92 22 82Z', p.body2, p.line, 1.2) + E.p('M22 80Q56 84 92 89', null, p.line, 1.4);
  s += E.el(94, 56, 5, 5, 0, p.accent, p.line, 0.7) + E.el(62, 48, 7, 3.4, -18, p.accent, null) + E.p('M28 64Q40 44 62 36', null, p.hi, 2.4, 'opacity=".7"') + E.p('M40 74Q60 66 84 70', null, p.line, 0.6, 'opacity=".6"');
  return s;
}

/* megaloceros — Megaloceros giganteus, crâne vu de face avec ses bois.
   ① petit crâne étroit au centre ; ② perches qui partent sur les côtés ; ③ grandes paumes plates à andouillers ;
   ④ andouiller d'œil près de la base ; ⑤ fines rainures */
function artMegaloceros(p) {
  const cx = 170;
  const half = (col, colD) => {
    let o = '';
    /* andouiller d'œil */
    o += E.p(taperD([[148, 88], [136, 96], [128, 110]], 6, 1.4), col, p.line, 0.9);
    /* perche et paume */
    const PALM = [[154, 86], [132, 76], [110, 70], [92, 60], [78, 44], [70, 28], [60, 36], [58, 20], [46, 30], [40, 16], [30, 30], [22, 22], [16, 38], [8, 44], [14, 56], [6, 64], [18, 70], [40, 80], [70, 86], [100, 88], [126, 92], [150, 96]];
    o += E.p(smoothD(PALM, true), col, p.line, 1.2);
    o += E.p('M150 90Q120 80 96 76M100 80Q70 70 44 58M92 70Q74 52 64 34M80 76Q56 60 36 44M70 80Q40 72 20 60', null, colD, 0.8, 'opacity=".7"');
    o += E.p('M146 84Q120 74 96 68Q84 56 76 40', null, p.hi, 1.6, 'opacity=".55"');
    return o;
  };
  let s = half(p.body, p.line) + mirrorG(half(p.body2, p.line), cx);
  /* crâne de face */
  s += E.p('M' + (cx - 30) + ' 94Q' + cx + ' 82 ' + (cx + 30) + ' 94Q' + (cx + 34) + ' 118 ' + (cx + 22) + ' 140Q' + (cx + 14) + ' 176 ' + (cx + 12) + ' 204Q' + cx + ' 212 ' + (cx - 12) + ' 204Q' + (cx - 14) + ' 176 ' + (cx - 22) + ' 140Q' + (cx - 34) + ' 118 ' + (cx - 30) + ' 94Z', p.relief, p.line, 1.2);
  s += E.c(cx - 28, 116, 7, p.accent, p.line, 0.8) + E.c(cx + 28, 116, 7, p.accent, p.line, 0.8) + E.c(cx - 20, 90, 7, p.relief, p.line, 0.9) + E.c(cx + 20, 90, 7, p.relief, p.line, 0.9);
  s += E.p('M' + cx + ' 96L' + cx + ' 200M' + (cx - 8) + ' 140Q' + (cx - 10) + ' 170 ' + (cx - 8) + ' 198M' + (cx + 8) + ' 140Q' + (cx + 10) + ' 170 ' + (cx + 8) + ' 198', null, p.line, 0.7, 'opacity=".7"');
  s += E.el(cx - 5, 206, 3, 2, 0, p.accent) + E.el(cx + 5, 206, 3, 2, 0, p.accent);
  return s;
}

/* coelodonta — Coelodonta antiquitatis, rhinocéros laineux, crâne de profil avec ses cornes (museau à gauche).
   ① crâne long et bas, occiput relevé ; ② cloison nasale ossifiée ; ③ grande corne avant aplatie, courbée vers l'avant, corne arrière plus courte ;
   ④ orbite, arcade zygomatique ; ⑤ molaires hautes, mandibule */
function artCoelodonta(p) {
  let s = '';
  /* mandibule */
  s += E.p('M58 142Q120 150 200 150Q238 148 252 128L246 104Q262 110 266 140Q262 172 236 172Q150 170 66 156Z', p.body2, p.line, 1.1);
  /* crâne */
  const SK = [[26, 94], [34, 84], [70, 84], [110, 86], [150, 90], [196, 80], [232, 64], [262, 50], [290, 56], [298, 80], [292, 104], [270, 112], [240, 116], [200, 124], [150, 130], [104, 130], [70, 122], [44, 112]];
  s += E.p(smoothD(SK, true), p.relief, p.line, 1.3);
  /* cloison nasale ossifiée et échancrure nasale */
  s += E.p('M34 92Q46 96 48 116L40 118Q32 104 30 94Z', p.body, p.line, 0.9) + E.p('M56 96Q84 92 108 100Q96 112 64 112Z', p.accent, p.line, 0.8);
  /* orbite, arcade */
  s += E.el(186, 104, 9, 8.5, 0, p.accent, p.line, 0.9) + E.p('M160 120Q206 110 250 110', null, p.line, 1.4) + E.p('M160 120Q206 112 250 112', null, p.hi, 1.2, 'opacity=".5"');
  /* molaires hautes */
  let mo = '';
  for (let k = 0; k < 6; k++) { const x = 112 + k * 17; mo += E.p('M' + x + ' 126L' + (x + 15) + ' 126L' + (x + 14) + ' 144L' + (x + 1) + ' 144Z', p.hi, p.line, 0.8) + E.p('M' + (x + 4) + ' 130Q' + (x + 8) + ' 136 ' + (x + 5) + ' 141M' + (x + 10) + ' 129Q' + (x + 7) + ' 134 ' + (x + 11) + ' 140', null, p.line, 0.5); }
  s += mo;
  s += E.p('M100 88Q150 96 196 82M234 66Q250 80 246 104', null, p.line, 0.7, 'opacity=".6"');
  /* cornes (kératine plus sombre) */
  const front = [[48, 86], [40, 62], [30, 40], [18, 22], [12, 14], [24, 22], [46, 40], [74, 60], [104, 84]];
  s += E.p(smoothD(front, true), p.shade, p.line, 1.2);
  let st = ''; for (let k = 1; k < 5; k++) { const f = k / 5; st += 'M' + r1(lerp(50, 100, f)) + ' ' + r1(lerp(86, 84, f)) + 'Q' + r1(lerp(36, 60, f)) + ' ' + r1(lerp(56, 50, f)) + ' ' + r1(lerp(16, 22, f * 0.5)) + ' ' + r1(lerp(18, 26, f * 0.5)); }
  s += E.p(st, null, p.line, 0.6, 'opacity=".6"');
  s += E.p('M136 90Q134 64 146 44Q152 62 170 88Z', p.shade, p.line, 1.1) + E.p('M142 86Q142 66 146 52', null, p.line, 0.5, 'opacity=".6"');
  s += E.p('M40 76Q30 52 20 30', null, p.hi, 1.6, 'opacity=".45"') + E.p('M110 90Q170 92 230 70', null, p.hi, 1.8, 'opacity=".55"');
  return s;
}

/* mammouth — Mammuthus primigenius, pièce unique, squelette complet de profil (tête à gauche).
   ① crâne haut en dôme ; ② défenses spiralées vers l'avant ; ③ bosse au garrot, dos qui descend ;
   ④ cage thoracique profonde ; ⑤ pattes en colonnes ; ⑥ bassin, petite queue */
function artMammouth(p) {
  const back = resample(sk_spline([[112, 76], [140, 66], [180, 70], [224, 82], [266, 96]], 6), 20), tail = resample(sk_spline([[266, 96], [282, 108], [296, 130]], 5), 8);
  const neck = resample(sk_spline([[98, 86], [106, 80], [114, 76]], 4), 4);
  let s = sk_film([[40, 60], [80, 26], [118, 52], [150, 46], [210, 60], [276, 88], [300, 130], [290, 160], [284, 250], [256, 256], [252, 190], [200, 186], [170, 196], [168, 252], [140, 256], [138, 190], [104, 150], [60, 150]], p, 0.24);
  const leg = (a, b, c, d, w, col) => sk_bone(a, b, w, p, w * 1.5, col) + sk_bone(b, c, w * 0.85, p, w * 1.3, col) + E.p('M' + r1(c[0] - w * 1.4) + ' ' + r1(c[1] + 2) + 'L' + r1(c[0] + w * 1.6) + ' ' + r1(c[1] + 2) + 'L' + r1(d[0] + w * 2) + ' ' + r1(d[1]) + 'L' + r1(d[0] - w * 1.8) + ' ' + r1(d[1]) + 'Z', col, p.line, 0.8);
  /* défense lointaine et membres éloignés */
  s += E.p(taperD(sk_spline([[70, 130], [58, 170], [44, 196], [30, 190], [24, 168]], 6), 11, 4), p.shade, p.line, 1);
  s += leg([164, 128], [170, 178], [166, 230], [168, 250], 7, p.shade) + leg([262, 128], [270, 186], [266, 234], [270, 252], 7.5, p.shade);
  /* côtes, colonne à épines hautes au garrot, queue */
  s += sk_ribs(back, 2, 16, p, { len: t => 92 - 34 * t, back: 0.05, bend: 0.2, w: 2.2 });
  s += sk_column(neck, p, { h: () => 10, spine: () => 12, lean: 0.4 }) + sk_column(back, p, { h: () => 9, spine: t => 42 * Math.pow(1 - t, 1.4) + 8, lean: 0.35, sw: 2.8 }) + sk_column(tail, p, { h: t => 6 - 3.4 * t, lean: 0.4 });
  /* omoplate, bassin */
  s += E.p('M132 74Q162 70 170 86L160 134Q146 136 138 128Z', p.relief, p.line, 1) + E.p('M246 86Q276 82 292 100L286 138Q266 142 250 128Z', p.relief, p.line, 1) + E.c(270, 118, 8, p.shade, p.line, 0.8);
  /* membres proches */
  s += leg([152, 130], [158, 180], [152, 232], [150, 252], 8, p.relief) + leg([266, 124], [256, 188], [262, 236], [258, 254], 8.4, p.relief);
  /* crâne en dôme */
  s += E.p('M44 66Q56 30 88 26Q112 30 116 58Q118 86 104 104L96 132Q80 150 62 146Q46 134 44 110Z', p.relief, p.line, 1.3);
  s += E.p('M66 136Q78 156 104 152Q112 136 102 124Q88 132 72 130Z', p.relief, p.line, 1) + E.el(80, 86, 6.5, 6, 0, p.accent, p.line, 0.8) + E.p('M56 44Q76 34 96 40M50 70Q70 62 90 70', null, p.line, 0.7, 'opacity=".6"');
  s += E.el(58, 124, 11, 8, -30, p.shade, p.line, 0.9);
  /* défense proche */
  const tusk = sk_spline([[60, 126], [48, 164], [30, 194], [12, 190], [8, 160], [18, 132]], 6);
  s += E.p(taperD(tusk, 15, 5), p.hi, p.line, 1.3);
  let gl = ''; for (let i = 6; i < tusk.length - 4; i += 5) { const t = tangentAt(tusk, i), w = lerp(6.5, 2.6, i / tusk.length); gl += 'M' + r1(tusk[i][0] - t[1] * w) + ' ' + r1(tusk[i][1] + t[0] * w) + 'L' + r1(tusk[i][0] + t[1] * w) + ' ' + r1(tusk[i][1] - t[0] * w); }
  s += E.p(gl, null, p.line, 0.6, 'opacity=".45"');
  s += E.p('M52 58Q64 36 88 32', null, p.hi, 2.2, 'opacity=".7"');
  return s;
}

Object.assign(ART, {
  eurohippus: { vb: [280, 200], fn: artEurohippus, area: { cx: 140, cy: 110, rx: 128, ry: 80 } },
  gastornis: { vb: [250, 320], fn: artGastornis, area: { cx: 128, cy: 160, rx: 112, ry: 150 } },
  megaloceros: { vb: [340, 220], fn: artMegaloceros, area: { cx: 170, cy: 100, rx: 160, ry: 90 } },
  coelodonta: { vb: [310, 186], fn: artCoelodonta, area: { cx: 156, cy: 96, rx: 144, ry: 80 } },
  mammouth: { vb: [320, 268], fn: artMammouth, area: { cx: 160, cy: 140, rx: 150, ry: 120 } }
});
