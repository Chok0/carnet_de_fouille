/* ============ fossiles : Dévonien (Miguasha, Cleveland) et Carbonifère (Commentry) ============ */

/* ---- aides locales (préfixe d2_) ---- */
function d2_fo(p, v) { return 'fill-opacity="' + (p.flat ? 1 : v) + '"'; }            // opacité de remplissage neutralisée en silhouette
function d2_op(p, v) { return 'opacity="' + (p.flat ? 1 : v) + '"'; }
function d2_n(v) { const r = Math.round(v * 10) / 10; return String(r === 0 ? 0 : r).replace(/^(-?)0\./, '$1.'); }
function d2_pair(a, b) { const A = d2_n(a), B = d2_n(b); return A + (B[0] === '-' ? '' : ' ') + B; }
function d2_nums(a) { let s = ''; a.forEach((v, i) => { const t = d2_n(v); s += (i && t[0] !== '-' ? ' ' : '') + t; }); return s; }
/* courbe lissée (même construction que smoothD) écrite en c relatifs compacts */
function d2_sm(pts, close) {
  const n = pts.length;
  if (n < 3) return polyD(pts, close);
  const g = i => (close ? pts[(i + n) % n] : pts[clamp(i, 0, n - 1)]);
  let cx = r1(pts[0][0]), cy = r1(pts[0][1]), d = 'M' + d2_pair(cx, cy) + 'c';
  const segs = close ? n : n - 1;
  for (let i = 0; i < segs; i++) {
    const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2);
    const a = [r1(p1[0] + (p2[0] - p0[0]) / 6), r1(p1[1] + (p2[1] - p0[1]) / 6)], b = [r1(p2[0] - (p3[0] - p1[0]) / 6), r1(p2[1] - (p3[1] - p1[1]) / 6)], e = [r1(p2[0]), r1(p2[1])];
    const t = d2_nums([a[0] - cx, a[1] - cy, b[0] - cx, b[1] - cy, e[0] - cx, e[1] - cy]);
    d += (i && t[0] !== '-' ? ' ' : '') + t;
    cx = e[0]; cy = e[1];
  }
  return close ? d + 'z' : d;
}
/* chemin compact : polylignes → M absolu puis m/l relatifs calculés sur les coordonnées arrondies (pas de dérive) */
function d2_rel(lines) {
  let d = '', px = 0, py = 0, last = '';
  lines.forEach(pl => pl.forEach((q, i) => {
    const x = r1(q[0]), y = r1(q[1]);
    if (!last) { d += 'M' + d2_pair(x, y); last = 'M'; }
    else {
      const c = i ? 'l' : 'm', v = d2_pair(x - px, y - py);
      d += (c === 'l' && last === 'l') ? (v[0] === '-' ? '' : ' ') + v : c + v;
      last = c;
    }
    px = x; py = y;
  }));
  return d;
}
function d2_dots(pts) { let d = '', px = 0, py = 0; pts.forEach((q, i) => { const x = r1(q[0]), y = r1(q[1]); d += (i ? 'm' + d2_pair(x - px, y - py) : 'M' + d2_pair(x, y)) + 'h0'; px = x; py = y; }); return d; }
/* rayons : n segments de la base (polyligne) vers le bord libre (polyligne), répartis à abscisse curviligne égale */
function d2_fan(B, D, n) { const A = resample(B, n), Z = resample(D, n); return A.map((a, i) => [a, Z[i]]); }
/* écailles imbriquées : colonnes de festons (bord libre tourné vers la queue), taille qui suit la hauteur du corps */
function d2_scales(xa, xb, yT, yB, size) {
  let d = '', x = xa, j = 0;
  while (x < xb) {
    const t = yT(x), h = yB(x) - t;
    if (h < 2.5) { x += 2; continue; }
    const n = Math.max(1, Math.round(h / size(x))), s = h / n, odd = j % 2, cnt = odd ? n - 1 : n;
    if (cnt > 0) {
      d += 'M' + d2_pair(x, t + (odd ? s / 2 : 0));
      const q = 'q' + d2_pair(s, s / 2) + ' 0 ' + d2_n(s);
      for (let k = 0; k < cnt; k++) d += q;
    }
    x += s * 0.6; j++;
  }
  return d;
}

/* ---------------- eusthenopteron — Eusthenopteron foordi (Miguasha, Dévonien sup.) — profil gauche ----------------
   Fiche anatomique :
   ① corps fuselé allongé ; tête ≈ 22 % de la longueur (museau → bord de l'opercule), hauteur max ≈ 18 % vers le premier tiers ;
   ② queue TRIFIDE (diphycerque) : lobes épicordal et hypocordal égaux, symétriques de part et d'autre de l'axe,
      + petit lobe central (lobe supplémentaire) qui prolonge l'axe écailleux ;
   ③ nageoires impaires très en arrière : 1re dorsale au-dessus des pelviennes (~55 %), 2e dorsale au-dessus de l'anale (~68 %) ;
      paires (pectorale, pelvienne) à lobe charnu écailleux frangé de rayons ; dans le lobe pectoral, en relief :
      1 humérus, puis radius et cubitus côte à côte, puis petits radiaux — le « bras » des tétrapodes ;
   ④ écailles rondes imbriquées en rangées obliques, plus petites vers la queue ;
   ⑤ tête en plaques : toit crânien (bandeau à sutures transverses), orbite cerclée haut et en avant, narine,
      joue (lacrymal, jugal, postorbitaire, squamosal, quadratojugal, préoperculaire), opercule + sous-opercule
      (stries de croissance), maxillaire et mâchoire inférieure dentés, plaques sous-mandibulaires ;
   ⑥ ligne latérale : rangée de pores de l'opercule jusqu'à l'axe de la queue.
   Construction : profils dorsal/ventral tabulés en t (0 = museau, 0,958 = bout de l'axe écailleux), axe y = 70 ;
   nageoires = base (sur le profil) + bord libre, rayons interpolés ; écailles en colonnes de festons. */
function artEusthenopteron(p) {
  const X0 = 12, LEN = 296, YC = 70, X = t => X0 + LEN * t;
  const TOP = [[0, 1.5], [.008, -4], [.025, -9.5], [.05, -14], [.09, -18.5], [.14, -22], [.2, -24.8], [.28, -26.6], [.36, -27], [.44, -26], [.52, -23.6], [.6, -20], [.67, -16], [.73, -12.3], [.79, -9.4], [.85, -6.8], [.9, -4.4], [.935, -2.4], [.958, 0]].map(q => [X(q[0]), YC + q[1]]);
  const BOT = [[0, 1.5], [.008, 6], [.025, 10.5], [.06, 15.5], [.11, 19.5], [.17, 22.8], [.24, 25.5], [.32, 27], [.4, 27], [.48, 25.4], [.56, 22.4], [.64, 18.3], [.71, 14], [.77, 10.6], [.83, 7.8], [.89, 5], [.935, 2.6], [.958, 0]].map(q => [X(q[0]), YC + q[1]]);
  const yT = x => interpY(TOP, x), yB = x => interpY(BOT, x);
  const edge = (f, a, b, n) => { const o = []; for (let i = 0; i <= n; i++) { const x = lerp(a, b, i / n); o.push([x, f(x)]); } return o; };
  const mir = pts => pts.map(q => [q[0], 2 * YC - q[1]]);
  const fo = d2_fo(p, p.filmOp), ray = d2_op(p, 0.8);
  let s = '';
  /* ②③ nageoires impaires, derrière le corps : film + rayons (base cachée sous le corps) */
  const fin = (B, LE, D, n) => E.p(d2_sm([B[0]].concat(LE, D, [B[B.length - 1]]), false) + polyD(B.slice().reverse(), false).replace('M', 'L') + 'Z', p.film, p.line, 0.6, fo) +
    E.p(d2_rel(d2_fan(B, D, n)), null, p.line, 0.55, ray);
  const LEu = [[244, 50.3], [259, 42.3]], Du = [[272, 35.6], [275.5, 35.1], [278.6, 38.4], [281.3, 47.5], [285.6, 57], [289.3, 63.2]];
  s += fin(edge(yT, X(.73), X(.935), 12), LEu, Du, 17) + fin(edge(yB, X(.73), X(.935), 12), mir(LEu), mir(Du), 17);
  const Dc = [[290.6, 63.5], [298, 64.3], [304.5, 67.3], [308.3, 70], [304.5, 72.7], [298, 75.7], [290.6, 76.5]];
  s += E.p(d2_sm(Dc.concat([[287, 70]]), true), p.film, p.line, 0.6, fo) + E.p(d2_rel(d2_fan([[289, 67.7], [293, 68.9], [295.8, 70], [293, 71.1], [289, 72.3]], Dc, 8)), null, p.line, 0.55, ray);
  s += fin(edge(yT, 167.4, 182.2, 5), [[171, 37]], [[176, 29], [179.5, 28.2], [183, 31], [188, 38.5], [192, 46.2]], 10);
  s += fin(edge(yT, 207.4, 220.7, 5), [[210.8, 45]], [[215.5, 37.5], [219, 37], [222.5, 40], [227.5, 47], [231, 54.2]], 9);
  s += fin(edge(yB, 205.9, 219.2, 5), [[209.3, 96]], [[214, 104], [217.5, 104.5], [221, 101.5], [226, 94.5], [229.5, 86.5]], 9);
  /* ① corps */
  const body = TOP.concat(BOT.slice(1, -1).reverse());
  s += E.p(d2_sm(body, true), p.body, p.line, 1.1);
  const band = (f0, f1, a, b) => d2_sm(edge(f0, a, b, 9).concat(edge(f1, b, a, 9)), true);
  s += E.p(band(x => yB(x) - 0.6, x => yB(x) - 0.3 * (yB(x) - yT(x)), 80, 292), p.shade, null, 0, d2_fo(p, 0.75));
  s += E.p(band(x => yT(x) + 0.6, x => yT(x) + 0.22 * (yB(x) - yT(x)), 80, 292), p.relief, null, 0, d2_fo(p, 0.4));
  /* ④ écailles */
  s += E.p(d2_scales(81, 293, x => yT(x) + 0.8, x => yB(x) - 0.8, x => lerp(7.4, 3.8, clamp((x - 81) / 212, 0, 1))), null, p.relief, 0.6, d2_op(p, 0.7));
  /* ⑥ ligne latérale */
  const ll = [];
  for (let x = 85; x < 291; x += 3.6) ll.push([x, (yT(x) + yB(x)) / 2 - 0.17 * (yB(x) - yT(x))]);
  s += E.p(d2_dots(ll), null, p.hi, 1.3, d2_op(p, 0.75));
  /* ③ nageoires paires : frange de rayons, lobe charnu écailleux */
  const lobeFin = (P0, ang, lobe, B, D, n, fill) => {
    const a = ang * D2R, dx = Math.cos(a), dy = Math.sin(a), G = q => [P0[0] + q[0] * dx - q[1] * dy, P0[1] + q[0] * dy + q[1] * dx];
    const Bg = B.map(G), Dg = D.map(G);
    let o = E.p(d2_sm([Bg[0]].concat(Dg, [Bg[Bg.length - 1]]), false) + polyD(Bg.slice().reverse(), false).replace('M', 'L') + 'Z', p.film, p.line, 0.6, fo);
    o += E.p(d2_rel(d2_fan(Bg, Dg, n)), null, p.line, 0.55, ray);
    o += E.p(d2_sm(lobe.map(G), true), fill, p.line, 0.9);
    let sc = '';
    for (let u = 2; u < lobe[4][0] - 3; u += 2.8) [-1, 1].forEach(sd => {
      const hw = interpY(lobe.slice(0, 5), u) * -1, v = sd * (Math.abs(hw) - 1.9);
      sc += 'M' + PS(G([u, v - 1.5])) + 'Q' + PS(G([u + 2.6, v])) + ' ' + PS(G([u, v + 1.5]));
    });
    return { s: o + E.p(sc, null, p.relief, 0.5, d2_op(p, 0.8)), G };
  };
  const pelv = lobeFin([152, 94.2], 24, [[-1, -3.8], [5, -4.8], [11, -4.6], [16.5, -3.2], [20.5, 0], [16.5, 3.2], [11, 4.6], [5, 4.8], [-1, 3.8]],
    [[5, -4.9], [11, -4.7], [16.5, -3.3], [20.5, 0], [16.5, 3.3], [11, 4.7], [5, 4.9]],
    [[6, -7], [15, -8.6], [25, -7.2], [32, -2.6], [33.5, 1.2], [29, 6.5], [20, 9.4], [11, 9], [5.5, 7]], 15, p.shade);
  s += pelv.s;
  const pect = lobeFin([79, 86.5], 30, [[-1, -4.6], [6, -6.1], [14, -6.1], [22, -4.9], [28.5, -2.7], [31.8, 0], [28.5, 2.7], [22, 4.9], [14, 6.1], [6, 6.1], [-1, 4.6]],
    [[8, -6.2], [16, -6], [23, -4.7], [28.5, -2.7], [31.8, 0], [28.5, 2.7], [23, 4.7], [16, 6], [8, 6.2]],
    [[9, -8.6], [20, -11.6], [32, -11.2], [42, -8], [49, -2.5], [50.5, 1.5], [46, 7], [36, 11.5], [24, 12.5], [14, 11], [8.5, 8.6]], 21, p.shade);
  s += pect.s;
  const G = pect.G;
  const bone = (u0, v0, u1, v1, w, k) => E.p(d2_sm(taperPts(linePts(G([u0, v0]), G([u1, v1]), 4), w, w, t => 1 - k * Math.sin(Math.PI * t)), true), p.relief, p.line, 0.6);
  s += bone(0.6, 0, 12.6, 0, 5.6, 0.42) + bone(13.8, -2.3, 22.6, -2.7, 3, 0.3) + bone(13.8, 2.2, 21.4, 3.1, 3.2, 0.3);
  s += E.el(...G([24.9, -3]), 1.3, 1, 30, p.relief, p.line, 0.5) + E.el(...G([24, 3.5]), 1.3, 1, 30, p.relief, p.line, 0.5) + E.el(...G([27.2, 0.3]), 1.1, 0.9, 30, p.relief, p.line, 0.5);
  s += E.p('M' + PS(G([3, -1.3])) + 'L' + PS(G([10.5, -0.9])) + 'M' + PS(G([15.5, -3])) + 'L' + PS(G([20.5, -3.2])), null, p.hi, 0.8, d2_op(p, 0.7));
  /* ⑤ tête */
  const OPM = [[76.5, 45.1], [80.2, 51], [81.8, 60], [81.3, 70], [79.5, 79], [77, 87.5], [74.5, 94.3]];
  s += E.p(d2_sm(edge(yT, 12, 76.5, 9).concat(OPM.slice(1), edge(yB, 74.5, 12, 9).slice(1, -1)), true), p.relief, p.line, 1.1);
  const R = [[15, 66.5], [22, 62.8], [30, 58.8], [40, 56], [52, 54], [64, 52.5], [77, 51.5]], yR = x => interpY(R, x);
  const J = [[14.3, 76.4], [25, 81.6], [40, 85.4], [52, 87.3], [60, 87.4], [64.5, 85.5]], yJ = x => interpY(J, x);
  let sut = d2_sm(R) + d2_sm([[15.5, 70.4], [30, 71.6], [45, 72.6], [55, 72.2], [60.5, 73.4], [62.5, 76.5], [64.5, 80], [64.5, 85.5]]) + d2_sm(J) +
    d2_sm([[16.5, 75.4], [30, 78.8], [45, 81.4], [58, 83.1]]);
  [25, 40, 54, 67].forEach(x => { sut += 'M' + PS([x + 0.8, yT(x + 0.8) + 0.3]) + 'L' + PS([x - 0.8, yR(x - 0.8)]); });
  sut += 'M28.5 65.4L26.5 71.3M38.4 64.2L44.5 66.2L46.5 72.4M47 54.9L44.5 66.2M52.5 72.3L61 67.8M61 52.9Q61 62 62.5 76.5M17.5 70.6L18.5 72.9';
  [36, 43, 50, 57].forEach(x => { sut += 'M' + PS([x, yJ(x)]) + 'L' + PS([x + 2.4, yB(x + 2.4) - 0.3]); });
  [66, 71].forEach(x => { sut += 'M' + PS([x, 88]) + 'L' + PS([x + 2, yB(x + 2) - 0.3]); });
  s += E.p(sut, null, p.line, 0.7);
  /* bouche entrouverte, dents */
  const GU = [[12.8, 72.2], [25, 74.4], [40, 76.8], [52, 78.6], [61.5, 79.8]], GL = [[13.3, 73.2], [25, 76.6], [40, 79.2], [52, 80.4], [61.5, 80.4]];
  s += E.p(d2_sm(GU) + d2_sm(GL.slice().reverse()).replace('M', 'L') + 'Z', p.accent, p.line, 0.6);
  const teeth = (row, sd) => {
    const L = [];
    for (let x = 15; x < 58; x += 2.5) {
      const y = interpY(row, x), h = (x < 21 ? 2.5 : 1.7) * sd;
      L.push([[x - 0.7, y - sd * 0.3], [x + 0.2, y + h], [x + 0.8, y - sd * 0.3]]);
    }
    return L;
  };
  s += E.p(d2_rel(teeth(GU, 1).concat(teeth(GL, -1))), p.hi, null, 0, d2_op(p, 0.9));
  /* œil cerclé de plaques, narine */
  let orb = '';
  for (let k = 0; k < 7; k++) { const a = k / 7 * TAU + 0.3; orb += 'M' + PS([33 + Math.cos(a) * 4.3, 61 + Math.sin(a) * 4.3]) + 'L' + PS([33 + Math.cos(a) * 6.4, 61 + Math.sin(a) * 6.4]); }
  s += E.c(33, 61, 6.4, p.body, p.line, 0.8) + E.p(orb, null, p.line, 0.6) + E.c(33, 61, 4.3, p.accent, p.line, 0.7) + E.c(31.6, 59.6, 1.1, p.hi, null, 0, d2_op(p, 0.7));
  s += E.el(21.5, 65.6, 1.4, 0.9, -20, p.accent);
  /* opercule et sous-opercule, stries de croissance */
  const arcs = (cx, cy, rs, a0, a1) => rs.map(r => 'M' + PS([cx + Math.cos(a0) * r, cy + Math.sin(a0) * r]) + 'A' + r + ' ' + r + ' 0 0 1 ' + PS([cx + Math.cos(a1) * r, cy + Math.sin(a1) * r])).join('');
  s += E.p(d2_sm([[66.3, 52.4], [73, 52], [79, 51.8], [81.2, 55], [82, 62], [81.4, 69.5], [80.1, 74.6], [73, 75.6], [66.6, 74.4]], true), p.relief, p.line, 0.9);
  s += E.p(d2_sm([[66.6, 74.4], [73, 75.6], [80.1, 74.6], [79.4, 80], [77.3, 86.8], [71, 88.6], [65.6, 86.4], [64.8, 80]], true), p.relief, p.line, 0.9);
  s += E.p(arcs(67.8, 53.8, [4.5, 9, 13], 0.14, 1.43) + arcs(66.4, 75.6, [4, 7.5, 11], 0.17, 1.4), null, p.line, 0.5, d2_op(p, 0.7));
  /* reflet unique */
  s += E.p(d2_sm([[17.5, 64.2], [28, 57.6], [45, 52.2], [64, 48.8], [80, 47.4], [110, 45.2]]), null, p.hi, 1.7, d2_op(p, 0.65));
  return s;
}

/* ============ registre ============ */
Object.assign(ART, {
  eusthenopteron: { vb: [320, 140], fn: artEusthenopteron, area: { cx: 160, cy: 72, rx: 146, ry: 36 } }
});
