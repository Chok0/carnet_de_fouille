/* ============ fossiles : Paléogène ============ */

/* ---------- aides (préfixe pg_) ---------- */
function pg_fo(p, o) { return 'fill-opacity="' + (p.flat ? 1 : o) + '"'; }
function pg_op(p, o) { return 'opacity="' + (p.flat ? 1 : o) + '"'; }
function pg_ad(a, v, k) { return [a[0] + v[0] * k, a[1] + v[1] * k]; }
function pg_dir(a) { return [Math.cos(a), Math.sin(a)]; }
function pg_mid(a, b) { return [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]; }
/* nombre au dixième, sans zéro inutile */
function pg_n(v) { const r = Math.round(v * 10) / 10; return String(r === 0 ? 0 : r).replace(/^(-?)0\./, '$1.'); }
/* chemin compact : commandes relatives arrondies au dixième, calculées depuis les absolus arrondis (pas de dérive) */
function pg_B() {
  let d = '', x = 0, y = 0, sx = 0, sy = 0, last = '';
  const R = v => Math.round(v * 10) / 10;
  const put = (c, a) => {
    let t = '';
    a.forEach((v, i) => { const n = pg_n(v); t += (i && n[0] !== '-' ? ' ' : '') + n; });
    d += c === last ? (t[0] === '-' ? '' : ' ') + t : c + t;
    last = c;
  };
  const B = {
    M(q) {
      const X = R(q[0]), Y = R(q[1]);
      if (!d) { d = 'M' + pg_n(X) + (Y < 0 ? '' : ' ') + pg_n(Y); last = 'L'; } else { put('m', [X - x, Y - y]); last = 'l'; }
      x = sx = X; y = sy = Y; return B;
    },
    L(q) { const X = R(q[0]), Y = R(q[1]); put('l', [X - x, Y - y]); x = X; y = Y; return B; },
    Q(c, q) { const X = R(q[0]), Y = R(q[1]); put('q', [R(c[0]) - x, R(c[1]) - y, X - x, Y - y]); x = X; y = Y; return B; },
    C(a, b, q) { const X = R(q[0]), Y = R(q[1]); put('c', [R(a[0]) - x, R(a[1]) - y, R(b[0]) - x, R(b[1]) - y, X - x, Y - y]); x = X; y = Y; return B; },
    Z() { d += 'z'; last = 'z'; x = sx; y = sy; return B; },
    pl(pts, close) { B.M(pts[0]); for (let i = 1; i < pts.length; i++) B.L(pts[i]); return close ? B.Z() : B; },
    sm(pts, close) {
      const n = pts.length;
      if (n < 3) return B.pl(pts, close);
      const g = i => (close ? pts[(i + n) % n] : pts[clamp(i, 0, n - 1)]);
      B.M(pts[0]);
      for (let i = 0; i < (close ? n : n - 1); i++) {
        const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2);
        B.C([p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6], [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6], p2);
      }
      return close ? B.Z() : B;
    },
    d: () => d
  };
  return B;
}
/* échantillonne une courbe de Catmull-Rom passant par les points (k points par segment) */
function pg_cr(pts, k) {
  const o = [], n = pts.length, g = i => pts[clamp(i, 0, n - 1)];
  for (let i = 0; i < n - 1; i++) {
    const a = g(i - 1), b = g(i), c = g(i + 1), d = g(i + 2);
    for (let j = 0; j < k; j++) {
      const t = j / k, t2 = t * t, t3 = t2 * t;
      o.push([0, 1].map(m => 0.5 * (2 * b[m] + (c[m] - a[m]) * t + (2 * a[m] - 5 * b[m] + 4 * c[m] - d[m]) * t2 + (3 * b[m] - a[m] - 3 * c[m] + d[m]) * t3)));
    }
  }
  o.push(pts[n - 1]);
  return o;
}
function pg_sm(pts, close) { return pg_B().sm(pts, close).d(); }
function pg_tp(pts, w0, w1, prof) { return pg_sm(taperPts(pts, w0, w1, prof), true); }

/* nummulites — Nummulites gizehensis (Gizeh, ~45 Ma). Fiche anatomique :
   ① test lenticulaire « pièce de monnaie » : disque vu de face, lentille biconvexe vue de profil ;
   ② coupe équatoriale (spécimen fendu) : spirale serrée de 7 tours, lame spirale sombre ;
   ③ cloisons (septa) droites à la base puis arquées vers l'arrière, de plus en plus nombreuses vers l'extérieur ;
   ④ loges embryonnaires (protoconque + deutéroconque) au centre de la spirale ;
   ⑤ face externe : filets cloisonnaires radiaux sinueux, bouton central (pilier), cordon marginal ;
   ⑥ gisement en amas : spécimens serrés qui se chevauchent. */
function artNummulites(p) {
  let s = '';
  /* spécimen entier vu de face : disque incliné (aplatissement k, rotation rotD) */
  const coin = (c, R, k, rotD, seed) => {
    const a = rotD * D2R, ca = Math.cos(a), sa = Math.sin(a);
    const pol = (r, th) => { const x = r * Math.cos(th), y = r * Math.sin(th) * k; return [c[0] + x * ca - y * sa, c[1] + x * sa + y * ca]; };
    const ring = (r, dx, dy) => { const q = []; for (let i = 0; i < 16; i++) { const t = pol(r, i / 16 * TAU); q.push([t[0] + dx, t[1] + dy]); } return pg_sm(q, true); };
    const rnd = mulberry32(seed);
    let o = E.p(ring(R, 1.8, 3.2), p.shade, p.line, 1.1) + E.p(ring(R, 0, 0), p.body, p.line, 1.2);
    o += E.el(c[0] - R * 0.1, c[1] - R * 0.13, R * 0.72, R * k * 0.72, rotD, p.relief, null, 0, pg_op(p, 0.5));
    const B = pg_B(), N = Math.round(R);
    for (let i = 0; i < N; i++) {
      const th = (i + rnd() * 0.5) / N * TAU, r0 = R * (i % 2 ? 0.5 : 0.23), r3 = R * 0.92, tw = 0.34, wv = 0.15;
      B.M(pol(r0, th)).C(pol(lerp(r0, r3, 0.35), th + wv), pol(lerp(r0, r3, 0.7), th + tw - wv), pol(r3, th + tw));
    }
    o += E.p(B.d(), null, p.line, 0.55, pg_op(p, 0.8));
    o += E.el(c[0], c[1], R * 0.21, R * k * 0.21, rotD, p.relief, p.line, 0.9);
    o += E.c(c[0] - R * 0.05, c[1] - R * 0.06, R * 0.07, p.hi, null, 0, pg_op(p, 0.7));
    const H = pg_B();
    for (let t = 0; t <= 6; t++) { const q = pol(R * 0.84, lerp(3.35, 4.35, t / 6) - a); t ? H.L(q) : H.M(q); }
    return o + E.p(H.d(), null, p.hi, 1.5, pg_op(p, 0.65));
  };
  /* spécimen vu de profil : lentille biconvexe symétrique, bord aigu, bouton (pilier) au centre de chaque face */
  const lens = (c, L, T, rotD) => {
    const a = rotD * D2R, u = [Math.cos(a), Math.sin(a)], v = [-u[1], u[0]];
    const P = (x, y) => [c[0] + u[0] * x + v[0] * y, c[1] + u[1] * x + v[1] * y];
    const th = x => T * Math.pow(Math.max(0, 1 - (2 * x / L) ** 2), 0.6) + 2.4 * Math.exp(-((x / (L * 0.08)) ** 2));
    const X = i => lerp(-L / 2, L / 2, i / 12), side = (sg, f) => { const q = []; for (let i = 0; i <= 12; i++) q.push(P(X(i), sg * th(X(i)) * f)); return q; };
    const top = side(-1, 1), bot = side(1, 1);
    let o = E.p(pg_sm(top.concat(bot.slice(1, 12).reverse()), true), p.body, p.line, 1.2);
    o += E.p(pg_sm(top.concat(side(-1, 0.45).slice(1, 12).reverse()), true), p.relief, null, 0, pg_op(p, 0.7));
    o += E.p(pg_sm(bot.concat(side(1, 0.55).slice(1, 12).reverse()), true), p.shade, null, 0, pg_op(p, 0.7));
    o += E.p(pg_sm(side(1, 0.62).slice(2, 11)), null, p.line, 0.55, pg_op(p, 0.55));
    const b0 = P(0, -th(0) + 1.6);
    o += E.el(b0[0], b0[1], 3.2, 1.8, rotD, p.hi, null, 0, pg_op(p, 0.6));
    return o + E.p(pg_sm(side(-1, 0.72).slice(3, 6)), null, p.hi, 1.5, pg_op(p, 0.65));
  };
  s += coin([42, 163], 25, 0.84, 12, 7);
  s += coin([186, 58], 40, 0.9, -18, 11);
  s += coin([190, 145], 36, 0.74, 24, 13);
  s += lens([43, 49], 62, 13, -45);
  /* spécimen fendu : coupe équatoriale */
  const C = [98, 104], R = 62, NT = 6, g = 1.13, r0 = 4.4, a0 = -2.2;
  const h0 = (R - 1.2 - r0) * (g - 1) / (Math.pow(g, NT) - 1);
  const rr = th => r0 + h0 * (Math.pow(g, th / TAU) - 1) / (g - 1);
  const pol = (r, th) => [C[0] + r * Math.cos(th + a0), C[1] + r * Math.sin(th + a0)];
  s += E.c(C[0] + 2.6, C[1] + 4.4, R, p.shade, p.line, 1.2);
  s += E.c(C[0], C[1], R, p.relief, p.line, 1.5) + E.c(C[0], C[1], R - 1, p.hi, null, 0, pg_op(p, 0.22));
  /* cloisons : droites à la base, arquées vers l'arrière */
  const S = pg_B();
  for (let th = TAU * 0.8; th < (NT + 1) * TAU;) {
    const ri = rr(th - TAU), ro = th <= NT * TAU ? rr(th) : R, h = ro - ri;
    if (th > TAU && h > 1.8) S.M(pol(ri + 0.5, th)).Q(pol(ri + h * 0.8, th + 0.02), pol(ro - 0.5, th - 0.42 * h / ro));
    const rm = (ri + Math.max(ro, ri + 2)) / 2;
    th += (3.9 + 0.06 * rm) / rm;
  }
  s += E.p(S.d(), null, p.line, 0.55, pg_op(p, 0.75));
  /* lame spirale */
  const sp = [];
  for (let i = 0; i <= NT * 14; i++) { const th = i / 14 * TAU; sp.push(pol(rr(th), th)); }
  s += E.p(pg_sm(sp), null, p.line, 1.35);
  s += E.c(C[0] - 1.2, C[1] + 0.8, 3.1, p.accent, p.line, 0.6) + E.c(C[0] + 2.5, C[1] - 1.6, 2.2, p.accent, p.line, 0.6);
  const H = pg_B();
  for (let t = 0; t <= 8; t++) { const q = [C[0] + (R - 4) * Math.cos(lerp(3.3, 4.5, t / 8)), C[1] + (R - 4) * Math.sin(lerp(3.3, 4.5, t / 8))]; t ? H.L(q) : H.M(q); }
  s += E.p(H.d(), null, p.hi, 2, pg_op(p, 0.7));
  return s;
}

/* knightia — Knightia eocaena (Green River, ~50 Ma). Fiche anatomique :
   ① corps fuselé mais haut (hauteur ≈ 30 % de la longueur), ventre très arrondi, pédoncule étroit ;
   ② tête ≈ 25 % de la longueur : grand œil, bouche relevée (mâchoire inférieure oblique), opercule strié en éventail, cleithrum ;
   ③ ~40 vertèbres, longues côtes courbées vers le bas, épines neurales et hémales, fines arêtes intermusculaires ;
   ④ dorsale triangulaire au milieu du dos, pelvienne sous la dorsale, petite anale près de la queue, pectorale basse ;
   ⑤ caudale très fourchue ;
   ⑥ scutelles ventrales : rangée de chevrons de la gorge à l'anus. */
function artKnightia(p) {
  const top = [[9, 60], [15, 56], [26, 51], [40, 45], [56, 39], [76, 35], [100, 33], [122, 34], [146, 39], [172, 48], [198, 58], [222, 65], [240, 68]];
  const bot = [[9, 62], [15, 70], [24, 81], [38, 93], [58, 104], [80, 110], [104, 112], [128, 109], [152, 102], [176, 94], [200, 87], [222, 84], [240, 83]];
  const yT = x => interpY(top, x), yB = x => interpY(bot, x), fop = pg_fo(p, 0.55);
  const fin = (a, b, dir, n, L0, L1, spread) => {
    const R = pg_B(), tips = [];
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1), q = lerpPt(a, b, t), an = (dir + spread * (t - 0.5)) * D2R, L = lerp(L0, L1, t), e = [q[0] + Math.cos(an) * L, q[1] + Math.sin(an) * L];
      R.M(q).L(e); tips.push(e);
    }
    return E.p(pg_B().pl([a].concat(tips, [b]), true).d(), p.film, null, 0, fop) + E.p(R.d(), null, p.line, 0.5);
  };
  let s = fin([116, yT(116)], [140, yT(140)], -58, 11, 25, 6, 36);
  s += fin([121, yB(121) - 2], [130, yB(130) - 2], 60, 7, 17, 11, 20);
  s += fin([194, yB(194) - 1], [214, yB(214) - 1], 62, 8, 11, 5, 16);
  /* caudale très fourchue */
  const CR = pg_B(), ct = [];
  for (let i = 0; i <= 22; i++) {
    const t = i / 22, b = [236 + 3 * Math.sin(t * Math.PI), lerp(66, 85, t)], an = lerp(-37, 37, t) * D2R, L = 64 * (1 - 0.66 * Math.pow(Math.sin(t * Math.PI), 2.2));
    const e = [b[0] + Math.cos(an) * L, b[1] + Math.sin(an) * L];
    CR.M(b).L(e); ct.push(e);
  }
  s += E.p(pg_B().pl([[234, 67]].concat(ct, [[234, 84]]), true).d(), p.film, null, 0, fop) + E.p(CR.d(), null, p.line, 0.55);
  s += E.p(pg_B().M([236, 67]).L(ct[0]).M([236, 84]).L(ct[22]).d(), null, p.line, 1);
  /* corps */
  s += E.p(pg_sm(top.concat(bot.slice().reverse()), true), p.film, p.line, 1.1, pg_fo(p, p.filmOp));
  /* squelette axial */
  const N = 40, x0 = 72, x1 = 237, sp = (x1 - x0) / N;
  const ax = x => lerp(yT(x), yB(x), lerp(0.42, 0.5, (x - x0) / (x1 - x0)));
  const V = pg_B(), SP = pg_B(), IM = pg_B();
  for (let i = 0; i < N; i++) {
    const x = x0 + (i + 0.5) * sp, y = ax(x), h = lerp(7.4, 4, i / N), w = sp * 0.42, yt = yT(x), yb = yB(x), cau = x > 186;
    V.M([x - w, y - h / 2]).L([x + w, y - h / 2]).Q([x + w * 0.45, y], [x + w, y + h / 2]).L([x - w, y + h / 2]).Q([x - w * 0.45, y], [x - w, y - h / 2]).Z();
    const up = y - h / 2 - yt - 3;
    SP.M([x, y - h / 2]).L([x + up * (cau ? 0.7 : 0.38), yt + 3]);
    if (!cau) SP.M([x, y + h / 2]).Q([x + 3, lerp(y, yb, 0.62)], [x + 11, yb - 3.5]);
    else SP.M([x, y + h / 2]).L([x + (yb - y) * 0.7, yb - 3]);
    if (i > 1) IM.M([x + 1.5, y - h / 2 - 2]).L([x + 10, y - (y - yt) * 0.62]);
    if (i > 20) IM.M([x + 1.5, y + h / 2 + 2]).L([x + 10, y + (yb - y) * 0.6]);
  }
  s += E.p(IM.d(), null, p.line, 0.4, pg_op(p, 0.45)) + E.p(SP.d(), null, p.line, 0.6, pg_op(p, 0.7));
  s += E.p(V.d(), p.relief, p.line, 0.5);
  /* tête */
  const hd = [];
  for (let x = 10; x <= 66; x += 8) hd.push([x, yT(x)]);
  hd.push([71, 46], [74, 60], [72, 78], [65, 93], [54, 102]);
  for (let x = 50; x >= 10; x -= 8) hd.push([x, yB(x)]);
  s += E.p(pg_sm(hd, true), p.relief, p.line, 1, pg_fo(p, 0.85));
  const op = quadPts([70, 46], [77, 70], [58, 100], 9), F = pg_B();
  op.forEach((q, i) => { if (i && i < 9) F.M([52, 50]).L(lerpPt([52, 50], q, 0.9)); });
  s += E.p(F.d(), null, p.line, 0.5, pg_op(p, 0.8));
  s += E.p(pg_tp(quadPts([45, 46], [52, 84], [34, 93], 10), 4.2, 3), p.relief, p.line, 0.8);
  s += E.p(pg_B().M([50, 90]).Q([60, 92], [66, 92]).M([36, 95]).Q([48, 101], [56, 102]).d(), null, p.line, 0.6);
  s += E.p(pg_tp(quadPts([78, 40], [83, 72], [72, 101], 10), 4, 3), p.body, p.line, 0.8);
  /* mâchoires : bouche relevée */
  s += E.p(pg_tp([[10, 62.5], [20, 72], [32, 83]], 3.2, 5.2), p.body, p.line, 0.8);
  s += E.p(pg_tp([[12, 59.5], [22, 64], [33, 70]], 2.4, 3.4), p.relief, p.line, 0.7);
  s += E.p('M9.5 61.2L16 62.6', null, p.line, 0.8);
  s += fin([74, 99], [78, 103], 38, 8, 25, 16, 24);
  /* scutelles ventrales */
  const SC = pg_B();
  for (let x = 44; x <= 190; x += 5.6) {
    const q = [x, yB(x)], d = yB(x + 1) - yB(x - 1), l = Math.hypot(2, d), t = [2 / l, d / l], n = [t[1], -t[0]];
    SC.M(pg_ad(pg_ad(q, n, 5.6), t, -1.6)).L(pg_ad(pg_ad(q, n, -1.4), t, 1.8)).L(pg_ad(pg_ad(q, n, 4.4), t, 3.6));
  }
  s += E.p(SC.d(), null, p.line, 1.7) + E.p(SC.d(), null, p.relief, 0.7);
  /* œil */
  s += E.c(32, 58, 8.6, p.shade, p.line, 1) + E.c(32, 58, 4.8, p.accent) + E.c(29.6, 55.6, 1.8, p.hi, null, 0, pg_op(p, 0.75));
  s += E.p(pg_sm([[22, 52], [44, 42], [76, 38], [104, 37]]), null, p.hi, 1.6, pg_op(p, 0.65));
  return s;
}

/* heliobatis — Heliobatis radians (Green River, ~50 Ma), vue dorsale. Fiche anatomique :
   ① disque presque rond : nageoires pectorales soudées à la tête, bord postérieur rentrant vers la queue ;
   ② rayons du disque (radiaux cartilagineux) : 72 par côté, des cartilages basaux autour de l'axe jusqu'au bord, segmentés — effet « soleil » ;
   ③ axe : crâne à rostre court, petits yeux et spiracles à l'avant, arcs branchiaux, ceinture pectorale (barre transversale),
      colonne vertébrale, ceinture pelvienne ;
   ④ deux petites nageoires pelviennes arrondies qui dépassent à l'arrière du disque ;
   ⑤ longue queue fine (≈ longueur du disque) armée d'un aiguillon dentelé au premier tiers. */
function artHeliobatis(p) {
  const cx = 120, N = 72, mir = q => [2 * cx - q[0], q[1]];
  const mg = [[120, 12], [96, 15], [72, 24], [52, 40], [40, 60], [35, 84], [37, 108], [45, 130], [60, 148], [80, 160], [101, 166]];
  const rt = [[117, 22], [108, 30], [101, 46], [97, 68], [95, 96], [97, 122], [102, 142], [108, 156]];
  const M = resample(pg_cr(mg, 8), N), Rt = resample(pg_cr(rt, 8), N);
  /* queue (derrière le disque) */
  const tl = cubicPts([cx, 150], [cx, 200], [122, 248], [128, 292], 30);
  let s = E.p(pg_tp(tl, 12, 1.4), p.body, p.line, 0.9);
  s += E.p(pg_tp(tl.slice(0, 22), 4.4, 1.6), p.relief, p.line, 0.5);
  const TK = pg_B();
  for (let i = 1; i < 21; i++) { const t = tangentAt(tl, i), w = lerp(2.2, 1, i / 21); TK.M([tl[i][0] - t[1] * w, tl[i][1] + t[0] * w]).L([tl[i][0] + t[1] * w, tl[i][1] - t[0] * w]); }
  s += E.p(TK.d(), null, p.line, 0.5);
  /* nageoires pelviennes */
  const pel = col => {
    const R = pg_B();
    [[97, 158], [93, 166], [95, 174], [101, 179], [108, 179]].forEach(q => R.M([109, 154]).L(lerpPt([109, 154], q, 0.92)));
    return E.p(pg_sm([[107, 150], [97, 155], [92, 166], [95, 177], [104, 182], [112, 177], [114, 162]], true), col, p.line, 0.9) + E.p(R.d(), null, p.line, 0.5, pg_op(p, 0.8));
  };
  s += pel(p.body) + mirrorG(pel(p.body2), cx);
  /* disque */
  s += E.p(pg_sm(mg.concat([[cx, 170]], mg.slice(1).reverse().map(mir)), true), p.film, p.line, 1.1, pg_fo(p, p.filmOp));
  const RY = pg_B();
  for (let k = 0; k < N; k++) RY.M(Rt[k]).L(lerpPt(Rt[k], M[k], 0.985));
  const rays = E.p(RY.d(), null, p.line, 0.6, pg_op(p, 0.8) + ' stroke-dasharray="3.4 .9"');
  s += rays + mirrorG(rays, cx);
  /* tronc (entre les cartilages basaux) */
  const trunk = col => E.p(pg_B().sm(rt).L([cx, 158]).L([cx, 20]).Z().d(), col, null);
  const basal = E.p(pg_tp(pg_cr(rt, 4), 4.6, 3.2), p.relief, p.line, 0.6);
  s += trunk(p.body) + mirrorG(trunk(p.body2), cx) + basal + mirrorG(basal, cx);
  /* colonne, ceintures */
  s += E.p(pg_tp(linePts([cx, 58], [cx, 154], 8), 8, 5), p.relief, p.line, 0.7);
  const VT = pg_B();
  for (let y = 64; y < 152; y += 3.2) VT.M([cx - 3.4, y]).L([cx + 3.4, y]);
  s += E.p(VT.d(), null, p.line, 0.5);
  s += E.p(pg_tp(pg_cr([[94, 83], [106, 78], [120, 77], [134, 78], [146, 83]], 4), 5.4, 5.4), p.relief, p.line, 0.8);
  s += E.p(pg_tp(pg_cr([[100, 145], [110, 151], [120, 152.5], [130, 151], [140, 145]], 4), 4.6, 4.6), p.relief, p.line, 0.8);
  /* crâne, yeux, spiracles, arcs branchiaux */
  const sk = [[cx, 16], [112, 21], [107, 31], [106, 45], [109, 57], [cx, 63]];
  s += E.p(pg_sm(sk.concat(sk.slice(1, -1).reverse().map(mir)), true), p.relief, p.line, 0.9);
  const GA = pg_B();
  for (let i = 0; i < 5; i++) { const y = 64.5 + i * 2.6; GA.M([110, y]).Q([103, y + 0.6], [98.5, y + 3.4]); }
  const head = E.c(112, 36, 2.9, p.accent) + E.c(111.2, 35.1, 0.9, p.hi, null, 0, pg_op(p, 0.7)) + E.el(111, 45.5, 2.6, 1.4, -18, p.shade, p.line, 0.5) + E.p(GA.d(), null, p.line, 0.6);
  s += head + mirrorG(head, cx);
  /* aiguillon dentelé */
  const sb = [tl[9][0] + 2.4, tl[9][1]], st = [tl[17][0] + 8.5, tl[17][1] + 1];
  const L = Math.hypot(st[0] - sb[0], st[1] - sb[1]), d = [(st[0] - sb[0]) / L, (st[1] - sb[1]) / L], n = [-d[1], d[0]], K = 12, le = [], ri = [];
  for (let i = 0; i <= K; i++) {
    const u = i / K, w = 2.4 * Math.pow(1 - u, 0.7), c = pg_ad(sb, d, L * u);
    le.push(pg_ad(c, n, w)); ri.push(pg_ad(c, n, -w));
    if (i < K) { const c2 = pg_ad(sb, d, L * (u + 0.3 / K)), w2 = 2.4 * Math.pow(1 - u, 0.7) + 1.3; le.push(pg_ad(c2, n, w2)); ri.push(pg_ad(c2, n, -w2)); }
  }
  s += E.p(pg_B().pl(le.concat(ri.reverse()), true).d(), p.relief, p.line, 0.6) + E.p(pg_B().M(sb).L(pg_ad(sb, d, L * 0.85)).d(), null, p.line, 0.5);
  /* reflet */
  s += E.p(pg_sm(M.slice(9, 26).filter((q, i) => i % 3 === 0).map((q, i) => lerpPt(q, Rt[9 + i * 3], 0.1))), null, p.hi, 1.6, pg_op(p, 0.6));
  return s;
}

/* ---------------- registre ---------------- */
Object.assign(ART, {
  nummulites: { vb: [240, 200], fn: artNummulites, area: { cx: 120, cy: 102, rx: 104, ry: 86 } },
  knightia: { vb: [300, 140], fn: artKnightia, area: { cx: 148, cy: 74, rx: 136, ry: 40 } },
  heliobatis: { vb: [240, 300], fn: artHeliobatis, area: { cx: 120, cy: 108, rx: 86, ry: 104 } }
});
