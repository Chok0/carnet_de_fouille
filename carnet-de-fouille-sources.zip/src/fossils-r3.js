/* ============ fossiles : Carbonifère (fin), Permien, Trias ============ */

/* annularia — Annularia stellata, feuilles de calamite.
   ① tige à nœuds, rameaux obliques ; ② verticilles en étoile de feuilles étroites, un peu ovales ; ③ nervure médiane ; ④ film de carbone */
function artAnnularia(p) {
  const rnd = mulberry32(hashStr('annularia'));
  let stems = '', leaves = '', veins = '', nodes = '';
  const whorl = (c, R, n, axisAng) => {
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU + rnd() * 0.12, perp = Math.abs(Math.sin(a - axisAng)), L = R * (0.62 + 0.38 * perp) * (0.9 + rnd() * 0.18);
      const d = [Math.cos(a), Math.sin(a)], nr = [-d[1], d[0]], tip = [c[0] + d[0] * L, c[1] + d[1] * L], m = [c[0] + d[0] * L * 0.45, c[1] + d[1] * L * 0.45], w = 3.1;
      leaves += 'M' + PS([c[0] + d[0] * 3, c[1] + d[1] * 3]) + 'Q' + PS([m[0] + nr[0] * w, m[1] + nr[1] * w]) + ' ' + PS(tip) + 'Q' + PS([m[0] - nr[0] * w, m[1] - nr[1] * w]) + ' ' + PS([c[0] + d[0] * 3, c[1] + d[1] * 3]) + 'Z';
      veins += 'M' + PS([c[0] + d[0] * 4, c[1] + d[1] * 4]) + 'L' + PS([c[0] + d[0] * L * 0.85, c[1] + d[1] * L * 0.85]);
    }
    nodes += E.c(c[0], c[1], 3.2, p.relief, p.line, 0.7);
  };
  const shoot = (pts, w, R, n, from) => {
    const P = sk_spline(pts, 6);
    stems += E.p(taperD(P, w, w * 0.6), p.body, p.line, 0.8);
    let node = '';
    for (let k = from; k < pts.length; k++) {
      const q = pts[k], tg = tangentAt(pts, k), ax = Math.atan2(tg[1], tg[0]);
      node += 'M' + PS([q[0] - tg[1] * w * 0.6, q[1] + tg[0] * w * 0.6]) + 'L' + PS([q[0] + tg[1] * w * 0.6, q[1] - tg[0] * w * 0.6]);
      whorl(q, R * (1 - 0.1 * (k - from)), n, ax);
    }
    stems += E.p(node, null, p.line, 1);
  };
  shoot([[62, 234], [86, 192], [110, 148], [136, 104], [162, 64], [186, 34]], 5, 32, 16, 1);
  shoot([[110, 148], [80, 124], [54, 106], [32, 94]], 3.6, 22, 13, 1);
  shoot([[136, 104], [168, 110], [198, 120], [218, 134]], 3.4, 21, 12, 1);
  let s = stems + E.p(leaves, p.body, p.line, 0.6) + E.p(veins, null, p.hi, 0.6, 'opacity=".55"') + nodes;
  return s;
}

/* arthropleura — Arthropleura, pièce unique, mille-pattes géant, vue dorsale.
   ① petite tête ; ② ~30 tergites : partie axiale bombée + paranotes latérales à tubercules ; ③ tergites imbriqués ;
   ④ pattes qui dépassent par paires ; ⑤ corps en S doux */
function artArthropleura(p) {
  const ax = resample(cubicPts([26, 112], [118, 60], [214, 156], [318, 94], 80), 31);
  const W = t => 31 * (t < 0.08 ? 0.62 + 4.75 * t : t > 0.88 ? Math.max(0.35, 1 - (t - 0.88) * 5) : 1);
  let legs = '', par = '', axl = '', dots = '';
  for (let i = ax.length - 2; i >= 0; i--) {
    const t = i / (ax.length - 2), A = ax[i], B = ax[i + 1], tg = tangentAt(ax, i), n = [-tg[1], tg[0]], w = W(t), wb = W(Math.min(1, t + 0.033));
    [-1, 1].forEach(sd => {
      const o = (q, k, back) => [q[0] + n[0] * sd * k + tg[0] * (back || 0), q[1] + n[1] * sd * k + tg[1] * (back || 0)];
      par += 'M' + PS(o(A, w * 0.34, -1)) + 'L' + PS(o(A, w * 0.9, -1)) + 'Q' + PS(o(A, w * 1.06, 2)) + ' ' + PS(o(B, w * 0.98, 3.5)) + 'Q' + PS(o(B, wb * 0.86, 1.5)) + ' ' + PS(o(B, wb * 0.34, 0.5)) + 'Z';
      dots += 'M' + PS(o(lerpPt(A, B, 0.45), w * 0.58)) + 'h.1M' + PS(o(lerpPt(A, B, 0.45), w * 0.78)) + 'h.1';
      legs += 'M' + PS(o(lerpPt(A, B, 0.3), w * 0.96)) + 'l' + r1((n[0] * sd * 0.9 + tg[0] * 0.6) * 7) + ' ' + r1((n[1] * sd * 0.9 + tg[1] * 0.6) * 7) + 'M' + PS(o(lerpPt(A, B, 0.75), w * 0.94)) + 'l' + r1((n[0] * sd * 0.9 + tg[0] * 0.7) * 6) + ' ' + r1((n[1] * sd * 0.9 + tg[1] * 0.7) * 6);
    });
    const a1 = [A[0] + n[0] * w * 0.36, A[1] + n[1] * w * 0.36], a2 = [A[0] - n[0] * w * 0.36, A[1] - n[1] * w * 0.36], b1 = [B[0] + n[0] * wb * 0.34 + tg[0], B[1] + n[1] * wb * 0.34 + tg[1]], b2 = [B[0] - n[0] * wb * 0.34 + tg[0], B[1] - n[1] * wb * 0.34 + tg[1]];
    axl += 'M' + PS(a1) + 'Q' + PS([A[0] - tg[0] * 3, A[1] - tg[1] * 3]) + ' ' + PS(a2) + 'L' + PS(b2) + 'L' + PS(b1) + 'Z';
    dots += 'M' + PS(lerpPt(A, B, 0.5)) + 'h.1';
  }
  let s = sk_str(legs, 1.8, p, p.shade) + E.p(par, p.body, p.line, 0.8) + E.p(axl, p.relief, p.line, 0.8) + E.p(dots, null, p.hi, 2.4, 'opacity=".6"');
  /* tête et antennes */
  const h = ax[0], tg0 = tangentAt(ax, 0), n0 = [-tg0[1], tg0[0]];
  s += E.p('M' + PS([h[0] + n0[0] * 12, h[1] + n0[1] * 12]) + 'q' + r1(-tg0[0] * 14 + n0[0] * 4) + ' ' + r1(-tg0[1] * 14 + n0[1] * 4) + ' ' + r1(-tg0[0] * 22 + n0[0] * 12) + ' ' + r1(-tg0[1] * 22 + n0[1] * 12) + 'M' + PS([h[0] - n0[0] * 12, h[1] - n0[1] * 12]) + 'q' + r1(-tg0[0] * 14 - n0[0] * 4) + ' ' + r1(-tg0[1] * 14 - n0[1] * 4) + ' ' + r1(-tg0[0] * 22 - n0[0] * 12) + ' ' + r1(-tg0[1] * 22 - n0[1] * 12), null, p.line, 1.6);
  s += E.el(h[0] - tg0[0] * 5, h[1] - tg0[1] * 5, 11, 15, Math.atan2(tg0[1], tg0[0]) / D2R, p.relief, p.line, 1);
  /* reflet */
  s += E.p(polyD(ax.slice(2, 14).map((q, i) => { const t = tangentAt(ax, i + 2); return [q[0] + t[1] * 9, q[1] - t[0] * 9]; })), null, p.hi, 1.6, 'opacity=".55"');
  return s;
}

/* dimetrodon — Dimetrodon grandis, pièce unique, squelette de profil (tête à gauche).
   ① grand crâne haut, une fenêtre temporale, dents inégales (canines) ; ② colonne et longue queue ;
   ③ voile d'épines neurales très hautes reliées par une membrane ; ④ côtes ; ⑤ membres écartés à 5 doigts griffus */
function artDimetrodon(p) {
  const back = sk_spline([[116, 108], [140, 104], [170, 102], [200, 103], [236, 110]], 5), tail = sk_spline([[236, 110], [262, 114], [290, 126], [312, 140], [334, 156]], 5);
  const dors = resample(back, 22), caud = resample(tail, 26);
  const spineH = t => 12 + 76 * Math.pow(Math.sin(Math.PI * clamp((t - 0.08) / 0.84, 0, 1)), 0.8);
  let s = '';
  /* voile : membrane entre les pointes */
  const tips = dors.map((q, i) => { const t = i / (dors.length - 1), tg = tangentAt(dors, i), up = [tg[1], -tg[0]], L = spineH(t); return [q[0] + (up[0] * 0.99 + tg[0] * 0.14) * L, q[1] + (up[1] * 0.99 + tg[1] * 0.14) * L]; });
  s += sk_film([dors[0]].concat(tips, [dors[dors.length - 1]]), p, 0.45);
  /* membres éloignés (derrière) */
  const limb = (sh, el, wr, hand, col) => sk_bone(sh, el, 2.6, p, 4, col) + sk_bone(el, wr, 2.2, p, 3.4, col) + sk_digits(wr, hand, 70, [11, 13, 14, 13, 10], 1.4, p, 3);
  s += limb([146, 120], [158, 146], [150, 170], -12, p.shade) + limb([232, 122], [248, 150], [236, 174], -14, p.shade);
  /* côtes */
  s += sk_ribs(dors, 3, 17, p, { len: t => 40 - 8 * Math.abs(t - 0.4), back: 0.12, bend: 0.25, w: 1.7 });
  /* colonne, voile, queue */
  s += sk_column(dors, p, { h: () => 7, spine: spineH, lean: 0.14, sw: 1.9 });
  s += sk_column(caud, p, { h: t => 6.4 - 4.6 * t, spine: t => 8 * (1 - t), chev: t => 9 * (1 - t), lean: 0.5 });
  /* bassin et épaule */
  s += E.p('M226 106Q240 98 252 108L246 122Q236 128 228 120Z', p.relief, p.line, 0.9) + E.p('M230 122L222 140L236 136Z', p.relief, p.line, 0.8);
  s += E.p('M142 100Q150 96 156 104L152 126Q144 128 140 120Z', p.relief, p.line, 0.9);
  /* membres proches */
  s += limb([150, 122], [138, 150], [150, 174], -20, p.relief) + limb([238, 124], [224, 154], [242, 178], -18, p.relief);
  /* cou */
  s += sk_column(resample(sk_spline([[112, 110], [124, 106], [138, 104]], 4), 4), p, { h: () => 7.4, spine: () => 8, lean: 0.2 });
  /* crâne */
  const SK = [[16, 120], [22, 104], [36, 94], [60, 86], [84, 82], [102, 86], [114, 98], [116, 122], [104, 128], [60, 126], [26, 126]];
  s += E.p(smoothD(SK, true), p.relief, p.line, 1.1);
  s += E.p('M22 138Q60 140 108 132L112 124L24 128Z', p.relief, p.line, 1);
  s += E.el(78, 98, 9, 8.5, 0, p.accent, p.line, 0.9) + E.el(99, 108, 6.5, 9, 10, p.accent, p.line, 0.8) + E.el(24, 108, 3, 2.2, 0, p.accent);
  s += E.p('M40 92Q56 100 60 118M88 86Q92 100 90 120M60 118Q80 112 110 116', null, p.line, 0.6, 'opacity=".7"');
  const jaw = linePts([26, 125], [100, 125], 18);
  s += sk_teeth(jaw.filter((q, i) => i !== 3 && i !== 5), 3.4, 1, p, 1.2) + sk_teeth([jaw[3], jaw[5]], 11, 1, p, 2.2, -0.1) + sk_teeth(linePts([28, 129], [96, 129], 16), 3, -1, p, 1.1);
  s += E.p('M28 102Q48 88 80 84', null, p.hi, 2, 'opacity=".7"');
  return s;
}

/* nothosaurus — Nothosaurus mirabilis, squelette vu de dessus, corps en S.
   ① crâne plat à grandes fenêtres temporales, crocs sur les côtés ; ② long cou ; ③ côtes latérales et gastralia ;
   ④ quatre membres étalés en palettes ; ⑤ longue queue */
function artNothosaurus(p) {
  const axis = resample(sk_spline([[64, 112], [90, 106], [116, 106], [144, 112], [174, 118], [204, 118], [234, 114], [264, 116], [292, 124], [314, 134]], 6), 58);
  const nk = 15, tr = 32;
  /* silhouette du tronc en film */
  const hw = i => { const t = (i - nk + 4) / (tr + 10); return t <= 0 ? 7 : t >= 1 ? 4 : 7 + 22 * Math.pow(Math.sin(Math.PI * Math.min(1, t * 1.15)), 0.8); };
  const L1 = [], L2 = [];
  for (let i = 4; i < axis.length; i += 2) { const q = axis[i], tg = tangentAt(axis, i), w = i < nk - 2 ? 6 : hw(i) * (i > nk + tr ? Math.max(0.2, 1 - (i - nk - tr) / 16) : 1); L1.push([q[0] - tg[1] * w, q[1] + tg[0] * w]); L2.push([q[0] + tg[1] * w, q[1] - tg[0] * w]); }
  let s = sk_film(L1.concat(L2.reverse()), p, 0.4);
  /* membres (4), étalés de part et d'autre */
  const limb = (i, sd, L1, L2, dig) => {
    const q = axis[i], tg = tangentAt(axis, i), n = [-tg[1] * sd, tg[0] * sd];
    const el = [q[0] + n[0] * L1 - tg[0] * L1 * 0.25, q[1] + n[1] * L1 - tg[1] * L1 * 0.25], wr = [el[0] + n[0] * L2 * 0.8 + tg[0] * L2 * 0.45, el[1] + n[1] * L2 * 0.8 + tg[1] * L2 * 0.45];
    const ang = Math.atan2(n[1] * 0.7 + tg[0] * 0.5 * 0 + tg[1] * 0.6, n[0] * 0.7 + tg[0] * 0.6) / D2R;
    return sk_bone([q[0] + n[0] * 5, q[1] + n[1] * 5], el, 2.8, p, 4.2) + sk_bone(el, wr, 2.2, p, 3.4) + sk_digits(wr, ang, 60, dig, 1.5, p, 0);
  };
  s += limb(nk + 2, -1, 26, 22, [12, 15, 17, 15, 12]) + limb(nk + 2, 1, 26, 22, [12, 15, 17, 15, 12]) + limb(nk + tr - 6, -1, 24, 20, [11, 14, 16, 14, 11]) + limb(nk + tr - 6, 1, 24, 20, [11, 14, 16, 14, 11]);
  /* côtes des deux côtés et gastralia */
  let ribs = '', gas = '';
  for (let i = nk; i < nk + tr - 6; i++) {
    const t = (i - nk) / (tr - 7), q = axis[i], tg = tangentAt(axis, i), L = 16 + 10 * Math.sin(Math.PI * t);
    [-1, 1].forEach(sd => { const n = [-tg[1] * sd, tg[0] * sd]; ribs += 'M' + PS(q) + 'Q' + PS([q[0] + n[0] * L * 0.6 + tg[0] * 2, q[1] + n[1] * L * 0.6 + tg[1] * 2]) + ' ' + PS([q[0] + n[0] * L + tg[0] * 7, q[1] + n[1] * L + tg[1] * 7]); });
    if (i % 2 === 0) { const n = [-tg[1], tg[0]], w = L * 0.8; gas += 'M' + PS([q[0] + n[0] * w + tg[0] * 3, q[1] + n[1] * w + tg[1] * 3]) + 'L' + PS([q[0] + tg[0] * 7, q[1] + tg[1] * 7]) + 'L' + PS([q[0] - n[0] * w + tg[0] * 3, q[1] - n[1] * w + tg[1] * 3]); }
  }
  s += E.p(gas, null, p.line, 0.6, 'opacity=".5"') + sk_str(ribs, 1.7, p);
  /* queue : apophyses transverses */
  let tp = '';
  for (let i = nk + tr - 4; i < axis.length - 6; i++) { const q = axis[i], tg = tangentAt(axis, i), L = 7 * (1 - (i - nk - tr) / (axis.length - nk - tr)); tp += 'M' + PS([q[0] + tg[1] * L, q[1] - tg[0] * L]) + 'L' + PS([q[0] - tg[1] * L, q[1] + tg[0] * L]); }
  s += sk_str(tp, 1.4, p);
  s += sk_column(axis.slice(0, nk), p, { h: () => 6.4 }) + sk_column(axis.slice(nk), p, { h: t => 7.6 - 6 * t * t });
  /* crâne plat */
  const q0 = axis[0], tg = tangentAt(axis, 0), n = [-tg[1], tg[0]], P = (f, o) => [q0[0] + tg[0] * f + n[0] * o, q0[1] + tg[1] * f + n[1] * o];
  const SK = [P(2, 0), P(-2, 15), P(-18, 16), P(-36, 11), P(-50, 6), P(-56, 0), P(-50, -6), P(-36, -11), P(-18, -16), P(-2, -15)];
  s += E.p(smoothD(SK, true), p.relief, p.line, 1.1);
  s += E.el(...P(-10, 6.5), 7, 4.4, Math.atan2(tg[1], tg[0]) / D2R, p.accent, p.line, 0.8) + E.el(...P(-10, -6.5), 7, 4.4, Math.atan2(tg[1], tg[0]) / D2R, p.accent, p.line, 0.8);
  s += E.c(...P(-24, 5.5), 3.2, p.accent, p.line, 0.6) + E.c(...P(-24, -5.5), 3.2, p.accent, p.line, 0.6) + E.c(...P(-46, 2.4), 1.3, p.accent) + E.c(...P(-46, -2.4), 1.3, p.accent);
  let fang = '';
  [-50, -45, -40, -35, -30].forEach((f, k) => { [-1, 1].forEach(sd => { const b = P(f, sd * (6 + (f + 56) * 0.28)), e = P(f - 3, sd * (6 + (f + 56) * 0.28 + 5 + (k < 2 ? 3 : 0))); fang += 'M' + PS(b) + 'L' + PS(e); }); });
  s += sk_str(fang, 1.3, p, p.hi);
  s += E.p('M' + PS(P(-8, -10)) + 'Q' + PS(P(-26, -12)) + ' ' + PS(P(-44, -6)), null, p.hi, 1.6, 'opacity=".7"');
  return '<g transform="translate(0 -26)">' + s + '</g>';
}

/* tanystropheus — Tanystropheus longobardicus, squelette de profil (tête à gauche).
   ① petit crâne denté ; ② cou de 13 vertèbres très longues, côtes cervicales en baguettes ; ③ tronc court à côtes ;
   ④ membres postérieurs plus grands ; ⑤ queue à chevrons */
function artTanystropheus(p) {
  const neck = resample(sk_spline([[42, 72], [80, 76], [120, 80], [150, 84], [178, 90]], 6), 14);
  const trunk = resample(sk_spline([[178, 90], [200, 90], [220, 92], [236, 96]], 5), 10), tail = resample(sk_spline([[236, 96], [262, 102], [292, 112], [334, 122]], 6), 22);
  let s = '';
  /* membres éloignés */
  const limb = (sh, el, wr, ang, dig, w, col) => sk_bone(sh, el, w, p, w * 1.6, col) + sk_bone(el, wr, w * 0.8, p, w * 1.3, col) + sk_digits(wr, ang, 50, dig, 1.3, p, 2);
  s += limb([188, 98], [196, 122], [188, 142], 170, [8, 10, 11, 9], 2.4, p.shade) + limb([234, 102], [248, 128], [236, 152], 160, [12, 15, 17, 14], 2.8, p.shade);
  /* côtes du tronc et côtes cervicales */
  s += sk_ribs(trunk, 1, 9, p, { len: t => 30 - 10 * t, back: 0.1, bend: 0.2, w: 1.5 });
  let cr = '';
  for (let i = 1; i < neck.length - 1; i++) { const a = neck[i], b = neck[Math.min(neck.length - 1, i + 2)]; cr += 'M' + r1(a[0] + 2) + ' ' + r1(a[1] + 5.5) + 'L' + r1(b[0] - 2) + ' ' + r1(b[1] + 6.5); }
  s += sk_str(cr, 0.9, p);
  /* vertèbres cervicales allongées */
  let cv = '';
  for (let i = 0; i < neck.length - 1; i++) cv += sk_bone(neck[i], neck[i + 1], 2.2, p, 3.2);
  s += cv + E.p(neck.slice(0, -1).map((q, i) => 'M' + r1(q[0] + 3) + ' ' + r1(q[1] - 2.6) + 'L' + r1(neck[i + 1][0] - 3) + ' ' + r1(neck[i + 1][1] - 2.8)).join(''), null, p.line, 0.6, 'opacity=".6"');
  s += sk_column(trunk, p, { h: () => 6.4, spine: () => 7, lean: 0.3 }) + sk_column(tail, p, { h: t => 6 - 4.4 * t, spine: t => 7 * (1 - t), chev: t => 8 * (1 - t), lean: 0.5 });
  /* bassin */
  s += E.p('M226 92Q238 86 248 94L244 106Q236 110 228 104Z', p.relief, p.line, 0.9);
  /* membres proches */
  s += limb([186, 98], [178, 124], [188, 146], 175, [8, 10, 11, 9], 2.4, p.relief) + limb([236, 102], [222, 130], [240, 154], 168, [12, 15, 17, 14], 2.8, p.relief);
  /* crâne */
  s += E.p('M12 70Q16 62 28 60Q40 60 46 66L46 76Q34 80 14 76Z', p.relief, p.line, 1) + E.c(33, 66, 4, p.accent, p.line, 0.7) + E.p('M14 72L44 72', null, p.line, 0.7);
  s += sk_teeth(linePts([16, 72], [38, 72], 6), 2.4, 1, p, 0.8);
  s += E.p('M50 70L170 84', null, p.hi, 1.4, 'opacity=".6"');
  return s;
}

Object.assign(ART, {
  annularia: { vb: [240, 240], fn: artAnnularia, area: { cx: 124, cy: 122, rx: 104, ry: 106 } },
  arthropleura: { vb: [340, 200], fn: artArthropleura, area: { cx: 170, cy: 104, rx: 160, ry: 70 } },
  dimetrodon: { vb: [340, 200], fn: artDimetrodon, area: { cx: 172, cy: 104, rx: 160, ry: 90 } },
  nothosaurus: { vb: [320, 180], fn: artNothosaurus, area: { cx: 170, cy: 92, rx: 150, ry: 74 } },
  tanystropheus: { vb: [340, 170], fn: artTanystropheus, area: { cx: 172, cy: 100, rx: 160, ry: 54 } }
});
