/* ============ fossiles : Ordovicien ============ */

/* ---------- aides (préfixe o_) ---------- */
/* opacités : 1 en mode silhouette (p.flat) */
function o_fo(p, o) { return 'fill-opacity="' + (p.flat ? 1 : o) + '"'; }
function o_op(p, o) { return 'opacity="' + (p.flat ? 1 : o) + '"'; }
/* nombre au dixième, sans zéro inutile */
function o_n(v) { let s = String(Math.round(v * 10) / 10); if (s === '-0') s = '0'; return s.replace(/^(-?)0\./, '$1.'); }
/* constructeur de chemin compact : commandes relatives arrondies au dixième, sans dérive */
function o_B() {
  let d = '', X = 0, Y = 0, SX = 0, SY = 0, last = '';
  const R = v => Math.round(v * 10) / 10;
  const put = (c, a) => {
    let s = '';
    a.forEach((v, i) => { const t = o_n(v); s += (i && t[0] !== '-' ? ' ' : '') + t; });
    if (c === last && c !== 'm') d += (s[0] === '-' ? '' : ' ') + s; else d += c + s;
    last = c;
  };
  const B = {
    M(q) { const x = R(q[0]), y = R(q[1]); if (d) put('m', [x - X, y - Y]); else { d = 'M' + o_n(x) + ' ' + o_n(y); last = 'M'; } X = SX = x; Y = SY = y; return B; },
    L(q) { const x = R(q[0]), y = R(q[1]); put('l', [x - X, y - Y]); X = x; Y = y; return B; },
    Q(c, q) { const x = R(q[0]), y = R(q[1]); put('q', [R(c[0]) - X, R(c[1]) - Y, x - X, y - Y]); X = x; Y = y; return B; },
    C(a, b, q) { const x = R(q[0]), y = R(q[1]); put('c', [R(a[0]) - X, R(a[1]) - Y, R(b[0]) - X, R(b[1]) - Y, x - X, y - Y]); X = x; Y = y; return B; },
    Z() { d += 'z'; last = 'z'; X = SX; Y = SY; return B; },
    pl(pts, close) { B.M(pts[0]); for (let i = 1; i < pts.length; i++) B.L(pts[i]); if (close) B.Z(); return B; },
    /* courbe lissée passant par les points (comme smoothD) */
    sm(pts, close) {
      const n = pts.length;
      if (n < 3) return B.pl(pts, close);
      const g = i => (close ? pts[(i + n) % n] : pts[clamp(i, 0, n - 1)]);
      B.M(pts[0]);
      for (let i = 0; i < (close ? n : n - 1); i++) {
        const a = g(i - 1), b = g(i), c = g(i + 1), e = g(i + 2);
        B.C([b[0] + (c[0] - a[0]) / 6, b[1] + (c[1] - a[1]) / 6], [c[0] - (e[0] - b[0]) / 6, c[1] - (e[1] - b[1]) / 6], c);
      }
      if (close) B.Z();
      return B;
    },
    d: () => d
  };
  return B;
}
/* enveloppe convexe (chaîne monotone) ; les points peuvent porter une étiquette en [2] */
function o_hull(pts) {
  const P = pts.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const cr = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
  const lo = [], up = [];
  P.forEach(q => { while (lo.length > 1 && cr(lo[lo.length - 2], lo[lo.length - 1], q) <= 0) lo.pop(); lo.push(q); });
  for (let i = P.length - 1; i >= 0; i--) { const q = P[i]; while (up.length > 1 && cr(up[up.length - 2], up[up.length - 1], q) <= 0) up.pop(); up.push(q); }
  return lo.slice(0, -1).concat(up.slice(0, -1));
}
/* vecteurs 3D */
function o_ad(a, b, k) { return [a[0] + b[0] * k, a[1] + b[1] * k, a[2] + b[2] * k]; }
function o_dt(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
function o_cr(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
function o_nz(a) { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }

/* stipe de graptolite. D : bord dorsal (proximal → distal), sg : côté des thèques (+1 = normale (-ty, tx)),
   W(f) : largeur totale, n thèques à partir de la fraction fa. Renvoie contour, reflets des thèques, septes. */
function o_stipe(D, sg, W, n, fa) {
  const N = D.length - 1;
  const P = (f, o) => {
    const x = clamp(f, 0, 1) * N, i = Math.min(N - 1, Math.floor(x)), t = x - i, a = D[i], b = D[i + 1];
    const tx = b[0] - a[0], ty = b[1] - a[1], l = Math.hypot(tx, ty) || 1;
    return [a[0] + tx * t - ty / l * sg * o, a[1] + ty * t + tx / l * sg * o];
  };
  const dz = (1 - fa) / n, ven = [P(0, W(0) * 0.5)];
  if (fa > 0) ven.push(P(fa * 0.5, W(fa * 0.5) * 0.52));
  const T = o_B(), S = o_B(), O = o_B();
  for (let k = 0; k < n; k++) {
    const f = fa + k * dz, ft = f + 0.8 * dz, w0 = W(f), wt = W(ft);
    const nch = P(f, w0 * 0.56), tip = P(ft, wt);
    ven.push(nch, tip);
    T.pl([nch, tip, P(ft - 0.14 * dz, wt - 3.3), P(f + 0.16 * dz, w0 * 0.56 + 1.7)], true);
    if (k) S.pl([nch, P(f - 0.95 * dz, w0 * 0.13)]);
  }
  ven.push(P(1, W(1) * 0.55));
  const dors = [];
  for (let i = 0; i <= 36; i++) dors.push(P(i / 36, 0));
  O.pl(dors.concat(ven.reverse()), true);
  return { o: O.d(), t: T.d(), s: S.d(), P };
}

/* graptolite — Didymograptus murchisoni, le « graptolite diapason » (film carboné à plat).
   ① sicule : petit cône, apex en haut, ouverture en bas, logé entre les racines des stipes ;
   ② deux stipes pendants : ils s'écartent de la sicule (courbe exponentielle) puis descendent presque
      parallèles (diapason), légèrement incurvés dans le même sens, élargis vers le bas (12 → 17 px) ;
   ③ thèques : dents de scie régulières sur le bord INTÉRIEUR (ventral), pointe tournée vers l'extrémité
      distale, 24 par stipe, séparées par des septes interthécaux obliques ;
   ④ néma : fil effilé qui prolonge l'apex de la sicule vers le haut ;
   ⑤ film de carbone sombre, thèques à reflet argenté ; une seconde colonie plus petite et un fragment de
      stipe brisé remplissent la dalle. */
function artGraptolite(p) {
  let s = '';
  const colony = (ox, oy, sc, rot, L, n, hl) => {
    const c = Math.cos(rot), sn = Math.sin(rot);
    const G = q => [ox + sc * (q[0] * c - q[1] * sn), oy + sc * (q[0] * sn + q[1] * c)];
    const W = f => sc * (f < 0.12 ? lerp(6, 12, f / 0.12) : lerp(12, 17, (f - 0.12) / 0.88));
    let o = E.p(taperD([G([0, 2]), G([0.4, -6]), G([1.6, -13]), G([3.4, -19])], 2.6 * sc, 0.9 * sc), p.body, p.line, 0.6);
    [[-1, 0.965, p.body], [1, 1, p.body2]].forEach(([sd, lf, col]) => {
      const D = [];
      for (let i = 0; i <= 64; i++) {
        const f = i / 64, y = 11 + f * L * lf;
        D.push(G([sd * (33 - 29.5 * Math.exp(-(y - 11) / 15)) + 7 * f * f, y]));
      }
      const st = o_stipe(D, sd, W, n, 0.09);
      o += E.p(st.o, col, p.line, 1) + E.p(st.t, p.relief, null, 0, o_fo(p, 0.75)) + E.p(st.s, null, p.line, 0.6, o_op(p, 0.85));
      if (hl && sd < 0) { const h = []; for (let i = 0; i <= 12; i++) h.push(st.P(0.1 + 0.4 * i / 12, 2.6)); o += E.p(o_B().pl(h).d(), null, p.hi, 1.4, o_op(p, 0.65)); }
    });
    const sic = [[-0.9, -1], [-2.6, 12], [-5, 28.5], [-3.6, 31.4], [0, 32.2], [3.6, 31.4], [5, 28.5], [2.6, 12], [0.9, -1]].map(G);
    o += E.p(o_B().sm(sic, true).d(), p.body, p.line, 0.9);
    o += E.p(o_B().pl([G([-1.6, 8]), G([-3.2, 25])]).d(), null, p.hi, 1, o_op(p, 0.6));
    o += E.p(o_B().pl([G([-3.8, 29.6]), G([0, 30.6]), G([3.8, 29.6])]).d(), null, p.line, 0.6);
    return o;
  };
  s += colony(76, 30, 1, 0, 208, 24, true);
  s += colony(157, 33, 0.66, 0.04, 188, 16, false);
  /* fragment de stipe brisé */
  const F = [];
  for (let i = 0; i <= 20; i++) { const t = i / 20; F.push([lerp(140, 184, t) - 5 * Math.sin(Math.PI * t), lerp(186, 244, t)]); }
  const fr = o_stipe(F, 1, () => 12.5, 7, 0);
  s += E.p(fr.o, p.body2, p.line, 1) + E.p(fr.t, p.relief, null, 0, o_fo(p, 0.75)) + E.p(fr.s, null, p.line, 0.6, o_op(p, 0.85));
  return s;
}

/* echinosphaerites — Echinosphaerites aurantium, cystoïde rhombifère (vue de trois quarts, pôle oral incliné vers nous).
   ① thèque sphérique (rayon 90 dans 220 × 220) ;
   ② plaques polygonales : cellules de Voronoï SUR LA SPHÈRE (points de Fibonacci perturbés, découpe en projection
      gnomonique), projetées orthographiquement → hexagones qui se compriment et rapetissent vers le bord ;
   ③ losanges de pores (dichopores) à cheval sur des sutures, fentes parallèles perpendiculaires à la suture ;
   ④ bouche en étoile (5 sillons) au pôle oral, gonopore voisin ; périprocte latéral fermé par une pyramide
      de 6 valves triangulaires éclairées une à une ;
   ⑤ cicatrice de fixation : courte base tronquée au pôle aboral ;
   ⑥ ombre de sphère (croissant sombre en bas à droite), reflet unique en haut à gauche. */
function artEchinosphaerites(p) {
  const cx = 110, cy = 104, R = 90, tl = 24 * D2R, ct = Math.cos(tl), st = Math.sin(tl);
  const rnd = mulberry32(hashStr('echinosphaerites'));
  const W = v => [v[0], v[1] * ct - v[2] * st, v[1] * st + v[2] * ct];
  const S = v => [cx + R * v[0], cy - R * v[1]];
  const T3 = (c, a, b, u, v) => o_nz(o_ad(o_ad(c, a, u), b, v));
  const Lt = o_nz([-0.5, 0.62, 0.6]), Mo = W([0, 1, 0]), m2 = W([0, 0, 1]);
  const Vp = o_nz([-0.5, 0.3, 0.81]), p1 = o_nz(o_cr([0, 1, 0], Vp)), p2 = o_cr(Vp, p1);
  const N = 170, pts = [];
  for (let i = 0; i < N; i++) {
    const y = 1 - 2 * (i + 0.5) / N, r = Math.sqrt(1 - y * y), a = i * 2.39996;
    pts.push(W(o_nz([r * Math.cos(a) + (rnd() - 0.5) * 0.07, y + (rnd() - 0.5) * 0.07, r * Math.sin(a) + (rnd() - 0.5) * 0.07])));
  }
  let s = '';
  /* cicatrice de fixation, derrière la sphère */
  s += E.p(o_B().pl([[cx - 11, cy + R - 9], [cx - 7.5, cy + R + 8], [cx + 7.5, cy + R + 8], [cx + 11, cy + R - 9]], true).d(), p.body2, p.line, 1);
  s += E.el(cx, cy + R + 8, 7.5, 2.4, 0, p.shade, p.line, 0.8) + E.c(cx, cy + R + 8, 1.3, p.accent);
  s += E.c(cx, cy, R, p.body, p.line, 1.4);
  const BB = [o_B(), o_B(), o_B()], sut = o_B(), edges = [];
  pts.forEach((q, i) => {
    if (q[2] < -0.12) return;
    const e1 = o_nz(o_cr(Math.abs(q[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0], q)), e2 = o_cr(q, e1);
    let poly = [[-0.6, -0.6], [0.6, -0.6], [0.6, 0.6], [-0.6, 0.6]];
    pts.forEach((o, j) => { const cd = o_dt(q, o); if (j !== i && cd > 0.7) poly = clipHalf(poly, o_dt(e1, o), o_dt(e2, o), 1 - cd); });
    let v3 = poly.map(u => T3(q, e1, e2, u[0], u[1]));
    if (q[2] > 0.3) v3.forEach((a, k) => { const b = v3[(k + 1) % v3.length]; if (a[2] > 0.35 && b[2] > 0.35) edges.push([a, b]); });
    if (q[2] < 0.5) { const o = []; v3.forEach((a, k) => { const b = v3[(k + 1) % v3.length]; o.push(a, o_nz(o_ad(a, [b[0] - a[0], b[1] - a[1], b[2] - a[2]], 0.5))); }); v3 = o; }
    const c3 = [];
    v3.forEach((a, k) => {
      const b = v3[(k + 1) % v3.length];
      if (a[2] >= 0) c3.push(a);
      if ((a[2] >= 0) !== (b[2] >= 0)) { const t = a[2] / (a[2] - b[2]); c3.push(o_nz([lerp(a[0], b[0], t), lerp(a[1], b[1], t), 0])); }
    });
    if (c3.length < 3) return;
    const sp = c3.map(S);
    sut.pl(sp, true);
    const I = o_dt(q, Lt), bi = I > 0.72 ? 0 : I > 0.45 ? 1 : I > 0.18 ? 2 : -1;
    if (bi >= 0 && q[2] > 0.1) {
      const m = sp.reduce((a, b) => [a[0] + b[0] / sp.length, a[1] + b[1] / sp.length], [0, 0]);
      BB[bi].pl(sp.map(v => [m[0] + (v[0] - m[0]) * 0.7 - 0.6, m[1] + (v[1] - m[1]) * 0.7 - 0.6]), true);
    }
  });
  [0.8, 0.5, 0.25].forEach((o, k) => { s += E.p(BB[k].d(), p.relief, null, 0, o_fo(p, o)); });
  s += E.p(sut.d(), null, p.line, 0.8);
  /* losanges de pores à cheval sur des sutures */
  const rh = o_B(), sl = o_B(), used = [];
  edges.forEach(([a, b]) => {
    const dv = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], len = Math.hypot(dv[0], dv[1], dv[2]);
    if (len < 0.13) return;
    const M = o_nz(o_ad(a, dv, 0.5));
    if (used.some(u => o_dt(u, M) > 0.87) || o_dt(M, Mo) > 0.9 || o_dt(M, Vp) > 0.9) return;
    used.push(M);
    const sd = o_nz(dv), qd = o_nz(o_cr(M, sd)), A = Math.min(0.055, len * 0.36), Bq = 0.095;
    const P3 = (t, u) => S(o_nz(o_ad(o_ad(M, sd, t), qd, u)));
    rh.pl([P3(A, 0), P3(0, Bq), P3(-A, 0), P3(0, -Bq)], true);
    for (let k = -2; k <= 2; k++) { const t = k / 2.7 * A, h = Bq * (1 - Math.abs(t) / A) * 0.8; sl.pl([P3(t, -h), P3(t, h)]); }
  });
  s += E.p(rh.d(), p.shade, p.line, 0.6) + E.p(sl.d(), null, p.relief, 0.7);
  /* périprocte : collerette + pyramide de valves */
  const ringP = (c, a, b, r, n) => { const o = []; for (let k = 0; k < n; k++) { const t = k / n * TAU; o.push(T3(c, a, b, r * Math.cos(t), r * Math.sin(t))); } return o; };
  s += E.p(o_B().sm(ringP(Vp, p1, p2, 0.155, 18).map(S), true).d(), p.relief, p.line, 0.9);
  const rim = ringP(Vp, p1, p2, 0.115, 6), apx = o_ad(Vp, Vp, 0.06), VB = [o_B(), o_B(), o_B()];
  rim.forEach((a, k) => {
    const b = rim[(k + 1) % 6];
    let nv = o_nz(o_cr([a[0] - apx[0], a[1] - apx[1], a[2] - apx[2]], [b[0] - apx[0], b[1] - apx[1], b[2] - apx[2]]));
    if (o_dt(nv, Vp) < 0) nv = nv.map(v => -v);
    const I = o_dt(nv, Lt);
    VB[I > 0.62 ? 0 : I > 0.3 ? 1 : 2].pl([S(apx), S(a), S(b)], true);
  });
  s += E.p(VB[0].d(), p.relief, p.line, 0.6) + E.p(VB[1].d(), p.body, p.line, 0.6) + E.p(VB[2].d(), p.shade, p.line, 0.6);
  /* bouche en étoile et gonopore */
  s += E.p(o_B().sm(ringP(Mo, [1, 0, 0], m2, 0.08, 16).map(S), true).d(), p.relief, p.line, 0.9);
  const star = [];
  for (let k = 0; k < 10; k++) { const a = k / 10 * TAU - Math.PI / 2, r = k % 2 ? 0.03 : 0.155; star.push(S(T3(Mo, [1, 0, 0], m2, r * Math.cos(a), r * Math.sin(a)))); }
  s += E.p(o_B().pl(star, true).d(), p.accent, p.line, 0.6);
  const gp = S(T3(Mo, [1, 0, 0], m2, 0.1, 0.13));
  s += E.c(gp[0], gp[1], 2, p.accent, p.relief, 0.7);
  /* ombre en croissant (bas-droite) et reflet */
  const k2 = 0.2 * R, R2 = 1.1 * R, P1 = [cx + 0.8507 * R, cy - 0.5257 * R], P2 = [cx - 0.5257 * R, cy + 0.8507 * R];
  s += E.p('M' + PS(P1) + 'A' + R + ' ' + R + ' 0 0 1 ' + PS(P2) + 'A' + r1(R2) + ' ' + r1(R2) + ' 0 0 0 ' + PS(P1) + 'Z', p.shade, null, 0, o_fo(p, 0.5));
  const hp = a => PS([cx + 0.86 * R * Math.cos(a * D2R), cy + 0.86 * R * Math.sin(a * D2R)]);
  s += E.p('M' + hp(198) + 'A' + r1(0.86 * R) + ' ' + r1(0.86 * R) + ' 0 0 1 ' + hp(246), null, p.hi, 2.4, o_op(p, 0.7));
  s += E.c(cx, cy, R, null, p.line, 1.6);
  return s;
}

Object.assign(ART, {
  graptolite: { vb: [200, 260], fn: artGraptolite, area: { cx: 116, cy: 132, rx: 80, ry: 116 } },
  echinosphaerites: { vb: [220, 220], fn: artEchinosphaerites, area: { cx: 110, cy: 106, rx: 88, ry: 92 } }
});
