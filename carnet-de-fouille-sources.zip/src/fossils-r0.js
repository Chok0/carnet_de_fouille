/* ============ fossiles : boîte à outils des derniers lots (os, colonnes, côtes, dents) ============ */
/* os long « haltère » de a à b : w = demi-largeur au milieu, head = demi-largeur des épiphyses */
function sk_boneD(a, b, w, head) {
  const dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L, nx = -uy, ny = ux, h = head || w * 1.8;
  const P = (s, o) => [a[0] + ux * s + nx * o, a[1] + uy * s + ny * o];
  return smoothD([P(-h * 0.45, 0), P(-h * 0.2, h * 0.92), P(h * 0.4, h), P(L * 0.25, w * 1.05), P(L * 0.5, w), P(L * 0.75, w * 1.05), P(L - h * 0.4, h), P(L + h * 0.2, h * 0.92),
    P(L + h * 0.45, 0), P(L + h * 0.2, -h * 0.92), P(L - h * 0.4, -h), P(L * 0.75, -w * 1.05), P(L * 0.5, -w), P(L * 0.25, -w * 1.05), P(h * 0.4, -h), P(-h * 0.2, -h * 0.92)], true);
}
const sk_bone = (a, b, w, p, head, fill) => E.p(sk_boneD(a, b, w, head), fill || p.relief, p.line, 0.8);
/* trait d'os bon marché : trait sombre large sous un trait clair (os fins, côtes, épines, doigts) */
const sk_str = (d, w, p, col) => (d ? E.p(d, null, p.line, w + 1.5) + E.p(d, null, col || p.relief, w) : '');
/* colonne vertébrale le long d'une polyligne (orientée tête → queue) : o.h(t) hauteur des centres,
   o.spine(t) longueur des épines neurales, o.chev(t) chevrons, o.lean inclinaison vers la queue */
function sk_column(pts, p, o) {
  const n = pts.length, lean = o.lean == null ? 0.35 : o.lean;
  let cent = '', sp = '', ch = '';
  for (let i = 0; i < n; i++) {
    const t = n > 1 ? i / (n - 1) : 0, q = pts[i], tg = tangentAt(pts, i), up = [tg[1], -tg[0]];
    const nb = i < n - 1 ? pts[i + 1] : pts[i - 1], seg = Math.hypot(nb[0] - q[0], nb[1] - q[1]), h = o.h(t);
    cent += E.el(q[0], q[1], seg * 0.46, h / 2, Math.atan2(tg[1], tg[0]) / D2R, p.relief, p.line, 0.55);
    const L = o.spine ? o.spine(t) : 0, C = o.chev ? o.chev(t) : 0;
    if (L > 0.8) { const b = [q[0] + up[0] * h * 0.35, q[1] + up[1] * h * 0.35]; sp += 'M' + PS(b) + 'l' + r1((up[0] * Math.cos(lean) + tg[0] * Math.sin(lean)) * L) + ' ' + r1((up[1] * Math.cos(lean) + tg[1] * Math.sin(lean)) * L); }
    if (C > 0.8) { const b = [q[0] - up[0] * h * 0.35, q[1] - up[1] * h * 0.35]; ch += 'M' + PS(b) + 'l' + r1((-up[0] * Math.cos(lean) + tg[0] * Math.sin(lean)) * C) + ' ' + r1((-up[1] * Math.cos(lean) + tg[1] * Math.sin(lean)) * C); }
  }
  return sk_str(sp, o.sw || 2.2, p) + sk_str(ch, o.cw || 1.8, p) + cent;
}
/* côtes depuis les vertèbres [from, to) : o.len(t), o.back (recul vers la queue), o.bend (courbure), o.w */
function sk_ribs(pts, from, to, p, o) {
  let d = '';
  for (let i = from; i < to; i++) {
    const t = (i - from) / Math.max(1, to - from - 1), q = pts[i], tg = tangentAt(pts, i), dn = [-tg[1], tg[0]], L = o.len(t), bk = o.back == null ? 0.25 : o.back, bd = o.bend == null ? 0.3 : o.bend;
    const e = [q[0] + dn[0] * L + tg[0] * L * bk, q[1] + dn[1] * L + tg[1] * L * bk], c = [q[0] + dn[0] * L * 0.45 + tg[0] * L * (bk + bd), q[1] + dn[1] * L * 0.45 + tg[1] * L * (bk + bd)];
    d += 'M' + PS(q) + 'Q' + PS(c) + ' ' + PS(e);
  }
  return sk_str(d, o.w || 1.6, p);
}
/* doigts en éventail depuis base, direction ang (degrés), écart spread, longueurs lens, griffes */
function sk_digits(base, ang, spread, lens, w, p, claw) {
  let d = '', cl = '';
  lens.forEach((L, i) => {
    const a = (ang + (lens.length > 1 ? (i / (lens.length - 1) - 0.5) * spread : 0)) * D2R, e = [base[0] + Math.cos(a) * L, base[1] + Math.sin(a) * L];
    const m = [base[0] + Math.cos(a) * L * 0.5, base[1] + Math.sin(a) * L * 0.5];
    d += 'M' + PS(base) + 'L' + PS(m) + 'L' + PS(e);
    if (claw) { const c = [e[0] + Math.cos(a + 0.5) * claw, e[1] + Math.sin(a + 0.5) * claw]; cl += 'M' + PS([e[0] + Math.cos(a - 1.2) * w * 0.7, e[1] + Math.sin(a - 1.2) * w * 0.7]) + 'Q' + PS([e[0] + Math.cos(a) * claw, e[1] + Math.sin(a) * claw]) + ' ' + PS(c) + 'L' + PS([e[0] + Math.cos(a + 1.6) * w * 0.7, e[1] + Math.sin(a + 1.6) * w * 0.7]) + 'Z'; }
  });
  return sk_str(d, w, p) + (cl ? E.p(cl, p.shade, p.line, 0.6) : '');
}
/* silhouette du corps en film (tissus mous) */
const sk_film = (pts, p, op) => E.p(smoothD(pts, true), p.film, null, 0, 'fill-opacity="' + (p.flat ? 1 : op || p.filmOp) + '"');
/* dents triangulaires le long d'une polyligne de mâchoire ; dir = 1 vers le bas (mâchoire supérieure), −1 vers le haut */
function sk_teeth(pts, len, dir, p, w, curve) {
  let d = '';
  for (let i = 0; i < pts.length; i++) {
    const q = pts[i], tg = tangentAt(pts, i), n = [-tg[1] * dir, tg[0] * dir], L = typeof len === 'function' ? len(i / Math.max(1, pts.length - 1)) : len, hw = (w || 1.6);
    const tip = [q[0] + n[0] * L + tg[0] * L * (curve || 0), q[1] + n[1] * L + tg[1] * L * (curve || 0)];
    d += 'M' + PS([q[0] - tg[0] * hw, q[1] - tg[1] * hw]) + 'L' + PS(tip) + 'L' + PS([q[0] + tg[0] * hw, q[1] + tg[1] * hw]) + 'Z';
  }
  return E.p(d, p.hi, p.line, 0.5);
}
/* tubercules dans un polygone */
function sk_dots(rnd, poly, n, r, col, op) {
  let d = '', k = 0, x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  poly.forEach(q => { x0 = Math.min(x0, q[0]); y0 = Math.min(y0, q[1]); x1 = Math.max(x1, q[0]); y1 = Math.max(y1, q[1]); });
  for (let i = 0; i < n * 4 && k < n; i++) { const q = [x0 + rnd() * (x1 - x0), y0 + rnd() * (y1 - y0)]; if (pointInPoly(poly, q)) { d += 'M' + PS(q) + 'h.1'; k++; } }
  return E.p(d, null, col, r * 2, op ? 'opacity="' + op + '"' : '');
}
/* ligne décalée d'une polyligne (le long de sa normale gauche) */
const sk_offset = (pts, d) => pts.map((q, i) => { const t = tangentAt(pts, i); return [q[0] - t[1] * (typeof d === 'function' ? d(i / (pts.length - 1)) : d), q[1] + t[0] * (typeof d === 'function' ? d(i / (pts.length - 1)) : d)]; });
/* points serrés le long de la courbe lissée qu'on dessine avec smoothD (Catmull-Rom) */
function sk_spline(pts, k, close) {
  const n = pts.length, g = i => (close ? pts[(i + n) % n] : pts[clamp(i, 0, n - 1)]), out = [pts[0]], segs = close ? n : n - 1;
  for (let i = 0; i < segs; i++) {
    const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2);
    out.push(...cubicPts(p1, [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6], [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6], p2, k || 8).slice(1));
  }
  return out;
}
