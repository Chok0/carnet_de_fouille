/* ============ professeur Kayou : portrait à l'encre et au lavis ============ */
/* Directeur du nouveau musée. Chapeau de brousse avec une épingle d'ammonite, lunettes rondes,
   moustache et barbe grises, foulard rouille, gilet de terrain et loupe au cou. */
const KY = {
  ink: '#2a2016', skin: '#e8b793', skinSh: '#c98f6c', blush: '#dc8a72', nose: '#e39a7d',
  hair: '#dcd6ca', hairSh: '#a59e91', hat: '#b99e69', hatSh: '#8d7547', band: '#5a432c', pin: '#c9a24a',
  vest: '#8b7b53', vestSh: '#6b5d3c', shirt: '#efe8d8', scarf: '#b3533b', scarfSh: '#873a28', glass: '#34291e', mouth: '#7b3326'
};
/* expressions : yeux, sourcils (hauteur, inclinaison du bout intérieur en degrés), bouche */
const KY_EXPR = {
  content: { eyes: 'happy', brow: [-3, -8, -3, -8], mouth: 'grin' },
  encourage: { eyes: 'open', brow: [-2, 10, -2, 10], mouth: 'smile' },
  conseil: { eyes: 'side', brow: [-6, -6, 1, -12], mouth: 'smirk' },
  surpris: { eyes: 'wide', brow: [-6, -2, -6, -2], mouth: 'o' },
  soucieux: { eyes: 'open', brow: [0, 22, 0, 22], mouth: 'frown' }
};
function kayouSVG(expr, mode) {
  const X = KY_EXPR[expr] || KY_EXPR.content, K = KY, P = E.p;
  const vb = mode === 'face' ? '33 22 94 94' : '0 0 160 180';
  let s = '<svg class="ky-svg" viewBox="' + vb + '" aria-hidden="true"><g stroke-linecap="round" stroke-linejoin="round">';
  /* buste : gilet, col, foulard, loupe au cou */
  s += P('M10 181C12 152 38 137 62 132L98 132C122 137 148 152 150 181Z', K.vest, K.ink, 2);
  s += P('M22 181C24 160 40 146 58 140', null, K.vestSh, 3, 'opacity=".6"') + P('M138 181C136 160 120 146 102 140', null, K.vestSh, 3, 'opacity=".6"');
  s += P('M80 146V181', null, K.ink, 1.4) + E.c(84, 158, 1.6, K.ink) + E.c(84, 170, 1.6, K.ink);
  s += P('M30 162h24l-2 8h-20z', K.vestSh, K.ink, 1.3) + P('M106 162h24l-2 8h-20z', K.vestSh, K.ink, 1.3);
  s += P('M44 163l3 -16 3 1 -3 16z', '#e3b33c', K.ink, 1) + P('M47 147l1.6 -3 1.4 3.4', '#f2dcb0', K.ink, 0.8);
  s += P('M64 139Q70 156 64 166', null, '#5b4a33', 1.2) + E.c(62, 170, 5.4, 'rgba(214,232,236,.55)', K.ink, 1.6) + P('M58 176l-3 4', null, K.ink, 2.2);
  /* le cou : court, cerné d'encre, avec l'ombre de la mâchoire (la tête ne flotte plus) */
  s += P('M69.5 110L68.5 134Q80 138 91.5 134L90.5 110Z', K.skin, K.ink, 1.8) + P('M69.5 118Q80 127 90.5 118', null, K.skinSh, 4, 'opacity=".6"');
  s += P('M60 131L80 146L71 151L55 137Z', K.shirt, K.ink, 1.5) + P('M100 131L80 146L89 151L105 137Z', K.shirt, K.ink, 1.5);
  s += P('M68 136Q80 128 92 136Q86 141 80 141Q74 141 68 136Z', K.scarf, K.ink, 1.5);
  s += P('M76 139L71 160L80 153L89 159L84 139Z', K.scarf, K.ink, 1.4) + P('M78 142L75 155', null, K.scarfSh, 1.4, 'opacity=".7"');
  s += E.el(80, 138, 5.2, 4, 0, K.scarfSh, K.ink, 1.3);
  /* en buste, la tête descend un peu sur le cou */
  if (mode !== 'face') s += '<g transform="translate(0 6)">';
  /* oreilles */
  s += E.el(45, 83, 5.5, 8, -8, K.skin, K.ink, 1.6) + E.el(115, 83, 5.5, 8, 8, K.skin, K.ink, 1.6);
  s += P('M43 81q3 -2 4 3', null, K.skinSh, 1.2) + P('M117 81q-3 -2 -4 3', null, K.skinSh, 1.2);
  /* tête en galet */
  const head = [[80, 33], [98, 35], [109, 46], [114, 64], [114, 84], [108, 101], [96, 111], [80, 115], [64, 111], [52, 101], [46, 84], [46, 64], [51, 46], [62, 35]];
  s += P(smoothD(head, true), K.skin, K.ink, 2.1);
  s += P('M106 58Q114 76 107 98Q100 108 90 112Q104 98 106 80Q108 66 102 56Z', K.skinSh, null, 0, 'opacity=".45"');
  s += P('M48 55Q60 50 80 50Q100 50 112 55L112 45Q98 41 80 41Q62 41 48 45Z', K.skinSh, null, 0, 'opacity=".5"');
  /* touffes de cheveux blancs au-dessus des oreilles */
  const tuft = sd => {
    const f = q => [80 + (q[0] - 80) * sd, q[1]];
    const pts = [[51, 55], [44, 56], [39, 61], [40, 66], [37, 71], [41, 76], [47, 79], [50, 74], [50, 64]].map(f);
    return P(smoothD(pts, true), K.hair, K.ink, 1.5) + P(polyD([[45, 60], [42, 66]].map(f)) + polyD([[46, 68], [43, 74]].map(f)), null, K.hairSh, 1.1);
  };
  s += tuft(1) + tuft(-1);
  /* joues */
  s += E.el(58, 91, 6.5, 3.8, -8, K.blush, null, 0, 'opacity=".45"') + E.el(102, 91, 6.5, 3.8, 8, K.blush, null, 0, 'opacity=".45"');
  /* barbe courte le long de la mâchoire, ouverte sur la bouche */
  s += P('M49 87Q50 103 60 113Q70 124 80 125Q90 124 100 113Q110 103 111 87Q106 97 98 100Q92 108 80 109Q68 108 62 100Q54 97 49 87Z', K.hair, K.ink, 1.8);
  s += P('M55 101q2 4 5 5M62 111q3 3 7 4M92 115q4 -1 7 -4M100 106q3 -1 5 -5M74 119q6 2 12 0', null, K.hairSh, 1.2);
  /* bouche */
  const m = X.mouth;
  if (m === 'grin') s += P('M71 102Q80 113 89 102Q80 107 71 102Z', K.mouth, K.ink, 1.4) + P('M74 103.6Q80 105.6 86 103.6', null, '#f4ede0', 1.3);
  else if (m === 'smile') s += P('M72 103Q80 109 88 103', null, K.ink, 1.8);
  else if (m === 'smirk') s += P('M73 105Q81 107 88 101', null, K.ink, 1.8);
  else if (m === 'o') s += E.el(80, 105.5, 3.4, 4.2, 0, K.mouth, K.ink, 1.4);
  else if (m === 'frown') s += P('M72 107Q80 102 88 107', null, K.ink, 1.8);
  else s += P('M72 105Q80 103.5 88 105', null, K.ink, 1.8);
  /* nez */
  s += P('M76 78Q72 89 76 93Q80 96 84 93Q88 89 84 78', K.skin, K.ink, 1.7) + E.el(80, 90, 5, 3.6, 0, K.nose, null, 0, 'opacity=".5"');
  s += P('M76.5 92.5q1.4 1 2.6 0.4M83.5 92.5q-1.4 1 -2.6 0.4', null, K.ink, 1.1);
  /* moustache en deux vagues */
  s += P('M80 93Q72 91 64 94Q56 97 52 104Q60 101 66 102Q74 102 80 98Q86 102 94 102Q100 101 108 104Q104 97 96 94Q88 91 80 93Z', K.hair, K.ink, 1.8);
  s += P('M78 95Q70 95 62 99M82 95Q90 95 98 99M76 98Q68 99 60 102M84 98Q92 99 100 102', null, K.hairSh, 1.1);
  /* yeux derrière les lunettes */
  const eye = cx => {
    if (X.eyes === 'happy') return P('M' + (cx - 5) + ' 76Q' + cx + ' 69.5 ' + (cx + 5) + ' 76', null, K.ink, 2.1);
    const r = X.eyes === 'wide' ? 3.3 : 2.5, dx = X.eyes === 'side' ? 2.6 : 0;
    return E.c(cx + dx, 74, r, K.ink) + E.c(cx + dx + 0.9, 73, r * 0.34, '#ffffff');
  };
  s += eye(67) + eye(93);
  /* lunettes rondes */
  s += E.c(67, 74, 10.5, 'rgba(214,232,236,.28)', K.glass, 2) + E.c(93, 74, 10.5, 'rgba(214,232,236,.28)', K.glass, 2);
  s += P('M77.5 73Q80 70 82.5 73', null, K.glass, 2) + P('M56.5 72L47 69M103.5 72L113 69', null, K.glass, 1.8);
  s += P('M61 69a7 7 0 0 1 5 -3M87 69a7 7 0 0 1 5 -3', null, '#ffffff', 1.3, 'opacity=".8"');
  /* sourcils broussailleux : [hauteur gauche, inclinaison gauche, hauteur droite, inclinaison droite] */
  const brow = (cx, dy, tilt, side) => {
    /* tilt > 0 : bout intérieur relevé (air bienveillant ou inquiet) ; tilt < 0 : froncé */
    const a = tilt * D2R, c = Math.cos(a), sn = Math.sin(a), L = 10, y = 58.5 + dy;
    const o = [cx - L * c * side, y + L * sn], i = [cx + L * c * side, y - L * sn];
    let n = [-(i[1] - o[1]) / (2 * L), (i[0] - o[0]) / (2 * L)];
    if (n[1] > 0) n = [-n[0], -n[1]];
    const w0 = 2.4, w1 = 4.2;
    const pts = [[o[0] + n[0] * w0, o[1] + n[1] * w0], [(o[0] + i[0]) / 2 + n[0] * 4.8, (o[1] + i[1]) / 2 + n[1] * 4.8 - 1.2], [i[0] + n[0] * w1, i[1] + n[1] * w1], [i[0] - n[0] * w1, i[1] - n[1] * w1], [(o[0] + i[0]) / 2 - n[0] * 2.6, (o[1] + i[1]) / 2 - n[1] * 2.6], [o[0] - n[0] * w0, o[1] - n[1] * w0]];
    return P(smoothD(pts, true), '#bdb6a8', K.ink, 1.7) + P('M' + PS(o) + 'L' + PS(i), null, '#857e71', 1.3);
  };
  const B = X.brow;
  s += brow(67, B[0], B[1], 1) + brow(93, B[2], B[3], -1);
  /* chapeau de brousse : bord, calotte, bandeau, épingle d'ammonite */
  s += '<g transform="translate(0 -11)">';
  s += P('M22 52Q80 34 138 52Q116 60 80 60Q44 60 22 52Z', K.hat, K.ink, 2);
  s += P('M30 53Q80 42 130 53', null, K.hatSh, 1.4, 'opacity=".7"');
  s += P('M53 49C50 32 58 20 80 19C102 20 110 32 107 49Q80 54 53 49Z', K.hat, K.ink, 2);
  s += P('M66 23Q80 30 94 23', null, K.hatSh, 1.6) + P('M58 34Q60 26 70 22', null, '#d8c292', 2, 'opacity=".8"');
  s += P('M54 41Q80 46 106 41L107 48Q80 53 53 48Z', K.band, K.ink, 1.5);
  let sp = ''; for (let t = 0; t <= 12; t++) { const a = t * 0.62, r = 0.5 + t * 0.34; sp += (t ? 'L' : 'M') + r1(96 + Math.cos(a) * r) + ' ' + r1(45 + Math.sin(a) * r); }
  s += E.c(96, 45, 4.6, K.pin, K.ink, 1.2) + P(sp, null, K.band, 1) + '</g>';
  if (mode !== 'face') s += '</g>';
  return s + '</g></svg>';
}

/* ============ la salle vide du nouveau musée (scène d'introduction, cadrage portrait) ============ */
function museumHallSVG() {
  const ink = '#2a2016', P = E.p, rnd = mulberry32(4242), T = (x, y, t, fs) => '<text x="' + x + '" y="' + y + '" text-anchor="middle" font-family="Special Elite, Courier New, monospace" font-size="' + fs + '" fill="' + ink + '">' + t + '</text>';
  let s = '<svg class="hall-svg" viewBox="0 0 300 440" preserveAspectRatio="xMidYMax slice" aria-hidden="true"><g stroke-linecap="round" stroke-linejoin="round">';
  /* mur, corniche, lambris */
  s += P('M0 0H300V318H0Z', '#e7dcc2') + P('M0 0H300V26H0Z', '#d8caab') + P('M0 26H300', null, ink, 1.2);
  for (let x = 25; x < 300; x += 50) s += P('M' + x + ' 26V292', null, 'rgba(122,96,54,.14)', 1);
  s += P('M0 292H300V318H0Z', '#cdbd98') + P('M0 292H300', null, ink, 1.3);
  /* bannière et frise de cadres encore vides */
  s += P('M58 36H242V62H58Z', '#f6f0e1', ink, 1.4) + T(150, 53, 'FRISE DES TEMPS · BIENTÔT', 9.5);
  const ghost = [
    'M0 0m-8 0a8 8 0 1 0 16 0a8 8 0 1 0 -16 0M-3 0a3 3 0 1 0 6 0',
    'M-6 -8Q0 -11 6 -8L5 8Q0 11 -5 8ZM0 -9V9M-6 -3H6M-6 3H6',
    'M-9 1Q-2 -7 7 -1L11 -5V5L7 1Q-2 7 -9 1Z',
    'M0 9V-2M0 -2Q-8 -6 -7 -10M0 -2Q8 -6 7 -10M0 2Q-6 0 -8 -4M0 2Q6 0 8 -4',
    'M-4 -5Q-4 -9 0 -9Q5 -9 5 -5Q5 -2 0 0V3M0 7V8'
  ];
  ghost.forEach((g, k) => {
    const x = 42 + k * 54, y = 86;
    s += P('M' + (x - 19) + ' ' + (y - 15) + 'h38v30h-38z', '#efe6d0', ink, 1.3);
    s += '<g transform="translate(' + x + ' ' + y + ')">' + P(g, null, 'rgba(90,70,40,.55)', 1.2, 'stroke-dasharray="2.4 2"') + '</g>';
  });
  /* grande fenêtre en arc derrière le professeur */
  s += P('M100 292V160A50 50 0 0 1 200 160V292Z', '#f4ecd8', ink, 1.8);
  s += P('M110 292V162A40 40 0 0 1 190 162V292Z', '#dfe7e2', ink, 1.1);
  s += P('M150 122V292M110 206H190M110 250H190', null, ink, 1);
  s += P('M122 196L138 150M126 282L160 214M168 190L180 164', null, '#ffffff', 2.4, 'opacity=".7"');
  /* sol en perspective, rai de lumière */
  s += P('M0 318H300V440H0Z', '#bfa77a');
  for (let i = -7; i <= 7; i++) s += P('M' + (150 + i * 26) + ' 318L' + (150 + i * 70) + ' 440', null, 'rgba(70,48,24,.32)', 1);
  [334, 356, 386, 424].forEach(y => { s += P('M0 ' + y + 'H300', null, 'rgba(70,48,24,.26)', 1); });
  s += P('M0 318H300', null, ink, 1.8);
  s += P('M110 318L190 318L236 440L64 440Z', 'rgba(255,248,226,.3)');
  /* deux vitrines vides de chaque côté */
  const vitrine = x => {
    let v = P('M' + x + ' 320h72v-50h-72z', '#8c6a43', ink, 1.6) + P('M' + (x + 5) + ' 306h62', null, 'rgba(255,240,210,.35)', 1.2);
    v += P('M' + (x + 4) + ' 270v-58h64v58z', 'rgba(220,236,238,.5)', ink, 1.6) + P('M' + (x + 4) + ' 212l6 -6h52l6 6', '#d8e4e4', ink, 1.3);
    v += P('M' + (x + 12) + ' 262L' + (x + 26) + ' 222M' + (x + 48) + ' 264L' + (x + 60) + ' 236', null, '#ffffff', 2, 'opacity=".8"');
    v += P('M' + (x + 26) + ' 266h20v-8h-20z', '#f6f0e1', ink, 1) + T(x + 36, 264.5, '?', 6.5);
    return v;
  };
  s += vitrine(12) + vitrine(216);
  /* caisse du déménagement et socle sous un drap */
  s += P('M6 432h66v-40h-66z', '#b88c55', ink, 1.8) + P('M6 412h66M17 392v40M61 392v40', null, ink, 1.2);
  let straw = ''; for (let i = 0; i < 14; i++) { const x = 10 + rnd() * 58; straw += 'M' + r1(x) + ' 392l' + r1((rnd() - 0.5) * 8) + ' ' + r1(-4 - rnd() * 6); }
  s += P(straw, null, '#d9b75e', 1.4) + T(39, 427, 'FRAGILE', 7);
  s += P('M236 432q-6 -24 4 -40q13 -9 26 0q10 16 4 40z', '#efe7d4', ink, 1.6) + P('M245 404q6 9 2 25M258 398q4 14 0 32', null, 'rgba(90,70,40,.35)', 1.2);
  return s + '</g></svg>';
}
