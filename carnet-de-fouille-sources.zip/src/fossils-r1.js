/* ============ fossiles : Ordovicien (fin), Dévonien, Carbonifère ============ */

/* asaphus — Asaphus kowalewskii, trilobite aux yeux pédonculés, de profil (tête à gauche).
   ① dôme lisse : céphalon arrondi, thorax de 8 segments, grand pygidium ; ② lobe axial en relief sur le dessus ;
   ③ deux longues tiges oculaires dressées, coiffées d'un œil réniforme à lentilles ; ④ plèvres festonnées en bas ; ⑤ courte pointe génale */
function artAsaphus(p) {
  const TOP = [[20, 162], [25, 140], [38, 118], [60, 101], [92, 90], [130, 85], [168, 86], [204, 93], [230, 108], [248, 128], [256, 156]];
  const BOT = [[256, 156], [248, 166], [214, 171], [150, 172], [100, 171], [60, 169], [32, 167]];
  const top = sk_spline(TOP, 8), yT = x => interpY(top, x), bot = sk_spline(BOT, 6).slice().reverse(), yB = x => interpY(bot, x);
  const furrow = sk_offset(top, t => 7 + 19 * Math.pow(Math.sin(Math.PI * t), 0.55)), yF = x => interpY(furrow, x);
  let s = '';
  /* tige lointaine, derrière le corps */
  s += E.p(taperD([[93, 94], [92, 64], [90, 38]], 5, 3.4), p.shade, p.line, 0.9) + E.el(89, 32, 9, 6, -12, p.shade, p.line, 0.9);
  /* corps */
  s += E.p(smoothD(TOP.concat(BOT.slice(1)), true), p.body, p.line, 1.3);
  /* pointes des plèvres, sous le bord */
  let tips = '';
  for (let k = 0; k < 8; k++) { const x = 104 + k * 11; tips += E.el(x + 3, yB(x) + 1.5, 5, 3, 18, p.body, p.line, 0.8); }
  s = tips + s;
  s += E.p(polyD(bot.map(q => [q[0], q[1] - 3])), null, p.shade, 3, 'opacity=".6"');
  /* lobe axial */
  s += E.p(polyD(top.concat(furrow.slice().reverse()), true), p.relief, p.line, 0.8);
  /* céphalon : bourrelet frontal, limite postérieure */
  const front = top.filter(q => q[0] < 92), rim = sk_offset(front, 6);
  s += E.p(polyD(rim), null, p.line, 0.8, 'opacity=".75"');
  /* segments du thorax et sillons pleuraux */
  let seg = '', fur = '';
  for (let k = 0; k <= 8; k++) {
    const x = 98 + k * 11, t0 = yT(x), b0 = yB(x + 7) - 1;
    seg += 'M' + r1(x) + ' ' + r1(t0) + 'Q' + r1(x + 2) + ' ' + r1((t0 + b0) / 2) + ' ' + r1(x + 7) + ' ' + r1(b0);
    if (k < 8) { const xm = x + 5.5, f = yF(xm); fur += 'M' + r1(xm) + ' ' + r1(f + 2) + 'Q' + r1(xm + 1.5) + ' ' + r1(f + (yB(xm) - f) * 0.35) + ' ' + r1(xm + 5) + ' ' + r1(f + (yB(xm) - f) * 0.7); }
  }
  s += E.p(seg, null, p.line, 1) + E.p(fur, null, p.line, 0.6, 'opacity=".7"');
  /* anneaux axiaux du pygidium et bordure */
  let ring = '';
  [200, 212, 223].forEach(x => { ring += 'M' + r1(x) + ' ' + r1(yT(x) + 1) + 'Q' + r1(x + 3) + ' ' + r1((yT(x) + yF(x)) / 2) + ' ' + r1(x + 1) + ' ' + r1(yF(x) - 1); });
  s += E.p(ring, null, p.line, 0.7, 'opacity=".7"');
  const rear = BOT.slice(0, 3).concat([]), rr = sk_offset(sk_spline([[196, 168], [226, 166], [246, 160], [252, 146], [248, 130]], 6), -5);
  s += E.p(polyD(rr), null, p.line, 0.7, 'opacity=".6"');
  void rear;
  /* courte pointe génale */
  s += E.p(taperD([[92, 169], [106, 173], [118, 175]], 4, 0.6), p.body, p.line, 0.8);
  /* tige proche et œil à lentilles */
  s += E.p(taperD([[80, 97], [78, 64], [75, 34]], 7.5, 5), p.body2, p.line, 1) + E.p('M78.5 92L76.8 60', null, p.hi, 1.2, 'opacity=".6"');
  s += E.el(72, 27, 14, 9, -14, p.accent, p.line, 1.1);
  let lens = '';
  for (let r = 0; r < 3; r++) for (let c = 0; c < 6; c++) { const a = (-150 + c * 26) * D2R, rad = 3 + r * 2.4; lens += 'M' + r1(72 + Math.cos(a) * rad * 1.35) + ' ' + r1(27 + 2 + Math.sin(a) * rad * 0.62) + 'h.1'; }
  s += E.p(lens, null, p.hi, 1.5, 'opacity=".75"');
  /* reflet */
  s += E.p(polyD(sk_offset(top.slice(4, 22), 4.5)), null, p.hi, 2, 'opacity=".65"');
  return s;
}

/* endoceras — Endoceras giganteum, orthocône géant, coupe polie.
   ① coquille conique droite ; ② septa concaves vers l'ouverture, serrés vers l'apex ; ③ large siphon ventral à endocônes ;
   ④ chambre d'habitation sans cloisons ; ⑤ stries de croissance ; ouverture ovale */
function artEndoceras(p) {
  const A = [14, 80], B = [300, 66], L = Math.hypot(B[0] - A[0], B[1] - A[1]), u = [(B[0] - A[0]) / L, (B[1] - A[1]) / L], n = [-u[1], u[0]];
  const R = s => 4 + 44 * Math.pow(s, 0.8), C = s => [A[0] + u[0] * L * s, A[1] + u[1] * L * s];
  const up = (s, k) => { const c = C(s), r = R(s) * (k == null ? 1 : k); return [c[0] - n[0] * r, c[1] - n[1] * r]; };
  const dn = (s, k) => { const c = C(s), r = R(s) * (k == null ? 1 : k); return [c[0] + n[0] * r, c[1] + n[1] * r]; };
  const ctl = (s, k) => { const c = C(s), r = R(s); return [c[0] - u[0] * r * k, c[1] - u[1] * r * k]; };
  const S = []; for (let i = 0; i <= 50; i++) S.push(i / 50);
  const outline = [[A[0] - 3, A[1] + 0.2]].concat(S.slice(1).map(s => up(s)), S.slice(1).reverse().map(s => dn(s)));
  let s = E.p(smoothD(outline, true), p.body, p.line, 1.4);
  /* chambres alternées, septa */
  const sep = []; let x = 0.8; while (x > 0.035) { sep.push(x); x -= 0.5 * R(x) / L; }
  let cam = '', sp = '';
  for (let k = 0; k < sep.length; k++) {
    const s2 = sep[k], d2 = 'M' + PS(up(s2)) + 'Q' + PS(ctl(s2, 0.62)) + ' ' + PS(dn(s2));
    sp += d2;
    if (k % 2 === 0 && k + 1 < sep.length) { const s1 = sep[k + 1]; cam += 'M' + PS(up(s1)) + 'L' + PS(up(s2)) + 'Q' + PS(ctl(s2, 0.62)) + ' ' + PS(dn(s2)) + 'L' + PS(dn(s1)) + 'Q' + PS(ctl(s1, 0.62)) + ' ' + PS(up(s1)) + 'Z'; }
  }
  s += E.p(cam, p.relief, null, 0, 'opacity="' + (p.flat ? 1 : 0.5) + '"') + E.p(sp, null, p.line, 0.8);
  /* siphon et endocônes */
  const s0 = 0.03, s1 = 0.8, sipIn = [], sipOut = [];
  for (let i = 0; i <= 30; i++) { const t = s0 + (s1 - s0) * i / 30; sipIn.push(dn(t, 0.34)); sipOut.push(dn(t, 0.94)); }
  s += E.p(polyD(sipIn.concat(sipOut.slice().reverse()), true), p.shade, p.line, 0.9);
  let cone = ''; x = s1 - 0.02;
  while (x > s0 + 0.02) { const dx = 0.45 * R(x) / L; cone += 'M' + PS(dn(x + dx * 0.6, 0.9)) + 'L' + PS(dn(x - dx * 0.4, 0.64)) + 'L' + PS(dn(x + dx * 0.6, 0.38)); x -= dx; }
  s += E.p(cone, null, p.hi, 0.8, 'opacity=".55"');
  /* chambre d'habitation : stries de croissance */
  let gr = '';
  for (let t = 0.815; t < 0.985; t += 0.02) gr += 'M' + PS(up(t)) + 'Q' + PS([C(t)[0] + u[0] * R(t) * 0.25, C(t)[1] + u[1] * R(t) * 0.25]) + ' ' + PS(dn(t));
  s += E.p(gr, null, p.line, 0.5, 'opacity=".45"');
  /* ouverture */
  const c1 = C(1), ang = Math.atan2(u[1], u[0]) / D2R;
  s += E.el(c1[0], c1[1], R(1) * 0.26, R(1), ang, p.shade, p.line, 1.2) + E.el(c1[0] + u[0] * 1.5, c1[1] + u[1] * 1.5, R(1) * 0.16, R(1) * 0.8, ang, p.accent, null);
  /* reflet */
  s += E.p('M' + PS(up(0.12, 0.72)) + 'L' + PS(up(0.78, 0.72)), null, p.hi, 2, 'opacity=".6"');
  return s;
}

/* isotelus — Isotelus rex, pièce unique, vue dorsale.
   ① céphalon semi-circulaire lisse, angles génaux arrondis ; ② petits yeux en croissant très écartés ; ③ thorax de 8 segments ;
   ④ grand pygidium lisse aussi grand que le céphalon ; ⑤ bourrelet et lignes de terrasse le long du bord */
function artIsotelus(p) {
  const cx = 116, arc = (ox, oy, rx, ry, a0, a1, n) => { const o = []; for (let i = 0; i <= n; i++) { const a = lerp(a0, a1, i / n); o.push([ox + rx * Math.cos(a), oy + ry * Math.sin(a)]); } return o; };
  const cephL = arc(cx, 104, 98, 90, 1.5 * Math.PI, Math.PI, 16), pygL = arc(cx, 180, 92, 118, Math.PI, Math.PI / 2, 16);
  const aw = y => lerp(37, 30, (y - 104) / 76), xs = y => lerp(19, 24, (y - 104) / 76);
  let s = '';
  /* pygidium */
  const pyg = (col) => E.p(polyD([[cx, 178]].concat(pygL), true), col, p.line, 1.3);
  s += pyg(p.body) + mirrorG(pyg(p.body2), cx);
  const pygRim = pygL.map(q => [cx + (q[0] - cx) * 0.9, 180 + (q[1] - 180) * 0.92]);
  s += E.p(polyD(pygRim), null, p.line, 0.8, 'opacity=".7"') + mirrorG(E.p(polyD(pygRim), null, p.line, 0.8, 'opacity=".7"'), cx);
  s += E.p(taperD([[cx, 182], [cx, 222], [cx, 262]], 58, 8), p.relief, null, 0, 'opacity="' + (p.flat ? 1 : 0.55) + '"');
  s += E.p('M' + (cx - 26) + ' 196Q' + cx + ' 191 ' + (cx + 26) + ' 196M' + (cx - 19) + ' 212Q' + cx + ' 207 ' + (cx + 19) + ' 212', null, p.line, 0.6, 'opacity=".45"');
  /* thorax : 8 segments, de l'arrière vers l'avant */
  const pleura = col => {
    let o = '';
    for (let k = 7; k >= 0; k--) {
      const y0 = 104 + k * 9.5, y1 = y0 + 9.5, xa = cx - aw(y0), xe = xs(y0);
      o += E.p(smoothD([[xa, y0], [xe + 4, y0 + 2.5], [xe - 0.5, y0 + 6.5], [xe + 3, y1 + 2.6], [xa, y1]], true), col, p.line, 0.9);
      o += E.p('M' + r1(xa - 1) + ' ' + r1(y0 + 3.6) + 'L' + r1(xe + 10) + ' ' + r1(y0 + 6), null, p.line, 0.6, 'opacity=".7"') + E.p('M' + r1(xe + 3) + ' ' + r1(y0 + 3) + 'l3 5', null, p.line, 0.5, 'opacity=".6"');
    }
    return o;
  };
  s += pleura(p.body) + mirrorG(pleura(p.body2), cx);
  let rings = '';
  for (let k = 7; k >= 0; k--) { const y0 = 104 + k * 9.5, y1 = y0 + 9.5, a = aw(y0); rings += E.p('M' + r1(cx - a) + ' ' + r1(y0) + 'Q' + cx + ' ' + r1(y0 - 3) + ' ' + r1(cx + a) + ' ' + r1(y0) + 'L' + r1(cx + a) + ' ' + r1(y1) + 'Q' + cx + ' ' + r1(y1 - 3) + ' ' + r1(cx - a) + ' ' + r1(y1) + 'Z', p.relief, p.line, 0.9); }
  s += rings;
  /* céphalon */
  const ceph = col => E.p(polyD([[cx, 106]].concat(cephL, [[20, 106]]), true), col, p.line, 1.3);
  s += ceph(p.body) + mirrorG(ceph(p.body2), cx);
  const rim = cephL.map(q => [cx + (q[0] - cx) * 0.9, 104 + (q[1] - 104) * 0.88]), terr = cephL.map(q => [cx + (q[0] - cx) * 0.95, 104 + (q[1] - 104) * 0.94]);
  const half = E.p(polyD(rim), null, p.line, 0.9) + E.p(polyD(terr), null, p.line, 0.5, 'opacity=".45"');
  s += half + mirrorG(half, cx);
  /* glabelle effacée, yeux, sutures faciales */
  s += E.p('M' + (cx - 30) + ' 104Q' + (cx - 38) + ' 58 ' + (cx - 20) + ' 34Q' + cx + ' 24 ' + (cx + 20) + ' 34Q' + (cx + 38) + ' 58 ' + (cx + 30) + ' 104Z', p.relief, null, 0, 'opacity="' + (p.flat ? 1 : 0.35) + '"');
  const eye = E.el(cx - 50, 66, 9, 6.5, -10, p.relief, p.line, 0.8) + E.p('M' + (cx - 57) + ' 62Q' + (cx - 60) + ' 67 ' + (cx - 55) + ' 71Q' + (cx - 53) + ' 66 ' + (cx - 55) + ' 62Z', p.accent, p.line, 0.6) +
    E.p('M' + (cx - 46) + ' 60Q' + (cx - 40) + ' 40 ' + (cx - 26) + ' 20', null, p.line, 0.6, DASH) + E.p('M' + (cx - 48) + ' 73Q' + (cx - 56) + ' 90 ' + (cx - 64) + ' 104', null, p.line, 0.6, DASH);
  s += eye + mirrorG(eye, cx);
  /* reflet */
  s += E.p('M40 72Q56 38 96 24', null, p.hi, 2.4, 'opacity=".7"') + E.p('M36 196Q40 232 62 258', null, p.hi, 1.8, 'opacity=".45"');
  return s;
}

/* dunkleosteus — Dunkleosteus terrelli, pièce unique : tête et bouclier cuirassés, de profil (tête à gauche).
   ① casque de plaques avec sutures ; ② grande orbite cerclée ; ③ crocs osseux en bec, lame mandibulaire, bouche entrouverte ;
   ④ articulation crâne-thorax ; ⑤ bouclier thoracique et encoche pectorale ; corps esquissé en film */
function artDunkleosteus(p) {
  const rnd = mulberry32(hashStr('dunkleosteus'));
  const HEAD = [[28, 118], [25, 98], [33, 78], [50, 60], [76, 46], [110, 38], [148, 35], [172, 40], [180, 58], [178, 86], [171, 110], [160, 127], [146, 134], [120, 128], [92, 124], [66, 122], [46, 122], [34, 122]];
  const THOR = [[170, 40], [206, 37], [238, 45], [254, 66], [256, 98], [248, 128], [230, 154], [202, 168], [172, 168], [156, 156], [150, 140], [160, 127], [171, 110], [178, 86], [180, 58]];
  let s = '';
  /* corps en film derrière la cuirasse */
  s += sk_film([[236, 48], [262, 60], [286, 78], [297, 96], [292, 116], [270, 134], [240, 148]], p, 0.6);
  s += E.p('M258 70Q280 84 292 100', null, p.line, 0.7, 'opacity=".35"');
  /* bouclier thoracique */
  s += E.p(smoothD(THOR, true), p.shade, p.line, 1.3);
  s += E.p('M206 38Q214 96 200 166M160 128Q206 118 248 126M226 44Q234 60 252 70', null, p.line, 0.9);
  s += E.p('M244 138Q232 146 234 158Q244 156 248 146Z', p.accent, p.line, 0.8);
  /* mâchoire inférieure (lame) */
  const JAW = [[152, 138], [122, 143], [84, 147], [58, 147], [48, 136], [43, 139], [41, 152], [54, 161], [92, 161], [130, 157], [155, 150]];
  s += E.p(polyD([[46, 124], [100, 127], [148, 134], [150, 139], [122, 143], [84, 147], [56, 147]], true), p.accent, null, 0, 'opacity="' + (p.flat ? 1 : 0.8) + '"');
  s += E.p(smoothD(JAW, true), p.relief, p.line, 1.1) + E.p('M60 150Q100 154 148 146', null, p.line, 0.6, 'opacity=".6"');
  /* casque */
  s += E.p(smoothD(HEAD, true), p.body, p.line, 1.4);
  s += E.p('M92 40Q100 70 90 98M131 36Q138 76 124 104M100 70Q118 72 136 76M40 104Q70 98 92 100Q126 104 162 116M150 36Q164 64 174 96', null, p.line, 0.9);
  /* croc supérieur en bec et lame postérieure */
  s += E.p('M30 110L46 116L42 134L35 146L29 132Z', p.relief, p.line, 1) + E.p('M48 122L100 126L102 131L50 128Z', p.relief, p.line, 0.8);
  /* orbite et anneau sclérotique */
  s += E.c(70, 80, 21, p.relief, p.line, 1) + E.p('M70 59V67M91 80H83M70 101V93M49 80H57', null, p.line, 0.8) + E.c(70, 80, 13, p.accent, p.line, 1) + E.c(65, 75, 3.4, p.hi, null, 0, 'opacity=".7"');
  /* articulation crâne-thorax */
  s += E.c(177, 50, 6, p.relief, p.line, 0.9);
  /* tubercules */
  s += sk_dots(rnd, HEAD, 70, 0.8, p.line, 0.4) + sk_dots(rnd, THOR, 60, 0.8, p.line, 0.4);
  /* reflet */
  s += E.p('M40 84Q60 54 104 42', null, p.hi, 2.4, 'opacity=".7"') + E.p('M184 48Q214 42 236 52', null, p.hi, 1.8, 'opacity=".5"');
  return s;
}

/* meganeura — Meganeura monyi, libellule géante, vue de dessus.
   ① gros yeux composés ; ② thorax court ; ③ long abdomen de 10 segments ; ④ 4 ailes longues et étroites ; ⑤ nervation en réseau */
function artMeganeura(p) {
  const cx = 160, rnd = mulberry32(hashStr('meganeura'));
  const wing = (B, T, C) => {
    const L = Math.hypot(T[0] - B[0], T[1] - B[1]), u = [(T[0] - B[0]) / L, (T[1] - B[1]) / L], nf = [u[1], -u[0]];
    const ch = t => C * (0.42 + 0.58 * Math.sin(Math.PI * Math.min(1, t * 1.25) / 2)) * (t > 0.86 ? Math.sqrt(Math.max(0.02, 1 - Math.pow((t - 0.86) / 0.14, 2))) : 1);
    const at = (t, v) => { const c = [B[0] + u[0] * L * t, B[1] + u[1] * L * t], w = ch(t), o = w * 0.16 - v * w; return [c[0] + nf[0] * o, c[1] + nf[1] * o]; };
    const N = 36, lead = [], trail = [];
    for (let i = 0; i <= N; i++) { const t = i / N; lead.push(at(t, 0)); trail.push(at(t, 1)); }
    let o = E.p(smoothD(lead.concat(trail.slice().reverse()), true), p.film, p.line, 1, 'fill-opacity="' + (p.flat ? 1 : p.filmOp) + '"');
    const V = [0.1, 0.24, 0.42, 0.62, 0.8];
    let lv = '', cv = '';
    V.forEach(v => { let d = ''; for (let i = 0; i <= N - 2; i++) d += (i ? 'L' : 'M') + PS(at(i / N, v)); lv += d; });
    for (let j = 0; j < V.length - 1; j++) for (let t = 0.05; t < 0.93; t += 0.045 + rnd() * 0.012) { const a = at(t, V[j]), b = at(t + (rnd() - 0.5) * 0.012, V[j + 1]); cv += 'M' + PS(a) + 'L' + PS(b); }
    for (let t = 0.1; t < 0.9; t += 0.05 + rnd() * 0.02) cv += 'M' + PS(at(t, 0.8)) + 'L' + PS(at(t + 0.01, 1));
    o += E.p(cv, null, p.line, 0.45, 'opacity=".7"') + E.p(lv, null, p.line, 0.8) + E.p(polyD(lead.slice(2, N - 3)), null, p.hi, 1.3, 'opacity=".55"');
    o += E.p('M' + PS(at(0.46, 0)) + 'l' + r1(-nf[0] * 3) + ' ' + r1(-nf[1] * 3), null, p.line, 1.2);
    return o;
  };
  const wings = wing([cx - 12, 64], [18, 50], 25) + wing([cx - 12, 80], [22, 118], 29);
  let s = wings + mirrorG(wings, cx);
  /* pattes */
  s += E.p('M150 66l-10 4 -4 8M150 74l-11 6 -2 9M151 82l-8 9 0 8', null, p.line, 1.1) + mirrorG(E.p('M150 66l-10 4 -4 8M150 74l-11 6 -2 9M151 82l-8 9 0 8', null, p.line, 1.1), cx);
  /* abdomen de 10 segments */
  let ab = '';
  for (let k = 0; k < 10; k++) { const y0 = 86 + k * 12, w0 = lerp(6.2, 3.6, k / 9); ab += E.p('M' + r1(cx - w0) + ' ' + r1(y0 + 1) + 'Q' + cx + ' ' + r1(y0 - 1.5) + ' ' + r1(cx + w0) + ' ' + r1(y0 + 1) + 'L' + r1(cx + w0 * 0.92) + ' ' + r1(y0 + 12) + 'Q' + cx + ' ' + r1(y0 + 13.5) + ' ' + r1(cx - w0 * 0.92) + ' ' + r1(y0 + 12) + 'Z', k % 2 ? p.body2 : p.body, p.line, 0.8); }
  s += ab + E.p('M158 206l-4 9M162 206l4 9', null, p.line, 1.2);
  /* thorax, tête et yeux */
  s += E.el(cx, 71, 13, 17, 0, p.body, p.line, 1.1) + E.p('M' + (cx - 8) + ' 62Q' + cx + ' 58 ' + (cx + 8) + ' 62', null, p.relief, 1.4, 'opacity=".7"');
  s += E.el(cx, 50, 8, 5, 0, p.relief, p.line, 0.9) + E.c(cx - 9, 42, 9.5, p.body, p.line, 1) + E.c(cx + 9, 42, 9.5, p.body2, p.line, 1) + E.c(cx - 11.5, 39, 3, p.hi, null, 0, 'opacity=".6"');
  return s;
}

Object.assign(ART, {
  asaphus: { vb: [280, 200], fn: artAsaphus, area: { cx: 140, cy: 118, rx: 124, ry: 70 } },
  endoceras: { vb: [320, 140], fn: artEndoceras, area: { cx: 158, cy: 72, rx: 150, ry: 44, rot: -0.049 } },
  isotelus: { vb: [232, 312], fn: artIsotelus, area: { cx: 116, cy: 156, rx: 100, ry: 142 } },
  dunkleosteus: { vb: [300, 220], fn: artDunkleosteus, area: { cx: 150, cy: 100, rx: 136, ry: 70 } },
  meganeura: { vb: [320, 220], fn: artMeganeura, area: { cx: 160, cy: 108, rx: 150, ry: 78 } }
});
