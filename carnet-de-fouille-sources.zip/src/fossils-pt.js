/* ============ fossiles : Permien, Trias ============ */

/* ---------- aides (préfixe pt_) ---------- */
function pt_fo(p, o) { return 'fill-opacity="' + (p.flat ? 1 : o) + '"'; }
function pt_op(p, o) { return 'opacity="' + (p.flat ? 1 : o) + '"'; }
function pt_ad(a, v, k) { return [a[0] + v[0] * k, a[1] + v[1] * k]; }
function pt_nr(t) { return [t[1], -t[0]]; }
function pt_dir(a) { return [Math.cos(a), Math.sin(a)]; }
function pt_mid(a, b) { return [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]; }
function pt_qp(a, b, c, u) { const v = 1 - u; return [v * v * a[0] + 2 * v * u * b[0] + u * u * c[0], v * v * a[1] + 2 * v * u * b[1] + u * u * c[1]]; }
function pt_qt(a, b, c, u) { const v = 1 - u, x = 2 * v * (b[0] - a[0]) + 2 * u * (c[0] - b[0]), y = 2 * v * (b[1] - a[1]) + 2 * u * (c[1] - b[1]), l = Math.hypot(x, y) || 1; return [x / l, y / l]; }
/* point à la fraction f (0–1) d'une polyligne, par indice */
function pt_at(pts, f) { const x = clamp(f, 0, 1) * (pts.length - 1), i = Math.min(pts.length - 2, Math.floor(x)); return lerpPt(pts[i], pts[i + 1], x - i); }
/* nombre au dixième, sans zéro inutile */
function pt_n1(v) { let s = String(Math.round(v * 10) / 10); if (s === '-0') s = '0'; return s.replace(/^(-?)0\./, '$1.'); }
/* constructeur de chemin compact : commandes relatives, arrondies au dixième, sans dérive */
function pt_B() {
  let d = '', cx = 0, cy = 0, sx = 0, sy = 0, last = '';
  const R = v => Math.round(v * 10) / 10;
  const nums = a => a.map((v, i) => { const s = pt_n1(v); return i && s[0] !== '-' ? ' ' + s : s; }).join('');
  const cmd = (c, a) => { const s = nums(a); d += c === last ? (s[0] === '-' ? '' : ' ') + s : c + s; last = c; };
  const P = {
    M(q) { const x = R(q[0]), y = R(q[1]); if (!d) { d = 'M' + nums([x, y]); last = 'M'; } else { cmd('m', [x - cx, y - cy]); last = 'm'; } cx = sx = x; cy = sy = y; return P; },
    L(q) { const x = R(q[0]), y = R(q[1]); cmd('l', [x - cx, y - cy]); cx = x; cy = y; return P; },
    Q(c, q) { const x = R(q[0]), y = R(q[1]); cmd('q', [R(c[0]) - cx, R(c[1]) - cy, x - cx, y - cy]); cx = x; cy = y; return P; },
    C(c1, c2, q) { const x = R(q[0]), y = R(q[1]); cmd('c', [R(c1[0]) - cx, R(c1[1]) - cy, R(c2[0]) - cx, R(c2[1]) - cy, x - cx, y - cy]); cx = x; cy = y; return P; },
    Z() { d += 'z'; last = 'z'; cx = sx; cy = sy; return P; },
    pl(pts, close) { P.M(pts[0]); for (let i = 1; i < pts.length; i++) P.L(pts[i]); if (close) P.Z(); return P; },
    sm(pts, close) {
      const n = pts.length;
      if (n < 3) return P.pl(pts, close);
      const g = i => (close ? pts[(i + n) % n] : pts[clamp(i, 0, n - 1)]);
      P.M(pts[0]);
      for (let i = 0; i < (close ? n : n - 1); i++) {
        const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2);
        P.C([p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6], [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6], p2);
      }
      if (close) P.Z();
      return P;
    },
    d() { return d; }
  };
  return P;
}
function pt_sm(pts, close) { return pt_B().sm(pts, close).d(); }
function pt_taper(pts, w0, w1, prof) { return pt_sm(taperPts(pts, w0, w1, prof), true); }
/* croissant de a à b : centre bombé de « bend » (côté normale gauche), épaisseur max w */
function pt_lens(B, a, b, bend, w) {
  const m = pt_mid(a, b), L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1, n = [(b[1] - a[1]) / L, -(b[0] - a[0]) / L];
  return B.M(a).Q(pt_ad(m, n, 2 * bend + w), b).Q(pt_ad(m, n, 2 * bend - w), a).Z();
}
/* épine : base b de largeur w, pointe t, courbure bend */
function pt_spike(B, b, t, w, bend) {
  const L = Math.hypot(t[0] - b[0], t[1] - b[1]) || 1, d = [(t[0] - b[0]) / L, (t[1] - b[1]) / L], n = [d[1], -d[0]];
  const m = pt_ad(pt_mid(b, t), n, bend);
  return B.M(pt_ad(b, n, w / 2)).Q(pt_ad(m, n, w * 0.32), t).Q(pt_ad(m, n, -w * 0.32), pt_ad(b, n, -w / 2)).Z();
}
/* os long : diaphyse de largeur w, épiphyses k·w */
function pt_bone(B, a, b, w, k) {
  const L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1, d = [(b[0] - a[0]) / L, (b[1] - a[1]) / L], n = [d[1], -d[0]];
  const h = w / 2, K = h * (k || 1.5), e = Math.min(L * 0.3, K * 1.7);
  const P = (o, dd, nn) => [o[0] + d[0] * dd + n[0] * nn, o[1] + d[1] * dd + n[1] * nn];
  return B.sm([P(a, -K * 0.6, 0), P(a, 0, K), P(a, e, h), P(b, -e, h), P(b, 0, K), P(b, K * 0.6, 0), P(b, 0, -K), P(b, -e, -h), P(a, e, -h), P(a, 0, -K)], true);
}

/* ---------------- Glossopteris indica — feuille en langue ----------------
   Fiche anatomique :
   ① feuille en langue / spatule : pétiole étroit, limbe cunéiforme qui s'élargit jusqu'aux 2/3, sommet arrondi, bord entier ;
   ② nervure médiane nette, faisceau de 3 brins parallèles, de la base jusqu'aux 9/10 de la feuille ;
   ③ nervures secondaires serrées, en angle aigu (~20°) sur la médiane, arquées vers le bord qu'elles abordent presque à angle droit ;
   ④ anastomoses : les secondaires se soudent en réseau à mailles étroites et allongées (signature du genre) ;
   ⑤ une seconde feuille, plus petite, passe en biais derrière ; film de carbone sombre. */
function pt_glossLeaf(p, P0, P1, P2, W, nv, seed, fill, main) {
  const rnd = mulberry32(seed), u0 = 0.05, um = 0.66, k = W / 40;
  const wf = u => {
    if (u <= u0) return 2.4 * k;
    if (u < um) return Math.max(2.4 * k, W * Math.pow(Math.sin((u - u0) / (um - u0) * Math.PI / 2), 1.6));
    const x = Math.min(1, (u - um) / (1 - um));
    return W * Math.sqrt(Math.max(0, 1 - Math.pow(x, 2.2)));
  };
  const mw = u => lerp(3.6, 0.9, u) * k;
  const at = (u, v) => { const q = pt_qp(P0, P1, P2, u), t = pt_qt(P0, P1, P2, u); return [q[0] - t[1] * v, q[1] + t[0] * v]; };
  /* contour : échantillonnage serré vers le sommet arrondi */
  const us = [];
  for (let i = 0; i <= 14; i++) us.push(um * i / 14);
  for (let j = 1; j <= 10; j++) us.push(um + (1 - um) * Math.sin(j / 10 * Math.PI / 2));
  const Lf = us.map(u => at(u, -wf(u))), Rt = us.slice(0, -1).map(u => at(u, wf(u)));
  let s = E.p(pt_sm(Lf.concat(Rt.reverse()), true), fill, p.line, main ? 1.3 : 1.1);
  /* nervures secondaires : départ aigu sur la médiane, arquées vers le bord */
  const veins = [[], []], vd = pt_B();
  [-1, 1].forEach((sd, si) => {
    for (let q = 0; q < nv; q++) {
      const ua = 0.06 + 0.86 * (q + 0.3 + 0.4 * rnd()) / nv, A = 0.28 * Math.sqrt(1 - ua), pts = [];
      for (let j = 0; j <= 5; j++) {
        const f = j / 5, u = Math.min(0.995, ua + A * (0.85 * (1 - Math.pow(1 - f, 1.8)) + 0.15 * f));
        const m = mw(u), w = wf(u) * 0.96;
        pts.push(at(u, sd * (m + f * Math.max(0, w - m))));
      }
      veins[si].push(pts);
      vd.pl(pts);
    }
  });
  /* anastomoses en quinconce : liens obliques entre nervures voisines → mailles étroites et allongées */
  const ld = pt_B();
  veins.forEach(side => {
    for (let q = 0; q + 1 < side.length; q++) {
      for (let f = 0.08 + 0.1 * (q % 2) + 0.05 * rnd(); f < 0.9; f += 0.2 + 0.04 * rnd()) ld.M(pt_at(side[q], f)).L(pt_at(side[q + 1], Math.min(0.97, f + 0.07)));
    }
  });
  s += E.p(vd.d(), null, p.line, main ? 0.55 : 0.5, pt_op(p, 0.62)) + E.p(ld.d(), null, p.line, 0.5, pt_op(p, 0.55));
  /* nervure médiane : faisceau de brins */
  const mu = [], mid = [];
  for (let i = 0; i <= 18; i++) { const u = 0.9 * i / 18; mu.push(u); mid.push(pt_qp(P0, P1, P2, u)); }
  s += E.p(pt_taper(mid, mw(0) * 2, mw(0.9) * 1.2), p.shade, p.line, 0.6);
  const st = pt_B();
  [-0.45, 0.45].forEach(o => st.pl(mu.slice(0, 17).map(u => at(u, o * mw(u)))));
  s += E.p(st.d(), null, p.line, 0.55, pt_op(p, 0.85)) + E.p(pt_B().pl(mu.slice(1, 15).map(u => at(u, 0))).d(), null, p.relief, 0.7, pt_op(p, 0.75));
  if (main) s += E.p(pt_B().sm(us.filter(u => u > 0.4 && u < 0.88).map(u => at(u, -(wf(u) - 4.5 * k)))).d(), null, p.hi, 1.5, pt_op(p, 0.6));
  return s;
}
function artGlossopteris(p) {
  let s = pt_glossLeaf(p, [178, 94], [118, 150], [34, 252], 26, 18, hashStr('glossopteris-b'), p.body2, false);
  s += pt_glossLeaf(p, [118, 272], [120, 150], [90, 12], 41, 30, hashStr('glossopteris'), p.body, true);
  return s;
}

/* ---------------- Walchia piniformis — l'un des premiers conifères ----------------
   Fiche anatomique :
   ① axe principal (rameau d'avant-dernier ordre) un peu courbe, qui monte, plus épais à la base ;
   ② rameaux latéraux alternes, tous dans un même plan (penné), à ~60° de l'axe, réguliers,
      de plus en plus courts vers le sommet : silhouette de plume triangulaire ;
   ③ rameaux et axe hérissés de minuscules feuilles en aiguille, serrées, recourbées vers l'avant (en crochet),
      des deux côtés : chaque rameau est une bande dentelée ;
   ④ film de carbone (aplat sombre, sans relief) ; allure d'araucaria. */
function pt_brush(B, pts, hw0, hw1, step, rnd) {
  /* bande dentelée : aiguilles en crochet pointées vers l'extrémité (montée douce, chute raide), des deux côtés */
  const L = arcLen(pts), n = Math.max(3, Math.round(L / step)), rs = resample(pts, 8 * n + 1);
  const side = sd => {
    const o = [];
    for (let i = 0; i < n; i++) {
      const f = i / n, hw = lerp(hw0, hw1, f) * (f > 0.68 ? 1 - (f - 0.68) * 1.7 : 1) * (0.86 + 0.24 * rnd());
      const ja = 8 * i, jb = 8 * i + 5 + Math.floor(rnd() * 3);
      o.push(pt_ad(rs[ja], pt_nr(tangentAt(rs, ja)), sd * hw * 0.32), pt_ad(rs[jb], pt_nr(tangentAt(rs, jb)), sd * hw));
    }
    o.push(pt_ad(rs[8 * n], pt_nr(tangentAt(rs, 8 * n)), sd * hw1 * 0.3));
    return o;
  };
  const t = tangentAt(rs, 8 * n), tip = pt_ad(rs[8 * n], t, hw1 * 0.9);
  return B.pl(side(1).concat([tip], side(-1).reverse()), true);
}
function artWalchia(p) {
  const rnd = mulberry32(hashStr('walchia'));
  const A0 = [118, 272], A1 = [128, 150], A2 = [102, 12];
  const ax = []; for (let i = 0; i <= 40; i++) ax.push(pt_qp(A0, A1, A2, i / 40));
  const br = pt_B(), stem = pt_B();
  const nb = 26;
  for (let i = 0; i < nb; i++) {
    const u = 0.09 + 0.85 * i / (nb - 1), sd = i % 2 ? 1 : -1;
    const q = pt_qp(A0, A1, A2, u), t = pt_qt(A0, A1, A2, u);
    const L = 7 + 86 * Math.pow(1 - u, 0.95) * (0.94 + 0.12 * rnd());
    const d = pt_dir(Math.atan2(t[1], t[0]) + sd * 60 * D2R), up = pt_ad([0, 0], pt_nr(d), sd);
    const e = pt_ad(q, d, L), c = pt_ad(pt_mid(q, e), up, L * 0.06);
    const pts = quadPts(q, c, e, 10);
    pt_brush(br, pts, 5.4, 3.6, 3.7, rnd);
    stem.pl(pts.slice(0, 9));
  }
  let s = E.p(br.d(), p.body, p.line, 0.55);
  s += E.p(stem.d(), null, p.line, 0.7, pt_op(p, 0.7));
  s += E.p(pt_brush(pt_B(), ax.slice(2, 40), 8, 4.4, 3.9, rnd).d(), p.body, p.line, 0.6);
  s += E.p(pt_taper(ax, 5.6, 1.2), p.shade, p.line, 0.8);
  s += E.p(pt_B().sm(ax.slice(6, 30).map((q, i) => { const t = tangentAt(ax, i + 6); return [q[0] + t[1] * 1.1, q[1] - t[0] * 1.1]; })).d(), null, p.hi, 0.9, pt_op(p, 0.6));
  return s;
}

/* ---------------- Helicoprion bessonowi — spirale dentaire ----------------
   Fiche anatomique :
   ① spirale logarithmique d'un peu plus de 3 tours (r = a·e^(bθ)) ; les tours sont jointifs : les pointes d'un tour
      touchent la racine du tour suivant ; centre petit ;
   ② dents triangulaires tranchantes sur le bord externe, pointées vers l'extérieur et vers l'avant (vers l'extrémité libre),
      bords dentelés, de plus en plus grandes vers l'extérieur, à pas angulaire constant (18 par tour, ≈ 55 visibles) ;
   ③ racine : bande spirale (la « tige ») où les bases se soudent ; chaque base se prolonge en chevron sous la dent précédente ;
   ④ dents centrales minuscules (arc juvénile) ;
   ⑤ extrémité externe ouverte : la tige dépasse la dernière dent, les dernières couronnes à peine formées. */
function artHelicoprion(p) {
  const G = 1.9, b = Math.log(G) / TAU, thE = 3.1 * TAU, dth = TAU / 19, rot = 2.4, th0 = -0.3 * TAU, cf = 0.38;
  const Tn = th => Math.exp(b * (th - thE));
  /* boîte englobante du dernier tour → échelle et centrage */
  let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
  for (let th = thE - TAU; th <= thE; th += 0.02) {
    const r = Tn(th), x = r * Math.cos(th + rot), y = r * Math.sin(th + rot);
    x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y);
  }
  const K = 222 / Math.max(x1 - x0, y1 - y0), ox = 120 - K * (x0 + x1) / 2, oy = 120 - K * (y0 + y1) / 2;
  /* T : pointes ; I : bord interne de la tige (= pointes du tour précédent) ; Bs : bases des couronnes */
  const T = th => K * Tn(th), I = th => T(th) / G, Bs = th => I(th) + cf * (T(th) - I(th));
  const pol = (r, th) => [ox + r * Math.cos(th + rot), oy + r * Math.sin(th + rot)];
  const thL = thE - 1.75 * dth;
  /* tige : bande spirale entre I et Bs, coupée net à l'extrémité */
  const out = [], inn = [];
  for (let th = th0; th < thE; th += clamp(4.5 / Bs(th), 0.04, 0.5)) { out.push(pol(Bs(th), th)); inn.push(pol(I(th), th)); }
  out.push(pol(Bs(thE), thE)); inn.push(pol(I(thE), thE - 0.05));
  let s = E.p(pt_B().pl(out.concat(inn.reverse()), true).d(), p.body, p.line, 1.2);
  /* couronnes : bord arrière long, pointe portée vers l'avant, bord avant court et bombé, bords dentelés */
  const zz = pt_B();
  const serr = (pts, a, c, h, sgn) => {
    const n = Math.max(2, Math.round(Math.hypot(c[0] - a[0], c[1] - a[1]) / 2.2)), dx = (c[0] - a[0]) / n, dy = (c[1] - a[1]) / n, l = Math.hypot(dx, dy) || 1;
    const nx = -dy / l * sgn, ny = dx / l * sgn, amp = clamp(h * 0.03, 0.3, 0.75);
    for (let j = 0; j < n; j++) pts.push([a[0] + dx * (j + 0.6) + nx * amp, a[1] + dy * (j + 0.6) + ny * amp], [a[0] + dx * (j + 1), a[1] + dy * (j + 1)]);
  };
  /* chaque couronne glisse sa base sous la précédente : on dessine de l'extrémité vers le centre */
  const crowns = [];
  const tooth = (th, hf, wf) => {
    const ta = th + 0.7 * dth * wf, h = (T(ta) - Bs(ta)) * hf, tb = pt_B();
    const bk = pol(Bs(th - 0.4 * dth), th - 0.4 * dth), tp = pol(Bs(ta) + h * 0.985, ta);
    const fm = pol(Bs(th + dth * wf) + h * 0.4, th + 1.02 * dth * wf), fr = pol(Bs(th + dth * wf), th + dth * wf);
    const pts = [bk];
    if (h > 7) { serr(pts, bk, tp, h, 1); pts.pop(); pts.push(tp); serr(pts, tp, fm, h, 1); pts.push(fr); }
    else pts.push(tp, fm, fr);
    crowns.push(tb.pl(pts, true).d());
  };
  let first = true;
  for (let th = th0 + 0.1; th <= thL + 1e-6; th += dth) {
    tooth(th, 1, 1);
    /* racines : zigzag de chevrons pointés vers le centre, sous chaque couronne */
    const v = pol(lerp(I(th), Bs(th), 0.22), th + 0.35 * dth), fr = pol(Bs(th + dth), th + dth);
    if (Bs(th) - I(th) > 3) { if (first) { zz.M(pol(Bs(th), th)); first = false; } zz.L(v).L(fr); }
  }
  /* extrémité ouverte : une couronne naissante sur la tige qui dépasse */
  tooth(thL + dth, 0.4, 0.55);
  s += E.p(crowns.reverse().join(''), p.relief, p.line, 0.8);
  s += E.p(zz.d(), null, p.line, 0.65, pt_op(p, 0.8));
  s += E.p(pt_B().pl([pol(Bs(thE), thE), pol(I(thE), thE - 0.05)]).d(), null, p.line, 1.2);
  s += E.c(ox, oy, I(th0) * 0.85, p.accent);
  /* reflet : le long de la tige du dernier tour, en haut à gauche */
  const hl = [];
  for (let th = thE - TAU; th <= thE; th += 0.05) { const q = pol(lerp(I(th), Bs(th), 0.7), th); if (q[0] < ox + 14 && q[1] < oy + 4) hl.push(q); }
  if (hl.length > 2) s += E.p(pt_B().pl(hl).d(), null, p.hi, 1.5, pt_op(p, 0.6));
  return s;
}

/* ---------------- Ceratites nodosus — l'ammonite du Trias ----------------
   Fiche anatomique :
   ① coquille modérément évolute : 4 tours visibles, chaque tour ne recouvre que le bord externe du précédent,
      ombilic assez large (≈ 43 % du diamètre) ; flancs plats ;
   ② côtes radiales fortes et peu nombreuses (11 à 16 par tour), un peu flexueuses, renflées en nœuds
      près de l'ombilic et, plus gros, à l'épaulement externe (« nodosus ») ;
   ③ entre les côtes, lignes de suture cératitiques : selles arrondies, lobes au fond finement denticulé ;
   ④ dernier demi-tour (chambre d'habitation) lisse de sutures, ouverture simple ;
   ⑤ différence avec Dactylioceras : peu de côtes, larges, noueuses ; tours plus hauts ; sutures visibles. */
function artCeratites(p) {
  const cx = 110, cy = 110, R = 101, Wx = 2.1, kap = 0.1, rot = -0.35;
  const V = th => R * Math.pow(Wx, th / TAU), S = th => V(th - TAU) * (1 - kap);
  const pol = (r, th) => [cx + r * Math.cos(th + rot), cy + r * Math.sin(th + rot)];
  const at = (th, f, off) => { const rr = lerp(S(th), V(th), f); return pol(rr, th + (off || 0) / rr); };
  const thMin = -4.15 * TAU, nR = [16, 15, 13, 11];
  let s = '';
  /* ligne de suture : (f, décalage angulaire en px) ; selles vers l'avant, lobes dentelés vers l'arrière */
  const EL = [['s', 0, 0.07, 0.05], ['l', 0.07, 0.2, 0.08, 2], ['s', 0.2, 0.37, 0.12], ['l', 0.37, 0.55, 0.14, 3], ['s', 0.55, 0.77, 0.15], ['l', 0.77, 0.92, 0.11, 3], ['s', 0.92, 0.99, 0.05]];
  const suture = (B, th, fmax) => {
    const h = V(th) - S(th), pts = [];
    EL.forEach(([k, f0, f1, A, nd]) => {
      const n = k === 's' ? 6 : 2 * nd + 2;
      for (let j = pts.length ? 1 : 0; j <= n; j++) {
        const u = j / n, f = lerp(f0, f1, u);
        if (f > fmax) return;
        let o = k === 's' ? A * h * Math.pow(Math.sin(Math.PI * u), 0.6) : -A * h * Math.pow(Math.sin(Math.PI * u), 0.5);
        if (k === 'l' && j % 2 === 1 && u > 0.12 && u < 0.88) o -= h * 0.028;
        pts.push(at(th, f, o));
      }
    });
    B.pl(pts);
  };
  for (let j = 3; j >= 0; j--) {
    const a = Math.max(thMin, -(j + 1) * TAU), b = -j * TAU, ou = [], iu = [];
    for (let th = a - (j < 3 ? 0.02 : 0); th <= b + 1e-6; th += 0.06) { ou.push(pol(V(th), th)); iu.push(pol(S(th), th)); }
    if (j === 3) iu.forEach((q, k) => { iu[k] = lerpPt(pol(0, 0), q, Math.min(1, k / 8)); });
    s += E.p(pt_B().pl(ou.concat(iu.slice().reverse()), true).d(), p.body);
    /* ombre douce en bas à droite du tour */
    const sh = [];
    for (let th = a; th <= b; th += 0.06) { const q = pol(V(th), th); if (q[1] > cy + 0.25 * (q[0] - cx) - 0.4 * V(th)) sh.push(th); }
    if (sh.length > 3 && j === 0) {
      const t0 = sh[0], t1 = sh[sh.length - 1], o2 = [], i2 = [];
      for (let th = t0; th <= t1; th += 0.06) { o2.push(pol(V(th) - 1, th)); i2.push(pol(S(th) + 1, th)); }
      s += E.p(pt_B().pl(o2.concat(i2.reverse()), true).d(), p.shade, null, 0, pt_op(p, 0.35));
    }
    /* sutures : phragmocône seulement (pas sur le dernier demi-tour) */
    const su = pt_B(), dr = TAU / nR[j];
    for (let th = a + dr * 0.5; th < Math.min(b, -Math.PI) - 0.05; th += dr) suture(su, th + dr * 0.02, j === 0 ? 0.99 : 0.82);
    s += E.p(su.d(), null, p.line, j === 0 ? 0.6 : 0.45, pt_op(p, 0.85));
    /* côtes + nœuds, groupés par demi-tour pour régler l'épaisseur */
    for (let hh = 0; hh < 2; hh++) {
      const r0 = pt_B(), n0 = pt_B(), n1 = pt_B(), ha = a + hh * Math.PI, hb = ha + Math.PI;
      let w = 0, cnt = 0;
      for (let th = b - 0.12 - dr * Math.ceil((b - 0.12 - ha) / dr - 1e-6); th < hb - 1e-6; th += dr) {
        if (th < ha - 1e-6 || th < thMin + 0.4 || th > b - 0.05) continue;
        const h = V(th) - S(th); w += h; cnt++;
        const p0 = at(th, 0.1, 0), p2 = at(th, 0.8, h * 0.07), c = at(th, 0.47, -h * 0.07);
        r0.M(p0).Q(c, p2);
        n0.M(at(th, 0.06, -h * 0.01)).L(at(th, 0.13, 0));
        n1.M(at(th, 0.77, h * 0.06)).L(at(th, 0.83, h * 0.075));
      }
      if (!cnt) continue;
      w /= cnt;
      const rw = w * 0.1, nw0 = w * 0.15, nw1 = w * 0.2;
      s += E.p(r0.d(), null, p.line, r1(rw + 1.3)) + E.p(n0.d(), null, p.line, r1(nw0 + 1.3)) + E.p(n1.d(), null, p.line, r1(nw1 + 1.3));
      s += E.p(r0.d(), null, p.relief, r1(rw)) + E.p(n0.d(), null, p.relief, r1(nw0)) + E.p(n1.d(), null, p.relief, r1(nw1));
    }
    /* contours du tour : bord externe et suture ombilicale */
    s += E.p(pt_B().pl(ou).d(), null, p.line, j === 0 ? 1.5 : 1.1) + E.p(pt_B().pl(iu.slice(j === 3 ? 8 : 0)).d(), null, p.line, j === 0 ? 1.2 : 0.9);
  }
  s += E.c(cx, cy, 2.6, p.accent);
  s += E.p(pt_B().pl([pol(S(0), 0), pol(V(0), 0)]).d(), null, p.line, 1.6);
  const hl = [];
  for (let th = -TAU; th <= 0; th += 0.05) { const q = pol(V(th) - 3.2, th); if (q[0] < cx - 8 && q[1] < cy + 30) hl.push(q); }
  if (hl.length > 2) s += E.p(pt_B().pl(hl).d(), null, p.hi, 2.2, pt_op(p, 0.7));
  return s;
}

/* ---------------- registre ---------------- */
Object.assign(ART, {
  glossopteris: { vb: [200, 280], fn: artGlossopteris, area: { cx: 98, cy: 148, rx: 66, ry: 118, rot: -0.1 } },
  walchia: { vb: [220, 280], fn: artWalchia, area: { cx: 112, cy: 148, rx: 74, ry: 118 } },
  helicoprion: { vb: [240, 240], fn: artHelicoprion, area: { cx: 120, cy: 120, rx: 104, ry: 104 } },
  ceratites: { vb: [220, 220], fn: artCeratites, area: { cx: 110, cy: 110, rx: 92, ry: 92 } }
});
