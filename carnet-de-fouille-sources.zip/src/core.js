/* ============ core : hasard, bruit, géométrie, SVG ============ */
const TAU = Math.PI * 2, D2R = Math.PI / 180;

function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function hashStr(s) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function hash2(x, y, seed) {
  let h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(seed | 0, 1442695041)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}
function vnoise(x, y, seed) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi, seed), b = hash2(xi + 1, yi, seed);
  const c = hash2(xi, yi + 1, seed), d = hash2(xi + 1, yi + 1, seed);
  const ab = a + (b - a) * u, cd = c + (d - c) * u;
  return ab + (cd - ab) * v;
}
function fbm(x, y, seed, oct) {
  let amp = 0.5, fr = 1, t = 0, s = 0;
  for (let o = 0; o < oct; o++) { t += vnoise(x * fr, y * fr, seed + o * 131) * amp; s += amp; amp *= 0.5; fr *= 2.03; }
  return t / s;
}
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const lerp = (a, b, t) => a + (b - a) * t;
const smooth = t => t * t * (3 - 2 * t);
function randInt(rng, a, b) { return Math.floor(rng() * (b - a + 1)) + a; }
function pick(rng, arr) { return arr[Math.floor(rng() * arr.length)]; }
function shuffle(rng, arr) { for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; } return arr; }
function hex2rgb(h) { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
function rgb2hex(c) { return '#' + c.map(v => clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0')).join(''); }
function mixHex(a, b, t) { const A = hex2rgb(a), B = hex2rgb(b); return rgb2hex([lerp(A[0], B[0], t), lerp(A[1], B[1], t), lerp(A[2], B[2], t)]); }
function rgba(h, a) { const c = hex2rgb(h); return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }

/* ---------- géométrie ---------- */
const r1 = n => Math.round(n * 10) / 10;
const PS = p => r1(p[0]) + ' ' + r1(p[1]);
function polyD(pts, close) { let d = 'M' + PS(pts[0]); for (let i = 1; i < pts.length; i++) d += 'L' + PS(pts[i]); return close ? d + 'Z' : d; }
function smoothD(pts, close) {
  const n = pts.length;
  if (n < 3) return polyD(pts, close);
  const g = i => (close ? pts[(i + n) % n] : pts[clamp(i, 0, n - 1)]);
  let d = 'M' + PS(pts[0]);
  const segs = close ? n : n - 1;
  for (let i = 0; i < segs; i++) {
    const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2);
    const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
    const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
    d += 'C' + PS(c1) + ' ' + PS(c2) + ' ' + PS(p2);
  }
  return close ? d + 'Z' : d;
}
function quadPts(p0, p1, p2, n) {
  const o = [];
  for (let i = 0; i <= n; i++) { const t = i / n, u = 1 - t; o.push([u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0], u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1]]); }
  return o;
}
function cubicPts(p0, p1, p2, p3, n) {
  const o = [];
  for (let i = 0; i <= n; i++) {
    const t = i / n, u = 1 - t, a = u * u * u, b = 3 * u * u * t, c = 3 * u * t * t, d = t * t * t;
    o.push([a * p0[0] + b * p1[0] + c * p2[0] + d * p3[0], a * p0[1] + b * p1[1] + c * p2[1] + d * p3[1]]);
  }
  return o;
}
function linePts(a, b, n) { const o = []; for (let i = 0; i <= n; i++) o.push([lerp(a[0], b[0], i / n), lerp(a[1], b[1], i / n)]); return o; }
function tangentAt(pts, i) {
  const a = pts[Math.max(0, i - 1)], b = pts[Math.min(pts.length - 1, i + 1)];
  let tx = b[0] - a[0], ty = b[1] - a[1]; const l = Math.hypot(tx, ty) || 1;
  return [tx / l, ty / l];
}
/* contour d'un trait effilé le long d'une polyligne */
function taperPts(pts, w0, w1, prof) {
  const n = pts.length, L = [], R = [];
  for (let i = 0; i < n; i++) {
    const [tx, ty] = tangentAt(pts, i), t = i / (n - 1);
    const w = (w0 + (w1 - w0) * t) * (prof ? prof(t) : 1) / 2;
    L.push([pts[i][0] - ty * w, pts[i][1] + tx * w]);
    R.push([pts[i][0] + ty * w, pts[i][1] - tx * w]);
  }
  return L.concat(R.reverse());
}
const taperD = (pts, w0, w1, prof) => smoothD(taperPts(pts, w0, w1, prof), true);
function ellipsePts(cx, cy, rx, ry, rot, n) {
  const o = [], c = Math.cos(rot), s = Math.sin(rot);
  for (let i = 0; i < n; i++) { const a = i / n * TAU, x = Math.cos(a) * rx, y = Math.sin(a) * ry; o.push([cx + x * c - y * s, cy + x * s + y * c]); }
  return o;
}
function rotPt(p, c, a) { const s = Math.sin(a), k = Math.cos(a), x = p[0] - c[0], y = p[1] - c[1]; return [c[0] + x * k - y * s, c[1] + x * s + y * k]; }
function arcLen(pts) { let L = 0; for (let i = 1; i < pts.length; i++) L += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); return L; }
function resample(pts, count) {
  const acc = [0];
  for (let i = 1; i < pts.length; i++) acc.push(acc[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
  const L = acc[acc.length - 1], out = [];
  let j = 0;
  for (let k = 0; k < count; k++) {
    const d = L * k / (count - 1);
    while (j < acc.length - 2 && acc[j + 1] < d) j++;
    const seg = acc[j + 1] - acc[j] || 1, t = (d - acc[j]) / seg;
    out.push([lerp(pts[j][0], pts[j + 1][0], t), lerp(pts[j][1], pts[j + 1][1], t)]);
  }
  return out;
}
function jagPts(a, b, amp, step) {
  const swap = a[0] > b[0] || (a[0] === b[0] && a[1] > b[1]);
  const A = swap ? b : a, B = swap ? a : b;
  const rnd = mulberry32(hashStr(r1(A[0]) + ',' + r1(A[1]) + ',' + r1(B[0]) + ',' + r1(B[1])));
  const L = Math.hypot(B[0] - A[0], B[1] - A[1]) || 1, n = Math.max(2, Math.round(L / (step || 5)));
  const nx = -(B[1] - A[1]) / L, ny = (B[0] - A[0]) / L, pts = [A];
  for (let i = 1; i < n; i++) { const t = i / n, o = (rnd() - 0.5) * 2 * amp; pts.push([A[0] + (B[0] - A[0]) * t + nx * o, A[1] + (B[1] - A[1]) * t + ny * o]); }
  pts.push(B);
  return swap ? pts.reverse() : pts;
}
/* ---------- cellules de Voronoï (découpe en blocs) ---------- */
function clipHalf(poly, a, b, c) {
  const out = [];
  for (let i = 0; i < poly.length; i++) {
    const P = poly[i], Q = poly[(i + 1) % poly.length];
    const vp = a * P[0] + b * P[1] - c, vq = a * Q[0] + b * Q[1] - c;
    if (vp <= 0) out.push(P);
    if ((vp < 0 && vq > 0) || (vp > 0 && vq < 0)) { const t = vp / (vp - vq); out.push([P[0] + (Q[0] - P[0]) * t, P[1] + (Q[1] - P[1]) * t]); }
  }
  return out;
}
function voronoiCells(seeds, W, H) {
  return seeds.map((s, i) => {
    let poly = [[0, 0], [W, 0], [W, H], [0, H]];
    seeds.forEach((t, j) => {
      if (i === j) return;
      const a = t[0] - s[0], b = t[1] - s[1], c = (t[0] * t[0] + t[1] * t[1] - s[0] * s[0] - s[1] * s[1]) / 2;
      poly = clipHalf(poly, a, b, c);
    });
    return poly;
  });
}
function voronoiEdges(cells, seeds, W, H) {
  const edges = [], eps = 0.05;
  for (let i = 0; i < cells.length; i++) {
    for (let j = i + 1; j < cells.length; j++) {
      const s = seeds[i], t = seeds[j], a = t[0] - s[0], b = t[1] - s[1], c = (t[0] * t[0] + t[1] * t[1] - s[0] * s[0] - s[1] * s[1]) / 2;
      const nrm = Math.hypot(a, b), on = [];
      cells[i].forEach(p => { if (Math.abs(a * p[0] + b * p[1] - c) / nrm < eps) on.push(p); });
      if (on.length >= 2) edges.push([on[0], on[on.length - 1]]);
    }
  }
  return edges;
}
/* graines réparties dans une ellipse (Lloyd) */
function blockSeeds(n, area, seed) {
  const rnd = mulberry32(seed), pts = [];
  for (let gy = -1; gy <= 1; gy += 0.05) for (let gx = -1; gx <= 1; gx += 0.05) if (gx * gx + gy * gy <= 1) pts.push([gx, gy]);
  const ga = Math.PI * (3 - Math.sqrt(5));
  let S = [];
  for (let i = 0; i < n; i++) { const r = Math.sqrt((i + 0.5) / n) * 0.9, a = i * ga + rnd() * 0.5; S.push([Math.cos(a) * r, Math.sin(a) * r]); }
  for (let it = 0; it < 12; it++) {
    const acc = S.map(() => [0, 0, 0]);
    pts.forEach(p => {
      let bi = 0, bd = 1e9;
      S.forEach((s, i) => { const d = (p[0] - s[0]) ** 2 + (p[1] - s[1]) ** 2; if (d < bd) { bd = d; bi = i; } });
      acc[bi][0] += p[0]; acc[bi][1] += p[1]; acc[bi][2]++;
    });
    S = S.map((s, i) => (acc[i][2] ? [acc[i][0] / acc[i][2], acc[i][1] / acc[i][2]] : s));
  }
  const c = Math.cos(area.rot || 0), sn = Math.sin(area.rot || 0);
  return S.map(p => { const x = p[0] * area.rx, y = p[1] * area.ry; return [area.cx + x * c - y * sn, area.cy + x * sn + y * c]; });
}

/* ---------- constructeurs SVG ---------- */
function attrs(o) { let s = ''; for (const k in o) if (o[k] !== undefined && o[k] !== null && o[k] !== false) s += ' ' + k + '="' + o[k] + '"'; return s; }
const E = {
  p: (d, fill, stroke, sw, extra) => '<path d="' + d + '" fill="' + (fill || 'none') + '"' + (stroke ? ' stroke="' + stroke + '" stroke-width="' + (sw || 1) + '"' : '') + (extra ? ' ' + extra : '') + '/>',
  c: (x, y, r, fill, stroke, sw, extra) => '<circle cx="' + r1(x) + '" cy="' + r1(y) + '" r="' + r1(r) + '" fill="' + (fill || 'none') + '"' + (stroke ? ' stroke="' + stroke + '" stroke-width="' + (sw || 1) + '"' : '') + (extra ? ' ' + extra : '') + '/>',
  el: (x, y, rx, ry, rotDeg, fill, stroke, sw, extra) => '<ellipse cx="' + r1(x) + '" cy="' + r1(y) + '" rx="' + r1(rx) + '" ry="' + r1(ry) + '"' + (rotDeg ? ' transform="rotate(' + r1(rotDeg) + ' ' + r1(x) + ' ' + r1(y) + ')"' : '') + ' fill="' + (fill || 'none') + '"' + (stroke ? ' stroke="' + stroke + '" stroke-width="' + (sw || 1) + '"' : '') + (extra ? ' ' + extra : '') + '/>',
  g: (inner, extra) => '<g' + (extra ? ' ' + extra : '') + '>' + inner + '</g>'
};
const mirrorG = (inner, cx) => '<g transform="matrix(-1 0 0 1 ' + r1(2 * cx) + ' 0)">' + inner + '</g>';
