/* ============ fossiles : générateurs SVG (fiche anatomique → silhouette → construction) ============ */
/* Palettes : body/body2 (moitié droite), relief (parties bombées), hi (reflet unique), shade, line (encre), accent (yeux, ombilic), film (tissus mous) */
const FPAL = {
  cambrien: { body: '#5d4934', body2: '#503e2c', relief: '#86694a', hi: '#b89a72', shade: '#3e3022', line: '#221810', accent: '#140e08', film: '#6a5440', filmOp: 0.55 },
  ordovicien: { body: '#4a4540', body2: '#403b36', relief: '#6c655d', hi: '#a39a8e', shade: '#322e2a', line: '#1a1714', accent: '#0c0a08', film: '#57514a', filmOp: 0.55 },
  silurien: { body: '#6b6152', body2: '#5f5648', relief: '#8e8474', hi: '#c6bcab', shade: '#4d463b', line: '#29241c', accent: '#16120d', film: '#786e5f', filmOp: 0.5 },
  devonien: { body: '#4b3a30', body2: '#413228', relief: '#6f5a4b', hi: '#ab927e', shade: '#35281f', line: '#1c130d', accent: '#0e0906', film: '#5b483b', filmOp: 0.55 },
  carbonifere: { body: '#2e2c28', body2: '#272521', relief: '#46433c', hi: '#79756c', shade: '#1f1d1a', line: '#0f0e0c', accent: '#060605', film: '#2c2a26', filmOp: 0.72 },
  permien: { body: '#5c3b2c', body2: '#513326', relief: '#7f5843', hi: '#b88c6e', shade: '#40291e', line: '#21140c', accent: '#110a05', film: '#6b4737', filmOp: 0.55 },
  trias: { body: '#8a7550', body2: '#7c6946', relief: '#ae9872', hi: '#ddcba5', shade: '#665537', line: '#3a2f1c', accent: '#241c0f', film: '#9a8560', filmOp: 0.55 },
  jurassique: { body: '#c39a61', body2: '#b28a53', relief: '#dfc08c', hi: '#f5e4bf', shade: '#957040', line: '#553a1d', accent: '#3a2612', film: '#a97f4c', filmOp: 0.5 },
  cretace: { body: '#8b8171', body2: '#7f7566', relief: '#aba191', hi: '#d9d1c3', shade: '#686052', line: '#39332a', accent: '#221e18', film: '#978d7d', filmOp: 0.5 },
  paleogene: { body: '#4b3727', body2: '#402f21', relief: '#6b5140', hi: '#a28874', shade: '#33251a', line: '#1a120b', accent: '#0d0905', film: '#5a4332', filmOp: 0.6 },
  neogene: { body: '#b5824e', body2: '#a67546', relief: '#d4a676', hi: '#f1d6ae', shade: '#895e35', line: '#4d3119', accent: '#2d1c0d', film: '#be8e5d', filmOp: 0.5 },
  quaternaire: { body: '#b39873', body2: '#a58b68', relief: '#d2bc97', hi: '#f0e3c7', shade: '#88704f', line: '#4a3822', accent: '#2b2013', film: '#bda383', filmOp: 0.5 }
};
function flatPal(c) { return { body: c, body2: c, relief: c, hi: c, shade: c, line: c, accent: c, film: c, filmOp: 1, flat: true }; }

const DASH = 'stroke-dasharray="2 1.6"';

/* ---------------- Trilobite — Elrathia kingii (vue dorsale) ---------------- */
function artTrilobite(p) {
  const cx = 100, N = 13, y0 = 86, sh = 9.3;
  const hw = i => 66 - 16 * i / (N - 1), ax = i => 19.5 - 6.5 * i / (N - 1);
  const spine = col => E.p(taperD(quadPts([33, 80], [22, 97], [18, 126], 14), 11, 0.3), col, p.line, 1.1);
  const pleurae = col => {
    let s = '';
    for (let i = N - 1; i >= 0; i--) {
      const y = y0 + i * sh, h = hw(i), a = ax(i);
      s += E.p('M' + r1(cx - a) + ' ' + r1(y) + 'L' + r1(cx - h + 3) + ' ' + r1(y + 0.6) + 'Q' + r1(cx - h - 2.6) + ' ' + r1(y + sh * 0.45) + ' ' + r1(cx - h - 0.6) + ' ' + r1(y + sh + 3.2) + 'L' + r1(cx - h + 4.5) + ' ' + r1(y + sh) + 'L' + r1(cx - a) + ' ' + r1(y + sh) + 'Z', col, p.line, 0.9);
      s += E.p('M' + r1(cx - a - 1) + ' ' + r1(y + sh * 0.36) + 'Q' + r1(cx - (a + h) / 2) + ' ' + r1(y + sh * 0.46) + ' ' + r1(cx - h + 5) + ' ' + r1(y + sh * 0.84), null, p.line, 0.7, 'opacity=".75"');
    }
    return s;
  };
  let s = spine(p.body) + mirrorG(spine(p.body2), cx);
  s += pleurae(p.body) + mirrorG(pleurae(p.body2), cx);
  for (let i = 0; i < N; i++) {
    const y = y0 + i * sh, a = ax(i);
    s += E.p('M' + r1(cx - a) + ' ' + r1(y) + 'Q' + cx + ' ' + r1(y - 2.6) + ' ' + r1(cx + a) + ' ' + r1(y) + 'L' + r1(cx + a) + ' ' + r1(y + sh) + 'Q' + cx + ' ' + r1(y + sh - 2.6) + ' ' + r1(cx - a) + ' ' + r1(y + sh) + 'Z', p.relief, p.line, 0.9);
    s += E.p('M' + r1(cx - a + 3) + ' ' + r1(y + 4.2) + 'L' + r1(cx - a + 8) + ' ' + r1(y + 3.4), null, p.hi, 1.2, 'opacity=".6"');
  }
  const py = y0 + N * sh;
  s += E.p('M' + (cx - 50) + ' ' + r1(py) + 'Q' + (cx - 52) + ' ' + r1(py + 31) + ' ' + cx + ' ' + r1(py + 33) + 'Q' + (cx + 52) + ' ' + r1(py + 31) + ' ' + (cx + 50) + ' ' + r1(py) + 'Z', p.body, p.line, 1.1);
  s += E.p('M' + (cx - 43) + ' ' + r1(py + 2) + 'Q' + (cx - 44) + ' ' + r1(py + 25) + ' ' + cx + ' ' + r1(py + 27) + 'Q' + (cx + 44) + ' ' + r1(py + 25) + ' ' + (cx + 43) + ' ' + r1(py + 2), null, p.line, 0.7);
  const pf = 'M' + (cx - 14) + ' ' + r1(py + 5) + 'Q' + (cx - 28) + ' ' + r1(py + 8) + ' ' + (cx - 38) + ' ' + r1(py + 15) + 'M' + (cx - 13) + ' ' + r1(py + 12) + 'Q' + (cx - 24) + ' ' + r1(py + 16) + ' ' + (cx - 31) + ' ' + r1(py + 22);
  s += E.p(pf, null, p.line, 0.7) + mirrorG(E.p(pf, null, p.line, 0.7), cx);
  s += E.p('M' + (cx - 12) + ' ' + r1(py) + 'L' + (cx - 5) + ' ' + r1(py + 24) + 'Q' + cx + ' ' + r1(py + 27) + ' ' + (cx + 5) + ' ' + r1(py + 24) + 'L' + (cx + 12) + ' ' + r1(py) + 'Z', p.relief, p.line, 0.9);
  s += E.p('M' + (cx - 10) + ' ' + r1(py + 7) + 'H' + (cx + 10) + 'M' + (cx - 8.5) + ' ' + r1(py + 13) + 'H' + (cx + 8.5) + 'M' + (cx - 7) + ' ' + r1(py + 19) + 'H' + (cx + 7), null, p.line, 0.7);
  /* céphalon */
  s += E.p('M26 86A74 66 0 0 1 174 86Z', p.body, p.line, 1.2);
  s += E.p('M26 86A74 66 0 0 1 174 86L166 86A66 58 0 0 0 34 86Z', p.relief);
  s += E.p('M26 86A74 66 0 0 1 174 86', null, p.line, 1.2);
  s += E.p('M34 86A66 58 0 0 1 166 86', null, p.line, 0.8);
  s += E.p('M81 85L83 52Q85 38 100 37Q115 38 117 52L119 85Z', p.relief, p.line, 1);
  s += E.p('M82 76Q100 72.5 118 76', null, p.line, 0.8);
  const det = E.p('M84 60L91 56M83 68L90 65', null, p.line, 0.8) +
    E.p('M84 46Q72 46 62 51', null, p.line, 0.8) +
    E.p('M58 50Q53 58 59 67Q65 60 63 51Z', p.accent, p.line, 0.8) +
    E.p('M72 33Q64 39 60 49', null, p.line, 0.6, DASH) + E.p('M60 67Q50 76 42 86', null, p.line, 0.6, DASH);
  s += det + mirrorG(det, cx);
  s += E.p('M58 52Q55 58 58 63', null, p.hi, 0.9, 'opacity=".7"');
  s += E.p('M40 66Q52 40 82 31', null, p.hi, 2.2, 'opacity=".7"');
  return s;
}

/* ---------------- Marrella splendens — le « crabe dentelle » ---------------- */
function artMarrella(p) {
  const cx = 100;
  const spA = col => E.p(taperD(cubicPts([91, 62], [44, 54], [28, 112], [48, 212], 36), 8, 0.4), col, p.line, 1);
  const spB = col => E.p(taperD(cubicPts([93, 80], [66, 92], [60, 150], [76, 206], 30), 6, 0.4), col, p.line, 0.9);
  let legs = '', gills = '';
  const N = 24, yt = 92, yb = 190;
  for (let i = 0; i < N; i++) {
    const t = i / (N - 1), y = yt + t * (yb - yt), hwv = 8.5 - 5.5 * t, len = 23 - 14 * t;
    const x0 = cx - hwv, x1 = x0 - len, y1 = y + len * 0.3;
    legs += 'M' + r1(x0) + ' ' + r1(y) + 'L' + r1(x1) + ' ' + r1(y1);
    for (let k = 1; k <= 3; k++) { const u = k / 4; gills += 'M' + r1(lerp(x0, x1, u)) + ' ' + r1(lerp(y, y1, u)) + 'l-1.2 3.4'; }
  }
  const legL = E.p(legs, null, p.line, 0.9) + E.p(gills, null, p.line, 0.5, 'opacity=".8"');
  const ant = E.p(taperD(cubicPts([95, 54], [86, 34], [62, 14], [34, 4], 26), 2.6, 0.5), p.body, p.line, 0.6);
  const sw = cubicPts([93, 62], [76, 50], [46, 46], [24, 66], 22);
  let setae = ''; for (let i = 3; i < sw.length; i += 2) setae += 'M' + PS(sw[i]) + 'l-2.6 6.8';
  const swimL = E.p(taperD(sw, 5.5, 1.8), p.body, p.line, 0.8) + E.p(setae, null, p.line, 0.6);
  let s = spA(p.body) + mirrorG(spA(p.body2), cx);
  s += spB(p.shade) + mirrorG(spB(p.shade), cx);
  s += legL + mirrorG(legL, cx);
  s += E.p(taperD(linePts([cx, 86], [cx, 196], 20), 17, 4), p.relief, p.line, 1);
  let seg = '';
  for (let i = 1; i < 24; i++) { const t = i / 24, y = 86 + t * 110, hwv = 8.5 - 6.5 * t; seg += 'M' + r1(cx - hwv) + ' ' + r1(y) + 'L' + r1(cx + hwv) + ' ' + r1(y); }
  s += E.p(seg, null, p.line, 0.6);
  s += E.p(taperD([[cx, 194], [cx, 200], [cx, 207]], 3, 0.3), p.body, p.line, 0.8);
  s += E.p('M100 46L90 57L86 74L91 88L100 92L109 88L114 74L110 57Z', p.relief, p.line, 1.1);
  s += E.p('M100 52L100 86', null, p.line, 0.6, 'opacity=".6"');
  s += ant + mirrorG(ant, cx) + swimL + mirrorG(swimL, cx);
  s += E.p('M42 116Q36 86 58 64', null, p.hi, 1.6, 'opacity=".65"');
  return s;
}

/* ---------------- Hallucigenia sparsa (vue latérale) ---------------- */
function artHallucigenia(p) {
  const cl = cubicPts([24, 92], [90, 78], [190, 80], [252, 94], 40).concat(quadPts([252, 94], [266, 98], [268, 114], 8).slice(1));
  const nrm = i => { const t = tangentAt(cl, i); return [t[1], -t[0]]; }; // normale vers le haut
  const add = (a, b, k) => [a[0] + b[0] * k, a[1] + b[1] * k];
  let far = '', near = '', legsFar = '', legsNear = '', tent = '';
  [12, 16, 20, 24, 28, 32, 36].forEach((idx, k) => {
    const c = cl[idx], n = nrm(idx), b = add(c, n, 3.5);
    const tip = [b[0] + n[0] * 48 + 9, b[1] + n[1] * 48];
    const mid = [lerp(b[0], tip[0], 0.5) - 2, lerp(b[1], tip[1], 0.5)];
    far += E.p(taperD([[b[0] + 4, b[1]], [mid[0] + 5, mid[1] + 1], [tip[0] + 7, tip[1] + 3]], 5.5, 0.3), p.shade, p.line, 0.7);
    near += E.p(taperD([b, mid, tip], 6, 0.3), k % 2 ? p.body2 : p.body, p.line, 0.9);
  });
  [11, 15, 19, 23, 27, 31, 35].forEach(idx => {
    const c = cl[idx], n = nrm(idx), b = add(c, n, -3);
    const pts = cubicPts(b, [b[0] + 1, b[1] + 10], [b[0] - 2, b[1] + 22], [b[0] - 4, b[1] + 30], 8);
    const tp = pts[pts.length - 1];
    legsNear += E.p(taperD(pts, 4.6, 2), p.body, p.line, 0.8) + E.p('M' + PS(tp) + 'q-3 1.6 -4.6 -1', null, p.line, 0.9);
    const pf = pts.map(q => [q[0] + 3.5, q[1] - 1.5]);
    legsFar += E.p(taperD(pf, 4, 1.8), p.shade, p.line, 0.6);
  });
  [3, 5, 7].forEach((idx, k) => {
    const c = cl[idx], n = nrm(idx), b = add(c, n, -2.5);
    const pts = cubicPts(b, [b[0] - 3, b[1] + 8], [b[0] - 10 + k * 2, b[1] + 16], [b[0] - 12 + k * 3, b[1] + 26 - k * 3], 10);
    tent += E.p(polyD(pts), null, p.line, 1.1);
  });
  let s = far + legsFar;
  s += E.p(taperD(cl, 8.5, 6.5), p.relief, p.line, 1.1);
  let ann = '';
  for (let i = 2; i < cl.length - 1; i += 2) { const c = cl[i], n = nrm(i); ann += 'M' + PS(add(c, n, -3.6)) + 'L' + PS(add(c, n, 3.6)); }
  s += E.p(ann, null, p.line, 0.5, 'opacity=".5"');
  s += legsNear + tent + near;
  s += E.el(16, 95, 10, 6.5, 18, p.relief, p.line, 1) + E.c(11, 92.5, 1.7, p.accent);
  const hl = cl.slice(8, 30).map((q, i) => add(q, nrm(i + 8), 2.4));
  s += E.p(polyD(hl), null, p.hi, 1.3, 'opacity=".6"');
  return s;
}

/* ---------------- Opabinia regalis — cinq yeux et une trompe ---------------- */
function artOpabinia(p) {
  const cx = 100;
  const prob = cubicPts([100, 88], [100, 60], [104, 38], [112, 18], 22);
  let s = E.p(taperD(prob, 8, 4.5), p.body, p.line, 1);
  let ann = '';
  for (let i = 2; i < prob.length - 1; i += 2) { const t = tangentAt(prob, i), w = lerp(4, 2.4, i / prob.length); ann += 'M' + r1(prob[i][0] - t[1] * w) + ' ' + r1(prob[i][1] + t[0] * w) + 'L' + r1(prob[i][0] + t[1] * w) + ' ' + r1(prob[i][1] - t[0] * w); }
  s += E.p(ann, null, p.line, 0.6);
  s += E.p('M110 19Q104 10 107 3L110 8L112 4L113 11Z', p.body, p.line, 0.9) + E.p('M114 19Q122 12 121 5L117 9L117 5L114 12Z', p.body, p.line, 0.9);
  const lobeL = col => {
    let o = '';
    const lens = [26, 30, 33, 34, 34, 33, 31, 29, 27, 25, 23, 21, 19, 17, 15];
    for (let i = 14; i >= 0; i--) {
      const y = 114 + i * 8.6, bw = 13 - 6 * i / 14, len = lens[i], a = 22 * D2R;
      const ex = cx - bw - len * 0.45 * Math.cos(a), ey = y + len * 0.45 * Math.sin(a);
      o += E.el(ex, ey, len / 2, 5.2, 180 - 22, col, p.line, 0.9);
      o += E.p('M' + r1(cx - bw - 4) + ' ' + r1(y - 1) + 'l-7 2.6M' + r1(cx - bw - 4) + ' ' + r1(y + 2) + 'l-7 2.6', null, p.line, 0.5, 'opacity=".7"');
    }
    return o;
  };
  s += lobeL(p.body) + mirrorG(lobeL(p.body2), cx);
  s += E.p(taperD(linePts([cx, 104], [cx, 240], 20), 26, 12), p.relief, p.line, 1);
  let seg = '';
  for (let i = 1; i < 15; i++) { const y = 110 + i * 8.6, hwv = 12.5 - 6 * i / 14; seg += 'M' + r1(cx - hwv) + ' ' + r1(y) + 'L' + r1(cx + hwv) + ' ' + r1(y); }
  s += E.p(seg, null, p.line, 0.6);
  const blade = col => {
    let o = '';
    [[16, 38], [32, 34], [48, 28]].forEach(([deg, len]) => {
      const a = (90 + deg) * D2R, bx = cx - 3, by = 240, ex = bx + Math.cos(a) * len / 2, ey = by + Math.sin(a) * len / 2;
      o += E.el(ex, ey, len / 2, 6.2, 90 + deg, col, p.line, 0.9);
      o += E.p('M' + r1(bx) + ' ' + r1(by) + 'L' + r1(bx + Math.cos(a) * len * 0.9) + ' ' + r1(by + Math.sin(a) * len * 0.9), null, p.line, 0.5);
    });
    return o;
  };
  s += blade(p.relief) + mirrorG(blade(p.relief), cx);
  s += E.el(cx, 100, 19, 14, 0, p.relief, p.line, 1.1);
  const eyes = [[[100, 94], [100, 76]], [[93, 94], [80, 76]], [[88, 100], [66, 90]], [[107, 94], [120, 76]], [[112, 100], [134, 90]]];
  eyes.forEach(([b, t]) => {
    const ang = Math.atan2(t[1] - b[1], t[0] - b[0]) / D2R;
    s += E.p(taperD([b, lerpPt(b, t, 0.5), t], 4, 3), p.body, p.line, 0.8);
    s += E.el(t[0], t[1], 6.4, 4.8, ang, p.accent, p.line, 0.8) + E.c(t[0] - 1.8, t[1] - 1.6, 1.3, p.hi, null, 0, 'opacity=".8"');
  });
  s += E.p('M86 96Q90 88 98 87', null, p.hi, 1.4, 'opacity=".65"');
  return s;
}
function lerpPt(a, b, t) { return [lerp(a[0], b[0], t), lerp(a[1], b[1], t)]; }

/* ---------------- Anomalocaris canadensis — pièce unique ---------------- */
function artAnomalocaris(p) {
  const cx = 120;
  const arm = resample(cubicPts([110, 62], [96, 24], [56, 8], [40, 36], 30).concat(quadPts([40, 36], [34, 58], [54, 62], 10).slice(1)), 30);
  const ctr = arm.reduce((a, q) => [a[0] + q[0] / arm.length, a[1] + q[1] / arm.length], [0, 0]);
  const armL = col => {
    let o = E.p(taperD(arm, 12, 5), col, p.line, 1.1), rings = '', spines = '';
    for (let i = 2; i < arm.length - 1; i += 2) {
      const t = tangentAt(arm, i), w = lerp(6, 2.5, i / arm.length);
      rings += 'M' + r1(arm[i][0] - t[1] * w) + ' ' + r1(arm[i][1] + t[0] * w) + 'L' + r1(arm[i][0] + t[1] * w) + ' ' + r1(arm[i][1] - t[0] * w);
      let n = [t[1], -t[0]];
      if ((ctr[0] - arm[i][0]) * n[0] + (ctr[1] - arm[i][1]) * n[1] < 0) n = [-n[0], -n[1]];
      const bs = [arm[i][0] + n[0] * w, arm[i][1] + n[1] * w], L = lerp(8, 3.5, i / arm.length);
      spines += 'M' + PS([bs[0] - t[0] * 1.6, bs[1] - t[1] * 1.6]) + 'L' + PS([bs[0] + n[0] * L + t[0] * 1.5, bs[1] + n[1] * L + t[1] * 1.5]) + 'L' + PS([bs[0] + t[0] * 1.6, bs[1] + t[1] * 1.6]) + 'Z';
    }
    return E.p(spines, p.shade, p.line, 0.6) + o + E.p(rings, null, p.line, 0.7);
  };
  const flapL = col => {
    let o = '';
    const lens = [36, 46, 54, 60, 62, 60, 56, 50, 42, 34, 26];
    for (let i = 10; i >= 0; i--) {
      const y = 100 + i * 12.2, bw = 21 - 11 * i / 10, L = lens[i], x0 = cx - bw;
      const pts = [[x0 + 2, y - 7], [x0 - L * 0.5, y - 6 + L * 0.08], [x0 - L, y + L * 0.3], [x0 - L * 0.62, y + 9 + L * 0.22], [x0 + 2, y + 8]];
      o += E.p(smoothD(pts, true), col, p.line, 1);
      let v = '';
      for (let k = 0; k < 4; k++) { const yy = y - 3 + k * 3.4; v += 'M' + r1(x0 - 3) + ' ' + r1(yy) + 'L' + r1(x0 - L * (0.55 + 0.1 * k)) + ' ' + r1(yy + L * (0.12 + 0.05 * k)); }
      o += E.p(v, null, p.line, 0.5, 'opacity=".7"');
    }
    return o;
  };
  const fan = col => {
    let o = '';
    [[10, 50], [26, 46], [42, 40]].forEach(([deg, len]) => {
      const a = (90 + deg) * D2R, bx = cx - 4, by = 234, ex = bx + Math.cos(a) * len / 2, ey = by + Math.sin(a) * len / 2;
      o += E.el(ex, ey, len / 2, 9, 90 + deg, col, p.line, 1);
      o += E.p('M' + r1(bx) + ' ' + r1(by) + 'L' + r1(bx + Math.cos(a) * len * 0.92) + ' ' + r1(by + Math.sin(a) * len * 0.92), null, p.line, 0.6);
    });
    return o;
  };
  let s = fan(p.relief) + mirrorG(fan(p.relief), cx);
  s += flapL(p.body) + mirrorG(flapL(p.body2), cx);
  s += E.p(taperD(linePts([cx, 92], [cx, 236], 20), 44, 18), p.relief, p.line, 1.1);
  let seg = '';
  for (let i = 1; i < 12; i++) { const y = 96 + i * 12, hwv = 21 - 11 * i / 11; seg += 'M' + r1(cx - hwv) + ' ' + r1(y) + 'Q' + cx + ' ' + r1(y + 2.5) + ' ' + r1(cx + hwv) + ' ' + r1(y); }
  s += E.p(seg, null, p.line, 0.7);
  s += armL(p.body) + mirrorG(armL(p.body2), cx);
  const eye = E.p(taperD([[104, 74], [90, 70], [80, 66]], 6, 4), p.body, p.line, 0.9) + E.el(69, 64, 14, 9.5, -12, p.accent, p.line, 1) + E.c(64, 61, 2.4, p.hi, null, 0, 'opacity=".75"');
  s += eye + mirrorG(eye, cx);
  s += E.el(cx, 80, 27, 21, 0, p.relief, p.line, 1.1);
  s += E.el(cx, 74, 15, 10, 0, p.body, p.line, 0.9);
  s += E.p('M98 72Q104 60 118 58', null, p.hi, 1.6, 'opacity=".7"');
  return s;
}

/* ---------------- Ammonite — Dactylioceras commune ---------------- */
function artAmmonite(p) {
  const cx = 110, cy = 110, Rmax = 100, W = 1.36, rmin = 5.5, rot = -0.55;
  const r = th => Rmax * Math.pow(W, th / TAU);
  const th0 = -Math.log(Rmax / rmin) / Math.log(W) * TAU;
  const pol = (rad, th) => [cx + rad * Math.cos(th + rot), cy + rad * Math.sin(th + rot)];
  const outer = [];
  for (let i = 0; i <= 140; i++) { const th = -TAU + TAU * i / 140; outer.push(pol(r(th), th)); }
  let s = E.p(polyD(outer, true), p.body, p.line, 1.6);
  /* ombre bas-droite du dernier tour */
  const band = (a1, a2) => {
    const o = [], iN = [];
    for (let i = 0; i <= 40; i++) { const th = lerp(a1, a2, i / 40); o.push(pol(r(th) - 0.8, th)); iN.push(pol(r(th - TAU) + 0.8, th)); }
    return polyD(o.concat(iN.reverse()), true);
  };
  const shadeFrom = -TAU + ((0.1 - rot) % TAU + TAU) % TAU;
  s += E.p(band(shadeFrom, Math.min(0, shadeFrom + 1.9)), p.shade, null, 0, 'opacity=".35"');
  /* crêtes (relief) le long de chaque tour */
  let crest = '';
  for (let th = th0 + TAU; th <= 0; th += 0.05) {
    const rm = (r(th) + r(th - TAU)) / 2, q = pol(rm, th);
    crest += (crest ? 'L' : 'M') + PS(q);
  }
  s += E.p(crest, null, p.relief, 3.2, 'opacity=".55"');
  /* côtes */
  let ribs = '', ribs2 = '';
  const dth = TAU / 42;
  for (let th = th0 + TAU + dth; th <= 0.0001; th += dth) {
    const ri = r(th - TAU) + 0.6, ro = r(th) - 0.6, bw = ro - ri;
    const a = pol(ri, th - 0.02), m = pol(ri + bw * 0.5, th + 0.015), b = pol(ro, th + 0.06);
    const d = 'M' + PS(a) + 'Q' + PS(m) + ' ' + PS(b);
    if (bw > 9) ribs += d; else ribs2 += d;
    if (th > -TAU && bw > 9 && th + dth / 2 < -0.02) {
      const tt = th + dth / 2, s0 = pol(ri + bw * 0.62, tt + 0.03), s1 = pol(ro, tt + 0.06);
      ribs += 'M' + PS(s0) + 'L' + PS(s1);
    }
  }
  s += E.p(ribs, null, p.line, 0.9, 'opacity=".85"') + E.p(ribs2, null, p.line, 0.6, 'opacity=".8"');
  /* suture spirale */
  let sp = '';
  for (let th = th0; th <= 0; th += 0.04) sp += (sp ? 'L' : 'M') + PS(pol(r(th), th));
  s += E.p(sp, null, p.line, 1.4);
  s += E.c(cx, cy, rmin * 1.05, p.accent);
  const ap0 = pol(r(-TAU), 0), ap1 = pol(r(0), 0);
  s += E.p('M' + PS(ap0) + 'L' + PS(ap1), null, p.line, 1.8);
  let hl = '';
  for (let th = -TAU + 3.1 - rot; th <= -TAU + 4.4 - rot; th += 0.05) hl += (hl ? 'L' : 'M') + PS(pol(r(th) * 0.93, th));
  s += E.p(hl, null, p.hi, 2.4, 'opacity=".75"');
  return s;
}

/* ---------------- Leptolepides sprattiformis — poisson de Solnhofen ---------------- */
function artLeptolepides(p) {
  const top = [[16, 62], [26, 54], [44, 44], [70, 36], [96, 34], [126, 38], [156, 46], [184, 52], [204, 56]];
  const bot = [[204, 66], [184, 70], [156, 78], [126, 86], [96, 88], [70, 84], [44, 78], [26, 70], [16, 64]];
  const yTop = x => interpY(top, x), yBot = x => interpY(bot.slice().reverse(), x);
  let s = '';
  /* nageoires (derrière) */
  const fin = (base, dir, n, len0, len1, spread) => {
    let rays = '', tips = [];
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1), b = [lerp(base[0][0], base[1][0], t), lerp(base[0][1], base[1][1], t)];
      const a = (dir + spread * (t - 0.5)) * D2R, L = lerp(len0, len1, t), e = [b[0] + Math.cos(a) * L, b[1] + Math.sin(a) * L];
      rays += 'M' + PS(b) + 'L' + PS(e); tips.push(e);
    }
    return E.p(polyD([base[0]].concat(tips, [base[1]]), true), p.film, null, 0, 'opacity="' + (p.flat ? 1 : 0.55) + '"') + E.p(rays, null, p.line, 0.55);
  };
  s += fin([[118, yTop(118)], [140, yTop(140)]], -120, 9, 22, 12, 20);
  s += fin([[108, yBot(108)], [118, yBot(118)]], 125, 6, 15, 11, 16);
  s += fin([[156, yBot(156)], [176, yBot(176)]], 122, 8, 16, 10, 14);
  let caud = '', ct = [];
  for (let i = 0; i <= 18; i++) {
    const t = i / 18, ang = lerp(-38, 38, t) * D2R, fork = 1 - 0.38 * Math.sin(t * Math.PI);
    const L = 50 * fork, e = [206 + Math.cos(ang) * L, 61 + Math.sin(ang) * L * 0.95];
    caud += 'M206 61L' + PS(e); ct.push(e);
  }
  s += E.p(polyD([[204, 56]].concat(ct, [[204, 66]]), true), p.film, null, 0, 'opacity="' + (p.flat ? 1 : 0.55) + '"') + E.p(caud, null, p.line, 0.55);
  /* corps */
  s += E.p(smoothD(top.concat(bot), true), p.film, p.line, 1.1, 'fill-opacity="' + (p.flat ? 1 : p.filmOp) + '"');
  /* colonne vertébrale et arêtes */
  let spines = '', verts = '';
  const n = 36;
  for (let i = 0; i < n; i++) {
    const x = 70 + i * (134 / n), yt = yTop(x), yb = yBot(x), ym = lerp(yt, yb, 0.47);
    verts += E.el(x, ym, 1.7, lerp(3.4, 2.2, i / n), 0, p.relief, p.line, 0.5);
    spines += 'M' + r1(x) + ' ' + r1(ym - 3) + 'L' + r1(x + 5) + ' ' + r1(yt + 2.5);
    if (x < 140) spines += 'M' + r1(x) + ' ' + r1(ym + 3) + 'Q' + r1(x + 1) + ' ' + r1(yb - 6) + ' ' + r1(x + 6) + ' ' + r1(yb - 2.5);
    else spines += 'M' + r1(x) + ' ' + r1(ym + 3) + 'L' + r1(x + 5) + ' ' + r1(yb - 2);
  }
  s += E.p(spines, null, p.line, 0.5, 'opacity=".75"') + verts;
  /* tête */
  s += E.p('M16 62Q30 46 58 42L64 60L58 80Q34 78 16 64Z', p.relief, p.line, 0.9, 'fill-opacity="' + (p.flat ? 1 : 0.85) + '"');
  s += E.p('M60 43Q70 60 60 80M54 46Q61 60 54 76', null, p.line, 0.9);
  s += E.c(40, 54, 7.5, p.shade, p.line, 0.9) + E.c(38, 52, 2, p.hi, null, 0, 'opacity=".7"');
  s += E.p('M16 63L40 70M26 58L36 60', null, p.line, 0.8);
  s += fin([[68, 72], [72, 74]], 128, 7, 18, 12, 40);
  s += E.p('M28 52Q48 38 82 36', null, p.hi, 1.6, 'opacity=".7"');
  return s;
}
function interpY(pts, x) {
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i], b = pts[i + 1];
    if (x >= a[0] && x <= b[0]) return lerp(a[1], b[1], (x - a[0]) / (b[0] - a[0] || 1));
  }
  return pts[x < pts[0][0] ? 0 : pts.length - 1][1];
}

/* ---------------- Pentacrinites fossilis — lys de mer ---------------- */
function artPentacrinites(p) {
  const stem = cubicPts([106, 286], [128, 236], [78, 178], [100, 128], 64);
  let s = E.p(taperD(stem, 9, 7), p.body, p.line, 1);
  let col = '', cirri = '';
  for (let i = 1; i < stem.length - 1; i++) {
    const t = tangentAt(stem, i), w = 4.3;
    col += 'M' + r1(stem[i][0] - t[1] * w) + ' ' + r1(stem[i][1] + t[0] * w) + 'L' + r1(stem[i][0] + t[1] * w) + ' ' + r1(stem[i][1] - t[0] * w);
    if (i % 8 === 4) {
      [-1, 1].forEach(sd => {
        const b = [stem[i][0] + sd * 4.5, stem[i][1]];
        cirri += polyD(cubicPts(b, [b[0] + sd * 6, b[1] - 2], [b[0] + sd * 11, b[1] + 2], [b[0] + sd * 12, b[1] + 9], 6));
        cirri += polyD(cubicPts(b, [b[0] + sd * 4, b[1] + 1], [b[0] + sd * 7, b[1] + 6], [b[0] + sd * 6, b[1] + 12], 6));
      });
    }
  }
  s += E.p(cirri, null, p.line, 0.9) + E.p(col, null, p.line, 0.55, 'opacity=".8"');
  let arms = '', pinn = '';
  const arm = (x, y, ang, len, w, depth) => {
    const a = ang * D2R, e = [x + Math.sin(a) * len, y - Math.cos(a) * len];
    const bend = (depth === 3 ? -0.18 : 0.1) * Math.sign(ang || 1);
    const m = [lerp(x, e[0], 0.5) + Math.cos(a) * len * bend, lerp(y, e[1], 0.5) + Math.sin(a) * len * bend];
    const pts = quadPts([x, y], m, e, 10);
    arms += E.p(taperD(pts, w, w * 0.78), p.body, p.line, 0.6);
    for (let i = 1; i < pts.length; i++) {
      const t = tangentAt(pts, i), sd = i % 2 ? 1 : -1, L = 4.2 - depth * 0.4;
      pinn += 'M' + PS(pts[i]) + 'l' + r1((t[0] * 0.7 + sd * -t[1]) * L) + ' ' + r1((t[1] * 0.7 + sd * t[0]) * L);
    }
    if (depth < 3) { const sp = 13 + depth * 3; arm(e[0], e[1], ang - sp, len * 0.8, w * 0.78, depth + 1); arm(e[0], e[1], ang + sp, len * 0.8, w * 0.78, depth + 1); }
  };
  [-40, -20, 0, 20, 40].forEach(a => arm(100, 118, a, 34, 4.2, 0));
  s += E.p(pinn, null, p.line, 0.55, 'opacity=".9"') + arms;
  s += E.p('M91 131L89 119Q100 111 111 119L109 131Z', p.relief, p.line, 1);
  s += E.p('M92 124Q100 119 108 124', null, p.line, 0.6);
  s += E.p(polyD(stem.slice(8, 44).map((q, i) => { const t = tangentAt(stem, i + 8); return [q[0] + t[1] * 2.2, q[1] - t[0] * 2.2]; })), null, p.hi, 1.2, 'opacity=".6"');
  return s;
}

/* ---------------- Ichthyosaure — Stenopterygius (Holzmaden) ---------------- */
function artIchthyosaure(p) {
  const outline = [[8, 67], [30, 61], [58, 50], [84, 45], [120, 42], [150, 40], [172, 16], [190, 40], [224, 50], [256, 60], [272, 50], [306, 20], [296, 50], [284, 70], [296, 94], [304, 120], [270, 88], [252, 76], [220, 84], [170, 96], [120, 99], [84, 90], [54, 79], [26, 71]];
  let s = E.p(smoothD(outline, true), p.film, null, 0, 'fill-opacity="' + (p.flat ? 1 : 0.42) + '"');
  s += E.p(smoothD(outline, true), null, p.line, 0.6, 'opacity=".45"');
  const spine = resample(cubicPts([82, 63], [150, 64], [220, 72], [262, 73], 40).concat(cubicPts([262, 73], [274, 74], [288, 92], [300, 116], 14).slice(1)), 78);
  /* côtes */
  let ribs = '';
  for (let i = 2; i < 34; i += 2) {
    const q = spine[i], L = lerp(30, 18, i / 34);
    ribs += 'M' + r1(q[0]) + ' ' + r1(q[1] + 3) + 'Q' + r1(q[0] + 9) + ' ' + r1(q[1] + L * 0.55) + ' ' + r1(q[0] + 3) + ' ' + r1(q[1] + L);
  }
  s += E.p(ribs, null, p.line, 1.3) + E.p(ribs, null, p.relief, 0.6);
  /* nageoires-palettes (hyperphalangie) */
  const paddle = (cx, cy, rx, ry, rotD, cell) => {
    let o = E.el(cx, cy, rx, ry, rotD, p.shade, null, 0, 'opacity="' + (p.flat ? 1 : 0.4) + '"');
    const c = Math.cos(rotD * D2R), sn = Math.sin(rotD * D2R);
    for (let u = -rx + cell / 2; u < rx; u += cell) for (let v = -ry + cell * 0.45; v < ry; v += cell * 0.9) {
      if ((u * u) / (rx * rx) + (v * v) / (ry * ry) > 0.8) continue;
      const x = cx + u * c - v * sn, y = cy + u * sn + v * c;
      o += E.el(x, y, cell * 0.42, cell * 0.36, rotD, p.relief, p.line, 0.45);
    }
    return o;
  };
  s += paddle(106, 97, 22, 8.5, 32, 4.6);
  s += paddle(188, 91, 12, 5, 26, 3.6);
  s += E.p(taperD([[92, 76], [98, 84], [100, 88]], 6, 4), p.relief, p.line, 0.7);
  /* vertèbres */
  let neur = '', cent = '';
  spine.forEach((q, i) => {
    const t = tangentAt(spine, i), h = lerp(8, 3, Math.max(0, (i - 40) / 38)), ang = Math.atan2(t[1], t[0]) / D2R;
    cent += E.el(q[0], q[1], 1.55, h / 2, ang, p.relief, p.line, 0.5);
    if (i < 64) neur += 'M' + r1(q[0] + t[1] * h * 0.5) + ' ' + r1(q[1] - t[0] * h * 0.5) + 'l' + r1(t[1] * 5 + t[0] * 2) + ' ' + r1(-t[0] * 5 + t[1] * 2);
  });
  s += E.p(neur, null, p.line, 0.8) + cent;
  /* crâne */
  s += E.p('M8 67Q30 60 56 55Q72 50 86 53L86 72Q70 76 54 73Q30 72 8 67Z', p.relief, p.line, 1);
  s += E.p('M10 67Q34 67 58 66', null, p.line, 0.7);
  let teeth = '';
  for (let x = 13; x < 50; x += 3.2) teeth += 'M' + r1(x) + ' ' + r1(66.2 - (x - 13) * 0.02) + 'l0.6 1.8';
  s += E.p(teeth, null, p.line, 0.6);
  s += E.c(66, 61, 11.5, p.shade, p.line, 0.9);
  let scl = '';
  for (let k = 0; k < 14; k++) {
    const a0 = k / 14 * TAU + 0.08, a1 = (k + 1) / 14 * TAU - 0.08, ri = 6.8, ro = 10.6;
    scl += 'M' + PS([66 + Math.cos(a0) * ri, 61 + Math.sin(a0) * ri]) + 'L' + PS([66 + Math.cos(a0) * ro, 61 + Math.sin(a0) * ro]) + 'L' + PS([66 + Math.cos(a1) * ro, 61 + Math.sin(a1) * ro]) + 'L' + PS([66 + Math.cos(a1) * ri, 61 + Math.sin(a1) * ri]) + 'Z';
  }
  s += E.p(scl, p.relief, p.line, 0.5);
  s += E.el(48, 59, 3, 1.4, -8, p.accent);
  s += E.p('M22 62Q46 52 74 49', null, p.hi, 1.5, 'opacity=".7"');
  return s;
}

/* ---------------- Archaeopteryx lithographica — pièce unique ---------------- */
function artArchaeopteryx(p) {
  let s = '';
  const feather = (b, ang, L, w, col) => {
    const a = ang * D2R, d = [Math.cos(a), Math.sin(a)], n = [-d[1], d[0]];
    const tip = [b[0] + d[0] * L, b[1] + d[1] * L];
    const pts = [b, [b[0] + d[0] * L * 0.3 + n[0] * w, b[1] + d[1] * L * 0.3 + n[1] * w], [b[0] + d[0] * L * 0.75 + n[0] * w * 0.7, b[1] + d[1] * L * 0.75 + n[1] * w * 0.7], tip, [b[0] + d[0] * L * 0.75 - n[0] * w * 0.55, b[1] + d[1] * L * 0.75 - n[1] * w * 0.55], [b[0] + d[0] * L * 0.3 - n[0] * w * 0.6, b[1] + d[1] * L * 0.3 - n[1] * w * 0.6]];
    return E.p(smoothD(pts, true), col, p.line, 0.55) + E.p('M' + PS(b) + 'L' + PS([b[0] + d[0] * L * 0.92, b[1] + d[1] * L * 0.92]), null, p.line, 0.5);
  };
  const fop = 'fill-opacity="' + (p.flat ? 1 : 0.75) + '"';
  const wing = (sh, el, wr, hd, prim, sec) => {
    let o = '';
    for (let i = 0; i < 10; i++) { const t = i / 9, b = lerpPt(el, wr, t * 0.95); o += feather(b, lerp(sec[0], sec[1], t), lerp(46, 52, t), 6, p.film); }
    for (let i = 0; i < 9; i++) { const t = i / 8, b = lerpPt(wr, hd, t * 0.9); o += feather(b, lerp(prim[0], prim[1], t), lerp(56, 66, Math.sin(t * Math.PI * 0.8)), 6.5, p.film); }
    o = E.g(o, fop);
    o += E.p(taperD([sh, el], 4.6, 3.4), p.relief, p.line, 0.8) + E.p(taperD([el, wr], 3.6, 3), p.relief, p.line, 0.8) + E.p(taperD([wr, hd], 3, 2.2), p.relief, p.line, 0.8);
    return o;
  };
  /* queue : vertèbres + plumes par paires */
  const tail = resample(cubicPts([150, 156], [126, 172], [92, 190], [46, 208], 30), 18);
  let tf = '';
  tail.forEach((q, i) => {
    if (i < 3) return;
    const t = tangentAt(tail, i), a = Math.atan2(t[1], t[0]) / D2R;
    tf += feather(q, a - 46, 21, 4.2, p.film) + feather(q, a + 46, 21, 4.2, p.film);
  });
  s += E.g(tf, 'fill-opacity="' + (p.flat ? 1 : 0.55) + '"');
  s += wing([132, 112], [108, 102], [80, 86], [60, 74], [204, 244], [166, 204]);
  s += wing([136, 110], [160, 98], [188, 84], [208, 72], [-24, -64], [14, -24]);
  let tv = '';
  tail.forEach((q, i) => { const t = tangentAt(tail, i); tv += E.el(q[0], q[1], lerp(3.4, 2, i / 17), lerp(2.2, 1.4, i / 17), Math.atan2(t[1], t[0]) / D2R, p.relief, p.line, 0.5); });
  s += tv;
  /* doigts griffus */
  const claws = (hd, dirs) => dirs.map(([dx, dy]) => E.p('M' + PS(hd) + 'l' + dx + ' ' + dy + 'q' + r1(dx * 0.3 - 2) + ' ' + r1(dy * 0.3 + 2) + ' ' + r1(-dx * 0.2 - 1) + ' ' + r1(3), null, p.line, 1.1)).join('');
  s += claws([60, 74], [[-12, -4], [-14, 4], [-8, 10]]) + claws([208, 72], [[12, -6], [14, 2], [9, 9]]);
  /* bassin, pattes */
  const leg = (h, k, a, f) => E.p(taperD([h, k], 4.4, 3.4), p.relief, p.line, 0.8) + E.p(taperD([k, a], 3.4, 2.6), p.relief, p.line, 0.8) + E.p(taperD([a, f], 2.6, 2), p.relief, p.line, 0.8) +
    E.p('M' + PS(f) + 'l13 1m-13 -1l11 7m-11 -7l5 11m-5 -11l-9 5', null, p.line, 1.1);
  s += leg([152, 154], [182, 162], [200, 190], [214, 208]);
  s += leg([156, 150], [176, 170], [168, 202], [184, 220]);
  s += E.el(152, 150, 13, 6, 55, p.relief, p.line, 0.8) + E.p(taperD([[150, 154], [140, 176]], 3.6, 2.4), p.relief, p.line, 0.7);
  /* thorax : vertèbres dorsales, côtes, fourchette */
  const dors = linePts([128, 110], [150, 148], 9);
  let ribs = '';
  dors.forEach((q, i) => { if (i > 0 && i < 8) ribs += 'M' + PS(q) + 'Q' + r1(q[0] + 20) + ' ' + r1(q[1] + 3) + ' ' + r1(q[0] + 14) + ' ' + r1(q[1] + 20); });
  s += E.p(ribs, null, p.line, 1.1) + E.p(ribs, null, p.relief, 0.5);
  dors.forEach(q => { s += E.el(q[0], q[1], 2.6, 1.9, 60, p.relief, p.line, 0.5); });
  s += E.p('M126 112Q132 124 138 114', null, p.line, 1.4);
  /* cou rejeté en arrière + crâne */
  const neck = resample(cubicPts([128, 108], [112, 100], [98, 86], [106, 70], 20), 9);
  neck.forEach((q, i) => { const t = tangentAt(neck, i); s += E.el(q[0], q[1], 3.6, 2, Math.atan2(t[1], t[0]) / D2R, p.relief, p.line, 0.5); });
  s += E.p('M103 72Q106 55 122 52Q137 49 150 53L140 60Q128 64 116 74Z', p.relief, p.line, 0.9);
  s += E.c(120, 59, 4.6, p.shade, p.line, 0.7);
  let th = ''; for (let x = 128; x < 146; x += 3) th += 'M' + r1(x) + ' ' + r1(56.5 - (x - 128) * 0.12) + 'l0.4 1.6';
  s += E.p(th, null, p.line, 0.6);
  s += E.p('M134 56L148 54', null, p.line, 0.6);
  s += E.p('M95 84Q97 68 108 58', null, p.hi, 1.4, 'opacity=".7"');
  return s;
}

/* ---------------- registre des œuvres ---------------- */
const ART = {
  trilobite: { vb: [200, 250], fn: artTrilobite, area: { cx: 100, cy: 128, rx: 66, ry: 100 } },
  marrella: { vb: [200, 220], fn: artMarrella, area: { cx: 100, cy: 118, rx: 66, ry: 92 } },
  hallucigenia: { vb: [280, 150], fn: artHallucigenia, area: { cx: 142, cy: 82, rx: 124, ry: 50 } },
  opabinia: { vb: [200, 290], fn: artOpabinia, area: { cx: 100, cy: 150, rx: 62, ry: 124 } },
  anomalocaris: { vb: [240, 300], fn: artAnomalocaris, area: { cx: 120, cy: 150, rx: 90, ry: 130 } },
  ammonite: { vb: [220, 220], fn: artAmmonite, area: { cx: 110, cy: 110, rx: 92, ry: 92 } },
  leptolepides: { vb: [260, 120], fn: artLeptolepides, area: { cx: 132, cy: 62, rx: 112, ry: 34 } },
  pentacrinites: { vb: [200, 290], fn: artPentacrinites, area: { cx: 100, cy: 150, rx: 76, ry: 126 } },
  ichthyosaure: { vb: [320, 150], fn: artIchthyosaure, area: { cx: 158, cy: 72, rx: 142, ry: 50 } },
  archaeopteryx: { vb: [260, 240], fn: artArchaeopteryx, area: { cx: 130, cy: 124, rx: 110, ry: 100 } }
};
