/* ============ fossiles : Carbonifère (lot c2) — Neuropteris, Lepidodendron, Annularia, Arthropleura ============ */

/* ---- aides c2 ---- */
function c2_qPt(a, b, c, t) { const u = 1 - t; return [u * u * a[0] + 2 * u * t * b[0] + t * t * c[0], u * u * a[1] + 2 * u * t * b[1] + t * t * c[1]]; }
/* repère le long d'une quadratique a-b-c : (u en fraction de la courbe, v en px sur la normale) → point ; extrapolé hors de [0,1] */
function c2_qMap(a, b, c, L) {
  return (u, v) => {
    const t = clamp(u, 0, 1), P = c2_qPt(a, b, c, t);
    let tx = (1 - t) * (b[0] - a[0]) + t * (c[0] - b[0]), ty = (1 - t) * (b[1] - a[1]) + t * (c[1] - b[1]);
    const l = Math.hypot(tx, ty) || 1, e = (u - t) * L;
    tx /= l; ty /= l;
    return [P[0] + tx * e - ty * v, P[1] + ty * e + tx * v];
  };
}
function c2_rel(a, b) { return r1(b[0] - a[0]) + ' ' + r1(b[1] - a[1]); }
function c2_rot(v, a) { const c = Math.cos(a), s = Math.sin(a); return [v[0] * c - v[1] * s, v[0] * s + v[1] * c]; }
function c2_add(a, v, k) { return [a[0] + v[0] * k, a[1] + v[1] * k]; }
/* découpe d'un polygone par le demi-plan a·x + b·y ≤ c (Sutherland–Hodgman) */
function c2_clip(poly, a, b, c) {
  const o = [];
  for (let i = 0; i < poly.length; i++) {
    const P = poly[i], Q = poly[(i + 1) % poly.length], vp = a * P[0] + b * P[1] - c, vq = a * Q[0] + b * Q[1] - c;
    if (vp <= 0) o.push(P);
    if (vp * vq < 0) { const t = vp / (vp - vq); o.push([P[0] + (Q[0] - P[0]) * t, P[1] + (Q[1] - P[1]) * t]); }
  }
  return o;
}
/* tracé relatif compact : M absolu puis l/m relatifs calculés depuis le point arrondi précédent (pas de dérive) */
function c2_pen(start) {
  const r = q => [r1(q[0]), r1(q[1])];
  let cur = r(start), d = 'M' + PS(cur);
  const step = (cmd, q) => { const n = r(q); d += cmd + r1(n[0] - cur[0]) + ' ' + r1(n[1] - cur[1]); cur = n; };
  return { l: q => step('l', q), m: q => step('m', q), h: dx => { d += 'h' + r1(dx); cur = [r1(cur[0] + dx), cur[1]]; }, z: q => { d += 'z'; cur = r(q); }, d: () => d };
}

/* pinnule de Neuropteris : gabarit tpl = [encoche, 3 × (c1, c2, fin)] en (u fraction de L, v fraction de W), moitié +v ;
   renvoie { o: contour, v: nervures fines (+ fin de la médiane), m: base épaisse de la médiane } */
function c2_pinnule(a, b, c, L, W, tpl, K) {
  const map = c2_qMap(a, b, c, L), P = q => map(q[0], q[1] * W), N = q => map(q[0], -q[1] * W), T = tpl;
  let o = 'M' + PS(P(T[0]));
  for (let k = 1; k < 10; k += 3) o += 'C' + PS(P(T[k])) + ' ' + PS(P(T[k + 1])) + ' ' + PS(P(T[k + 2]));
  for (let k = 8; k > 0; k -= 3) o += 'C' + PS(N(T[k])) + ' ' + PS(N(T[k - 1])) + ' ' + PS(N(T[k - 2]));
  o += 'Z';
  /* nervures : points de marge régulièrement espacés, départ sur la médiane de plus en plus haut, arc qui s'ouvre vers le bord */
  const sc = q => [q[0] * L, q[1] * W];
  const side = cubicPts(sc(T[3]), sc(T[4]), sc(T[5]), sc(T[6]), 14).concat(cubicPts(sc(T[6]), sc(T[7]), sc(T[8]), sc(T[9]), 10).slice(1));
  const M = resample(side, K + 1);
  let v = '';
  for (let k = 0; k < K; k++) {
    const m = M[k], f = k / (K - 1), us = L * lerp(0.05, 0.64, Math.pow(f, 0.85));
    for (const sg of [1, -1]) {
      const S = map(us / L, sg * 0.5), C = map((us + (m[0] - us) * 0.62) / L, sg * m[1] * 0.14), E2 = map(m[0] / L, sg * m[1] * 0.93);
      v += 'M' + PS(S) + 'q' + c2_rel(S, C) + ' ' + c2_rel(S, E2);
    }
  }
  const m0 = map(0, 0), mid = (t, w) => 'M' + PS(m0) + 'Q' + PS(lerpPt(a, b, t)) + ' ' + PS(c2_qPt(a, b, c, t));
  return { o: o, v: v + mid(0.68), m: mid(0.42) };
}

/* ---------------- neuropteris — Neuropteris heterophylla (Brongniart), fougère à graines ----------------
   Fiche anatomique :
   ① rachis de la penne, épais à la base, légèrement courbe, effilé vers le haut ;
   ② 14 pinnules latérales ALTERNES « en langue » : bords presque parallèles, bout arrondi,
      base étroite en cœur (deux oreillettes autour d'un point d'attache unique) ;
      longues et presque perpendiculaires à la base, de plus en plus courtes et obliques vers le haut ;
   ③ grande pinnule terminale ovale dans l'axe du rachis (le caractère « heterophylla ») ;
   ④ nervation néoptéridienne : médiane qui s'efface aux 2/3, nombreuses nervures fines qui partent
      presque parallèles à la médiane puis s'arquent pour toucher le bord presque à angle droit ;
   ⑤ film de carbone sombre, marges plus foncées.
   Construction : chaque pinnule = gabarit (u, v) en Bézier cubiques plaqué sur son axe courbe (quadratique),
   positions le long du rachis cumulées d'après la largeur des pinnules ; nervures générées le long de la marge. */
function artNeuropteris(p) {
  const rnd = mulberry32(hashStr('neuropteris'));
  const R0 = [104, 268], R1 = [121, 170], R2 = [110, 78];
  const TONGUE = [[0.03, 0], [-0.06, 0.12], [-0.1, 0.9], [0.1, 1], [0.34, 1.08], [0.62, 1.03], [0.8, 0.84], [0.93, 0.68], [1, 0.4], [1, 0]];
  const OVAL = [[0.03, 0], [-0.03, 0.22], [-0.01, 0.8], [0.12, 0.94], [0.3, 1.1], [0.62, 1.08], [0.8, 0.8], [0.92, 0.6], [1, 0.34], [1, 0]];
  const n = 12, pin = [];
  for (let i = 0; i < n; i++) {
    const f = i / (n - 1), L = lerp(90, 44, Math.pow(f, 0.9)) * (1 + (rnd() - 0.5) * 0.06);
    const W = L * lerp(0.18, 0.22, f), th = lerp(78, 54, f) + (rnd() - 0.5) * 4;
    pin.push({ L: L, W: W, th: th * D2R, side: i % 2 ? 1 : -1, st: (W * 1.08 + 1.8) / Math.sin(th * D2R) });
  }
  const pos = [0];
  for (let i = 1; i < n; i++) pos.push(pos[i - 1] + (pin[i - 1].st + pin[i].st) / 2);
  const tanR = t => { const x = (1 - t) * (R1[0] - R0[0]) + t * (R2[0] - R1[0]), y = (1 - t) * (R1[1] - R0[1]) + t * (R2[1] - R1[1]), l = Math.hypot(x, y); return [x / l, y / l]; };
  let lat = '';
  const draw = (q, fill) => E.p(q.o, fill, p.line, 1) + E.p(q.v, null, p.line, 0.45, 'opacity=".8"') + E.p(q.m, null, p.line, 1.2);
  const order = [];
  for (let i = n - 1; i >= 0; i--) order.push(i);
  order.forEach(i => {
    const q = pin[i], t = lerp(0.05, 0.91, pos[i] / pos[n - 1]), R = c2_qPt(R0, R1, R2, t), T = tanR(t);
    const d1 = c2_rot(T, q.side * q.th), d2 = c2_rot(T, q.side * (q.th - 0.1));
    const P0 = c2_add(R, d1, 1.5), P1 = c2_add(P0, d1, q.L * 0.5), P2 = c2_add(P0, d2, q.L);
    lat += draw(c2_pinnule(P0, P1, P2, q.L, q.W, TONGUE, Math.round(q.L / 6.5)), p.relief);
  });
  let s = lat;
  const rp = quadPts(R0, R1, R2, 16);
  s += E.p(taperD(rp, 6.5, 2.6), p.body, p.line, 1);
  s += E.p('M' + PS(R0) + 'Q' + PS(R1) + ' ' + PS(R2), null, p.relief, 0.9, 'opacity=".8"');
  /* pinnule terminale */
  const Tt = tanR(1), Lt = 66, t0 = c2_add(R2, Tt, -1), t1 = c2_add(t0, Tt, Lt * 0.5), t2 = c2_add(t0, c2_rot(Tt, -0.05), Lt);
  s += draw(c2_pinnule(t0, t1, t2, Lt, 17.5, OVAL, 11), p.relief);
  /* reflet unique : bord gauche de la pinnule terminale */
  const mapT = c2_qMap(t0, t1, t2, Lt);
  s += E.p('M' + PS(mapT(0.3, -13.5)) + 'Q' + PS(mapT(0.55, -15.8)) + ' ' + PS(mapT(0.78, -12)), null, p.hi, 1.4, 'opacity=".65"');
  return s;
}

/* ---------------- lepidodendron — Lepidodendron aculeatum Sternberg, écorce d'« arbre à écailles » ----------------
   Fiche anatomique :
   ① fragment d'écorce = portion de cylindre (tronc légèrement fuselé), cassé en haut et en bas (lignes brisées),
      bords latéraux = profil du tronc, festonnés par les coussinets vus de côté ;
   ② coussinets foliaires en LOSANGES allongés verticalement (~28 × 14), pointes haute et basse étirées et
      légèrement déjetées en sens opposés (S), disposés en réseau de rangées obliques (hélice : réseau losangique cisaillé) ;
   ③ dans chaque coussinet : cicatrice foliaire au tiers supérieur (petit losange transversal à 3 points :
      faisceau + 2 parichnos), carène verticale en dessous, rides transversales vers la pointe basse ;
   ④ sillons sombres entre les coussinets (le fond du fragment, laissé visible entre les losanges) ;
   ⑤ ombrage cylindrique : teinte de chaque coussinet selon cos(φ − φlumière), bords plus sombres,
      coussinets comprimés (× cos φ) vers les bords.
   Construction : réseau (s, y) en abscisse curviligne, projeté x = cx + R·sin(s/R) ; découpe des coussinets
   par les bords cassés (demi-plans) ; détails seulement sur la face (|φ| < 38°). */
function artLepidodendron(p) {
  const rnd = mulberry32(hashStr('lepidodendron'));
  const cx = 110, Rr = y => lerp(90, 96, y / 280), a = 9, b = 18, g = 0.79, sh = Math.tan(7 * D2R), phL = -0.55;
  /* ① bords cassés (points de gauche à droite) */
  const brk = (y0, y1, amp) => {
    const o = [], xl = cx - Rr(y0), xr = cx + Rr(y1);
    for (let i = 0; i <= 16; i++) { const t = i / 16; o.push([lerp(xl, xr, t), lerp(y0, y1, t) + (rnd() - 0.5) * 2 * amp + (i % 4 === 2 ? amp * 1.2 : 0)]); }
    return o;
  };
  const top = brk(19, 10, 3.2), bot = brk(263, 271, 3.2);
  const yAt = (pts, x) => interpY(pts, clamp(x, pts[0][0], pts[pts.length - 1][0]));
  const scal = (y, ph0) => 1.8 * Math.abs(Math.sin(Math.PI * (y - ph0) / b));
  let out = top.slice();
  for (let y = top[16][1] + 4; y < bot[16][1] - 2; y += 4.5) out.push([cx + Rr(y) + scal(y, 4), y]);
  out = out.concat(bot.slice().reverse());
  for (let y = bot[0][1] - 4; y > top[0][1] + 2; y -= 4.5) out.push([cx - Rr(y) - scal(y, 13), y]);
  let s = E.p(polyD(out, true), p.line, p.line, 1.2);
  /* ②–⑤ coussinets */
  const tones = [p.relief, p.body, p.body2, p.shade], C = ['', '', '', ''];
  let det = '', dots = '';
  for (let j = -3; j < 19; j++) for (let i = -10; i <= 10; i++) {
    const sc = (i + (j & 1) / 2) * 2 * a, y = 6 + j * b + sc * sh, R = Rr(y), ph = sc / R;
    if (Math.abs(ph) > 1.36) continue;
    const k = Math.cos(ph), x = cx + R * Math.sin(ph), w = a * g * k, h = b * g, bend = 1.4 * k;
    let poly = [[x + bend, y - h], [x + w, y - 0.1 * h], [x - bend, y + h], [x - w, y - 0.1 * h]];
    const xa = x - w, xb = x + w, t1 = yAt(top, xa) + 1.6, t2 = yAt(top, xb) + 1.6, b1 = yAt(bot, xa) - 1.6, b2 = yAt(bot, xb) - 1.6;
    const m1 = (t2 - t1) / (xb - xa), m2 = (b2 - b1) / (xb - xa);
    let cut = false;
    if (y - h < Math.max(t1, t2)) { poly = c2_clip(poly, m1, -1, m1 * xa - t1); cut = true; }
    if (poly.length > 2 && y + h > Math.min(b1, b2)) { poly = c2_clip(poly, -m2, 1, b1 - m2 * xa); cut = true; }
    if (poly.length < 3) continue;
    const I = Math.cos(ph - phL), ti = I > 0.86 ? 0 : I > 0.6 ? 1 : I > 0.33 ? 2 : 3;
    const pen = c2_pen(poly[0]);
    for (let n = 1; n < poly.length; n++) pen.l(poly[n]);
    C[ti] += pen.d();
    if (cut || k < 0.79) continue;
    /* cicatrice (losange transversal) + carène + rides : un seul tracé */
    const ys = y - 0.36 * h, xs = x + bend * 0.36, sw = 3.7 * k, shh = 2.3;
    const q = c2_pen([xs - sw, ys]);
    q.l([xs, ys - shh]); q.l([xs + sw, ys]); q.l([xs, ys + shh]); q.z([xs - sw, ys]);
    q.m([xs - bend * 0.1, ys + shh + 1.4]); q.l([x - bend * 0.62, y + 0.74 * h]);
    const yw1 = y + 0.4 * h, yw2 = y + 0.57 * h, xw1 = x - bend * 0.4, xw2 = x - bend * 0.57;
    q.m([xw1 - 2.5 * k, yw1]); q.h(5 * k); q.m([xw2 - 1.8 * k, yw2]); q.h(3.6 * k);
    det += q.d();
    const dp = c2_pen([xs - 1.9 * k, ys]);
    dp.h(0); dp.m([xs, ys]); dp.h(0); dp.m([xs + 1.9 * k, ys]); dp.h(0);
    dots += dp.d();
  }
  C.forEach((d, n) => { if (d) s += E.p(d, tones[n]); });
  s += E.p(det, p.shade, p.line, 0.6) + E.p(dots, null, p.relief, 1.15);
  /* reflet unique : arête de cassure en haut à gauche */
  s += E.p(polyD(top.slice(0, 8).map(q => [q[0] + 1, q[1] + 2.2])), null, p.hi, 1.2, 'opacity=".6"');
  return s;
}

Object.assign(ART, {
  neuropteris: { vb: [220, 280], fn: artNeuropteris, area: { cx: 107, cy: 160, rx: 80, ry: 114 } },
  lepidodendron: { vb: [220, 280], fn: artLepidodendron, area: { cx: 110, cy: 140, rx: 90, ry: 124 } }
});
