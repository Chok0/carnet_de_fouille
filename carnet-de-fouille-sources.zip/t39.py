# v36 — tutoriel à l'établi : intro → trois pierres guidées → premier gisement
import asyncio, json
from playwright.async_api import async_playwright
H = """(() => { const d = window.__dbg(), D = d.Bench3D.debug();
  const pts = i => D.ST.planes[i].contour.pts, n = i => pts(i).length, hot = i => pts(i)[D.hotIndex(D.ST.planes[i])];
  const far = i => pts(i)[(D.hotIndex(D.ST.planes[i]) + Math.floor(n(i) / 2)) % n(i)];
  const mid = i => pts(i)[(D.hotIndex(D.ST.planes[i]) + Math.floor(n(i) / 8)) % n(i)];
  const t = () => d.tuto(), coach = () => document.querySelector('.tuto-coach .ky-text').textContent.slice(0, 60), note = () => document.querySelector('.tuto-coach .tc-note').textContent;
  return { d, D, pts, hot, far, mid, t, coach, note }; })()"""
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl'])
        pg = await b.new_page(viewport={'width':390,'height':844})
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)+' '+str(e.stack)[:300]))
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/src/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        ev = lambda js: pg.evaluate(js)
        # l'intro jusqu'au bout : le dernier bouton mène à l'établi
        for i in range(14):
            if await pg.locator('#inNext').count() == 0: break
            lbl = await pg.locator('#inNext').text_content()
            await pg.locator('#inNext').click(); await pg.wait_for_timeout(150)
        print('dernier bouton :', lbl)
        await pg.wait_for_timeout(800)
        print('1 tuto?', await ev(f"() => {{ const h = {H}; return [!!h.t(), h.t() && h.t().step, h.coach()]; }}"))
        await pg.screenshot(path='shots/tuto/1-geode.png')
        # géode : frapper avant d'écouter → refusé
        print('  frappe avant écoute', await ev(f"() => {{ const h = {H}; h.D.strike(h.hot(0), 0.5); return [h.t().step, h.note(), h.D.rock.done]; }}"))
        print('  tap', await ev(f"() => {{ const h = {H}; h.D.tap(h.hot(0)); return [h.t().step, h.coach()]; }}"))
        print('  trop fort', await ev(f"() => {{ const h = {H}; h.D.strike(h.hot(0), 0.95); return [h.note(), h.D.rock.done, h.D.rock.fatigue]; }}"))
        print('  dosé', await ev(f"() => {{ const h = {H}; h.D.strike(h.hot(0), 0.5); return [h.D.rock.done]; }}"))
        await pg.wait_for_timeout(1800)
        print('  ouvert', await ev("() => [document.getElementById('rTitle').textContent, document.getElementById('btnBack').hidden, document.getElementById('btnBack').textContent]"))
        await pg.screenshot(path='shots/tuto/2-geode-open.png')
        await pg.locator('#btnBack').click(); await pg.wait_for_timeout(700)
        # veine
        print('2', await ev(f"() => {{ const h = {H}; return [h.t().i, h.t().step, h.coach()]; }}"))
        await pg.screenshot(path='shots/tuto/3-veine.png')
        print('  pic', await ev(f"() => {{ const h = {H}; h.D.tap(h.mid(0)); return [h.t().step, h.coach()]; }}"))
        print('  pic sur la veine', await ev(f"() => {{ const h = {H}; h.D.tap(h.far(1)); return [h.t().step, h.note()]; }}"))
        await pg.wait_for_timeout(300); await pg.screenshot(path='shots/tuto/4a-veine-chemin.png')
        print('  ting', await ev(f"() => {{ const h = {H}; h.D.tap(h.hot(1)); return [h.t().step, h.coach()]; }}"))
        await pg.wait_for_timeout(300); await pg.screenshot(path='shots/tuto/4-veine-marques.png')
        print('  mauvais fil', await ev(f"() => {{ const h = {H}; h.D.strike(h.mid(0), 1); return [h.note(), h.D.rock.done]; }}"))
        print('  loin', await ev(f"() => {{ const h = {H}; h.D.strike(h.far(1), 1); return [h.note(), h.D.rock.done]; }}"))
        print('  cœur', await ev(f"() => {{ const h = {H}; h.D.strike(h.hot(1), 1); return [h.D.rock.done]; }}"))
        await pg.wait_for_timeout(1800)
        print('  ouvert', await ev("() => document.getElementById('rTitle').textContent"))
        await pg.screenshot(path='shots/tuto/5-veine-open.png')
        await pg.locator('#btnBack').click(); await pg.wait_for_timeout(700)
        # os
        print('3', await ev(f"() => {{ const h = {H}; return [h.t().i, h.t().step, h.coach()]; }}"))
        await pg.screenshot(path='shots/tuto/6-os.png')
        print('  pic', await ev(f"() => {{ const h = {H}; h.D.tap(h.mid(0)); return [h.t().step, h.coach()]; }}"))
        print('  pok loin', await ev(f"() => {{ const h = {H}; const pts = h.pts(1), D = h.D, pl = D.ST.planes[1], dm = pl.C.dmin; const P = pts.map(x => [x, D.distToContent(pl, x)]).filter(a => a[1] < dm + 0.35 && a[1] > dm + 0.2)[0]; if (P) D.tap(P[0]); return [!!P, h.t().step, h.coach()]; }}"))
        await pg.wait_for_timeout(300); await pg.screenshot(path='shots/tuto/7-os-marques.png')
        print('  POK', await ev(f"() => {{ const h = {H}; h.D.tap(h.hot(1)); return [h.t().step, h.coach()]; }}"))
        print('  frappe cœur', await ev(f"() => {{ const h = {H}; h.D.strike(h.hot(1), 1); return [h.D.rock.done, h.D.rock.fatigue]; }}"))
        await pg.wait_for_timeout(2800)
        print('  ouvert', await ev("() => [document.getElementById('rTitle').textContent, document.getElementById('btnBack').textContent]"))
        await pg.screenshot(path='shots/tuto/8-os-open.png')
        await pg.locator('#btnBack').click(); await pg.wait_for_timeout(900)
        print('fin', await ev("() => { const d = window.__dbg(); return [d.tuto(), document.querySelector('#scr-carte').hidden, d.G.notes.tutoEtabli, (document.querySelector('.kayou-say .ky-text') || {}).textContent]; }"))
        await pg.screenshot(path='shots/tuto/9-carte.png')
        # reprise depuis les réglages, puis « Passer »
        await ev("() => window.__dbg().closeSay()")
        await pg.locator('#btnMenu').click(); await pg.wait_for_timeout(300); await pg.locator('#btnTuto').click(); await pg.wait_for_timeout(800)
        print('réglages → tuto', await ev("() => !!window.__dbg().tuto()"))
        await pg.locator('.tc-skip').click(); await pg.wait_for_timeout(150); await pg.locator('.tc-skip').click(); await pg.wait_for_timeout(500)
        print('passer', await ev("() => [!!window.__dbg().tuto(), document.querySelector('#scr-carte').hidden, !!document.querySelector('.tuto-coach')]"))
        # rechargement : pas de tutoriel une fois vu
        await pg.reload(); await pg.wait_for_timeout(1500)
        print('reload', await ev("() => [!!window.__dbg().tuto(), !!document.querySelector('.intro')]"))
        print('errors', errs)
        await b.close()
asyncio.run(main())
