import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':390,'height':844}, device_scale_factor=2)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)+str(e.stack)[:300]))
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/carnet/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(400)
        await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); }"); await pg.wait_for_timeout(200)
        await pg.evaluate("() => { const d = window.__dbg(); d.closeSay(); d.G.notes.pierre = 1; }")
        await pg.screenshot(path='shots/v14/c-map.png')
        await pg.evaluate("""() => { const d = window.__dbg(), S = d.G.site, p = S.poches[0], F = d.FOSSILS[p.fid];
          const st = d.fos(p.fid); st.nk = 1; st.ind = [{ k: 1, site: S.seed, num: S.num, zone: p.z, found: Array.from({length: F.blocks - 1}, (_, i) => i), lost: false, hits: {} }]; p.k = 1;
          d.dig({ x: p.x, y: p.y }); }""")
        await pg.wait_for_timeout(1500)
        print(await pg.evaluate("() => window.__dbg().G.stone && window.__dbg().G.stone.contents"))
        await pg.evaluate("""() => { const _st = window.setTimeout; window.setTimeout = (f, d, ...a) => (d > 900 ? 0 : _st(f, d, ...a)); const D = window.__dbg().Bench3D.debug(), V={unique:4,os:3,eclat:2,veine:1,rien:0}; const pl = D.ST.planes.slice().sort((a,b)=>V[b.C.type]-V[a.C.type])[0]; let best=null,bd=-1; pl.contour.pts.forEach(p=>{const d=D.distToContent(pl,p); if(d>bd && d<1e8){bd=d;best=p;} }); D.strike(best || pl.contour.pts[0], 1); const T = D.rock.top; Object.defineProperty(T, 't0', { configurable: true, get: () => performance.now() + T.pre * 0.3 }); }""")
        await pg.evaluate("() => new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))")
        await pg.screenshot(path='shots/v14/c-pre.png')
        for ms in [300, 900, 1800, 3500]:
            await pg.wait_for_timeout(ms - globals()["prev"]); globals()["prev"] = ms
            await pg.screenshot(path=f'shots/v14/c-{ms}.png')
        print(await pg.evaluate("() => [document.getElementById('rTitle').textContent, document.getElementById('rSub').textContent, window.__dbg().G.money]"), errs)
        await b.close()
prev=0
asyncio.run(main())
