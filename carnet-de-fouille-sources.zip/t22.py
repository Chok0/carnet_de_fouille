import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':390,'height':844}, device_scale_factor=2)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)+' '+str(e.stack)[:300]))
        await pg.route('**/fonts.*/**', lambda r: r.abort())
        await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
        await pg.goto('file:///home/claude/carnet/dist/preview-debug.html'); await pg.wait_for_timeout(1500)
        await pg.locator('#inSkip').click(force=True); await pg.wait_for_timeout(300)
        await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); }"); await pg.wait_for_timeout(200)
        ev = lambda js: pg.evaluate(js)
        await ev("() => { const d = window.__dbg(); d.closeSay(); d.G.money = 0; d.startVoyage(); }"); await pg.wait_for_timeout(600)
        await ev("() => document.getElementById('depart').scrollIntoView()"); await pg.screenshot(path='shots/v14/at-escale.png')
        await ev("() => document.getElementById('btnChoose').click()"); await pg.wait_for_timeout(200)
        print('still voyage', await ev("() => !!window.__dbg().G.voyage"))
        await ev("() => document.getElementById('btnAtelier').click()"); await pg.wait_for_timeout(800)
        r = await pg.locator('#atDirt').bounding_box()
        await pg.mouse.move(r['x']+20, r['y']+20); await pg.mouse.down()
        for rep in range(3):
          for i in range(14):
              y = r['y'] + 20 + i * (r['height']-40)/13
              await pg.mouse.move(r["x"]+r["width"]-20, y, steps=12); await pg.mouse.move(r['x']+20, y+10, steps=12)
        await pg.mouse.up(); await pg.wait_for_timeout(200)
        print('brosse', await ev("() => document.getElementById('atProg').textContent"))
        await ev("() => document.querySelector('.at-tools button[data-t=grattoir]').click()")
        await pg.mouse.move(r['x']+20, r['y']+20); await pg.mouse.down()
        for i in range(14):
            y = r['y'] + 20 + i * (r['height']-40)/13
            await pg.mouse.move(r["x"]+r["width"]-20, y, steps=12)
            if i == 6: await pg.screenshot(path='shots/v14/at-scrape.png')
            await pg.mouse.move(r['x']+20, y+10, steps=12)
        await pg.mouse.up(); await pg.wait_for_timeout(400)
        await pg.screenshot(path='shots/v14/at-game.png')
        print('prog', await ev("() => [document.getElementById('atProg').textContent, document.getElementById('atScr').textContent]"))
        await ev("() => { const b = document.getElementById('atDone'); b && b.click(); }"); await pg.wait_for_timeout(400)
        await pg.screenshot(path='shots/v14/at-done.png')
        await ev("() => { const b = document.getElementById('atDone'); b && b.click(); }"); await pg.wait_for_timeout(400)
        print('money', await ev("() => [window.__dbg().G.money, window.__dbg().G.voyage.offers[0].price, window.__dbg().G.voyage.atelier]"))
        await ev("() => document.getElementById('btnChoose').click()"); await pg.wait_for_timeout(400)
        await ev("() => document.getElementById('btnDepart').click()"); await pg.wait_for_timeout(1200)
        print('departed', await ev("() => [!window.__dbg().G.voyage, window.__dbg().G.money]"), errs)
        await b.close()
asyncio.run(main())
