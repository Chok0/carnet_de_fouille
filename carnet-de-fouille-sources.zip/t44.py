# v42 — accueil en établi (carnet qui s'ouvre puis zoom) ; musique d'ambiance + nature sur la carte
import asyncio
from playwright.async_api import async_playwright
URL = 'file:///home/claude/src/dist/preview-debug.html?title'
async def run(b, w, h, tag):
    pg = await b.new_page(viewport={'width':w,'height':h})
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    await pg.route('**/fonts.*/**', lambda r: r.abort())
    await pg.route('**/three.min.js', lambda r: r.fulfill(path='/home/claude/protos/three.min.js', content_type='application/javascript'))
    await pg.goto(URL); await pg.wait_for_timeout(1400)
    await pg.screenshot(path=f'shots/v42/{tag}-0.png')
    await pg.locator('.nb').click()
    for i, ms in enumerate([350, 450, 350, 350]):
        await pg.wait_for_timeout(ms); await pg.screenshot(path=f'shots/v42/{tag}-{i+1}.png')
    await pg.wait_for_timeout(700)
    print(tag, 'intro', await pg.locator('.intro').count(), '· accueil parti', await pg.locator('.title-screen').count() == 0, '· musique', await pg.evaluate("() => window.__dbg().Ambient.on"), errs)
    return pg
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--autoplay-policy=no-user-gesture-required'])
        pg = await run(b, 390, 844, 'neuf')
        # sur la carte : la nature s'entend ; à l'établi : non
        await pg.evaluate("() => { const d = window.__dbg(); d.tutoFinish && d.tuto() && d.tutoFinish(); }")
        await pg.locator('#inSkip').count() and await pg.locator('#inSkip').click()
        await pg.wait_for_timeout(500)
        await pg.evaluate("() => { const d = window.__dbg(); if (d.tuto()) d.tutoFinish(); d.closeSay(); d.show('carte'); }"); await pg.wait_for_timeout(1500)
        print('carte : nature', await pg.evaluate("() => window.__dbg().Ambient.wild()"), round(await pg.evaluate("() => window.__dbg().Ambient.envG.gain.value"), 2))
        await pg.evaluate("() => { const d = window.__dbg(); d.G.notes.pierre = 1; const q = d.G.site.poches[0]; d.dig({ x: q.x, y: q.y }); }"); await pg.wait_for_timeout(3500)
        print('établi : nature', await pg.evaluate("() => window.__dbg().Ambient.wild()"), round(await pg.evaluate("() => window.__dbg().Ambient.envG.gain.value"), 3), '· volume', round(await pg.evaluate("() => window.__dbg().Ambient.g.gain.value"), 3))
        await pg.close()
        pg = await run(b, 360, 560, 'court')
        await pg.close()
        await b.close()
asyncio.run(main())
